package com.library.service;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.library.dao.LibrarianDAO;
import com.library.model.Librarian;

@Service
public class LibrarianService {

	@Autowired private LibrarianDAO dao;
	
	@Transactional(propagation=Propagation.REQUIRED)
	public void createContact(Librarian contact)
	{
		Serializable id= dao.save(contact);		
	}
	
	//DO NOT USE TRANSACTIONS, throws exceptions when called from transaction
	@Transactional(propagation=Propagation.NEVER)
	public List<Librarian> getAllContacts(){
		return dao.getAll();
	}
	
}
