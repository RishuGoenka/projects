package com.library.model;

import java.io.Serializable;

public class Librarian implements Serializable {

	private static final long serialVersionUID = 5835377881714326175L;
	private String liabrarianId;
	private String librarianName;
	private String password;

	public Librarian() {
		super();
	}

	public Librarian(String liabrarianId, String librarianName, String password) {
		super();
		this.liabrarianId = liabrarianId;
		this.librarianName = librarianName;
		this.password = password;
	}

	public String getLiabrarianId() {
		return liabrarianId;
	}

	public void setLiabrarianId(String liabrarianId) {
		this.liabrarianId = liabrarianId;
	}

	public String getLibrarianName() {
		return librarianName;
	}

	public void setLibrarianName(String librarianName) {
		this.librarianName = librarianName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
