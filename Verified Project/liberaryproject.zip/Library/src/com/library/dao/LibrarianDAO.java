package com.library.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.library.model.Librarian;

@Repository
public class LibrarianDAO {

	@Autowired
	private HibernateTemplate template;

	public Serializable save(Librarian librarian) {
		return template.save(librarian);
	}

	public List<Librarian> getAll() {
		return template.find("from Librarian c");
	}

	public List<Librarian> getByName(String name) {
		return template.find(
				"from Librarian c where c.librarianName=?", name,
				name);
	}

	public Librarian findById(Integer id) {
		return template.get(Librarian.class, id);
	}
}