package com.library.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.library.model.Librarian;
import com.library.service.LibrarianService;

@Controller 
public class RegisterLibrarianController{

	@Autowired private LibrarianService service;

	@RequestMapping(value="/home.do", method=RequestMethod.GET)
	public String process(){
		Librarian librarian = new Librarian();
		librarian.setLiabrarianId("Id1");
		librarian.setLibrarianName("Ram");
		librarian.setPassword("pass");
		
		service.createContact(librarian);
		System.out.println("Saved");
		return "success";
	}
}