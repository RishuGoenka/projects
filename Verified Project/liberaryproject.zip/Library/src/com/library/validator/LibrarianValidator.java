package com.library.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.library.model.Librarian;

public class LibrarianValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {

		return arg0.isAssignableFrom(Librarian.class);

	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		Librarian librarian = (Librarian) arg0;

		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "librarianName",
				"empty.librarianName", "Please enter Name");
		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "password",
				"empty.password", "Please enter password");

		// Manually generated errors
		if (librarian.getPassword().trim().length() < 8) {
			arg1.rejectValue("password", "invalid.password",
					"At least 8 characters in password");
		}
	}
}
