import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class DerivedClass extends Example{

	public static void print(){
		System.out.println("Derived class");
	}
	
	public static void main(String[] args) {
		
		
		List<String> list = new LinkedList<>();
		list.add("a");
		list.add("b");
		list.add("c");
		list.add("d");
		
		for(String e :list)			
		{
			list.remove("c");
		}
		
		
		 	}
	
}
