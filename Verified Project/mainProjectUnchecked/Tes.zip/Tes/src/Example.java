
public class Example {

public static void print(){
	System.out.println("Base class");
}

}
