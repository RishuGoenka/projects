jQuery(function($) {

	var sharedId = $('#test_shared_id').text();

	$.getJSON("new/get/" + sharedId, function(response) {

		var j = 1;

		$('#problem_h2').html("All the best");

		var problemTable = "";
		for ( var i in response) {

			var id = j++;

			var qid = response[i].problemId;
			var qName = response[i].problemName;
			var attempt = response[i].difficulty;

			problemTable += "<tr><td> " + id + "</td>"
					+ "<td> <a href=\"writeProgram?problemId=" + qid + "\">"
					+ qName + "</a></td>"
					+"<td>"+attempt+"</td>"
					+ "</tr>";
		}

		$('#problem_list_table').html(problemTable);

		updateView();
	})

});

/**
 * Starts the test and shows the countdown timer
 */
function startTest() {
	$.get("test-starting", {

		test_shared_id : $("#test_shared_id").text()
	}, function(duration) {

		$('.countdown').data('duration', duration);
		buildCountDownTimer();
		$('#start_test_btn').remove();

		$('.rules').hide();
		$('#problem_list_table').parent().show();
	});
}

/**
 * Shows/hides appropriate elements based on test status
 */
function updateView() {

	if ($('#start_test_btn').length === 0) {

		$('.rules').hide();
		$('#problem_list_table').parent().show();
	} else {

		$('#problem_list_table').parent().hide();
		$('.rules').show();
	}
}