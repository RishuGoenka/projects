//array that will store the id's of questions 
	var idArray = [];

	//function for add button
	function AddQuestionButton(dataId) {
		//check if id already exit or not
		if ($.inArray(dataId, idArray) != -1) {
			alert("Already added in the set can't add it agiain!")
		} else {
			idArray.push(dataId);
			$.ajax({
				url : "addQuestionToSet",
				data : {
					id : dataId
				},
				success : function(data) {
					var newTable = makeTable(data);
					$('#testQuestionsBody').html(newTable);
				},
				error : function(result) {
					alert("failed to add questions, Retry!")
				}
			});
		}
	}

	//Remove question from set
	function removeQuestionButton(dataId) {

		idArray.splice($.inArray(dataId, idArray), 1);
		$.ajax({
			url : "removeQuestionfromSet",
			data : {
				id : dataId
			},
			success : function(data) {

				var newTable = makeTable(data);
				$('#testQuestionsBody').html(newTable);

			},
			error : function(result) {
				alert("failed to remove questions, Retry!")
			}
		});
	}

	//SetUp question from set
	function setUpQuestion() {
		$.ajax({
			url : "questionTable",
			success : function(data) {
				if (data != null) {
					var newTable = makeTable(data);
					$('#testQuestionsBody').html(newTable);

					for (i = 0; i < data.length; i++) {
						idArray.push(data[i].problemId);
					}
				}
			}

		});
	}

	//function to create table
	function makeTable(data) {
		var newTable = "";
		for (var i = 0; i < data.length; i++) {
			newTable += "<tr><td>"
					+ data[i].problemName
					+ "</td>"
					+ "<td>"
					+ data[i].problemCategory
					+ "</td>"
					+ "<td>"
					+ data[i].difficulty
					+ "</td>"
					+ "<td><button class='btn btn-danger btn-sm' onclick='removeQuestionButton(\""
					+ data[i].problemId
					+ "\")'><em class='glyphicon glyphicon-trash'></em></button></td></tr>";
		}
		return newTable;
	}
	//<a class='btn btn-danger' href='deleteProblemSet?problemSetId="+oData.problemSetId+"'><em class='fa fa-trash'></em></a></div>
	//function to create the table of all questions
	$(document)
			.ready(
					function() {
						$("#problems")
								.dataTable(
										{
											"bServerSide" : true,
											"sAjaxSource" : "/testing/admin/searchProblem",
											"bProcessing" : true,
											"sPaginationType" : "full_numbers",
											"bJQueryUI" : true,
											"aoColumns" : [
													{
														"mDataProp" : "problemName",
														"fnCreatedCell" : function(
																nTd, sData,
																oData, iRow,
																iCol) {
															$(nTd)
																	.html(
																			"<a href='view-problem?problemId="
																					+ oData.problemId
																					+ "'>"
																					+ oData.problemName
																					+ "</a>");
														}
													},
													{
														"mDataProp" : "problemCategory"
													},
													{
														"mDataProp" : "difficulty"
													},
													{
														"fnCreatedCell" : function(
																nTd, sData,
																oData, iRow,
																iCol) {
															$(nTd)
																	.html(
																			"<button class='btn btn-primary btn-sm' onclick='AddQuestionButton(\""
																					+ oData.problemId
																					+ "\")'>Add Question</button>");
														},
														"mDataProp" : null,
														"bSortable" : false
													} ]
										});

						$("questionSet").DataTable();

					});

	function checkForm() {
		var submitOK = true;
		if (idArray.length <= 0) {
			alert("Please add question in Set first");
			return false;
		} else
			return true;
	}