package com.zycus.compiler.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zycus.compiler.model.Result;
import com.zycus.compiler.model.UserSubmission;
import com.zycus.compiler.service.CheckCompileService;
import com.zycus.compiler.service.CompileExecuteService;
import com.zycus.compiler.service.ProcessTask;
import com.zycus.compiler.service.ResultService;
import com.zycus.compiler.service.UserSubmissionService;
import com.zycus.compiler.utility.PathUtil;
import com.zycus.compiler.utility.StatusEnum;
import com.zycus.integration.model.UserTest;
import com.zycus.integration.service.ProblemSetService;
import com.zycus.integration.service.SubmissionScoreService;
import com.zycus.integration.service.UserService;
import com.zycus.integration.service.UserTestService;
import com.zycus.problem.model.Problem;
import com.zycus.problem.model.TestCase;
import com.zycus.problem.service.ProblemService;
import com.zycus.problem.service.TestCaseService;

@Controller
public class CompileExecuteController {
	@Autowired
	CompileExecuteService compileExecuteService;

	@Autowired
	UserTestService userTestService;

	@Autowired
	ProblemService problemService;

	@Autowired
	UserSubmissionService userSubmissionService;

	@Autowired
	ResultService resultService;

	@Autowired
	UserService userService;

	@Autowired
	ProblemSetService problemSetService;

	@Autowired
	TestCaseService testCaseService;

	@Autowired
	SubmissionScoreService submissionScoreService;

	@Autowired
	CheckCompileService checkCompileService;

	PathUtil pathUtil = new PathUtil();

	static boolean submissionCreated;

	@RequestMapping(value = "/program", method = RequestMethod.POST)
	private String onSubmit(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) throws IOException,
			InterruptedException {

		
		String code = request.getParameter("code");
		int userId = userService.getCurrentLoggedInUserId();
		int problemSetId = (int) request.getSession().getAttribute(
				"problemSetId");
		int problemId = Integer.parseInt(request.getParameter("problemId"));
		UserTest userTest = userTestService.findUserTest(userId, problemSetId);
		int versionNumber = getVersion(problemId, userTest);
		long remTime = userTestService.getRemainingTime(userTestService
				.findUserTest(userService.getCurrentLoggedInUserId(),
						problemSetId));
		if (remTime <= 0L) {
			return "newTest?expired";
		}
		setPath(versionNumber, userId, problemId, userTest.getUserTestId());
		int submissionId = 0;
		submissionId = executeProgram(code, userId, problemSetId, problemId,
				userTest, versionNumber, submissionId);
		submissionScoreService.saveOrUpdateSubmissionScore(submissionId);
		// request.setAttribute("submissionId", submissionId);
		// request.setAttribute("problemId", problemId);
		return "forward:showTest?sharedId="
				+ problemSetService.findProblemSetById(problemSetId)
						.getSharedId();
	}

	/**
	 * Saves, Compiles and Executes if Compiled successfully else Saves
	 * submission only
	 * 
	 * @param code
	 * @param userId
	 * @param problemSetId
	 * @param problemId
	 * @param userTest
	 * @param versionNumber
	 * @param submissionId
	 * @return submissionId of saved submission
	 */
	private int executeProgram(String code, int userId, int problemSetId,
			int problemId, UserTest userTest, int versionNumber,
			int submissionId) {
		try {
			compileExecuteService.saveCode(code, PathUtil.getPath());
			StatusEnum compiled = compileExecuteService.compile();
			if (compiled.equals(StatusEnum.COMPILE_SUCCESS))
				submissionId = execute(userId, problemId, problemSetId,
						versionNumber, userTest);
			else
				submissionId = createAndSaveUserSubmissionObject(problemId,
						problemSetId, userId, versionNumber).getSubmissionId();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return submissionId;
	}

	/**
	 * set path where user program and class to be stored
	 * 
	 * @param versionNumber
	 *            is count of total attempts of a user for same problem
	 * @param userId
	 *            who submit code
	 * @param problemId
	 */
	private void setPath(int versionNumber, int userId, int problemId,
			int userTestId) {
		String path = pathUtil.setPath(versionNumber, userId, problemId,
				userTestId);
		pathUtil.createDirectory(path);
	}

	/**
	 * Get input and output of all Testcases and Run the program accordingly
	 * 
	 * @param userId
	 * @param problemId
	 * @param problemSetId
	 * @param versionNumber
	 * @param userTest
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private int execute(int userId, int problemId, int problemSetId,
			int versionNumber, UserTest userTest) throws IOException,
			InterruptedException {
		int submissionId = 0;
		List<String> inputList = getInputList(problemId);
		List<String> outputList = getOutputList(problemId);
		List<ProcessTask> tasks = new ArrayList<ProcessTask>();

		addAllTasksToList(inputList, outputList, tasks);
		submissionId = runTasks(userId, problemId, problemSetId, versionNumber,
				submissionId, tasks, userTest);

		return submissionId;
	}

	/**
	 * Runs all the tasks in the list 'tasks' in a executor service so that all
	 * computing is done simultaneously
	 * 
	 * @param userId
	 * @param problemId
	 * @param problemSetId
	 * @param versionNumber
	 * @param submissionId
	 * @param tasks
	 * @return submissionId of the user Submission saved
	 * @throws InterruptedException
	 */
	private int runTasks(int userId, int problemId, int problemSetId,
			int versionNumber, int submissionId, List<ProcessTask> tasks,
			UserTest userTest) throws InterruptedException {
		ExecutorService service = Executors.newFixedThreadPool(1);
		List<Future<Result>> results = service.invokeAll(tasks);
		service.shutdown();

		List<com.zycus.problem.model.TestCase> testcases = testCaseService
				.getTestCaseByProblem(problemId);
		int i = 0;
		for (Future<Result> result : results) {
			try {
				submissionId = saveResult(
						(Result) result.get(3, TimeUnit.SECONDS),
						testcases.get(i++), userId, problemId, problemSetId,
						versionNumber, userTest);
			} catch (ExecutionException e) {
				e.printStackTrace();
			} catch (TimeoutException e) {
				result.cancel(true);
			}
		}
		return submissionId;
	}

	private void addAllTasksToList(List<String> inputList,
			List<String> outputList, List<ProcessTask> tasks) {
		for (int index = 0; index < inputList.size(); index++) {
			ProcessTask task = new ProcessTask(inputList.get(index),
					outputList.get(index));
			tasks.add(task);
		}
	}

	/**
	 * get the version number of the current code submission
	 * 
	 * @param problemId
	 * @param userTest
	 * @return latest version number
	 */
	private int getVersion(int problemId, UserTest userTest) {
		return userSubmissionService.getLatestVersionForUserForProblem(
				problemId, userTest);
	}

	/**
	 * Retrieves output list from the database
	 * 
	 * @param problemId
	 * @return Array list of the expected outputs
	 */
	private List<String> getOutputList(int problemId) {
		return testCaseService.getOutputByProblem(problemId);
	}

	/**
	 * Retrieves input test cases list from the database
	 * 
	 * @param problemId
	 * @return ArrayList of the inputs to be tested on the submitted program
	 */
	private List<String> getInputList(int problemId) {
		return testCaseService.getInputByProblem(problemId);
	}

	/**
	 * Checks if the User is submitting for the first time and stores according
	 * to version
	 * 
	 * @param result
	 * @param testCase
	 * @param userId
	 * @param problemId
	 * @param problemSetId
	 * @param versionNumber
	 * @return Primary key of the submission
	 */
	@Transactional
	private int saveResult(Result result, TestCase testCase, int userId,
			int problemId, int problemSetId, int versionNumber,
			UserTest userTest) {
		UserSubmission userSubmission = userSubmissionService
				.findByUserTestProblemIdVersionNumber(problemId, userTest,
						versionNumber);
		if (userSubmission.getVersionNumber() == 0) {
			userSubmission = createAndSaveUserSubmissionObject(problemId,
					problemSetId, userId, versionNumber);
		}
		result.setUserSubmission(userSubmission);
		result.setTestCase(testCase);
		resultService.saveResult(result);
		return userSubmission.getSubmissionId();

	}

	/**
	 * Saves user submission to the database
	 * 
	 * @param problemId
	 * @param problemSetId
	 * @param userId
	 * @param versionNumber
	 * @return
	 */
	private UserSubmission createAndSaveUserSubmissionObject(int problemId,
			int problemSetId, int userId, int versionNumber) {
		UserSubmission userSubmission = new UserSubmission();
		// Check if DB call is required. Instead create new object and set ID
		Problem problem = problemService.getByID(problemId);
		UserTest userTest = userTestService.findUserTest(userId, problemSetId);

		userSubmission.setProblem(problem);
		userSubmission.setUserTest(userTest);
		userSubmission.setVersionNumber(versionNumber);
		userSubmissionService.saveUserSubmission(userSubmission);
		return userSubmission;
	}

	/**
	 * Checks if the Code submitted has any compilation errors
	 * @param model
	 * @param request
	 * @param response
	 * @return Compilation error if any else Compilation successfull
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@RequestMapping(value = "/checkIfCompile", method = RequestMethod.GET)
	private @ResponseBody String compile(ModelMap model,
			HttpServletRequest request, HttpServletResponse response)
			throws IOException, InterruptedException {

		String code = request.getParameter("code");
		System.out.println("Code is:" + code);
		int problemSetId = (int) request.getSession().getAttribute(
				"problemSetId");
		int userId = userService.getCurrentLoggedInUserId();
		int problemId = Integer.parseInt(request.getParameter("problemId"));
		UserTest userTest = userTestService.findUserTest(userId, problemSetId);
		int versionNumber = getVersion(problemId, userTest);
		setPath(versionNumber, userId, problemId, userTest.getUserTestId());
		String result = null;
		try {
			compileExecuteService.saveCode(code, PathUtil.getPath());
			result = checkCompileService.compile();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String text = result.replaceAll("\"", "\\\\\"");
		text = text.replaceAll("(\r\n|\n)", "<br>");
		return text;
	}
}
