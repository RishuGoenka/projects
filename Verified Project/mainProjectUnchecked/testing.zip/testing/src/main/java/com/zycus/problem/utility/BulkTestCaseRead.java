package com.zycus.problem.utility;

import java.io.Console;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.aspose.words.Bookmark;
import com.aspose.words.Cell;
import com.aspose.words.Document;
import com.aspose.words.NodeCollection;
import com.aspose.words.NodeType;
import com.aspose.words.Row;
import com.aspose.words.SaveFormat;
import com.aspose.words.Table;
import com.aspose.words.TableCollection;
import com.zycus.problem.dto.BulkProblemDTO;
import com.zycus.problem.dto.BulkTestCaseDTO;

public class BulkTestCaseRead {

	static {
		com.aspose.words.License license = new com.aspose.words.License();
		try {
			license.setLicense(Thread.currentThread().getContextClassLoader()
					.getResourceAsStream("Aspose.Total.Java.lic"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@SuppressWarnings("deprecation")
	public List<List<BulkTestCaseDTO>> read(String s) throws Exception {
		Document doc = new Document(s);
		NodeCollection tables = doc.getChildNodes(NodeType.TABLE, true);
		Iterator tablesIterator = tables.iterator();
		
		List<BulkTestCaseDTO> completeTestCases = new ArrayList<BulkTestCaseDTO>();
		List<BulkTestCaseDTO> incompleteTestCases = new ArrayList<BulkTestCaseDTO>();
		
		
		BulkTestCaseDTO bulkTestCaseDTO;
		while (tablesIterator.hasNext()) 
		{
			bulkTestCaseDTO = new BulkTestCaseDTO();
			Table table = (Table) tablesIterator.next();
			for (int j = 0; j < 4; j++)
			{
				Cell cell = table.getRows().get(0).getCells().get(j);
				if (cell.toTxt().length() != 0) 
				{
					switch (j)
					{
					case 0: 
					{
						bulkTestCaseDTO.setQuestionNo(cell.toTxt().trim());
						break;
					}
					case 1: 
					{
						bulkTestCaseDTO.setInput(cell.toTxt().trim());
						break;
					}
					case 2:
					{
						bulkTestCaseDTO.setOutput(cell.toTxt().trim());
						break;
					}
					default:
						bulkTestCaseDTO.setTestCaseDifficulty(cell.toTxt().trim());
					}
				}
			}
				if("".equalsIgnoreCase(bulkTestCaseDTO.getQuestionNo()) || bulkTestCaseDTO.getQuestionNo()==null ||
						"".equalsIgnoreCase(bulkTestCaseDTO.getOutput()) ||bulkTestCaseDTO.getOutput()==null ||
								"".equalsIgnoreCase(bulkTestCaseDTO.getTestCaseDifficulty()) || bulkTestCaseDTO.getTestCaseDifficulty()==null)
				{
					incompleteTestCases.add(bulkTestCaseDTO);
					tables.iterator().next();
				}
				else
				{
					if(Integer.parseInt(bulkTestCaseDTO.getTestCaseDifficulty())<1 || Integer.parseInt(bulkTestCaseDTO.getTestCaseDifficulty())>5)
					{
						if(Integer.parseInt(bulkTestCaseDTO.getTestCaseDifficulty())<1)
						bulkTestCaseDTO.setTestCaseDifficulty("1");
						else
						bulkTestCaseDTO.setTestCaseDifficulty("5");
					}
						completeTestCases.add(bulkTestCaseDTO);
					tables.iterator().next();
				}
				
		}
		List<List<BulkTestCaseDTO>> allTestCases=new ArrayList<List<BulkTestCaseDTO>>();
		allTestCases.add(completeTestCases);
		allTestCases.add(incompleteTestCases);
		return allTestCases;
	}
}
