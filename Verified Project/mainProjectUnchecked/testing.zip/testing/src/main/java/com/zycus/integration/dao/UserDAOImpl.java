package com.zycus.integration.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.integration.model.User;

@Repository
@Transactional
public class UserDAOImpl implements UserDAO {

	@PersistenceContext
	private EntityManager manager;

	/* (non-Javadoc)
	 * @see com.zycus.integration.dao.UserDAO#save(com.zycus.integration.model.User)
	 */
	@Override
	public void save(User userObject) {

		manager.persist(userObject);
	}

	/* (non-Javadoc)
	 * @see com.zycus.integration.dao.UserDAO#getUserByID(int)
	 */
	@Override
	public User getUserByID(int id) {

		return manager.find(User.class, id);
	}

	/* (non-Javadoc)
	 * @see com.zycus.integration.dao.UserDAO#getAllUsers()
	 */
	@Override
	public List<User> getAllUsers() {

		List<User> userList = manager.createQuery("Select u from User u")
				.getResultList();
		return userList;
	}

	/* (non-Javadoc)
	 * @see com.zycus.integration.dao.UserDAO#update(com.zycus.integration.model.User)
	 */
	@Override
	public void update(User userObject) {

		User persistentUser = manager.find(User.class, userObject.getUserId());
		persistentUser = userObject;

	}

	/* (non-Javadoc)
	 * @see com.zycus.integration.dao.UserDAO#getUserByEmail(java.lang.String)
	 */
	@Override
	public User getUserByEmail(String emailString) {

		List<User> userList = null;
		userList = manager
				.createQuery("Select u from User u where u.email =:emailId")
				.setParameter("emailId", emailString).getResultList();

		if (userList.size() >= 1) {
			return userList.get(0);
		} else {
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see com.zycus.integration.dao.UserDAO#isEmailAvailable(java.lang.String)
	 */
	@Override
	public boolean isEmailAvailable(String email) {

		long value = (Long) manager
				.createQuery(
						"Select COUNT(u) from User u where u.email =:emailId")
				.setParameter("emailId", email).getSingleResult();

		System.out.println(value);
		if (value == 1) {
			return true;
		} else {
			return false;
		}

	}
	
	@Override
	public long getNoOfUsers() {
		long noOfUsers=(long) manager.createQuery("Select COUNT(u) from User u where u.role='ROLE_USER'").getSingleResult();
		return noOfUsers;
	}

}
