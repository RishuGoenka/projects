package com.zycus.integration.dao;

import java.util.List;

import com.zycus.integration.model.ProblemSet;

public interface ProblemSetDAO {

	public ProblemSet save(ProblemSet problemSet);
	public List<ProblemSet> getAllProblemSet();
	public boolean update(ProblemSet problemSetObject);
	public ProblemSet findBySharedId(String sharedId);
	public ProblemSet findById(int problemSetId);
	
	//Data Table
	public List<ProblemSet> search(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]);
	public long searchCount(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]);
	public List<ProblemSet> getAllProblems( int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]);
	public long sizeOfProblems();
	boolean delete(int problemSetId);
}
