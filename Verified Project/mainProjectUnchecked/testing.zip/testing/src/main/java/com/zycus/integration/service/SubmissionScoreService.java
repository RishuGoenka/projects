package com.zycus.integration.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.compiler.model.Result;
import com.zycus.compiler.model.UserSubmission;
import com.zycus.compiler.service.client.ResultAndUserSubmissionService;
import com.zycus.integration.dao.SubmissionScoreDAO;
import com.zycus.integration.model.ProblemSet;
import com.zycus.integration.model.ReportDTO;
import com.zycus.integration.model.SubmissionScore;
import com.zycus.problem.model.TestCase;
import com.zycus.problem.service.TestCaseService;

@Service
public class SubmissionScoreService {

	@Autowired
	com.zycus.compiler.service.UserSubmissionService UserSubmissionService;

	@Autowired
	ResultAndUserSubmissionService resultAndUserSubmissionService;

	@Autowired
	SubmissionScoreDAO submissionScoreDAO;

	@Autowired
	TestCaseService testCaseService;

	@Autowired
	MappedProblemService mappedProblemService;

	@Autowired
	ProblemSetService problemSetService;

	public SubmissionScoreService() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Gets submission object from its id Calculates the score, then adds a new
	 * row if not yet added else updates the score
	 * 
	 * @param submissionId
	 */
	public void saveOrUpdateSubmissionScore(int submissionId) {

		if (submissionId != 0) {
			UserSubmission userSubmission = UserSubmissionService
					.getById(submissionId);

			UserSubmission previousUserSubmission = getPreviousUserSubmission(userSubmission);
			SubmissionScore existingSubmissionScore = null;

			if (previousUserSubmission != null) {
				existingSubmissionScore = submissionScoreDAO
						.findByUserSubmission(previousUserSubmission);

			}
			if (existingSubmissionScore == null) {
				submissionScoreDAO.save(buildSubmissionScore(userSubmission));
			} else {
				submissionScoreDAO.update(getUpdatedSubmissionScore(
						previousUserSubmission, userSubmission));
			}
		} else {
			// Write Code to handle compile time error
		}

	}

	/**
	 * Gets a list of ReportDTO from given problem set id
	 * 
	 * @param problemSetId
	 * @return
	 */
	public List<ReportDTO> getReportList(int problemSetId, int maxResults) {

		ProblemSet problemSet = problemSetService
				.findProblemSetById(problemSetId);

		List<Object[]> submissionScoreList = submissionScoreDAO
				.findByProblemSet(problemSet, maxResults);

		return buildReportDTOList(submissionScoreList);
	}

	/**
	 * Searches result by username or email id and returns a report list
	 * 
	 * @return
	 */
	public List<ReportDTO> searchReportListByUsernameOrEmail(int problemSetId,
			String search) {

		ProblemSet problemSet = problemSetService
				.findProblemSetById(problemSetId);

		List<Object[]> submissionScoreList = submissionScoreDAO
				.findByProblemSetAndSearchByNameOrEmail(problemSet, search);

		return buildReportDTOList(submissionScoreList);
	}

	/**
	 * Builds a list of ReportDTO from List of SubmissionScore
	 * 
	 * @param submissionScoreList
	 * @return
	 */
	private List<ReportDTO> buildReportDTOList(
			List<Object[]> submissionScoreList) {

		List<ReportDTO> reportDTOList = new ArrayList<>();

		for (Object[] submissionScore : submissionScoreList) {

			ReportDTO report = new ReportDTO();

			if (doesListHaveName(reportDTOList,
					String.valueOf(submissionScore[3]))) {

				report = getByEmail(reportDTOList,
						String.valueOf(submissionScore[3]));

				report.setProblemSetScore(report.getProblemSetScore()
						+ (int) (submissionScore[0]));

			} else {
				report.setUserFirstName(submissionScore[1]);
				report.setUserLastName(submissionScore[2]);
				report.setUserEmail(String.valueOf(submissionScore[3]));
				report.setProblemSetScore((int) submissionScore[0]);
				report.setUserSubmission(submissionScore[4]);
				reportDTOList.add(report);

			}
		}

		return reportDTOList;
	}

	private boolean doesListHaveName(List<ReportDTO> reportDTOList, String name) {

		for (ReportDTO report : reportDTOList) {

			if (report.getUserEmail().equals(name))
				return true;
		}

		return false;

	}

	private ReportDTO getByEmail(List<ReportDTO> reportDTOList, String email) {

		for (ReportDTO report : reportDTOList) {

			if (report.getUserEmail().equals(email))
				return report;
		}
		return null;
	}

	/**
	 * Returns whether the submission score must be updated or inserted if it is
	 * to be updated a UserSubmission object will be returned else null will be
	 * returned
	 * 
	 * @param userSubmission
	 * @return
	 */
	private UserSubmission getPreviousUserSubmission(
			UserSubmission userSubmission) {

		int previousVersion = userSubmission.getVersionNumber() - 1;

		if (previousVersion > 0) {
			return UserSubmissionService.findByUserTestProblemIdVersionNumber(
					userSubmission.getProblem().getProblemId(),
					userSubmission.getUserTest(), previousVersion);
		}

		return null;
	}

	/**
	 * Creates an updated SubmissionScore object with same submissionScoreId but
	 * with new properties
	 * 
	 * @param oldUserSubmission
	 * @param newUserSubmission
	 * @return
	 */
	private SubmissionScore getUpdatedSubmissionScore(
			UserSubmission oldUserSubmission, UserSubmission newUserSubmission) {

		SubmissionScore existingSubmissionScore = submissionScoreDAO
				.findByUserSubmission(oldUserSubmission);

		SubmissionScore newSubmissionScore = buildSubmissionScore(newUserSubmission);
		newSubmissionScore.setSubmissionScoreId(existingSubmissionScore
				.getSubmissionScoreId());

		return newSubmissionScore;
	}

	/**
	 * Creates SubmissionScore object from UserSubmission object by calculating
	 * the score
	 * 
	 * Note: Will not contain submissionScoreId
	 * 
	 * @param userSubmission
	 * @return
	 */
	private SubmissionScore buildSubmissionScore(UserSubmission userSubmission) {
		SubmissionScore submissionScore = new SubmissionScore();
		submissionScore
				.setSubmissionScore(calculateSubmissionScore(userSubmission));
		submissionScore.setUserSubmission(userSubmission);
		return submissionScore;
	}

	/**
	 * Calculate Submission Score of UserSubmission if there are testcases for a
	 * problem return 0
	 * 
	 * @param userSubmission
	 * @return score
	 */

	private int calculateSubmissionScore(UserSubmission userSubmission) {

		List<TestCase> testCases = testCaseService
				.getTestCaseByProblem(userSubmission.getProblem()
						.getProblemId());
		List<Result> testCaseResults = resultAndUserSubmissionService
				.getResultBySubmissionId(userSubmission.getSubmissionId());

		int difficulty;
		int score = 0;

		if (testCaseResults.size() > 0) {
			for (int i = 0; i < testCases.size(); i++) {
				if (testCaseResults.get(i).getTestCasebit() == 1) {
					difficulty = Integer.parseInt(testCases.get(i)
							.getTestCaseDifficulty());
					score = score + difficulty;
				}
			}
		}
		return score;
	}

}
