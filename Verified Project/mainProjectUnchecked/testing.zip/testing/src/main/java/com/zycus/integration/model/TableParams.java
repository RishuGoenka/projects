package com.zycus.integration.model;

import java.io.Serializable;

public class TableParams implements Serializable{
	private int problemId;	
	private String problemName;
	private String problemCategory;
	private String difficulty;
	
	public TableParams() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public TableParams(int problemId, String problemName,
			String problemCategory, String difficulty) {
		super();
		this.problemId = problemId;
		this.problemName = problemName;
		this.problemCategory = problemCategory;
		this.difficulty = difficulty;
	}
	public String getProblemName() {
		return problemName;
	}
	public void setProblemName(String problemName) {
		this.problemName = problemName;
	}
	public String getProblemCategory() {
		return problemCategory;
	}
	public void setProblemCategory(String problemCategory) {
		this.problemCategory = problemCategory;
	}
	public String getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
	public int getProblemId() {
		return problemId;
	}
	public void setProblemId(int problemId) {
		this.problemId = problemId;
	}
}
