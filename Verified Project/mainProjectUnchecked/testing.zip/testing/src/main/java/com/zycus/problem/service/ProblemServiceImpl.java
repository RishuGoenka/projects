package com.zycus.problem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.problem.dao.ProblemDAO;
import com.zycus.problem.model.Problem;

@Service
public class ProblemServiceImpl implements ProblemService {

	@Autowired
	ProblemDAO problemDAO;
	
	/* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#getAllProblems()
	 */
	@Override
	public List<Problem> getAllProblems()  
	{
		return problemDAO.getAllProblems();
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#add(com.zycus.model.Problem)
	 */
	@Override
	public void add(Problem problem)
	{
		problemDAO.add(problem);
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#update(com.zycus.model.Problem)
	 */
	@Override
	public void update(Problem problem) 
    {
       problemDAO.update(problem);
    }
    
    /* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#delete(com.zycus.model.Problem)
	 */
    @Override
	public void delete(Problem problem) 
    {
    	problemDAO.delete(problem);
    }
    
    /* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#getByID(int)
	 */
    @Override
	public Problem getByID(int problemId)
    {
    	return problemDAO.getByID(problemId);
    }
    
	/* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#getByCategory(java.lang.String)
	 */
	@Override
	public List<Problem> getByCategory(String problemCategory)
    {
		return problemDAO.getByCategory(problemCategory);
    }
    
	/* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#getByName(java.lang.String)
	 */
	@Override
	public List<Problem> getByName(String problemname)
    {
		return problemDAO.getByName(problemname);
    }

	/* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#getByDifficulty(java.lang.String)
	 */
	@Override
	public List<Problem> getByDifficulty(String difficulty)
    {
		return problemDAO.getByDifficulty(difficulty);
    }
	
	/* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#sortByCategory()
	 */
	@Override
	public List<Problem> sortByCategory()
    {
		return problemDAO.sortByCategory();
    }
    
	/* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#sortByName()
	 */
	@Override
	public List<Problem> sortByName()
    {
		return problemDAO.sortByName();
    }

	/* (non-Javadoc)
	 * @see com.zycus.service.impl.ProblemService#sortByDifficulty()
	 */
	@Override
	public List<Problem> sortByDifficulty()
    {
		return problemDAO.sortByDifficulty();
    }

}
