package com.zycus.problem.dto;

public class BulkProblemDTO {
	private String questionNo;
	private String questionCategory;
	private String questionName;
	private String difficulty;
	private String questionDescription;

	@Override
	public String toString() {
		return "questionNo=" + questionNo
				+ ", questionCategory=" + questionCategory + ", questionName="
				+ questionName + ", difficulty=" + difficulty
				+ ", questionDescription=" + questionDescription + "\n";
	}

	public String getQuestionNo() {
		return questionNo;
	}

	public void setQuestionNo(String questionNo) {
		this.questionNo = questionNo;
	}

	public String getQuestionCategory() {
		return questionCategory;
	}

	public void setQuestionCategory(String questionCategory) {
		this.questionCategory = questionCategory;
	}

	public String getQuestionName() {
		return questionName;
	}

	public void setQuestionName(String questionName) {
		this.questionName = questionName;
	}

	public String getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public String getQuestionDescription() {
		return questionDescription;
	}

	public void setQuestionDescription(String questionDescription) {
		this.questionDescription = questionDescription;
	}

}
