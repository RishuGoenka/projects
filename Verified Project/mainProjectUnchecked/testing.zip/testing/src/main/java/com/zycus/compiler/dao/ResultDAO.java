package com.zycus.compiler.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.compiler.model.Result;

@Repository
public interface ResultDAO {

	public abstract List<Result> getById(int submissionId);

	public abstract void saveResult(Result result);

	public abstract void deleteResult(Result result);

	public abstract Result getSingleResult(int submissionId, int testCaseId);

	public abstract List<Result> getByProblemSetId(int submissionId);

}