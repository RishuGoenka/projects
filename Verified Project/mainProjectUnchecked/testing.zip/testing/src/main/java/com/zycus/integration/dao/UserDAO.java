package com.zycus.integration.dao;

import java.util.List;

import com.zycus.integration.model.User;

public interface UserDAO {

	/**
	 * Saves Users object passed to it 
	 * @param userObject
	 */
	public abstract void save(User userObject);

	/**
	 * returns user Object of the user whose id is passed to is
	 * else return null
	 * @param id
	 * @return User
	 */
	public abstract User getUserByID(int id);

	/**
	 * Return a list of all the users 
	 * if empty it return an empty list
	 * @return
	 */
	public abstract List<User> getAllUsers();

	/**
	 * Updates the object passed to it
	 * It is necessary to pass an object which has a userId
	 * @param userObject
	 */
	public abstract void update(User userObject);

	/**
	 * Returns Object of user having email = emailString or else returns null
	 * 
	 * @param emailString
	 * @return User
	 */
	public abstract User getUserByEmail(String emailString);
	
	/**
	 * Returns true if the email already exist in the database
	 * 
	 * @param email
	 * @return true/false
	 */

	public abstract boolean isEmailAvailable(String email);

	/**
	 * get total number of users
	 * @return
	 */
	public long getNoOfUsers(); 

}