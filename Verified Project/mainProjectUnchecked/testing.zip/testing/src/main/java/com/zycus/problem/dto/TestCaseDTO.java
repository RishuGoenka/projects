package com.zycus.problem.dto;

public class TestCaseDTO {

	private String input;
	private String output;
	private String testCaseDifficulty;
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	public String getTestCaseDifficulty() {
		return testCaseDifficulty;
	}
	public void setTestCaseDifficulty(String testCaseDifficulty) {
		this.testCaseDifficulty = testCaseDifficulty;
	}
	@Override
	public String toString() {
		return "input=" + input + ", output=" + output
				+ ", testCaseDifficulty=" + testCaseDifficulty + "\n";
	}
	
}
