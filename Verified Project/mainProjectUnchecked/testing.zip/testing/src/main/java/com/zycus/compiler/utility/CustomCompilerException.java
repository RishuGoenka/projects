package com.zycus.compiler.utility;

public class CustomCompilerException extends RuntimeException {

	private static final long serialVersionUID = 5795534551375835083L;
	
	
	public final static int SQL_EXCEPTION = 1;
	public final static int ENTITY_EXISTS_EXCEPTION = 2;
	public final static int PERSISTENCE_EXCEPTION = 3;
	public final static int TRANSACTION_REQUIRED_EXCEPTION = 4;
	public final static int CLASS_CAST_EXCEPTION = 5;
	public final static int NULL_POINTER_EXCEPTION = 6;
	public final static int ILLEGAL_ARGUEMENT_EXCEPTION = 7;
	public final static int SOMETHING_WENT_WRONG = 10;

	private int errorCode;

	public CustomCompilerException(int errorCode) {
		this.errorCode = errorCode;
	}

	public int getErrorCode() {
		return errorCode;
	}
}
