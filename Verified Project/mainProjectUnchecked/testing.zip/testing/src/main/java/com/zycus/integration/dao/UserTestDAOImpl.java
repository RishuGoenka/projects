package com.zycus.integration.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;



import com.zycus.integration.model.User;
import com.zycus.integration.model.UserTest;


@Repository
@Transactional
public class UserTestDAOImpl implements UserTestDAO {
	
	 @PersistenceContext
	 private EntityManager manager;
	 
	 /* (non-Javadoc)
	 * @see com.zycus.dao.UserTest#save(com.zycus.model.UserTest)
	 */
	@Override
	public boolean save(UserTest userTestObject){
		
		try{
			manager.persist(userTestObject);
			return true; 
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	 }
	 
	 /* (non-Javadoc)
	 * @see com.zycus.dao.UserTest#getUserTestByID(int)
	 */
	@Override
	public UserTest getUserTestByID(int id){
		 return manager.find(UserTest.class, id);
	 }
	 
	 /* (non-Javadoc)
	 * @see com.zycus.dao.UserTest#getAllUserTests()
	 */
	@Override
	public List<UserTest> getAllUserTests(){
		 List<UserTest> userTestList = manager.createQuery("Select u from UserTest u").getResultList();
		 return userTestList;
	 }
	 
	
	 /* (non-Javadoc)
	 * @see com.zycus.dao.UserTest#update(com.zycus.model.UserTest)
	 */
	@Override
	public boolean update(UserTest userTestObject){
		try{
			 UserTest persistentUserTest = manager.find(UserTest.class, userTestObject.getUserTestId());
			 persistentUserTest = userTestObject;
			 return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	 
	
	 
	 /* (non-Javadoc)
	 * @see com.zycus.dao.UserTest#getUsersByTest(int)
	 */
	@Override
	public List<User> getUsersByTest( int problemSetId){
		 List<User> userList = manager.createQuery("Select u.user from UserTest u where u.problemSet.problemSetId=:ID").setParameter("ID", problemSetId).getResultList();
		 return userList;
	 }
	
	 /* (non-Javadoc)
	 * @see com.zycus.dao.UserTest#getUserTestByIDs(int, int)
	 */
		@Override
		public UserTest getUserTestByIDs(int problemSetId, int userId){
			 List<UserTest> userTests = (List<UserTest>) manager.createQuery("Select u from UserTest u "
			 		+ "where u.problemSet.problemSetId =? and u.user.userId = ?")
					 .setParameter(1, problemSetId)
					 .setParameter(2, userId)
					 .getResultList();
			 
			 if (userTests.size() >= 1) {
					return userTests.get(0);
				} else {
					return null;
				}
		 }

	
	
}
