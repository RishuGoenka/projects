package com.zycus.problem.dao;

import java.util.List;

import com.zycus.problem.model.Problem;

public interface ProblemDAO {

	public abstract List<Problem> getAllProblems();

	public abstract void add(Problem problem);

	public abstract void update(Problem problem);

	public abstract void delete(Problem problem);

	public abstract Problem getByID(int problemId);

	public abstract List<Problem> getByCategory(String problemCategory);

	public abstract List<Problem> getByName(String problemname);

	public abstract List<Problem> getByDifficulty(String difficulty);

	public abstract List<Problem> sortByCategory();

	public abstract List<Problem> sortByName();

	public abstract List<Problem> sortByDifficulty();

}