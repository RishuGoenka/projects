package com.zycus.compiler.service.client;

import java.util.List;

import com.zycus.compiler.model.Result;
import com.zycus.compiler.model.UserSubmission;
import com.zycus.integration.model.UserTest;

public interface ResultAndUserSubmissionService {

	public abstract List<Result> getResultBySubmissionId(int submissionId);
	public abstract List<Result> getResultByProblemSetId(int submissionId);

	public abstract int getLatestVersionByUser(int problemId, UserTest userTest);

	public abstract UserSubmission getLatestUserSubmission(int problemId, UserTest userTest);

	public abstract Result getSingleResult(int submissionId, int testCaseId);

	public abstract List<UserSubmission> getAllUserSubmission(int problemId, UserTest userTest);

}