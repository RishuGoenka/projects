package com.zycus.compiler.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.compiler.dao.ResultDAO;
import com.zycus.compiler.dao.ResultDAOImpl;
import com.zycus.compiler.model.Result;

@Service
public class ResultServiceImpl implements ResultService {
	
	@Autowired
	ResultDAO resultDao = new ResultDAOImpl();
	
	/* (non-Javadoc)
	 * @see com.zycus.service.ResultService#setResultDao(com.zycus.dao.ResultDAO)
	 */
	@Override
	public void setResultDao(ResultDAO resultDao) {
		this.resultDao = resultDao;
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.ResultService#getById(int)
	 */
	@Override
	public  List<Result> getById(int submissionId){
		return resultDao.getById(submissionId);
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.ResultService#saveResult(com.zycus.model.ResultEntity)
	 */
	@Override
	public  void saveResult(Result result){
		resultDao.saveResult(result);
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.ResultService#deleteResult(com.zycus.model.ResultEntity)
	 */
	@Override
	public  void deleteResult(Result result){
		resultDao.deleteResult(result);
	}

	@Override
	public  Result getSingleResult(int submissionId, int testCaseId){
		return resultDao.getSingleResult(submissionId, testCaseId);
	}

	@Override
	public List<Result> getByProblemSetId(int submissionId) {
		// TODO Auto-generated method stub
		return resultDao.getByProblemSetId(submissionId);
	}
}
