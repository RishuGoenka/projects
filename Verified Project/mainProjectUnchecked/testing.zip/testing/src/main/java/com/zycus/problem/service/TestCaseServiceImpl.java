package com.zycus.problem.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.problem.dao.TestCaseDAO;
import com.zycus.problem.model.Problem;
import com.zycus.problem.model.TestCase;

@Service
public class TestCaseServiceImpl implements TestCaseService {

	@Autowired
	private TestCaseDAO testCaseDAO;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.service.impl.TestCaseService#add(com.zycus.model.TestCase)
	 */
	@Override
	public void add(TestCase object) {
		testCaseDAO.add(object);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.zycus.service.impl.TestCaseService#update(com.zycus.model.TestCase)
	 */
	@Override
	public void update(TestCase updatedTestCase) {
		testCaseDAO.update(updatedTestCase);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.zycus.service.impl.TestCaseService#delete(com.zycus.model.TestCase)
	 */
	@Override
	public void delete(TestCase testcase) {
		try {
			testCaseDAO.delete(testcase);
		} catch (Exception e) {
			System.out.println(e);
			throw new RuntimeException("Error Occurred");
		}
	}

	@Override
	public void deleteByProblem(Problem problem) {
		// TODO Auto-generated method stub
		testCaseDAO.deleteByProblem(problem);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.service.impl.TestCaseService#getByID(int)
	 */
	@Override
	public TestCase getByID(int testCaseId) {
		return testCaseDAO.getByID(testCaseId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.service.impl.TestCaseService#getTestCaseByProblem(int)
	 */
	@Override
	public List<TestCase> getTestCaseByProblem(int problem_id) {
		return testCaseDAO.getTestCaseByProblem(problem_id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.service.impl.TestCaseService#getInputByProblem(int)
	 */
	@Override
	public List<String> getInputByProblem(int problemId) {
		return testCaseDAO.getInputByProblem(problemId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.service.impl.TestCaseService#getOutputByProblem(int)
	 */
	@Override
	public List<String> getOutputByProblem(int problem) {
		return testCaseDAO.getOutputByProblem(problem);
	}

}
