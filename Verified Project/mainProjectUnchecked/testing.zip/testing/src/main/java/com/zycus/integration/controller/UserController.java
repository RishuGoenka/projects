package com.zycus.integration.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.compiler.model.UserSubmission;
import com.zycus.compiler.service.UserSubmissionService;
import com.zycus.integration.model.ProblemSet;
import com.zycus.integration.model.User;
import com.zycus.integration.model.UserPrincipal;
import com.zycus.integration.model.UserTest;
import com.zycus.integration.service.MappedProblemService;
import com.zycus.integration.service.ProblemSetService;
import com.zycus.integration.service.UserService;
import com.zycus.integration.service.UserTestService;
import com.zycus.problem.model.Problem;
import com.zycus.problem.service.ProblemService;

@Controller
@SessionAttributes("user")
public class UserController {

	@Autowired
	UserService userService;

	@Autowired
	MappedProblemService mappedProblemService;

	@Autowired
	ProblemSetService problemSetService;

	@Autowired
	UserTestService userTestService;

	@Autowired
	ProblemService problemService;

	@Autowired
	UserSubmissionService userSubmissionService;

	/**
	 * Registration Of user
	 * 
	 * @param user
	 * @param result
	 * @return
	 */
	/**
	 * @param user
	 * @param result
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView registerUser(
			@ModelAttribute("userObject") @Valid User user, BindingResult result) {

		ModelAndView modelAndView = new ModelAndView();
		if (result.hasErrors()) {
			return new ModelAndView("register");
		} else {
			if (!user.getPassword().equals(user.getConfirmPassword())) {
				modelAndView.setViewName("register");
				modelAndView.addObject("error", "Passwords do not match");
				modelAndView.addObject("userObject", user);
				return modelAndView;
			} else {
				if (userService.addUser(user)) {

					modelAndView.setViewName("forward:/login?registered");
					modelAndView.addObject("Success");
					return modelAndView;

				} else {

					modelAndView.setViewName("register");
					modelAndView.addObject("error",
							"This email Id already exist");
					modelAndView.addObject("userObject", user);
					return modelAndView;
				}
			}
		}
	}

	/**
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView setUpRegisterForm() {

		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {

			/* The user is logged in :) */
			return new ModelAndView("forward:/newTest");
		}

		ModelAndView modelAndView = new ModelAndView("register");
		User user = new User();
		modelAndView.addObject("userObject", user);
		return modelAndView;
	}

	/**
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logoutGet() {
		return new ModelAndView("forward:/");
	}

	/**
	 * @return String
	 */
	@RequestMapping(value = "/editor")
	public String viewAdminHome() {

		return "editor";
	}

	/**
	 * @param request
	 * @param response
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/writeProgram", method = RequestMethod.GET)
	public ModelAndView writeProgram(HttpServletRequest request,
			HttpServletResponse response) {
		int problemId = Integer.parseInt(request.getParameter("problemId"));
		Object problemSetIdObject = request.getSession().getAttribute(
				"problemSetId");

		if (problemSetIdObject == null)
			return new ModelAndView("forward:newTest");
		int problemSetId = (int) problemSetIdObject;
		if (mappedProblemService.validateProblemId(problemSetId, problemId)) {
			long remTime = userTestService.getRemainingTime(userTestService
					.findUserTest(userService.getCurrentLoggedInUserId(),
							problemSetId));
			if (remTime <= 0L) {
				return new ModelAndView("forward:newTest?expired");
			}
			ModelAndView modelAndView = new ModelAndView("editor");
			Problem problem = problemService.getByID(problemId);
			String text = problem.getProblemText().replaceAll("\"", "\\\\\"");
			text = text.replaceAll("(\r\n|\n)", "<br>");
			problem.setProblemText(text);
			modelAndView.addObject("problem", problem);
			modelAndView.addObject("remTime", remTime);
			System.err.println("problem -> " + problem);
			return modelAndView;
		}
		ModelAndView mv = new ModelAndView("newTest");
		mv.addObject("message", "Invalid Question attempted");
		return mv;
	}

	/**
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/newTest", method = RequestMethod.GET)
	public ModelAndView newTestSetUp() {
		ModelAndView mv = new ModelAndView("newTest");
		mv.addObject("problemSet", new ProblemSet());
		mv.addObject("user", userService.getCurrentUser());
		return mv;
	}

	/**
	 * @param request
	 * @param response
	 * @param problemSet
	 * @param bindingResult
	 * @return ModelAndView
	 * @throws Exception
	 */
	@RequestMapping(value = "/showTest")
	public ModelAndView createTest(HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute("problemSet") ProblemSet problemSet,
			BindingResult bindingResult) throws Exception {

		String sharedId = request.getParameter("sharedId");
		try {
			sharedId.equals(null);
		} catch (NullPointerException e) {
			sharedId = (String) request.getSession().getAttribute("sharedId");
		}
		problemSet = problemSetService.findProblemSetBySharedId(sharedId);

		ModelAndView mv = new ModelAndView("teststarted");

		mv.addObject("sharedId", sharedId);

		Object principal = SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();
		User user = ((UserPrincipal) principal).getUser();

		if (problemSet == null) {
			mv.setViewName("newTest");
			mv.addObject("msg", "No such Test exist");
		} else {

			if (userTestService.hasTestStarted(user.getUserId(),
					problemSet.getProblemSetId())) {

				UserTest userTest = userTestService.findUserTest(
						user.getUserId(), problemSet.getProblemSetId());

				mv.addObject("testStarted", true);
				mv.addObject("remTime",
						userTestService.getRemainingTime(userTest));

				if (userTestService.hasTestExpired(userTest)) {
					mv.setViewName("newTest");
					mv.addObject("msg", "Test has been expired");
				} else {
					HttpSession session = request.getSession();
					session.setAttribute("problemSetId",
							problemSet.getProblemSetId());
					session.setAttribute("sharedId", problemSet.getSharedId());
				}
			} else {
				mv.addObject("testStarted", false);
				mv.addObject("remTime", 0);
			}
		}
		return mv;
	}

	/**
	 * @param request
	 * @param response
	 * @return String
	 */
	@RequestMapping(value = "/test-starting", method = RequestMethod.GET)
	public @ResponseBody String startTest(HttpServletRequest request,
			HttpServletResponse response) {

		String sharedId = request.getParameter("test_shared_id");
		System.out.println(sharedId);

		Object principal = SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();
		User user = ((UserPrincipal) principal).getUser();

		ProblemSet problemSet = problemSetService
				.findProblemSetBySharedId(sharedId);
		HttpSession session = request.getSession();
		session.setAttribute("problemSetId", problemSet.getProblemSetId());
		if (userTestService.findUserTest(user.getUserId(),
				problemSet.getProblemSetId()) == null) {

			UserTest userTest = userTestService.createUserTest(new UserTest(
					problemSet, user));

			long remTime = userTestService.getRemainingTime(userTest);

			return String.valueOf(remTime);

		} else {
			// will never happen unless hack, so not handled on client side
			return "You have already given this test";
		}
	}

	/**
	 * @param sharedId
	 * @return Lsit Of Problems
	 */
	@RequestMapping(value = "/problems/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Problem> getResultList(
			@PathVariable("id") String sharedId) {
		List<Problem> problems = mappedProblemService.findBySharedId(sharedId);
		System.out.println(problems);
		return problems;
	}

	@RequestMapping(value = "/new/get/{id}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Problem> getResultLis(
			@PathVariable("id") String sharedId) {

		
		List<Problem> problems = mappedProblemService.findBySharedId(sharedId);
		int userId = userService.getCurrentLoggedInUserId();

		UserTest userTest = userTestService.findUserTest(userId,
				problemSetService.findProblemSetBySharedId(sharedId)
						.getProblemSetId());

		//System.out.println(userTest);

		for (Problem problem : problems) {

			if (userTest == null) {
				problem.setDifficulty("Not Attempted"); 
			} else {

				List<UserSubmission> submissions = userSubmissionService
						.getAllUserSubmission(problem.getProblemId(), userTest);
				if (submissions.size() > 0)
					problem.setDifficulty("Attempted");
				else
					problem.setDifficulty("Not Attempted");

			}
		}
		return problems;
	}

}
