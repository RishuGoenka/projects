package com.zycus.integration.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.zycus.integration.dao.UserDAO;
import com.zycus.integration.model.User;
import com.zycus.integration.model.UserPrincipal;
import com.zycus.integration.model.UserRoles;

@Component
public class UserService {

	@Autowired
	private UserDAO userDAO;

	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

	/**
	 * Finds a user by email id
	 * 
	 * @param email
	 * @return
	 */
	public User findByEmail(String email) {

		return userDAO.getUserByEmail(email);
	}

	/**
	 * Adds an user
	 * 
	 * @param user
	 * @return
	 */
	public boolean addUser(User user) {

		if (userDAO.isEmailAvailable(user.getEmail())) {

			return false;

		} else {

			user.setRegistrationTime(new Date());

			user.setRole(UserRoles.USER); // to be modified

			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			String hashedPassword = passwordEncoder.encode(user.getPassword());
			user.setPassword(hashedPassword);

			userDAO.save(user);
			return true;
		}

	}

	/**
	 * Gets user id of current logged in user
	 * 
	 * @return
	 */
	public int getCurrentLoggedInUserId() {

		User user = getCurrentUser();

		return user == null ? 0 : user.getUserId();
	}


	/**
	 * Gets current user object, null if he is not logged in
	 * @return
	 */
	public User getCurrentUser() {
		
		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			Object principal = SecurityContextHolder.getContext()
					.getAuthentication().getPrincipal();
			User user = ((UserPrincipal) principal).getUser();
			return user;
		}
		return null;

	

	}
	public long getNoOfUsers() {
		return userDAO.getNoOfUsers();
	}
	
}
