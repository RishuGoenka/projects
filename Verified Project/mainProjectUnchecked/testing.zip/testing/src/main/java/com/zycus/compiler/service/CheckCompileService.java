package com.zycus.compiler.service;

public interface CheckCompileService {

	/**
	 * Compiles the program in the path specified in the directory (Uses
	 * PathUtil utility class to find the same)
	 * 
	 * @return the compilation error if compilation failed else Compilation
	 *         Successful message
	 */
	public abstract String compile();

}