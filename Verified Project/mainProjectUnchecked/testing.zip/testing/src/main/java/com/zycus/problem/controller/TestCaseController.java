package com.zycus.problem.controller;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.problem.dto.TestCaseDTO;
import com.zycus.problem.model.Problem;
import com.zycus.problem.model.TestCase;
import com.zycus.problem.service.ProblemService;
import com.zycus.problem.service.TestCaseService;
@Controller
@RequestMapping("/admin")
public class TestCaseController 
{
	@Autowired
	TestCaseService testService;
	
	@Autowired
	ProblemService problemService;
	
	/**
	 * redirect to add test cases for single problems uploaded
	 * @param request
	 * @param response
	 * @return model and view object (add test case page)
	 */
	@RequestMapping(value = "/add-testcase-redirect")
	public ModelAndView addTestCase(HttpServletRequest request,
			HttpServletResponse response)	{
		ModelAndView mv = new ModelAndView("admin/individual-test-case");
		mv.addObject("problemId", request.getParameter("problemId"));		
		mv.addObject("testCase", new TestCase());
		return mv;
	}	
	
	/**
	 * add a single test case
	 * redirect to the same page so that more test cases for the same problem can be added
	 * @param request
	 * @param response
	 * @return model and view object (add test case for individual problem)
	 */
	@RequestMapping(value = "/add-testCase")
	public ModelAndView add(@ModelAttribute("testCase") @Valid TestCase testCase, BindingResult result,
			HttpServletRequest request)
	{
		if(result.hasErrors())	{

			return new ModelAndView("admin/individual-test-case");
		}
		
		int problemId = Integer.parseInt(request.getParameter("problemId"));
		
		testCase.setProblem(problemService.getByID(problemId));
		testService.add(testCase);		
		request.getSession().setAttribute("testCase", testCase);
		ModelAndView mv = new ModelAndView("admin/individual-test-case");
		mv.addObject("successMsg", "Test case added!");
		mv.addObject("problemId", request.getParameter("problemId"));
		mv.addObject("testCase", new TestCase());
		return mv;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/end-testcase-upload")
	public ModelAndView endTestCaseUpload(HttpServletRequest request,
			HttpServletResponse response)	{
				
		List<TestCase> testCases = testService.getTestCaseByProblem(Integer
				.parseInt(request.getParameter("problemId")));
		ModelAndView mv = new ModelAndView("admin/test-case-list");
		mv.addObject("testCases", testCases);
		mv.addObject("problemId", request.getParameter("problemId"));
		mv.addObject("successMsg", "Test cases added successfully");
		return mv;
	}
	
	/*@RequestMapping(value = "/get-all",method = RequestMethod.GET)
	public ModelAndView getAll(HttpServletRequest request, HttpServletResponse response)
	{
		List<TestCase> l = testService.getTestCaseByProblem((Integer)request.getSession().getAttribute("problemId"));
		ModelAndView mv = new ModelAndView("admin/testcase-list");
		mv.addObject("testcases", l);
		return mv;
	}	*/
}