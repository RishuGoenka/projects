package com.zycus.integration.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.integration.dao.DataTableDAO;
import com.zycus.integration.model.ProblemSetDataTableParam;
import com.zycus.integration.model.TableParams;
import com.zycus.problem.model.Problem;
@Service
public class DataTableService {
	
	@Autowired
	DataTableDAO dataTableDao;
	/**
	 * search the string entered in search box
	 * 
	 * @param sSearch				data to search
	 * @param iDisplayLength		number of entries to display per page
	 * @param iDisplayStart			from where to start the next page data
	 * @param sSortDirection		sort ASC or DESC
	 * @param iSortColumnIndex		which column to sort
	 * @param columns				String array of columns name
	 * @return
	 */
	public List<Problem> search(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]){
		return dataTableDao.search(sSearch, iDisplayLength, iDisplayStart, sSortDirection, iSortColumnIndex, columns);
	}
	
	/**
	 * search the string entered in search box 
	 * returns problem which do not have test cases 
	 * 
	 * @param sSearch				data to search
	 * @param iDisplayLength		number of entries to display per page
	 * @param iDisplayStart			from where to start the next page data
	 * @param sSortDirection		sort ASC or DESC
	 * @param iSortColumnIndex		which column to sort
	 * @param columns				String array of columns name
	 * @return
	 */
	public List<Problem> searchAll(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]){
		return dataTableDao.searchAll(sSearch, iDisplayLength, iDisplayStart, sSortDirection, iSortColumnIndex, columns);
	}
	/**
	 * counts the number of matched entries for a particular search 
	 * 
	 * @param sSearch				data to search
	 * @param iDisplayLength		number of entries to display per page 
	 * @param iDisplayStart			from where to start the next page data
	 * @param sSortDirection		sort ASC or DESC
	 * @param iSortColumnIndex		which column to sort
	 * @param columns				String array of columns name
	 * @return
	 */
	public long searchCount(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]) {
		return dataTableDao.searchCount(sSearch, iDisplayLength, iDisplayStart, sSortDirection, iSortColumnIndex, columns);
	}
	
	/**
	 * counts the number of matched entries for a particular search 
	 * 
	 * @param sSearch				data to search
	 * @param iDisplayLength		number of entries to display per page 
	 * @param iDisplayStart			from where to start the next page data
	 * @param sSortDirection		sort ASC or DESC
	 * @param iSortColumnIndex		which column to sort
	 * @param columns				String array of columns name
	 * @return
	 */
	public long searchCountAll(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]) {
		return dataTableDao.searchCountAll(sSearch, iDisplayLength, iDisplayStart, sSortDirection, iSortColumnIndex, columns);
	}
	
	/**
	 * get all problems from database by using pagination 
	 * 
	 * @param iDisplayLength    	number of entries to display per page 
	 * @param iDisplayStart     	from where to start the next page data
	 * @param sSortDirection		sort ASC or DESC
	 * @param iSortColumnIndex		which column to sort
	 * @param columns				String array of columns name
	 * @return
	 */
	public List<Problem> getAllProblems( int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]){
		return dataTableDao.getAllProblems(iDisplayLength, iDisplayStart, sSortDirection, iSortColumnIndex, columns);
	}
	
	/**
	 * get all problems from database by using pagination 
	 * 
	 * @param iDisplayLength    	number of entries to display per page 
	 * @param iDisplayStart     	from where to start the next page data
	 * @param sSortDirection		sort ASC or DESC
	 * @param iSortColumnIndex		which column to sort
	 * @param columns				String array of columns name
	 * @return
	 */
	public List<Problem> getAllProblemsAll( int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]){
		return dataTableDao.getAllProblemsAll(iDisplayLength, iDisplayStart, sSortDirection, iSortColumnIndex, columns);
	}
	
	/**
	 * returns number of problems int database 
	 * @return 
	 */
	public long sizeOfProblems(){
		return dataTableDao.sizeOfProblems();
	}
	
	/**
	 * returns number of problems int database 
	 * @return 
	 */
	public long sizeOfProblemsAll(){
		return dataTableDao.sizeOfProblemsAll();
	}
	
	/**
	 * get all problems when nothing is searched
	 * 
	 * @param param					JQueryDataTableParamModel
	 * @param sortColumnIndex		column index to sort
	 * @param sortDirection			sort ASC or DESC
	 * @param columns				String array of columns name
	 * @return						list of parameters to display in data table 
	 */
	public List<TableParams> noSearch(ProblemSetDataTableParam param,int sortColumnIndex,String sortDirection,String columns[]){
		List<TableParams> problems = new LinkedList<TableParams>();
		for(Problem c : dataTableDao.getAllProblems(param.iDisplayLength, param.iDisplayStart,sortDirection,sortColumnIndex,columns)){
			TableParams newTable = new TableParams();	
			newTable.setProblemId(c.getProblemId());
			newTable.setProblemName(c.getProblemName());
			newTable.setProblemCategory(c.getProblemCategory());
			newTable.setDifficulty(c.getDifficulty());			
			problems.add(newTable);			
		}
		return problems;
	}
	
	/**
	 * get all problems when nothing is searched
	 * 
	 * @param param					JQueryDataTableParamModel
	 * @param sortColumnIndex		column index to sort
	 * @param sortDirection			sort ASC or DESC
	 * @param columns				String array of columns name
	 * @return						list of parameters to display in data table 
	 */
	public List<TableParams> noSearchAll(ProblemSetDataTableParam param,int sortColumnIndex,String sortDirection,String columns[]){
		List<TableParams> problems = new LinkedList<TableParams>();
		for(Problem c : dataTableDao.getAllProblemsAll(param.iDisplayLength, param.iDisplayStart,sortDirection,sortColumnIndex,columns)){
			TableParams newTable = new TableParams();	
			newTable.setProblemId(c.getProblemId());
			newTable.setProblemName(c.getProblemName());
			newTable.setProblemCategory(c.getProblemCategory());
			newTable.setDifficulty(c.getDifficulty());			
			problems.add(newTable);			
		}
		return problems;
	}
	
	/**
	 * get all problems by search
	 * 
	 * @param param					JQueryDataTableParamModel
	 * @param sortColumnIndex		column index to sort
	 * @param sortDirection			sort ASC or DESC
	 * @param columns				String array of columns name
	 * @return						list of parameters to display in data table 
	 */
	public List<TableParams> newSearch(ProblemSetDataTableParam param,int sortColumnIndex,String sortDirection,String columns[]){
		List<TableParams> problems = new LinkedList<TableParams>();
		for(Problem c : dataTableDao.search(param.sSearch,param.iDisplayLength,param.iDisplayStart,sortDirection,sortColumnIndex,columns)){
			TableParams newTable = new TableParams();
			newTable.setProblemId(c.getProblemId());
			newTable.setProblemName(c.getProblemName());
			newTable.setProblemCategory(c.getProblemCategory());
			newTable.setDifficulty(c.getDifficulty());
			problems.add(newTable);// add problem that matches given search criterion	
		}
		return problems;
	}
	
	/**
	 * get all problems by search
	 * 
	 * @param param					JQueryDataTableParamModel
	 * @param sortColumnIndex		column index to sort
	 * @param sortDirection			sort ASC or DESC
	 * @param columns				String array of columns name
	 * @return						list of parameters to display in data table 
	 */
	public List<TableParams> newSearchAll(ProblemSetDataTableParam param,int sortColumnIndex,String sortDirection,String columns[]){
		List<TableParams> problems = new LinkedList<TableParams>();
		for(Problem c : dataTableDao.searchAll(param.sSearch,param.iDisplayLength,param.iDisplayStart,sortDirection,sortColumnIndex,columns)){
			TableParams newTable = new TableParams();
			newTable.setProblemId(c.getProblemId());
			newTable.setProblemName(c.getProblemName());
			newTable.setProblemCategory(c.getProblemCategory());
			newTable.setDifficulty(c.getDifficulty());
			problems.add(newTable);// add problem that matches given search criterion	
		}
		return problems;
	}
}
