package com.zycus.integration.service;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.integration.dao.ProblemSetDAO;
import com.zycus.integration.model.ProblemSet;
import com.zycus.integration.model.ProblemSetDataTableParam;

@Service
public class ProblemSetService {
	@Autowired
	ProblemSetDAO problemSetDao;
	

	
	/**
	 * Create test set
	 * @param problemSet
	 * @return ProblemSet
	 */
	public ProblemSet save(ProblemSet problemSet){
		problemSet.setSharedId(generateSharedId());
		return problemSetDao.save(problemSet);	
	}
	
	/**
	 * generate a random sharedId for each test 
	 * @return shared id
	 */
	public String generateSharedId(){
		char[] chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".toCharArray();
		Random rand = new Random();
		StringBuilder sb = new StringBuilder();
		int len = 6;
		for (int i = 0; i < len; i++) {
		    char c = chars[rand.nextInt(chars.length)];
		    sb.append(c);
		}
		return sb.toString();		
	}
	
	/**
	 * Find problem set by sharedId
	 * @param sharedId
	 * @return problem set
	 */
	public ProblemSet findProblemSetBySharedId(String sharedId){		
		return problemSetDao.findBySharedId(sharedId);
	}
	
	/**
	 * Find problem set by problemSetId
	 * @param problemSetId
	 * @return problem set
	 */
	public ProblemSet findProblemSetById(int problemSetId){		
		return problemSetDao.findById(problemSetId);
	}
	
	/**
	 * Update problem set
	 * @param problemSet
	 * @return true if updated else false
	 */
	public boolean update(ProblemSet problemSet){		
		return problemSetDao.update(problemSet);
	}
	
	/**
	 *Find list of problem set 
	 * @return list of problem set
	 */
	public List<ProblemSet> getAllProblemSet(){
		return problemSetDao.getAllProblemSet();
	}
	
	/**
	 * Delete Problem set
	 * @param problemSet
	 * @return true if delete else false
	 */
	public boolean delete(int problemSetId){
		return problemSetDao.delete(problemSetId);
	}
	
	
	///Data Table
	/**
	 * search the string entered in search box
	 * 
	 * @param sSearch				data to search
	 * @param iDisplayLength		number of entries to display per page
	 * @param iDisplayStart			from where to start the next page data
	 * @param sSortDirection		sort ASC or DESC
	 * @param iSortColumnIndex		which column to sort
	 * @param columns				String array of columns name
	 * @return
	 */
	public List<ProblemSet> search(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]){
		return problemSetDao.search(sSearch, iDisplayLength, iDisplayStart, sSortDirection, iSortColumnIndex, columns);
	}
	
	/**
	 * counts the number of matched entries for a particular search 
	 * 
	 * @param sSearch				data to search
	 * @param iDisplayLength		number of entries to display per page 
	 * @param iDisplayStart			from where to start the next page data
	 * @param sSortDirection		sort ASC or DESC
	 * @param iSortColumnIndex		which column to sort
	 * @param columns				String array of columns name
	 * @return
	 */
	public long searchCount(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]) {
		return problemSetDao.searchCount(sSearch, iDisplayLength, iDisplayStart, sSortDirection, iSortColumnIndex, columns);
	}
	
	/**
	 * get all problems from database by using pagination 
	 * 
	 * @param iDisplayLength    	number of entries to display per page 
	 * @param iDisplayStart     	from where to start the next page data
	 * @param sSortDirection		sort ASC or DESC
	 * @param iSortColumnIndex		which column to sort
	 * @param columns				String array of columns name
	 * @return
	 */
	public List<ProblemSet> getAllProblems( int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]){
		return problemSetDao.getAllProblems(iDisplayLength, iDisplayStart, sSortDirection, iSortColumnIndex, columns);
	}
	
	/**
	 * returns number of problem set int database 
	 * @return 
	 */
	public long sizeOfProblemSet(){
		return problemSetDao.sizeOfProblems();
	}
	
	/**
	 * get all problems when nothing is searched
	 * 
	 * @param param					JQueryDataTableParamModel
	 * @param sortColumnIndex		column index to sort
	 * @param sortDirection			sort ASC or DESC
	 * @param columns				String array of columns name
	 * @return						list of parameters to display in data table 
	 */
	public List<ProblemSet> noSearch(ProblemSetDataTableParam param,int sortColumnIndex,String sortDirection,String columns[]){
		List<ProblemSet> problems = new LinkedList<ProblemSet>();
		for(ProblemSet c : problemSetDao.getAllProblems(param.iDisplayLength, param.iDisplayStart,sortDirection,sortColumnIndex,columns)){
			
			
			problems.add(c);			
		}
		System.out.println(problems);
		return problems;
	}
	
	/**
	 * get all problems by search
	 * 
	 * @param param					JQueryDataTableParamModel
	 * @param sortColumnIndex		column index to sort
	 * @param sortDirection			sort ASC or DESC
	 * @param columns				String array of columns name
	 * @return						list of parameters to display in data table 
	 */
	public List<ProblemSet> newSearch(ProblemSetDataTableParam param,int sortColumnIndex,String sortDirection,String columns[]){
		List<ProblemSet> problems = new LinkedList<ProblemSet>();
		for(ProblemSet c : problemSetDao.search(param.sSearch,param.iDisplayLength,param.iDisplayStart,sortDirection,sortColumnIndex,columns)){
			
			problems.add(c);// add problem that matches given search criterion	
		}
		System.out.println(problems);
		return problems;
	}

	
}
