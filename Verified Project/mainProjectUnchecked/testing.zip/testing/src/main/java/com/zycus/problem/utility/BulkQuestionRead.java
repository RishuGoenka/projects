package com.zycus.problem.utility;
import java.io.Console;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.aspose.words.Bookmark;
import com.aspose.words.Cell;
import com.aspose.words.Document;
import com.aspose.words.NodeCollection;
import com.aspose.words.NodeType;
import com.aspose.words.Row;
import com.aspose.words.SaveFormat;
import com.aspose.words.Table;
import com.aspose.words.TableCollection;
import com.zycus.problem.dto.BulkProblemDTO;
import com.zycus.problem.dto.TestCaseDTO;
public class BulkQuestionRead
{
	static
	{
		com.aspose.words.License license = new com.aspose.words.License();
		try 
		{
			license.setLicense(Thread.currentThread().getContextClassLoader().getResourceAsStream("Aspose.Total.Java.lic"));
		} 
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public  List<List<BulkProblemDTO>> read(String s) throws Exception 
	{
		Document doc = new Document(s);
	    NodeCollection tables = doc.getChildNodes(NodeType.TABLE, true);
	    Iterator tablesIterator=tables.iterator();
	    List<BulkProblemDTO> questions=new ArrayList<BulkProblemDTO>();
	    List<BulkProblemDTO> incompleteQuestions=new ArrayList<BulkProblemDTO>();
	    BulkProblemDTO Question;
	    while(tablesIterator.hasNext())
	    {
	    	Question = new BulkProblemDTO();
	    	Table table = (Table)tablesIterator.next();
	    	 for(int j=0;j<4;j++)
		     {
		    	 Cell cell = table.getRows().get(0).getCells().get(j);
		    	 if(cell.toTxt().length()!=0)
		    	 {
		    		switch(j)
		    		{
			    		case 0:
			    		{
			    			Question.setQuestionNo(cell.toTxt().trim());
			    			break;
			    		}
			    		case 1:
			    		{
			    			Question.setQuestionCategory(cell.toTxt().trim());
			    			break;
			    		}
			    		case 2:
			    		{
			    			Question.setQuestionName(cell.toTxt().trim());
			    			break;
			    		}
			    		default:
			    		{
			    			Question.setDifficulty(cell.toTxt().trim());
			    		}
		    		}
		    	 }	    	
	    	 }
	    	 Cell cell = table.getRows().get(1).getCells().get(0);
	    	 String html = cell.toString(SaveFormat.HTML);
             Question.setQuestionDescription(html);  	 
             if(Question.getQuestionNo()==null || "".equalsIgnoreCase(Question.getQuestionNo()) || 
            		 Question.getQuestionCategory()==null ||  "".equalsIgnoreCase(Question.getQuestionCategory()) || 
            		 Question.getQuestionName()==null ||  "".equalsIgnoreCase(Question.getQuestionName()) || 
            		 cell.toTxt().length()==0 || "".equalsIgnoreCase(Question.getDifficulty()) || 
            		 Question.getDifficulty()==null)
             {
            	 incompleteQuestions.add(Question);
            	 tables.iterator().next();
             }
             else
             {
            	 if(Integer.parseInt(Question.getDifficulty())<1 || Integer.parseInt(Question.getDifficulty())>9)
            	 {
            		 if(Integer.parseInt(Question.getDifficulty())<1)
            		 Question.setDifficulty("1");	
            		 else
            		 Question.setDifficulty("9");	 
            	 }
            	 questions.add(Question);
               	 tables.iterator().next();
             }
	    }	 
	    List<List<BulkProblemDTO>> allQuestions=new ArrayList<List<BulkProblemDTO>>();
	    allQuestions.add(questions);
	    allQuestions.add(incompleteQuestions);
	    return allQuestions;
	}   
}
	
	
