package com.zycus.integration.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.integration.dao.UserTestDAO;
import com.zycus.integration.model.User;
import com.zycus.integration.model.UserTest;

@Service
public class UserTestService {

	@Autowired
	UserTestDAO userTestDAO;

	public UserTestService() {
		// TODO Auto-generated constructor stub
	}

	static final long ONE_MINUTE_IN_MILLIS = 60000;

	/**
	 * Gets end time of a test
	 * 
	 * @param userTest
	 * @return
	 */
	public Date getEndTime(UserTest userTest) {

		int duration = userTest.getProblemSet().getDuration();

		Calendar startCalendar = Calendar.getInstance();

		startCalendar.setTime(userTest.getStartTime());

		startCalendar.add(Calendar.MINUTE, duration);

		return startCalendar.getTime();

	}

	/**
	 * Starts the test by saving the current time as start time
	 * 
	 * @param userTest
	 * @return
	 */
	public UserTest createUserTest(UserTest userTest) {

		userTest.setStartTime(new Date());
		userTestDAO.save(userTest);

		return userTest;
	}

	/**
	 * Finds a user test based on user id and problem set id
	 * 
	 * @param userId
	 * @param problemSetId
	 * @return
	 */
	public UserTest findUserTest(int userId, int problemSetId) {
		return userTestDAO.getUserTestByIDs(problemSetId, userId);
	}

	/**
	 * Returns true if the test has expired
	 * 
	 * @param userTest
	 * @return
	 */
	public boolean hasTestExpired(UserTest userTest) {

		return (getEndTime(userTest)
				.compareTo(Calendar.getInstance().getTime())) < 0;
	}

	/**
	 * Checks if test has started or not
	 * 
	 * @param userId
	 * @param problemSetId
	 * @return
	 */
	public boolean hasTestStarted(int userId, int problemSetId) {

		return userTestDAO.getUserTestByIDs(problemSetId, userId) != null;
	}
	

	/**
	 * Gets remaining time of the test
	 * @param userTest
	 * @return
	 */
	public long getRemainingTime(UserTest userTest) {

		if(userTest == null) return 0;
		
		Date endDate = getEndTime(userTest);

		long remTime = (endDate.getTime() - Calendar.getInstance().getTime()
				.getTime()) / 1000;
		
		return remTime;
	}
	
	public  List<User> getUsersByTest(int problemSetId){
		return userTestDAO.getUsersByTest(problemSetId);
	}

}
