package com.zycus.problem.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.problem.model.Problem;

@Repository
@Transactional
public class ProblemDAOImpl implements ProblemDAO {

	@PersistenceContext
    private EntityManager manager;
	
	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#getAllProblems()
	 */
	@Override
	public List<Problem> getAllProblems() 
    {
		return manager.createQuery("Select p From Problem p", Problem.class).getResultList();
    }
	
    /* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#add(com.zycus.model.Problem)
	 */
    @Override
	public void add(Problem problem) 
    {
        manager.persist(problem);
    }
    
    /* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#update(com.zycus.model.Problem)
	 */
    @Override
	public void update(Problem problem) 
    {
    	manager.merge(problem);
    }
    
    /* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#delete(com.zycus.model.Problem)
	 */
    @Override
	public void delete(Problem problem) 
    {
        manager.remove(manager.merge(problem));
    }
    
    /* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#getByID(int)
	 */
    @Override
	public Problem getByID(int problemId)
    {
    	return (Problem) manager.find(Problem.class, problemId);
    }
    
	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#getByCategory(java.lang.String)
	 */
	@Override
	public List<Problem> getByCategory(String problemCategory)
    {
    	return manager.createQuery("Select p From Problem p where p.problemCategory=?")
    			.setParameter(1, problemCategory)
    			.getResultList();
    }
    
	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#getByName(java.lang.String)
	 */
	@Override
	public List<Problem> getByName(String problemname)
    {
    	return manager.createQuery("Select p From Problem p where p.problemName=?")
    			.setParameter(1, problemname)
    			.getResultList();
    }

	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#getByDifficulty(java.lang.String)
	 */
	@Override
	public List<Problem> getByDifficulty(String difficulty)
    {
    	return manager.createQuery("Select p From Problem p where p.difficulty=?")
    			.setParameter(1, difficulty)
    			.getResultList();
    }
	
	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#sortByCategory()
	 */
	@Override
	public List<Problem> sortByCategory()
    {
		System.out.println("in DAO");
    	return manager.createQuery("Select p From Problem p order by p.problemCategory").getResultList();
    }
    
	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#sortByName()
	 */
	@Override
	public List<Problem> sortByName()
    {
		System.out.println("in DAO");
    	return manager.createQuery("Select p From Problem p order by  p.problemName").getResultList();
    }

	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.ProblemDAO#sortByDifficulty()
	 */
	@Override
	public List<Problem> sortByDifficulty()
    {
		System.out.println("in DAO");
    	return manager.createQuery("Select p From Problem p order by p.difficulty").getResultList();
    }
}