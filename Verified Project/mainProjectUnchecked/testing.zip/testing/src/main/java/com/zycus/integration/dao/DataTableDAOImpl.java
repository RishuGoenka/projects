package com.zycus.integration.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.problem.model.Problem;


@Transactional
@Repository
public class DataTableDAOImpl implements DataTableDAO{

	@PersistenceContext
	EntityManager manager;

	
	
	
	/* (non-Javadoc)
	 * @see com.zycus.dao.DataTableDAO#search(java.lang.String, int, int, java.lang.String, int, java.lang.String[])
	 */
	@SuppressWarnings("unchecked")
	public List<Problem> searchAll(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]) {
			
		Query query = manager
				.createQuery("select p from Problem p where p.problemName like ? "
						+ "or p.problemCategory like ? or p.difficulty like ? order by "+columns[iSortColumnIndex]+" "+sSortDirection);
		
		query.setParameter(1, "%" + sSearch + "%")
				.setParameter(2, "%" + sSearch + "%")
				.setParameter(3, "%" + sSearch + "%");
				
		query.setFirstResult(iDisplayStart);
		query.setMaxResults(iDisplayLength);
		
		return query.getResultList();
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.dao.DataTableDAO#search(java.lang.String, int, int, java.lang.String, int, java.lang.String[])
	 */
	@SuppressWarnings("unchecked")
	public List<Problem> search(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]) {
			
		Query query = manager
				.createQuery("select distinct(p) from Problem p,TestCase t where  p.problemId = t.problem.problemId and (p.problemName like ? "
						+ "or p.problemCategory like ? or p.difficulty like ?) order by p."+columns[iSortColumnIndex]+" "+sSortDirection);
		
		query.setParameter(1, "%" + sSearch + "%")
				.setParameter(2, "%" + sSearch + "%")
				.setParameter(3, "%" + sSearch + "%");
				
		query.setFirstResult(iDisplayStart);
		query.setMaxResults(iDisplayLength);
		
		return query.getResultList();
	}

	/* (non-Javadoc)
	 * @see com.zycus.dao.DataTableDAO#searchCount(java.lang.String, int, int, java.lang.String, int, java.lang.String[])
	 */
	public long searchCountAll(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]) {
				
		Query query = manager
				.createQuery("select count(p) from Problem p where p.problemName like ? "
						+ "or p.problemCategory like ? or p.difficulty like ? order by "+columns[iSortColumnIndex]+" "+sSortDirection);
		
		query.setParameter(1, "%" + sSearch + "%")
				.setParameter(2, "%" + sSearch + "%")
				.setParameter(3, "%" + sSearch + "%");
						
		return (Long) query.getSingleResult();
	}
	
	public long searchCount(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]) {
				
		Query query = manager
				.createQuery("select count(p) from Problem p "
						+ "where exists (select t.problem.problemId from TestCase t where  p.problemId = t.problem.problemId)"
						+ "and (p.problemName like ? "
						+ "or p.problemCategory like ? or p.difficulty like ? ) order by p."+columns[iSortColumnIndex]+" "+sSortDirection);
		
		query.setParameter(1, "%" + sSearch + "%")
				.setParameter(2, "%" + sSearch + "%")
				.setParameter(3, "%" + sSearch + "%");
						
		System.out.println(query.getSingleResult());
		return (Long) query.getSingleResult();
		
	}
	/* (non-Javadoc)
	 * @see com.zycus.dao.DataTableDAO#getAllProblems(int, int, java.lang.String, int, java.lang.String[])
	 */
	@SuppressWarnings("unchecked")
	public List<Problem> getAllProblemsAll( int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]) {
	
		Query query = manager
				.createQuery("select p from Problem p  order by "+columns[iSortColumnIndex]+" "+sSortDirection);
					
		query.setFirstResult(iDisplayStart);
		query.setMaxResults(iDisplayLength);

		return query.getResultList();
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.dao.DataTableDAO#getAllProblems(int, int, java.lang.String, int, java.lang.String[])
	 */
	@SuppressWarnings("unchecked")
	public List<Problem> getAllProblems( int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]) {
	
		Query query = manager
				.createQuery("select distinct(t.problem) from TestCase t order by t.problem."+columns[iSortColumnIndex]+" "+sSortDirection);
					
		query.setFirstResult(iDisplayStart);
		query.setMaxResults(iDisplayLength);

		return query.getResultList();
	}
	
	
	/* (non-Javadoc)
	 * @see com.zycus.dao.DataTableDAO#sizeOfProblems()
	 */
	public long sizeOfProblems(){
		
		//return (Long) manager.createQuery("select count(p) from Problem p,TestCase t where  p.problemId = t.problem.problemId").getSingleResult();
		return (Long) manager.createQuery("select count(p) from Problem p where exists (select t.problem.problemId from TestCase t where  p.problemId = t.problem.problemId)").getSingleResult();
	
		
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.dao.DataTableDAO#sizeOfProblems()
	 */
	public long sizeOfProblemsAll(){
		return (Long) manager.createQuery("select count(p) from Problem p").getSingleResult();
				
	}
}
