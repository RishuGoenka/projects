package com.zycus.problem.utility;
import java.io.Console;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.aspose.words.Bookmark;
import com.aspose.words.Cell;
import com.aspose.words.Document;
import com.aspose.words.NodeCollection;
import com.aspose.words.NodeType;
import com.aspose.words.Row;
import com.aspose.words.SaveFormat;
import com.aspose.words.Table;
import com.aspose.words.TableCollection;
import com.zycus.problem.dto.BulkTestCaseDTO;
import com.zycus.problem.dto.TestCaseDTO;


public class TestCaseRead 
{

	static
	{
		com.aspose.words.License license = new com.aspose.words.License();
		try 
		{
			license.setLicense(Thread.currentThread().getContextClassLoader().getResourceAsStream("Aspose.Total.Java.lic"));
		} 
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public  List<List<TestCaseDTO>> read(String s) throws Exception
	{
		Document doc = new Document(s);
	    NodeCollection tables = doc.getChildNodes(NodeType.TABLE, true);
	    Iterator tablesIterator=tables.iterator();

		List<TestCaseDTO> completeTestCases = new ArrayList<TestCaseDTO>();
		List<TestCaseDTO> incompleteTestCases = new ArrayList<TestCaseDTO>();
	    
	    
	    TestCaseDTO testCaseDTO ;
	    while(tablesIterator.hasNext())
	    {
	    	 testCaseDTO = new TestCaseDTO();
			 Table table = (Table)tablesIterator.next();
		    	 for(int j=0;j<3;j++)
		    	 {
			    	 Cell cell = table.getRows().get(0).getCells().get(j);
				    	 if(cell.toTxt().length()!=0)
					    	 {
						    	 switch(j)
						    	 {
							    	    case 0:
							    	    {
							    	    	testCaseDTO.setInput(cell.toTxt().trim());
							    	    	break;
							    	    }
							    	    case 1:
							    	    {
							    	    	testCaseDTO.setOutput(cell.toTxt().trim());
							    	    	break;
							    	    }
							    	    default:
							    	    {
							    	    	 testCaseDTO.setTestCaseDifficulty(cell.toTxt().trim());
							    	    }
							    }		    	
					    	 }		    		 
		    	 }
		    	 if("".equalsIgnoreCase(testCaseDTO.getOutput()) || testCaseDTO.getOutput()==null || "".equalsIgnoreCase(testCaseDTO.getTestCaseDifficulty()) || testCaseDTO.getTestCaseDifficulty()==null)
		    	 {
		    		 incompleteTestCases.add(testCaseDTO);
		    		 tables.iterator().next();
		    	 }
		    	 else
		    	 {
		    		 if(Integer.parseInt(testCaseDTO.getTestCaseDifficulty())<1 || Integer.parseInt(testCaseDTO.getTestCaseDifficulty())>5)
						{
							if(Integer.parseInt(testCaseDTO.getTestCaseDifficulty())<1)
								testCaseDTO.setTestCaseDifficulty("1");
							else
								testCaseDTO.setTestCaseDifficulty("5");
						}
		    		 completeTestCases.add(testCaseDTO);
		    		 tables.iterator().next();
		    	 }
		    	 
	     }
	    
	    List<List<TestCaseDTO>> allTestCases=new ArrayList<List<TestCaseDTO>>();
		allTestCases.add(completeTestCases);
		allTestCases.add(incompleteTestCases);
		return allTestCases;	  
	}
}