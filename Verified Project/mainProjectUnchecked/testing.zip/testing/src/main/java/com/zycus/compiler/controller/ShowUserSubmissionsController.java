package com.zycus.compiler.controller;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.compiler.model.ShowSubmissionsDTO;
import com.zycus.compiler.model.UserSubmission;
import com.zycus.compiler.service.client.ResultAndUserSubmissionService;
import com.zycus.compiler.utility.PathUtil;
import com.zycus.integration.model.UserTest;
import com.zycus.integration.service.UserService;
import com.zycus.integration.service.UserTestService;

@Controller
@RequestMapping("/admin")
public class ShowUserSubmissionsController {

	@Autowired
	UserTestService userTestService;

	@Autowired
	ResultAndUserSubmissionService resultAndUserSubmissionService;

	@Autowired
	UserService userService;

	PathUtil pathUtil=new PathUtil();

	/**
	 * Finds all previous submissions of a user for that test and problem
	 * @param model
	 * @param request
	 * @param response
	 * @return list of submissions(DTO)
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@RequestMapping(value = "/showPreviousSubmissions", method = RequestMethod.GET)
	private String previousSubmissions(ModelAndView model, HttpServletRequest request,
			HttpServletResponse response) throws IOException,
			InterruptedException {

		int userId = userService.getCurrentLoggedInUserId();
		int problemId = Integer.parseInt(request.getParameter("problemId"));
		Object problemSetIdObject = request.getSession().getAttribute(
				"problemSetId");
		if (problemSetIdObject == null)
			return "forward:newTest";
		int problemSetId = (int) problemSetIdObject;
		
		UserTest userTest = userTestService.findUserTest(userId, problemSetId);
		List<UserSubmission> userSubmissions = resultAndUserSubmissionService
				.getAllUserSubmission(problemId, userTest);
		List<ShowSubmissionsDTO> submissions = getSubmissionDTO(userSubmissions);
		request.setAttribute("submissions", submissions);
		return "submissions";
	}

	/**
	 * Converts the List of userSubmission into List of Submission DTO
	 * @param userSubmissions
	 * @return List of Submission DTO
	 */
	private List<ShowSubmissionsDTO> getSubmissionDTO(
			List<UserSubmission> userSubmissions) {
		List<ShowSubmissionsDTO> submissions = new ArrayList<ShowSubmissionsDTO>();
		for (int i = 0; i < userSubmissions.size(); i++) {
			UserSubmission userSubmission = userSubmissions.get(i);
			ShowSubmissionsDTO submission = setAllAttributes(userSubmission);
			submissions.add(submission);
		}
		return submissions;
	}

	/**
	 * Sets all attributes in the Submission DTO object
	 * @param userSubmission
	 * @return updated Submission DTO
	 */
	private ShowSubmissionsDTO setAllAttributes(UserSubmission userSubmission) {
		ShowSubmissionsDTO submission = new ShowSubmissionsDTO();
		submission.setProblemId(userSubmission.getProblem().getProblemId());
		submission.setSubmissionId(userSubmission.getSubmissionId());
		submission.setSubmissionNumber(userSubmission.getVersionNumber());
		submission
				.setUserId(userSubmission.getUserTest().getUser().getUserId());
		submission.setTestId(userSubmission.getUserTest().getUserTestId());
		return submission;
	}

	/**
	 * Responsible for AJAX call, returns the Latest version Code submitted by the user for the specified test and problem
	 * @param model
	 * @param request
	 * @param response
	 * @return The appropriate code submitted by the user
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@RequestMapping(value = "/viewProgram", method = RequestMethod.GET)
	private @ResponseBody String showCode(ModelAndView model, HttpServletRequest request,
			HttpServletResponse response) throws IOException,
			InterruptedException {
		int userId = Integer.parseInt(request.getParameter("userId"));
		int problemId = Integer.parseInt(request.getParameter("problem"));
		int versionNumber = Integer.parseInt(request
				.getParameter("version"));
		int testId = Integer.parseInt(request.getParameter("test"));
		String myCode = getFileAsString(userId, problemId, versionNumber,
				testId);
		return myCode;
	}

	/**
	 * Returns the code in the File of the given path
	 * @param userId
	 * @param problemId
	 * @param versionNumber
	 * @param testId
	 * @return Code in the specified FILE
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private String getFileAsString(int userId, int problemId,
			int versionNumber, int testId) throws FileNotFoundException,
			IOException {
		BufferedReader reader = new BufferedReader(new FileReader(
				pathUtil.getPathForUser(versionNumber, userId, problemId,
						testId)));
		StringBuilder sb = new StringBuilder();
		String line;

		while ((line = reader.readLine()) != null) {
			sb.append(line + "\n");
		}
		reader.close();
		String myCode = sb.toString();
		return myCode;
	}

}
