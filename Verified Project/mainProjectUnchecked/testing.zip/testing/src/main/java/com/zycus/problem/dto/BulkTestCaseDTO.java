package com.zycus.problem.dto;

public class BulkTestCaseDTO {
	
	private String questionNo;
	private String input;
	private String output;
	private String testCaseDifficulty;
	public String getQuestionNo() {
		return questionNo;
	}
	public void setQuestionNo(String questionNo) {
		this.questionNo = questionNo;
	}
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	public String getTestCaseDifficulty() {
		return testCaseDifficulty;
	}
	public void setTestCaseDifficulty(String testCaseDifficulty) {
		this.testCaseDifficulty = testCaseDifficulty;
	}
	
	@Override
	public String toString() {
		return "questionNo=" + questionNo + ", input=" + input
				+ ", output=" + output + ", testCaseDifficulty="
				+ testCaseDifficulty + "\n";
	}

}
