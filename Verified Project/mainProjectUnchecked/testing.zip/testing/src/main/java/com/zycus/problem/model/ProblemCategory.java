package com.zycus.problem.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "category")
public class ProblemCategory implements Serializable {
	private static final long serialVersionUID = 4112206357712072L;

	@Id
	@GeneratedValue
	@Column(name = "category_id")
	private int categoryId;

	@NotNull
	@Column(name = "category_name")
	@NotEmpty(message = "cannot be empty")
	private String categoryName;

	public ProblemCategory() {
		super();
	}

	public ProblemCategory(int categoryId, String categoryName) {
		super();
		this.categoryId = categoryId;
		this.categoryName = categoryName;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	@Override
	public String toString() {
		return "ProblemCategory [categoryId=" + categoryId + ", categoryName="
				+ categoryName + "]";
	}

}
