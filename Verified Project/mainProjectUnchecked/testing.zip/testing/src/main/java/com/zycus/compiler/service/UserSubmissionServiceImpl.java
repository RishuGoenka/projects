package com.zycus.compiler.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.compiler.dao.UserSubmissionDAO;
import com.zycus.compiler.dao.UserSubmissionDAOImpl;
import com.zycus.compiler.model.UserSubmission;
import com.zycus.integration.model.UserTest;

@Service
public class UserSubmissionServiceImpl implements UserSubmissionService {
	@Autowired
	UserSubmissionDAO userSubmissionDao = new UserSubmissionDAOImpl();

	@Override
	public UserSubmission getById(int submissionId) {
		return userSubmissionDao.getById(submissionId);
	}

	@Override
	public void saveUserSubmission(UserSubmission submission) {
		userSubmissionDao.saveUserSubmission(submission);
	}

	public void deleteUserSubmission(UserSubmission submission) {
		userSubmissionDao.deleteUserSubmission(submission);
	}

	@Override
	public int getLatestVersionForUserForProblem(int problemId,
			UserTest userTest) {
		return userSubmissionDao.countUserSubmissionPerUserPerProblem(
				problemId, userTest);
	}

	@Override
	public UserSubmission findByUserTestAndProblemId(int problemId,
			UserTest userTest) {
		return userSubmissionDao
				.findByUserTestAndProblemId(problemId, userTest);
	}

	@Override
	public UserSubmission findByUserTestProblemIdVersionNumber(int problemId,
			UserTest userTest, int versionNumber) {
		return userSubmissionDao.findByUserTestProblemIdVersionNumber(
				problemId, userTest, versionNumber);
	}

	@Override
	public List<UserSubmission> getAllUserSubmission(int problemId, UserTest userTest) {
		return userSubmissionDao.getAllUserSubmission(problemId, userTest);
	}
}
