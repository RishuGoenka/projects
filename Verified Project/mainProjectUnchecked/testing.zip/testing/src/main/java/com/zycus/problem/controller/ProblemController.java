package com.zycus.problem.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.problem.model.Problem;
import com.zycus.problem.model.TestCase;
import com.zycus.problem.service.ProblemService;
import com.zycus.problem.service.TestCaseService;

@Controller
@RequestMapping("/admin")
public class ProblemController {

	@Autowired
	ProblemService problemService;

	@Autowired
	TestCaseService testCaseService;

	/**
	 * redirect to the add single problem page
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(add single problem page)
	 */
	@RequestMapping(value = "/add-problem-redirect", method = RequestMethod.GET)
	public ModelAndView addProblem(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mv = new ModelAndView("admin/add-problem");
		mv.addObject("problem", new Problem());
		return mv;
	}

	/**
	 * add a single problem redirect to add test case for a single problem page
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(add test case for a single problem page)
	 */
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ModelAndView add(@ModelAttribute("problem") @Valid Problem problem,
			BindingResult result, HttpServletRequest request) {
		if (result.hasErrors()) {
			return new ModelAndView("admin/add-problem");
		}
		//int bulk = Integer.parseInt(request.getParameter("bulk"));
		//System.out.println("bulk? " + bulk);
		problemService.add(problem);
		// request.getSession().setAttribute("problem",problem);

		ModelAndView mv = new ModelAndView("admin/individual-test-case");

		mv.addObject("problemId", problem.getProblemId());
		mv.addObject("testCase", new TestCase());

		return mv;
	}

	/**
	 * retrieve all problems create a list of all problems send the list to list
	 * of problems page
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(list of problems page)
	 */
	@RequestMapping(value = "/get-all", method = RequestMethod.GET)
	public ModelAndView getAll(HttpServletRequest request,
			HttpServletResponse response) {
		List<Problem> problems = problemService.getAllProblems();
		ModelAndView mv = new ModelAndView("admin/list-problems");
		mv.addObject("problems", problems);
		return mv;
	}

	/**
	 * retrieve list of problems sorted by a given attribute(name, category or
	 * difficulty) and send the list to list of problems page
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(list of problems page)
	 */
	@RequestMapping(value = "/sort-by", method = RequestMethod.GET)
	public ModelAndView sortBy(HttpServletRequest request,
			HttpServletResponse response) {
		List<Problem> problems = new ArrayList<Problem>();
		String sortByAttribute = request.getParameter("sortby");
		if (sortByAttribute.equals("name")) {
			problems = problemService.sortByName();
		} else if (sortByAttribute.equals("category")) {
			problems = problemService.sortByCategory();
		} else {
			problems = problemService.sortByDifficulty();
		}
		ModelAndView mv = new ModelAndView("admin/problem-list");
		mv.addObject("problems", problems);
		return mv;
	}

	/**
	 * retrieve list of problems searched by a given value of a given
	 * attribute(name, category or difficulty) and send the list to list of
	 * problems page
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(list of problems page)
	 */
	@RequestMapping(value = "/search-by", method = RequestMethod.GET)
	public ModelAndView searchBy(HttpServletRequest request,
			HttpServletResponse response) {
		List<Problem> problems = new ArrayList<Problem>();
		String searchByAttribute = request.getParameter("searchby");
		if (searchByAttribute.equals("name")) {
			problems = problemService.getByName(request
					.getParameter("searchbykey"));
		} else if (searchByAttribute.equals("category")) {
			problems = problemService.getByCategory(request
					.getParameter("searchbykey"));
		} else {
			problems = problemService.getByDifficulty(request
					.getParameter("searchbykey"));
		}
		ModelAndView mv = new ModelAndView("admin/problem-list");
		mv.addObject("problems", problems);
		return mv;
	}

	/**
	 * view a single problem when clicked on a problem in the list of problems
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(view single problem details page)
	 */
	@RequestMapping(value = "/view-problem", method = RequestMethod.GET)
	public ModelAndView viewProblem(HttpServletRequest request,
			HttpServletResponse response) {
		Problem problem = problemService.getByID(Integer.parseInt(request
				.getParameter("problemId")));
		ModelAndView mv = new ModelAndView("admin/problem-view");
		mv.addObject("problem", problem);
		return mv;
	}

	/**
	 * edit a single problem when clicked on a problem in the list of problems
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(view problem list page)
	 */
	@RequestMapping(value = "/edit-problem", method = RequestMethod.POST)
	public ModelAndView editProblem(
			@ModelAttribute("problem") @Valid Problem problem,
			BindingResult result, HttpServletRequest request) {
		if (result.hasErrors()) {
			return new ModelAndView("admin/edit-problem");
		}
		problemService.update(problem);
		ModelAndView mv = new ModelAndView("redirect:get-all");
		return mv;
	}

	/**
	 * edit a single problem when clicked on a problem in the list of problems
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(view problem list page)
	 */
	@RequestMapping(value = "/edit-problem-page", method = RequestMethod.GET)
	public ModelAndView editProblemPage(HttpServletRequest request,
			HttpServletResponse response) {
		Problem problem = problemService.getByID(Integer.parseInt(request
				.getParameter("problemId")));
		ModelAndView mv = new ModelAndView("admin/problem-edit");
		mv.addObject("problem", problem);
		return mv;
	}

	/**
	 * delete a single problem when clicked on a problem in the list of problems
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(view problem list page)
	 */
	@RequestMapping(value = "/delete-problem", method = RequestMethod.GET)
	public ModelAndView deleteProblem(HttpServletRequest request,
			HttpServletResponse response) {
		Problem problem = problemService.getByID(Integer.parseInt(request
				.getParameter("problemId")));
		testCaseService.deleteByProblem(problem);
		problemService.delete(problem);
		ModelAndView mv = new ModelAndView("redirect:get-all");
		return mv;
	}

	/**
	 * retrieve all test cases of one problem create a list of all test cases of
	 * one problem send the list to list of test cases page
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(list of test cases page)
	 */
	@RequestMapping(value = "/view-test-cases")
	public ModelAndView viewTestCases(HttpServletRequest request,
			HttpServletResponse response) {
		List<TestCase> testCases = testCaseService.getTestCaseByProblem(Integer
				.parseInt(request.getParameter("problemId")));
		ModelAndView mv = new ModelAndView("admin/test-case-list");
		mv.addObject("testCases", testCases);
		return mv;
	}

	/**
	 * delete a single problem when clicked on a problem in the list of problems
	 * 
	 * @param request
	 * @param response
	 * @return model and view object(view problem list page)
	 */
	@RequestMapping(value = "/delete-test-case", method = RequestMethod.GET)
	public ModelAndView deleteTestCases(HttpServletRequest request,
			HttpServletResponse response) {
		TestCase testCase = testCaseService.getByID(Integer.parseInt(request
				.getParameter("testCaseId")));
		System.out.println(testCase);
		try {
			testCaseService.delete(testCase);
		} catch (RuntimeException e) {
			System.err.println("Violations"+e);
			ModelAndView mv = new ModelAndView("redirect:view-test-cases");
			mv.addObject("problemId", testCase.getProblem().getProblemId());
			return mv;
		}
		ModelAndView mv = new ModelAndView("redirect:view-test-cases");
		mv.addObject("problemId", testCase.getProblem().getProblemId());
		return mv;
	}
}
