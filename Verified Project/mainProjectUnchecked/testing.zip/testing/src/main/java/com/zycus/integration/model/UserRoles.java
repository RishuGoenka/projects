package com.zycus.integration.model;

public class UserRoles {

	public static final String USER = "ROLE_USER";
	public static final String ADMIN = "ROLE_ADMIN";

}
