package com.zycus.integration.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.integration.model.ProblemSet;

@Repository
@Transactional
public class ProblemSetDAOImpl implements ProblemSetDAO {

	@PersistenceContext
	private EntityManager manager;

	/**
	 * save ProblemSet Object
	 * 
	 * @param problemSet
	 * @return boolean
	 */
	@Override
	public ProblemSet save(ProblemSet problemSet) {
		try {
			manager.persist(problemSet);
			return problemSet;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * get all the ProblemSet
	 * 
	 * @return List of ProblemSet
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ProblemSet> getAllProblemSet() {
		List<ProblemSet> problemSetList = manager.createQuery(
				"select ps from ProblemSet ps").getResultList();
		return problemSetList;
	}

	/**
	 * update ProblemSet
	 * 
	 * @param problemSetObject
	 * @return boolean
	 */
	@Override
	public boolean update(ProblemSet problemSetObject) {
		try {

			manager.merge(problemSetObject);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	/**
	 * Find a problem set by sharedId
	 * 
	 * @param sharedId
	 * @return problem set
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ProblemSet findBySharedId(String sharedId) {
		List<ProblemSet> problemSets = (List<ProblemSet>) manager
				.createQuery(
						"Select p from ProblemSet p where p.sharedId =:sharedId")
				.setParameter("sharedId", sharedId).getResultList();

		if (problemSets.size() >= 1) {
			return problemSets.get(0);
		} else {
			return null;
		}
	}

	/**
	 * Delete a problemSet object
	 * 
	 * @param problemSet
	 *            object
	 * @return boolean
	 */
	@Override
	public boolean delete(int problemSetId) {
		try {
			ProblemSet problemSet = manager.find(ProblemSet.class, problemSetId);
			manager.remove(problemSet);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Find problem set by problem set id
	 * 
	 * @param problemSetId
	 */
	@Override
	public ProblemSet findById(int problemSetId) {

		return manager.find(ProblemSet.class, problemSetId);
	}

	// Data Table

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.dao.DataTableDAO#search(java.lang.String, int, int,
	 * java.lang.String, int, java.lang.String[])
	 */
	@SuppressWarnings("unchecked")
	public List<ProblemSet> search(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection, int iSortColumnIndex,
			String columns[]) {
		
		Query query = manager
					.createQuery("select p from ProblemSet p where p.problemSetName like ? "
							+ " or p.sharedId like ? order by "
							+ columns[iSortColumnIndex] + " " + sSortDirection);

			query.setParameter(1, "%" + sSearch + "%")
					.setParameter(2, "%" + sSearch + "%");

	

		query.setFirstResult(iDisplayStart);
		query.setMaxResults(iDisplayLength);

		return query.getResultList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.dao.DataTableDAO#searchCount(java.lang.String, int, int,
	 * java.lang.String, int, java.lang.String[])
	 */
	public long searchCount(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection, int iSortColumnIndex,
			String columns[]) {

		Query query = manager
				.createQuery("select count(p) from ProblemSet p where p.problemSetName like ? "
						+ " or p.sharedId like ? order by "
						+ columns[iSortColumnIndex] + " " + sSortDirection);

		query.setParameter(1, "%" + sSearch + "%")
				.setParameter(2, "%" + sSearch + "%");

		return (Long) query.getSingleResult();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.dao.DataTableDAO#getAllProblems(int, int,
	 * java.lang.String, int, java.lang.String[])
	 */
	@SuppressWarnings("unchecked")
	public List<ProblemSet> getAllProblems(int iDisplayLength,
			int iDisplayStart, String sSortDirection, int iSortColumnIndex,
			String columns[]) {

		Query query = manager
				.createQuery("select p from ProblemSet p  order by "
						+ columns[iSortColumnIndex] + " " + sSortDirection);

		query.setFirstResult(iDisplayStart);
		query.setMaxResults(iDisplayLength);

		return query.getResultList();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.dao.DataTableDAO#sizeOfProblems()
	 */
	public long sizeOfProblems() {
		return (Long) manager.createQuery("select count(p) from ProblemSet p")
				.getSingleResult();

	}

}
