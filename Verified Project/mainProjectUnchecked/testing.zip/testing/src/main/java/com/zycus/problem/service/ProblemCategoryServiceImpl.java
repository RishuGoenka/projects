package com.zycus.problem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.problem.dao.ProblemCategoryDAO;
import com.zycus.problem.model.ProblemCategory;

@Service
public class ProblemCategoryServiceImpl implements ProblemCategoryService {

	@Autowired
	ProblemCategoryDAO categoryDao;

	@Override
	public List<ProblemCategory> getAllCategory() {
		return categoryDao.getAllCategory();
	}

	@Override
	public ProblemCategory getById(int categoryId) {
		return categoryDao.getById(categoryId);
	}

	@Override
	public void delete(ProblemCategory category) {
		categoryDao.delete(category);
	}

	@Override
	public void add(ProblemCategory category) {
		categoryDao.add(category);
	}

	@Override
	public void update(ProblemCategory category) {
		categoryDao.update(category);
	}

	@Override
	public List<ProblemCategory> searchCategory(String keyString) {
		return categoryDao.searchCategory(keyString);
	}
}
