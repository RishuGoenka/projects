package com.zycus.integration.controller;

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.zycus.integration.model.ProblemSet;
import com.zycus.integration.model.ProblemSetDataTableParam;
import com.zycus.integration.model.TableParams;
import com.zycus.integration.service.DataTableService;
import com.zycus.integration.service.MappedProblemService;
import com.zycus.integration.service.ProblemSetService;
import com.zycus.integration.service.UserTestService;
import com.zycus.integration.utility.ProblemSetDataTablesParamUtility;
import com.zycus.problem.model.Problem;
import com.zycus.problem.service.ProblemService;




@Controller
@RequestMapping("/admin")
public class Admin2Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Autowired
	DataTableService dataTableService;
	
	@Autowired
	ProblemService problemService;
	
	@Autowired
	ProblemSetService problemSetService;
	
	@Autowired
	MappedProblemService mappedProblemService;
	
	@Autowired
	UserTestService userTestService;
	
	//it will contain the problems which are to be added in set 
		static Set<Problem> setOfProblems;
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(path = "/searchProblem", method = RequestMethod.GET)
	public void createNewProblem(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		ProblemSetDataTableParam param = ProblemSetDataTablesParamUtility.getParam(request);
		
		String sEcho = param.sEcho;
		int iTotalRecords; // total number of records (unfiltered)
		int iTotalDisplayRecords; //value will be set when code filters companies by keyword
	
		//find sorting column index
		final int sortColumnIndex = param.iSortColumnIndex;
		if(sortColumnIndex == 3){
			return;
		}
		//set sort direction
		final String sortDirection = param.sSortDirection.equals("asc") ? "desc" : "asc";
		
		//find total records in database
		iTotalRecords = (int) dataTableService.sizeOfProblems();
		
		List<TableParams> problems = new LinkedList<TableParams>();
		
		String columns[] ={"problemName","problemCategory","difficulty"}; 
		if(param.sSearch==""){
			problems = dataTableService.noSearch(param,sortColumnIndex,sortDirection,columns);
			iTotalDisplayRecords = iTotalRecords;
		}
		else{
			iTotalDisplayRecords = (int) dataTableService.searchCount(param.sSearch,
					param.iDisplayLength, param.iDisplayStart, sortDirection, sortColumnIndex, columns);
			problems = dataTableService.newSearch(param, sortColumnIndex, sortDirection, columns);			
		}
			
		try {	
			JsonObject jsonResponse = new JsonObject();		
			jsonResponse.addProperty("sEcho", sEcho);
			jsonResponse.addProperty("iTotalRecords", iTotalRecords);
			jsonResponse.addProperty("iTotalDisplayRecords", iTotalDisplayRecords);			
			Gson gson = new Gson();
			jsonResponse.add("aaData", gson.toJsonTree(problems));
			
			response.setContentType("application/Json");
			response.getWriter().print(jsonResponse.toString());
			
		} catch (JsonIOException e) {
			e.printStackTrace();
			response.setContentType("text/html");
			response.getWriter().print(e.getMessage());
		}	
	}
	
	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(path = "/searchProblemAll", method = RequestMethod.GET)
	public void createNewProblemAll(HttpServletRequest request, HttpServletResponse response) throws IOException {
		
		ProblemSetDataTableParam param = ProblemSetDataTablesParamUtility.getParam(request);
		
		String sEcho = param.sEcho;
		int iTotalRecords; // total number of records (unfiltered)
		int iTotalDisplayRecords; //value will be set when code filters companies by keyword
	
		//find sorting column index
		final int sortColumnIndex = param.iSortColumnIndex;
		if(sortColumnIndex == 3){
			return;
		}
		//set sort direction
		final String sortDirection = param.sSortDirection.equals("asc") ? "desc" : "asc";
		
		//find total records in database
		iTotalRecords = (int) dataTableService.sizeOfProblemsAll();
		
		List<TableParams> problems = new LinkedList<TableParams>();
		
		String columns[] ={"problemName","problemCategory","difficulty"}; 
		if(param.sSearch==""){
			problems = dataTableService.noSearchAll(param,sortColumnIndex,sortDirection,columns);
			iTotalDisplayRecords = iTotalRecords;
		}
		else{
			iTotalDisplayRecords = (int) dataTableService.searchCountAll(param.sSearch,
					param.iDisplayLength, param.iDisplayStart, sortDirection, sortColumnIndex, columns);
			problems = dataTableService.newSearchAll(param, sortColumnIndex, sortDirection, columns);			
		}
			
		try {	
			JsonObject jsonResponse = new JsonObject();		
			jsonResponse.addProperty("sEcho", sEcho);
			jsonResponse.addProperty("iTotalRecords", iTotalRecords);
			jsonResponse.addProperty("iTotalDisplayRecords", iTotalDisplayRecords);			
			Gson gson = new Gson();
			jsonResponse.add("aaData", gson.toJsonTree(problems));
			
			response.setContentType("application/Json");
			response.getWriter().print(jsonResponse.toString());
			
		} catch (JsonIOException e) {
			e.printStackTrace();
			response.setContentType("text/html");
			response.getWriter().print(e.getMessage());
		}	
	}
	
	/**
	 * @return
	 */
	@RequestMapping(path = "/newProblemSet", method = RequestMethod.GET)
	public ModelAndView createNewProblem() {
		ModelAndView mv =new ModelAndView("admin/all-problems");
		setOfProblems = new  HashSet<Problem>();
		ProblemSet problemSet = new ProblemSet();
		mv.addObject("problemSet", problemSet);
		mv.addObject("function","Create Test");
		mv.addObject("action","createProblemSet");
		return mv;
		
	}
	
	/**
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(path = "/editingProblemSet", method = RequestMethod.GET)
	public ModelAndView editProblemSetSetUp(HttpServletRequest request,
			HttpServletResponse response) {
		
		int problemSetId = Integer.parseInt(request.getParameter("problemSetId"));
		setOfProblems = new  HashSet<Problem>();
		if(userTestService.getUsersByTest(problemSetId).isEmpty()){
			ModelAndView mv =new ModelAndView("admin/all-problems");
			ProblemSet problemSet = problemSetService.findProblemSetById(problemSetId);
			setOfProblems = mappedProblemService.findProblemInSet(problemSetId);
			mv.addObject("problemSet", problemSet);
			mv.addObject("function","Edit Test");
			mv.addObject("action","editProblemSet");
			return mv;
		}else{
				ModelAndView mv =new ModelAndView("forward:viewTestList");
				mv.addObject("msg", "Cannot edit test because this test is already given by some users. Create new test");
				return mv;
			
		}
		
		
	}
	

	
	/**
	 * @param problemSet
	 * @param result
	 * @return
	 */
	@RequestMapping(path = "/editProblemSet", method = RequestMethod.POST)
	public ModelAndView editProblemSet(@ModelAttribute("problemSet") @Valid ProblemSet problemSet, BindingResult result){
		
		if (result.hasErrors()) {
			ModelAndView mv =new ModelAndView("admin/all-problems");
			mv.addObject("function","Edit Test");
			mv.addObject("action","editProblemSet");
			return mv;
		}
		
		ModelAndView modelAndView =  new ModelAndView("/admin/view-test");
		
		ProblemSet existingProblemSet = problemSetService.findProblemSetBySharedId(problemSet.getSharedId());
		existingProblemSet.setDuration(problemSet.getDuration());
		existingProblemSet.setProblemSetName(problemSet.getProblemSetName());
		
		problemSetService.update(existingProblemSet);
		
		Set<Problem> problemList = new HashSet<Problem>();
		
		problemList = mappedProblemService.findProblemInSet(existingProblemSet.getProblemSetId());
		
		
		for (Problem problem : setOfProblems) {
			
			if(!problemList.contains(problem)){
				mappedProblemService.addMappedProblem(problem,existingProblemSet);
			}
			
		}
		
		for (Problem problem : problemList) {
			
			if(!setOfProblems.contains(problem)){
				
				mappedProblemService.deleteMappedProblem(existingProblemSet,problem);
			}
			
		}
		
		
		modelAndView.addObject("problemSetId",existingProblemSet.getProblemSetId());
		
		setOfProblems.clear();
		modelAndView.addObject("msg", "Test edited successfully");
		return modelAndView;
		
	}
	
	/**
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(path = "/deleteProblemSet", method = RequestMethod.GET)
	public ModelAndView deleteProblemSet(HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("in delete controller");
		ModelAndView mv =new ModelAndView("admin/view-test-list");
		int problemSetId = Integer.parseInt(request.getParameter("problemSetId"));
		System.out.println("user "+userTestService.getUsersByTest(problemSetId));
		if(userTestService.getUsersByTest(problemSetId).isEmpty()){
			
			ProblemSet problemSet = problemSetService.findProblemSetById(problemSetId);
		
			Set<Problem> problemsInSet = mappedProblemService.findProblemInSet(problemSetId);
			
			System.out.println(problemsInSet);
			
			for (Problem problem2 : problemsInSet) {
				mappedProblemService.deleteMappedProblem(problemSet, problem2);
			}
			mv.addObject("msg","Test deleted successfully");
			problemSetService.delete(problemSetId);
			return mv;
		}
		else{
			
			mv.addObject("msg","Cannot delete this test");
			return mv;
		}
	}
	

	
	/**
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	@RequestMapping(path = "/addQuestionToSet", method = RequestMethod.GET)
	public @ResponseBody Set<Problem> addQuestionSet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AJAX HERE!");
		int questionId = Integer.parseInt(request.getParameter("id"));
		Problem problem = problemService.getByID(questionId);
		
		setOfProblems.add(problem);
		//System.out.println(setOfProblems);
		System.out.println("@"+setOfProblems.size()+" added");
		return setOfProblems; 
		
	}
	
	/**
	 * @param problemSet
	 * @param result
	 * @return
	 */
	@RequestMapping(path="/createProblemSet")
	public ModelAndView createProblemSet(@ModelAttribute("problemSet") @Valid ProblemSet problemSet, BindingResult result){
		
		if (result.hasErrors()) {
			
			ModelAndView mv =new ModelAndView("admin/all-problems");
			mv.addObject("function","Create Test");
			mv.addObject("action","createProblemSet");
			return mv;
		}
		
		ModelAndView modelAndView =  new ModelAndView("/admin/view-test");
		problemSet = problemSetService.save(problemSet);
		mappedProblemService.addProblemsList(setOfProblems, problemSet);
		modelAndView.addObject("problemSetId",problemSet.getProblemSetId());
		
		setOfProblems.clear();
		
		return modelAndView;
		
	}
	
	/**
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	@RequestMapping(path="/questionTable")
	public @ResponseBody Set<Problem> returnQuestionSet() throws ServletException, IOException {
		return setOfProblems;
	}
	
	
	/**
	 * @param request
	 * @param response
	 * @return
	 * @throws ServletException
	 * @throws IOException
	 */
	@RequestMapping(path = "/removeQuestionfromSet", method = RequestMethod.GET)
	public @ResponseBody Set<Problem> removeQuestionSet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AJAX HERE!");
		int questionId = Integer.parseInt(request.getParameter("id"));
		Problem problem = problemService.getByID(questionId);
		System.out.println(problem.toString());
		setOfProblems.remove(problem);
		
		System.out.println("Inside remove");
		System.out.println("@"+setOfProblems.size()+" removed");
		return setOfProblems;
	}
}
