package com.zycus.problem.service;

import java.util.List;

import com.zycus.problem.model.Problem;
import com.zycus.problem.model.TestCase;

public interface TestCaseService {

	public abstract void add(TestCase object);

	public abstract void update(TestCase updatedTestCase);

	public abstract void delete(TestCase testcase);
	
	public abstract void deleteByProblem(Problem problem); 

	public abstract TestCase getByID(int testCaseId);

	public abstract List<TestCase> getTestCaseByProblem(int problem_id);

	public abstract List<String> getInputByProblem(int problemId);

	public abstract List<String> getOutputByProblem(int problem);

}