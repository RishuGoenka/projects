package com.zycus.integration.dao;


import java.util.List;

import com.zycus.compiler.model.UserSubmission;
import com.zycus.integration.model.ProblemSet;
import com.zycus.integration.model.SubmissionScore;
import com.zycus.integration.model.UserTest;

public interface SubmissionScoreDAO {
	
	/**
	 * Saves the submission Score
	 * Return true if saved succefully
	 * @param submissionScore
	 * @return true/false
	 */
	public abstract boolean save(SubmissionScore submissionScore);
	
	/**
	 * Updates SubmissionScore object 
	 * It does this by checking the SubmissionScoreId. 
	 * Thus necessary the paramater passed to it consist of submissionScoreId
	 * 
	 * Return true if saved succefully
	 * @param submissionScore
	 * @return true/false
	 */
	public abstract boolean update(SubmissionScore submissionScore);
	
	/**
	 * Find SubmissionScore by submissionScoreId
	 * If Id does not exist returns null
	 * @param submsissionScoreId
	 * @return SubmissionScore
	 */
	public abstract SubmissionScore findById(int submsissionScoreId);
	
	/**
	 * Find SubmissionScore by UserSubmission
	 * necessary the paramater passed to it consist of userSubmissionId
	 * If Id does not exist returns null
	 * @param userSubmission
	 * @return
	 */
	public abstract SubmissionScore findByUserSubmission(UserSubmission userSubmission);
	
	/**
	 * Returns a list of SubmissionScore by test id
	 * @param userTest
	 * @return
	 */
	public abstract List<Object[]> findByProblemSet(ProblemSet problemSet, int maxResults);



	List<Object[]> findByProblemSetAndSearchByNameOrEmail(
			ProblemSet problemSet, String search);

}
