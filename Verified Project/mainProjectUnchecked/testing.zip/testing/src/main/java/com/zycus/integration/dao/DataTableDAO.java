package com.zycus.integration.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.problem.model.Problem;

@Repository
public interface DataTableDAO {
	public abstract List<Problem> search(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]);
	public abstract long searchCount(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]);
	public abstract List<Problem> getAllProblems( int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]);
	public abstract long sizeOfProblems();
	
	public List<Problem> searchAll(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]);
	public long searchCountAll(String sSearch, int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]);
	public List<Problem> getAllProblemsAll( int iDisplayLength,
			int iDisplayStart, String sSortDirection,int iSortColumnIndex, String columns[]);
	public long sizeOfProblemsAll();
}
