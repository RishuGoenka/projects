package com.zycus.integration.model;

import com.zycus.compiler.model.UserSubmission;

public class ReportDTO {


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + problemSetScore;
		result = prime * result
				+ ((userEmail == null) ? 0 : userEmail.hashCode());
		result = prime * result
				+ ((userFirstName == null) ? 0 : userFirstName.hashCode());
		result = prime * result
				+ ((userLastName == null) ? 0 : userLastName.hashCode());
		result = prime * result
				+ ((userSubmission == null) ? 0 : userSubmission.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReportDTO other = (ReportDTO) obj;
		if (problemSetScore != other.problemSetScore)
			return false;
		if (userEmail == null) {
			if (other.userEmail != null)
				return false;
		} else if (!userEmail.equals(other.userEmail))
			return false;
		if (userFirstName == null) {
			if (other.userFirstName != null)
				return false;
		} else if (!userFirstName.equals(other.userFirstName))
			return false;
		if (userLastName == null) {
			if (other.userLastName != null)
				return false;
		} else if (!userLastName.equals(other.userLastName))
			return false;
		if (userSubmission == null) {
			if (other.userSubmission != null)
				return false;
		} else if (!userSubmission.equals(other.userSubmission))
			return false;
		return true;
	}

	public Object userFirstName;
	public Object userLastName;
	public Object userEmail;
	public int problemSetScore;

	public Object userSubmission;

	public Object getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(Object userFirstName) {
		this.userFirstName = userFirstName;
	}

	public Object getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(Object userLastName) {
		this.userLastName = userLastName;
	}

	public Object getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(Object userEmail) {
		this.userEmail = userEmail;
	}

	public int getProblemSetScore() {
		return problemSetScore;
	}

	public void setProblemSetScore(int problemSetScore) {
		this.problemSetScore = problemSetScore;
	}

	public Object getUserSubmission() {
		return userSubmission;
	}

	public void setUserSubmission(Object userSubmission) {
		this.userSubmission = userSubmission;
	}


}
