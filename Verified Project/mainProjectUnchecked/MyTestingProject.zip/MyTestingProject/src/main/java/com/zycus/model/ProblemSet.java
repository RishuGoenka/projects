package com.zycus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "problem_set")
public class ProblemSet {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="problem_set_id")
	private int problemSetId;

	@Column(name = "shared_id", nullable = false)
	private String sharedId;

	@Column(name="duration")
	private int duration;

	@Column(name = "problem_set_name")
	private String problemSetName;

	public ProblemSet(String sharedId, int duration, String problemSetName) {
		super();
		this.sharedId = sharedId;
		this.duration = duration;
		this.problemSetName = problemSetName;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}

	public String getProblemSetName() {
		return problemSetName;
	}

	public void setProblemSetName(String problemSetName) {
		this.problemSetName = problemSetName;
	}

	public int getProblemSetId() {
		return problemSetId;
	}

	public void setProblemSetId(int problemSetId) {
		this.problemSetId = problemSetId;
	}

	public ProblemSet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getSharedId() {
		return sharedId;
	}

	public void setSharedId(String sharedId) {
		this.sharedId = sharedId;
	}

}
