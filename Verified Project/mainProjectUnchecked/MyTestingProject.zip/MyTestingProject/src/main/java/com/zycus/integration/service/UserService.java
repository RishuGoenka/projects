package com.zycus.integration.service;

import java.sql.Time;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.zycus.integration.dao.UserDAO;
import com.zycus.model.User;
import com.zycus.model.UserRoles;

@Component
public class UserService {

	@Autowired
	private UserDAO userDAO;

	
	
	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

	/**
	 * Finds a user by email id
	 * 
	 * @param email
	 * @return
	 */
	public User findByEmail(String email) {

		return userDAO.getUserByEmail(email);
	}

	/**
	 * Adds an user
	 * @param user
	 * @return
	 */
	public boolean addUser(User user) {

		if (userDAO.isEmailAvailable(user.getEmail())) {

			return false;

		} else {

			Time currentTime = new Time(new Date().getTime());
			user.setRegistrationTime(currentTime);

			user.setRole(UserRoles.USER); // to be modified

			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			String hashedPassword = passwordEncoder.encode(user.getPassword());
			user.setPassword(hashedPassword);

			userDAO.save(user);
			return true;
		}

	}

}
