package com.zycus.integration.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.core.GrantedAuthority;

import com.zycus.model.User;
import com.zycus.model.UserPrincipal;

@Service("customUserDetailsService")
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	UserService userService;

	/**
	 * Loads user by email, this is called by spring service
	 */
	@Transactional(readOnly = true)
	public UserDetails loadUserByUsername(String email)
			throws UsernameNotFoundException {

		System.out.println(email);

		User user = userService.findByEmail(email);

		 System.out.println("User : " + user);

		if (user == null) {
			System.out.println("User not found");
			throw new UsernameNotFoundException("Username not found");
		}

		GrantedAuthority authority = new SimpleGrantedAuthority(user.getRole());

		UserPrincipal principal = new UserPrincipal(user.getEmail(),
				user.getPassword(), Arrays.asList(authority));

		principal.setUser(user);

		return principal;
	}

}