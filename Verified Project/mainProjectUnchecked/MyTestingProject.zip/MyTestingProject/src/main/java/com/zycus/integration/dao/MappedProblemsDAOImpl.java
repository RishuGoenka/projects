package com.zycus.integration.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;






import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.model.MappedProblems;
import com.zycus.model.Problem;

@Transactional
@Repository
public class MappedProblemsDAOImpl implements MappedProblemsDAO{

	@PersistenceContext
	EntityManager manager;
	public MappedProblemsDAOImpl() {
		// TODO Auto-generated constructor stub
	
	}
	
	/**
	 * Save Mapped Problem
	 * @param mappedProblems
	 */ 
	public boolean save(MappedProblems mappedProblems){
		try{
			manager.persist(mappedProblems);
				return true;
		}catch(Exception e){
			e.printStackTrace();
				return false;
			}
		} 

	
	/**
	 * find the test by id
	 * @param sharedId
	 * @return List of Problem
	 */
	@SuppressWarnings("unchecked")
	public List<Problem> findBySharedId(String sharedId) {
		
		List<Problem> problems = (List<Problem>) manager.createQuery("Select p.problem from MappedProblems p where p.problemSet.sharedId =:sharedId").setParameter("sharedId", sharedId).getResultList();
		return problems;
		
	}

	/**
	 * finds a problem belongs to which problem set
	 * @param problemId
	 * @return List of Problem
	 */
	@SuppressWarnings("unchecked")
	public List<Problem> findByProblemId(int problemId){
		
		List<Problem> problem = (List<Problem>) manager.createQuery("Select p.problem from ProblemMapped p where p.problemId =:problemId").setParameter("problemId", problemId).getSingleResult();
		return problem;
		
	}
	


}
