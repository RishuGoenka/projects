package com.zycus.compiler.dao;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TransactionRequiredException;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.zycus.compiler.utility.CustomCompilerException;
import com.zycus.model.UserSubmission;
import com.zycus.model.UserTest;

@Repository
@Transactional
public class UserSubmissionDAOImpl implements UserSubmissionDAO {
	@PersistenceContext
	private EntityManager manager;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.dao.UserSubmissionDAO#getById(int)
	 */
	@Override
	public UserSubmission getById(int submissionId) {
		try {
			return manager.find(UserSubmission.class, submissionId);
		} catch (IllegalArgumentException e2) {
			throw new CustomCompilerException(
					CustomCompilerException.ILLEGAL_ARGUEMENT_EXCEPTION);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.dao.UserSubmissionDAO#saveUserSubmission(com.zycus.model.
	 * UserSubmissionEntity)
	 */
	@Override
	public void saveUserSubmission(UserSubmission submission) {
		try {
			manager.persist(submission);
		} catch (EntityExistsException e1) {
			throw new CustomCompilerException(
					CustomCompilerException.ENTITY_EXISTS_EXCEPTION);
		} catch (IllegalArgumentException e2) {
			throw new CustomCompilerException(
					CustomCompilerException.ILLEGAL_ARGUEMENT_EXCEPTION);
		} catch (TransactionRequiredException e3) {
			throw new CustomCompilerException(
					CustomCompilerException.TRANSACTION_REQUIRED_EXCEPTION);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.zycus.dao.UserSubmissionDAO#deleteUserSubmission(com.zycus.model.
	 * UserSubmissionEntity)
	 */
	@Override
	public void deleteUserSubmission(UserSubmission submission) {
		try {
			manager.remove(submission);
		} catch (IllegalArgumentException e2) {
			throw new CustomCompilerException(
					CustomCompilerException.ILLEGAL_ARGUEMENT_EXCEPTION);
		} catch (TransactionRequiredException e3) {
			throw new CustomCompilerException(
					CustomCompilerException.TRANSACTION_REQUIRED_EXCEPTION);
		}
	}

	@Override
	public int countUserSubmissionPerUserPerProblem(int problemId,
			UserTest userTest) {
		int count = 0;

		try {
			count = (int) manager
					.createQuery(
							"Select table1.versionNumber From UserSubmission table1 Where table1.userTest.user.userId = ? AND table1.userTest.problemSet.problemSetId = ? AND table1.problem.problemId = ? order by submissionId DESC")
					.setParameter(1, userTest.getUser().getUserId())
					.setParameter(2, userTest.getProblemSet().getProblemSetId())
					.setParameter(3, problemId).getResultList().get(0);
		} catch (NullPointerException e1) {
			// Since there are no submissions present the current version is 1,
			// so no need to do anything
		} catch (IllegalArgumentException e2) {
			throw new CustomCompilerException(
					CustomCompilerException.ILLEGAL_ARGUEMENT_EXCEPTION);
		}
		return ++count;
	}

	@Override
	public UserSubmission findByUserTestAndProblemId(int problemId,
			UserTest userTest) {
		UserSubmission userSubmission = new UserSubmission();
		try {
			userSubmission = (UserSubmission) manager
					.createQuery(
							"From UserSubmission table1 Where table1.userTest.user.userId = ? AND table1.userTest.problemSet.problemSetId = ? AND table1.problem.problemId = ? order by submissionId DESC")
					.setParameter(1, userTest.getUser().getUserId())
					.setParameter(2, userTest.getProblemSet().getProblemSetId())
					.setParameter(3, problemId).getResultList().get(0);
		} catch (IllegalArgumentException e2) {
			throw new CustomCompilerException(
					CustomCompilerException.ILLEGAL_ARGUEMENT_EXCEPTION);
		}
		return userSubmission;
	}

	@Override
	public UserSubmission findByUserTestProblemIdVersionNumber(int problemId,
			UserTest userTest, int versionNumber) {
		UserSubmission userSubmission = new UserSubmission();
		try {
			userSubmission = (UserSubmission) manager
					.createQuery(
							"From UserSubmission table1 Where table1.userTest.user.userId = ? AND table1.userTest.problemSet.problemSetId = ? AND table1.problem.problemId = ? AND table1.versionNumber=?")
					.setParameter(1, userTest.getUser().getUserId())
					.setParameter(2, userTest.getProblemSet().getProblemSetId())
					.setParameter(3, problemId).setParameter(4, versionNumber)
					.getSingleResult();
		} catch (IllegalArgumentException e2) {
			throw new CustomCompilerException(
					CustomCompilerException.ILLEGAL_ARGUEMENT_EXCEPTION);
		}
		return userSubmission;
	}
}