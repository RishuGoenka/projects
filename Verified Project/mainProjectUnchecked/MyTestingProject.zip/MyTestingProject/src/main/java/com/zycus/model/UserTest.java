package com.zycus.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_test")
public class UserTest {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "user_test_id")	
	private int userTestId;

	
	
	@OneToOne
	private ProblemSet problemSet;	

	
	@OneToOne
	private User user;

	
	@Column(name="start_time")
	private Date startTime;

	public int getUserTestId() {
		return userTestId;
	}


	public void setUserTestId(int userTestId) {
		this.userTestId = userTestId;
	}


	public ProblemSet getProblemSet() {
		return problemSet;
	}


	public void setProblemSet(ProblemSet problemSet) {
		this.problemSet = problemSet;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User
			user) {
		this.user = user;
	};	
	
	
	public Date getStartTime() {
		return startTime;
	}


	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}


	public UserTest(ProblemSet problemSet, User user) {
		super();
		this.problemSet = problemSet;
		this.user = user;
	}


	public UserTest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}

