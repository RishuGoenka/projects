package com.zycus.integration.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import com.zycus.model.UserSubmission;

@Entity
@Table(name ="submission_score")
public class SubmissionScore {
	
	@Id
	@GeneratedValue
	@Column(name="submission_score_id")
	private int submissionScoreId;
	
	@OneToOne
	private UserSubmission userSubmission;
	
	@Column(name="submission_score")
	private int submissionScore;

	public UserSubmission getUserSubmission() {
		return userSubmission;
	}

	public void setUserSubmission(UserSubmission userSubmission) {
		this.userSubmission = userSubmission;
	}

	public int getSubmissionScoreId() {
		return submissionScoreId;
	}

	public void setSubmissionScoreId(int submissionScoreId) {
		this.submissionScoreId = submissionScoreId;
	}

	public int getSubmissionScore() {
		return submissionScore;
	}

	public void setSubmissionScore(int submissionScore) {
		this.submissionScore = submissionScore;
	}

	public SubmissionScore(UserSubmission userSubmission, int submissionScore) {
		super();
		this.userSubmission = userSubmission;
		this.submissionScore = submissionScore;
	}

	public SubmissionScore() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
