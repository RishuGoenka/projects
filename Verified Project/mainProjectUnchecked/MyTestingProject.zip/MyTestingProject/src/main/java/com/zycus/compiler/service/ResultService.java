package com.zycus.compiler.service;

import java.util.List;

import com.zycus.compiler.dao.ResultDAO;
import com.zycus.model.Result;

public interface ResultService {

	public abstract void setResultDao(ResultDAO resultDao);

	public abstract List<Result> getById(int submissionId);

	public abstract void saveResult(Result result);

	public abstract void deleteResult(Result result);

}