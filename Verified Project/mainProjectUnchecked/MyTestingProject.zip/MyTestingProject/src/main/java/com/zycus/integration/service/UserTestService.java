package com.zycus.integration.service;

import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.integration.dao.UserTestDAO;
import com.zycus.model.UserTest;

@Service
public class UserTestService {
	
	@Autowired
	UserTestDAO userTestDAO;

	public UserTestService() {
		// TODO Auto-generated constructor stub
	}
	static final long ONE_MINUTE_IN_MILLIS=60000;
	
	public Date getEndTime( UserTest userTest){
		
		
		int duration = userTest.getProblemSet().getDuration();

		Calendar startCalendar = Calendar.getInstance();
		
		startCalendar.setTime(userTest.getStartTime());
		
		startCalendar.add(Calendar.MINUTE, duration);
		
		return startCalendar.getTime();
		
		
	}
	
	public Date startTest(UserTest userTest){
		
		userTest.setStartTime(new Date());
		userTestDAO.save(userTest);	

		return getEndTime(userTest);
	}
	
	public UserTest findUserTest(int userId, int problemSetId){
		return userTestDAO.getUserTestByIDs(problemSetId, userId);
	}
}
