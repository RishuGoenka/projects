package com.zycus.integration.service;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.integration.dao.ProblemSetDAO;
import com.zycus.model.ProblemSet;

@Service
public class ProblemSetService {
	@Autowired
	ProblemSetDAO problemSetDao;
	

	
	/**
	 * Create test set
	 * @param problemSet
	 * @return true if created else false
	 */
	public ProblemSet save(ProblemSet problemSet){
		problemSet.setSharedId(generateSharedId());
		return problemSetDao.save(problemSet);	
	}
	
	/**
	 * generate a random sharedId for each test 
	 * @return shared id
	 */
	public String generateSharedId(){
		char[] chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".toCharArray();
		Random rand = new Random();
		StringBuilder sb = new StringBuilder();
		int len = 6;
		for (int i = 0; i < len; i++) {
		    char c = chars[rand.nextInt(chars.length)];
		    sb.append(c);
		}
		return sb.toString();		
	}
	
	/**
	 * Find problem set by sharedId
	 * @param sharedId
	 * @return problem set
	 */
	public ProblemSet findProblemSetBySharedId(String sharedId){		
		return problemSetDao.findBySharedId(sharedId);
	}
	
	/**
	 * Find problem set by id
	 * @param problemSetId
	 * @return problem set
	 */
	public ProblemSet findProblemInSet(int problemSetId){		
		return problemSetDao.findByProblemId(problemSetId);
	}
	
	/**
	 * Update problem set
	 * @param problemSet
	 * @return true if updated else false
	 */
	public boolean update(ProblemSet problemSet){		
		return problemSetDao.update(problemSet);
	}
	
	/**
	 *Find list of problem set 
	 * @return list of problem set
	 */
	public List<ProblemSet> getAllProblemSet(){
		return problemSetDao.getAllProblemSet();
	}
	
	/**
	 * Delete Problem set
	 * @param problemSet
	 * @return true if delete else false
	 */
	public boolean delete(ProblemSet problemSet){
		return problemSetDao.delete(problemSet);
	}
	
	

}
