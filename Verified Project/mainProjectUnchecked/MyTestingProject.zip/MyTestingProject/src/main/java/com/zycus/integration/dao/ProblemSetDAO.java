package com.zycus.integration.dao;

import java.util.List;

import com.zycus.model.ProblemSet;

public interface ProblemSetDAO {

	public ProblemSet save(ProblemSet problemSet);
	public List<ProblemSet> getAllProblemSet();
	public boolean update(ProblemSet problemSetObject);
	public ProblemSet findBySharedId(String sharedId);
	public ProblemSet findByProblemId(int problemId);
	public boolean delete(ProblemSet problemSet);
}
