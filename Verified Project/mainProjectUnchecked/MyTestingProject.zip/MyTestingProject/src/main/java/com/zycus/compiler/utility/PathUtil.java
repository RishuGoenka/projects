package com.zycus.compiler.utility;

import java.io.File;

public class PathUtil {
	private static String path;

	public static String getPath() {
		return path;
	}
	
	public String setPath(int versionNumber, int userId, int problemId) {
		path = createPathName(versionNumber, userId, problemId);
		createDirectory(path);
		return path;
	}

	private String createPathName(int versionNumber, int userId, int problemId) {
		return System.getProperty("catalina.home") + File.separator + "Files"
				+ File.separator + "entries" + File.separator + problemId
				+ File.separator + userId + File.separator + versionNumber
				+ File.separator;
	}

	public void createDirectory(String path) {
		File folder = new File(path);
		if (folder.exists() == false)
			folder.mkdirs();
	}
}
