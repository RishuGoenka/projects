package com.zycus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.dao.ProblemDAO;
import com.zycus.dao.ProblemDAOImpl;
import com.zycus.model.Problem;
@Service
public class ProblemServiceImpl implements ProblemService {

	@Autowired
	ProblemDAO problemDAO = new ProblemDAOImpl();

	/* (non-Javadoc)
	 * @see com.zycus.service.ProblemEntityService#setProblemDAO(com.zycus.dao.ProblemEntityDAO)
	 */
	@Override
	public void setProblemDAO(ProblemDAO problemDAO) {
		this.problemDAO = problemDAO;
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.service.ProblemEntityService#getAllProblems()
	 */
	@Override
	public  List<Problem> getAllProblems(){
		return problemDAO.getAllProblems();
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.ProblemEntityService#add(com.zycus.model.ProblemEntity)
	 */
	@Override
	public  void add(Problem ProblemEntity){
		problemDAO.add(ProblemEntity);
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.ProblemEntityService#update(com.zycus.model.ProblemEntity)
	 */
	@Override
	public  void update(Problem ProblemEntity){
		problemDAO.update(ProblemEntity);
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.ProblemEntityService#delete(com.zycus.model.ProblemEntity)
	 */
	@Override
	public  void delete(Problem ProblemEntity){
		problemDAO.delete(ProblemEntity);
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.ProblemEntityService#getByID(int)
	 */
	@Override
	public  Problem getByID(int ProblemEntityId){
		return problemDAO.getByID(ProblemEntityId);
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.ProblemEntityService#getByCategory(java.lang.String)
	 */
	@Override
	public  List<Problem> getByCategory(
			String ProblemEntityCategory){
		return problemDAO.getByCategory(ProblemEntityCategory);
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.ProblemEntityService#getByName(java.lang.String)
	 */
	@Override
	public  List<Problem> getByName(String ProblemEntityname){
		return problemDAO.getByName(ProblemEntityname);
	}

	/* (non-Javadoc)
	 * @see com.zycus.service.ProblemEntityService#getByDifficulty(java.lang.String)
	 */
	@Override
	public  List<Problem> getByDifficulty(String difficulty){
		return problemDAO.getByDifficulty(difficulty);
	}
}
