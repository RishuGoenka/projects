package com.zycus.compiler.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.springframework.stereotype.Service;

import com.zycus.compiler.utility.PathUtil;
import com.zycus.compiler.utility.StatusEnum;
import com.zycus.model.Result;
import com.zycus.model.UserSubmission;

@Service
public class CompileExecuteServiceImpl implements CompileExecuteService {
	private final String CONFIG_LOCATION = "C:" + File.separator
			+ "Program Files" + File.separator + "Apache Software Foundation"
			+ File.separator + "Tomcat 7.0" + File.separator + "Files"
			+ File.separator + "config" + File.separator + "Run.java";

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.service.CompileExecuteService2#compile(java.lang.String)
	 */
	@Override
	public StatusEnum compile(String pathName) {
		ProcessBuilder p = new ProcessBuilder("javac", pathName);
		setProperties(p);
		try {
			return compileStatus(p, true);
		} catch (IOException | InterruptedException e) {
			System.out.println("in compile() " + e);
		}
		return StatusEnum.COMPILE_ERROR;
	}

	private StatusEnum compileStatus(ProcessBuilder p, boolean compiled)
			throws IOException, InterruptedException {
		Process pp = p.start();
		InputStream is = pp.getInputStream();
		compiled = getErrorIfAny(compiled, is);
		pp.waitFor();
		is.close();
		if (!compiled)
			return StatusEnum.COMPILE_ERROR;
		return StatusEnum.COMPILE_SUCCESS;
	}

	private boolean getErrorIfAny(boolean compiled, InputStream is)
			throws IOException {
		String temp;
		BufferedReader b = new BufferedReader(new InputStreamReader(is));
		while ((temp = b.readLine()) != null) {
			compiled = false;
			System.out.println(temp);
		}
		return compiled;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.service.CompileExecuteService2#execute(java.lang.String,
	 * java.util.List, java.util.List, int)
	 */
	@Override
	public Result execute(String pathName, List<String> inputList,
			List<String> outputList, int index) throws IOException {
		ProcessBuilder p = new ProcessBuilder("java", pathName);
		setProperties(p);
		try {
			return runProgram(inputList, outputList, index, p);
		} catch (IOException | InterruptedException ioe) {
			System.err.println("in execute() " + ioe);
		}
		return null;
	}

	private Result runProgram(List<String> inputList, List<String> outputList,
			int index, ProcessBuilder p) throws IOException,
			InterruptedException {
		long startTime = System.nanoTime();
		Process process = runProgram(p, inputList.get(index));
		long endTime = System.nanoTime();
		if (process.exitValue() != 0)
			return getResultObject(
					(long) ((endTime - startTime) / (Math.pow(10, 9))), 0, 0L);
		else {
			return successfullyCompiled(outputList, index, startTime, process,
					endTime);
		}
	}

	private Result successfullyCompiled(List<String> outputList, int index,
			long startTime, Process process, long endTime) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(
				process.getInputStream()));
		String out = br.readLine();
		String result = null;
		while (out != null){
			result += out;
			out = br.readLine();
		}
		long memoryUsed = Long.parseLong(br.readLine());
		br.close();
		int testCasebit = isTestCasePass(index, outputList, result);
		// check DB storage of time taken
		return getResultObject(
				(long) ((endTime - startTime) / (Math.pow(10, 9))),
				testCasebit, memoryUsed);
	}

	private void setProperties(ProcessBuilder p) {
		p.directory(new File(PathUtil.getPath()));
		p.redirectErrorStream(true);
	}

	private Process runProgram(ProcessBuilder p, String input)
			throws IOException, InterruptedException {
		Process process;
		process = p.start();
		OutputStream outputStream = process.getOutputStream();
		outputStream.write(input.getBytes());
		outputStream.flush();
		outputStream.close();
		process.waitFor();
		return process;
	}

	private int isTestCasePass(int index, List<String> outputList, String result) {
		int testCasebit = 0;
		if (result.equals(outputList.get(index)))
			testCasebit = 1;
		return testCasebit;
	}

	private Result getResultObject(long timeTaken, int testCasebit,
			long memoryUsed) {
		Result result = new Result();
		result.setTestCasebit(testCasebit);
		result.setMemoryConsumed(memoryUsed);
		result.setTimeTaken(timeTaken);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.service.CompileExecuteService2#saveCode(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public void saveCode(String code, String path) throws IOException,
			InterruptedException {
		initializeEnvironment(path);
		File file = new File(path + "Main.java");
		FileWriter fw = new FileWriter(file);
		fw.write(code);
		fw.close();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.zycus.service.CompileExecuteService2#initializeEnvironment(java.lang
	 * .String)
	 */
	@Override
	public void initializeEnvironment(String path) throws IOException {
		File destination = new File(path + "Run.java");
		File source = new File(this.CONFIG_LOCATION);
		Files.copy(source.toPath(), destination.toPath(),
				StandardCopyOption.REPLACE_EXISTING);
	}

}
