package com.zycus.integration.controller;

import org.springframework.stereotype.Controller;


@Controller
public class AdminController {

	
	public String viewReport() {
	
		
		
		return "report";
	}
}
