package com.zycus.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.Range;

@Entity
@Table(name = "test_case")
public class TestCase implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -861559244903418158L;
	@Id
	@GeneratedValue
	@Column(name = "test_case_id")
	private int testCaseId;

	@Column(name = "input")
	private String input;

	@Column(name = "output")
	private String output;

	@ManyToOne
	private Problem problem;
	
	@Column(name = "test_case_difficulty")
	private String testCaseDifficulty;

	public String getTestCaseDifficulty() {
		return testCaseDifficulty;
	}

	public void setTestCaseDifficulty(String testCaseDifficulty) {
		this.testCaseDifficulty = testCaseDifficulty;
	}

	public int getTestCaseId() {
		return testCaseId;
	}

	public void setTestCaseId(int testCaseId) {
		this.testCaseId = testCaseId;
	}

	public String getInput() {
		return input;
	}

	public void setInput(String input) {
		this.input = input;
	}

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}

	public Problem getProblem() {
		return problem;
	}

	public void setProblem(Problem problem) {
		this.problem = problem;
	}

	

	public TestCase(String input, String output, Problem problem,
			String testCaseDifficulty) {
		super();
		this.input = input;
		this.output = output;
		this.problem = problem;
		this.testCaseDifficulty = testCaseDifficulty;
	}

	public TestCase() {
		super();
	}

	@Override
	public String toString() {
		return "TestCase [testCaseId=" + testCaseId + ", input=" + input
				+ ", output=" + output + ", problem=" + problem + "]";
	}

}
