package com.zycus.service;

import java.util.List;

import com.zycus.dao.ProblemDAO;
import com.zycus.model.Problem;

public interface ProblemService {

	public abstract void setProblemDAO(ProblemDAO problemDAO);

	public abstract List<Problem> getAllProblems();

	public abstract void add(Problem ProblemEntity);

	public abstract void update(Problem ProblemEntity);

	public abstract void delete(Problem ProblemEntity);

	public abstract Problem getByID(int ProblemEntityId);

	public abstract List<Problem> getByCategory(
			String ProblemEntityCategory);

	public abstract List<Problem> getByName(String ProblemEntityname);

	public abstract List<Problem> getByDifficulty(String difficulty);

}