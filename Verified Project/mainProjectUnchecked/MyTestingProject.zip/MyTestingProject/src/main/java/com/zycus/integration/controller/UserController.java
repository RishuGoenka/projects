package com.zycus.integration.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.integration.dao.UserDAO;
import com.zycus.integration.service.MappedProblemService;
import com.zycus.integration.service.ProblemSetService;
import com.zycus.integration.service.UserService;
import com.zycus.integration.service.UserTestService;
import com.zycus.model.Problem;
import com.zycus.model.ProblemSet;
import com.zycus.model.Result;
import com.zycus.model.User;
import com.zycus.model.UserPrincipal;
import com.zycus.model.UserTest;

@Controller
@SessionAttributes("user")
public class UserController {

	@Autowired
	UserDAO dao;

	@Autowired
	UserService userService;
	
	@Autowired
	MappedProblemService mappedProblemService;
	
	@Autowired
	ProblemSetService problemSetService;
	
	@Autowired
	UserTestService userTestService;


	/**
	 * Registration Of user
	 * @param user
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("userObject") @Valid User user,
			BindingResult result) {
		
		
		if (result.hasErrors()) {
			return new ModelAndView("register");
		} else {

			if (!userService.addUser(user)) {
				return new ModelAndView("register");
			} else {
				return new ModelAndView("success");
			}
		}
	}

	@RequestMapping("/check-user")
	public String check() {

		System.out.println(dao.isEmailAvailable("sagarika.singh"));

		return "success";
	}

	@RequestMapping("/get-user")
	public String get() {

		System.out.println(dao.getUserByEmail("sagarika.singh"));

		return "success";

	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView setUpRegisterForm() {

		ModelAndView modelAndView = new ModelAndView("register");
		User user = new User();

		modelAndView.addObject("userObject", user);

		return modelAndView;

	}
	
	@RequestMapping(value = "/newTest",method = RequestMethod.GET)
	public ModelAndView newTestSetUp(){
		
		ModelAndView mv = new ModelAndView("newTest");
		 mv.addObject("problemSet", new ProblemSet());
		 
		 return mv;
		
	}

	@RequestMapping(value = "/newTest", method=RequestMethod.POST)
	public ModelAndView startTest(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("problemSet")ProblemSet problemSet
			,BindingResult bindingResult) throws Exception {

		String sharedId = request.getParameter("sharedId");
		
		problemSet = problemSetService.findProblemSetBySharedId(sharedId);
		
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		User user = ((UserPrincipal) principal).getUser();	
		
		userTestService.startTest(new UserTest(problemSet, user));
		
		HttpSession session = request.getSession();
		session.setAttribute("problemSetId", problemSet.getProblemSetId());
		
		ModelAndView mv = new ModelAndView("teststarted");
	
		
		mv.addObject("sharedId", sharedId);
	
		return mv;
	
	}
	
	
	
	@RequestMapping(value = "/problems/get/{id}", method=RequestMethod.GET)	
	public @ResponseBody List<Problem> getResultList(@PathVariable("id") String sharedId) {
		
		System.out.println("Hello");
		List<Problem> problems =mappedProblemService.findBySharedId(sharedId);

		
		return problems;
	}
}
