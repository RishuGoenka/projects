package com.zycus.integration.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;












import com.zycus.compiler.service.UserSubmissionService;
import com.zycus.dao.ProblemDAO;
import com.zycus.integration.model.SubmissionScore;
import com.zycus.integration.service.MappedProblemService;
import com.zycus.integration.service.ProblemSetService;
import com.zycus.integration.service.SubmissionScoreService;
import com.zycus.integration.service.UserTestService;
import com.zycus.model.Problem;
import com.zycus.model.ProblemSet;
import com.zycus.model.TestCase;
import com.zycus.model.User;
import com.zycus.model.UserPrincipal;
import com.zycus.model.UserSubmission;
import com.zycus.model.UserTest;
import com.zycus.service.TestCaseService;

@Controller
//@RequestMapping("/problem")
public class ProblemSetController {

	
	@Autowired
	MappedProblemService mappedProblemService;
	
	@Autowired
	ProblemSetService problemSetService;
	
	@Autowired
	ProblemDAO problemDAO;
	
	@Autowired
	TestCaseService testCaseService;
	
	@Autowired
	UserTestService userTestService;
	
	
	@Autowired 
	UserSubmissionService userSubmissionService;
	
	
	@Autowired
	SubmissionScoreService scoreService;
	
	public ProblemSetController() {
		// TODO Auto-generated constructor stub
	}

	@RequestMapping("/practice")
	public void addProblemStuff(){
	
		Problem problem = new Problem("sag", "Awesome","Super","Very");
		problemDAO.add(problem);
		ProblemSet problemSet = problemSetService.save(new ProblemSet("123",1,"Big Problem"));
		
		mappedProblemService.addMappedProblem(problem, problemSet);
		
		System.out.println(problem);
		TestCase testCase = new TestCase("1","2",problem,"2");
		TestCase testCase2 = new TestCase("1","2",problem,"3");
		
		testCaseService.add(testCase);
		testCaseService.add(testCase2);
		
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		User user = ((UserPrincipal) principal).getUser();
		
		UserTest userTest = new UserTest(problemSet,user);
		 userTestService.startTest(userTest);
		
		 UserSubmission userSubmission = new UserSubmission(0,problem,userTest,1 );
		 
		 userSubmissionService.saveUserSubmission(userSubmission);
		 
		 
	}
	
	@RequestMapping("/testScore")
	
	public String scoreTest(){
		
		
		SubmissionScore submissionScore = new  SubmissionScore(userSubmissionService.getById(1),0);
		scoreService.saveOrUpdateSubmissionScore(1);
		
		return "success";
		
	}
	
	@RequestMapping("/testUpdateScore")
	
	public String scoreUpdate(){
		
		UserTest userTest =  userTestService.findUserTest(1, 9);
		Problem problem = problemDAO.getByID(9);
		UserSubmission userSubmission = new UserSubmission(0, problem, userTest, 2);
		
		userSubmissionService.saveUserSubmission(userSubmission);
		
		SubmissionScore submissionScore = new  SubmissionScore(userSubmissionService.getById(1),0);
		scoreService.saveOrUpdateSubmissionScore(1);
		
		return "success";
		
	}
	
	
	
	@RequestMapping("/xyz")
	public ModelAndView test(HttpServletRequest request, HttpServletResponse response,@ModelAttribute("problemSet")ProblemSet problemSet
			,BindingResult bindingResult)
			throws Exception {
		
		ModelAndView mv = new ModelAndView("teststarted");
		//System.out.println("in Controller newUser");
		
		if(bindingResult.hasErrors()){
			mv.addObject("msg","Incorrect SharedId");
			mv.setViewName("newTest");
			return mv;
		}
		String sharedId = problemSet.getSharedId();
	
		List<Problem> problems =mappedProblemService.findBySharedId(sharedId);
		
		if(problems.size() != 0){
			mv.addObject("problemList",problems);
			return mv;
		}else{
			
			mv.addObject("msg","Incorrect SharedId");
			mv.setViewName("newTest");
			return mv;
		}
		
		
	} 
	
	@RequestMapping("/select-test")
	public String setUpSelectTest(Model model){
		
		model.addAttribute("problemSet", new ProblemSet());
		return "newTest";
	}
}
