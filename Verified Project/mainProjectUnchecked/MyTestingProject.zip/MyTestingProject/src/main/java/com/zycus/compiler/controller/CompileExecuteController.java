package com.zycus.compiler.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.compiler.service.CompileExecuteService;
import com.zycus.compiler.service.ResultService;
import com.zycus.compiler.service.UserSubmissionService;
import com.zycus.compiler.utility.PathUtil;
import com.zycus.integration.service.ProblemSetService;
import com.zycus.integration.service.SubmissionScoreService;
import com.zycus.integration.service.UserService;
import com.zycus.integration.service.UserTestService;
import com.zycus.model.Problem;
import com.zycus.model.Result;
import com.zycus.model.UserSubmission;
import com.zycus.model.UserTest;
import com.zycus.service.ProblemService;
import com.zycus.service.TestCaseService;

@Controller
public class CompileExecuteController {
	@Autowired
	CompileExecuteService compileExecuteService;

	@Autowired
	UserTestService userTestService;

	@Autowired
	ProblemService problemService;

	@Autowired
	UserSubmissionService userSubmissionService;

	@Autowired
	ResultService resultService;

	@Autowired
	UserService userService;

	@Autowired
	ProblemSetService problemSetService;
	
	@Autowired
	TestCaseService testCaseService;

	@Autowired
	SubmissionScoreService submissionScoreService;
	
	PathUtil pathUtil;

	@RequestMapping(value = "/code/onSubmit", method = RequestMethod.POST)
	private String onSubmit(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) throws IOException,
			InterruptedException {
		int userId = Integer.parseInt("1");
		int problemId = Integer.parseInt("1");
		int problemSetId = Integer.parseInt("1");
		UserTest userTest = userTestService.findUserTest(userId, problemSetId);
		int versionNumber = getVersion(problemId, userTest);
		String code = request.getParameter("text");
		setPath(versionNumber, userId, problemId);
		compileExecuteService.saveCode(code, pathUtil.getPath());
		compileExecuteService.compile("Run.java");
		int submissionId = execute(userId, problemId, problemSetId,
				versionNumber);
		request.setAttribute("submissionId", submissionId);
		submissionScoreService.saveOrUpdateSubmissionScore(submissionId);;
		return "result";
	}

	// Shift to utility and remove the System.get propery and instead use from
	// utility
	/**
	 * set path where user program and class to be stored
	 * 
	 * @param versionNumber
	 *            is count of total attempts of a user for same problem
	 * @param userId
	 *            who submit code
	 * @param problemId
	 */
	private void setPath(int versionNumber, int userId, int problemId) {
		String path = pathUtil.setPath(versionNumber, userId, problemId);
		pathUtil.createDirectory(path);
	}

	private int execute(int userId, int problemId, int problemSetId,
			int versionNumber) throws IOException {

		int submissionId = 0;
		List<String> inputList = getInputList(problemId);
		List<String> outputList = getOutputList(problemId);
		for (int index = 0; index < inputList.size(); index++) {
			Result result = compileExecuteService.execute("Run", inputList,
					outputList, index);
			submissionId = saveResult(result, userId, problemId, problemSetId,
					versionNumber);
		}

		return submissionId;
	}

	/**
	 * get the version number of the current code submission
	 * 
	 * @param problemId
	 * @param userTest
	 * @return latest version number
	 */
	private int getVersion(int problemId, UserTest userTest) {
		return userSubmissionService.getLatestVersionForUserForProblem(
				problemId, userTest);
	}

	/**
	 * Retrieves output list from the database
	 * 
	 * @param problemId
	 * @return Array list of the expected outputs
	 */
	private List<String> getOutputList(int problemId) {
		return testCaseService.getOutputByProblem(problemId);
	}

	/**
	 * Retrieves input test cases list from the database
	 * 
	 * @param problemId
	 * @return ArrayList of the inputs to be tested on the submitted program
	 */
	private List<String> getInputList(int problemId) {
		return testCaseService.getInputByProblem(problemId);
	}

	/**
	 * 
	 * @param result
	 * @param userId
	 * @param problemId
	 * @param problemSetId
	 * @param versionNumber
	 * @return Primary key of the submission
	 */
	@Transactional
	private int saveResult(Result result, int userId, int problemId,
			int problemSetId, int versionNumber) {
		UserSubmission userSubmission = createAndSaveUserSubmissionObject(
				problemId, problemSetId, userId, versionNumber);
		result.setUserSubmission(userSubmission);
		System.out.println(result.toString());
		resultService.saveResult(result);
		return userSubmission.getSubmissionId();

	}

	/**
	 * Saves user submission to the database
	 * 
	 * @param problemId
	 * @param problemSetId
	 * @param userId
	 * @param versionNumber
	 * @return
	 */
	private UserSubmission createAndSaveUserSubmissionObject(int problemId,
			int problemSetId, int userId, int versionNumber) {
		UserSubmission userSubmission = new UserSubmission();
		Problem problem = problemService.getByID(problemId);
		UserTest userTest = userTestService.findUserTest(userId, problemSetId);
		userSubmission.setProblem(problem);
		userSubmission.setUserTest(userTest);
		userSubmission.setVersionNumber(versionNumber);
		userSubmissionService.saveUserSubmission(userSubmission);
		return userSubmission;
	}
}
