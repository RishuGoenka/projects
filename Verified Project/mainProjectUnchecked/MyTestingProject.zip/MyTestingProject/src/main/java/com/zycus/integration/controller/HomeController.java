package com.zycus.integration.controller;


import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.model.Result;
import com.zycus.model.User;
import com.zycus.model.UserPrincipal;



@Controller
public class HomeController{

	/*@RequestMapping(value={"/", "/home"}, method = RequestMethod.GET)
	public ModelAndView home(){

		ModelAndView model = new ModelAndView("home");
		model.addObject("msg", "hello world");
		new Result();
		return model;
	}*/
	
	
	@RequestMapping(value={"/hello"}, method = RequestMethod.GET)
	public ModelAndView hello(){

		ModelAndView model = new ModelAndView("hello");
		
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		User user = ((UserPrincipal) principal).getUser();		
		model.addObject("username", user.getFirstName());
				
		return model;
	}
	
	@RequestMapping(value={"/login","/"}, method = RequestMethod.GET)
	public ModelAndView login(){

		ModelAndView model = new ModelAndView("login");
		model.addObject("user", new User());

		return model;
	}
	
	
}