package com.zycus.model;

import java.io.Serializable;

import javax.persistence.Entity;

@Entity
public class MappedProblems implements Serializable{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8199713722416412774L;
	private Problem problem;
	private ProblemSet problemSet;
	
	public Problem getProblem() {
		return problem;
	}
	
	
	public void setProblem(Problem problem) {
		this.problem = problem;
	}
	public ProblemSet getProblemSet() {
		return problemSet;
	}
	public void setProblemSet(ProblemSet problemSet) {
		this.problemSet = problemSet;
	}
	public MappedProblems() {
		super();
		// TODO Auto-generated constructor stub
	}


	public MappedProblems(Problem problem, ProblemSet problemSet) {
		super();
		this.problem = problem;
		this.problemSet = problemSet;
	}
	
	

}
