package com.zycus.integration.dao;

import java.util.List;

import com.zycus.model.MappedProblems;
import com.zycus.model.Problem;

public interface MappedProblemsDAO {
	public boolean save(MappedProblems mappedProblems);
	public List<Problem> findBySharedId(String sharedId);
	public List<Problem> findByProblemId(int problemId);
}
