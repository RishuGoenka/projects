package com.zycus.dao;

import java.util.List;

import com.zycus.model.Problem;

public interface ProblemDAO {

	public abstract List<Problem> getAllProblems();

	public abstract void add(Problem Problem);

	public abstract void update(Problem Problem);

	public abstract void delete(Problem Problem);

	public abstract Problem getByID(int ProblemId);

	public abstract List<Problem> getByCategory(
			String ProblemCategory);

	public abstract List<Problem> getByName(String Problemname);

	public abstract List<Problem> getByDifficulty(String difficulty);

}