package com.zycus.compiler.dao;

import com.zycus.model.UserSubmission;
import com.zycus.model.UserTest;

public interface UserSubmissionDAO {

	public abstract UserSubmission getById(int submissionId);

	public abstract void saveUserSubmission(UserSubmission submission);

	public abstract void deleteUserSubmission(UserSubmission submission);

	public abstract int countUserSubmissionPerUserPerProblem(int problemId,
			UserTest testObject);

	public abstract UserSubmission findByUserTestAndProblemId(int problemId,
			UserTest userTest);

	public abstract UserSubmission findByUserTestProblemIdVersionNumber(
			int problemId, UserTest userTest, int versionNumber);
}