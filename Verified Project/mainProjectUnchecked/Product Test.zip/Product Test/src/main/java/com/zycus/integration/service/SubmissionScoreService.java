package com.zycus.integration.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.compiler.service.client.ResultAndUserSubmissionService;
import com.zycus.integration.dao.SubmissionScoreDAO;
import com.zycus.integration.model.SubmissionScore;
import com.zycus.model.Result;
import com.zycus.model.TestCase;
import com.zycus.model.UserSubmission;
import com.zycus.service.TestCaseService;

@Service
public class SubmissionScoreService {

	@Autowired
	com.zycus.compiler.service.UserSubmissionService UserSubmissionService;

	@Autowired
	ResultAndUserSubmissionService resultAndUserSubmissionService;

	@Autowired
	SubmissionScoreDAO submissionScoreDAO;
	
	@Autowired
	TestCaseService testCaseService;

	public SubmissionScoreService() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Gets submission object from its id Calculates the score, then adds a new
	 * row if not yet added else updates the score
	 * 
	 * @param submissionId
	 */
	public void saveOrUpdateSubmissionScore(int submissionId) {

		UserSubmission userSubmission = UserSubmissionService
				.getById(submissionId);

		UserSubmission previousUserSubmission = getPreviousUserSubmission(userSubmission);

		if (previousUserSubmission == null) {
			submissionScoreDAO.save(buildSubmissionScore(userSubmission));
		} else {
			submissionScoreDAO.update(getUpdatedSubmissionScore(
					previousUserSubmission, userSubmission));
		}

	}

	/**
	 * Returns whether the submission score must be updated or inserted if it is
	 * to be updated a UserSubmission object will be returned else null will be
	 * returned
	 * 
	 * @param userSubmission
	 * @return
	 */
	public UserSubmission getPreviousUserSubmission(
			UserSubmission userSubmission) {

		int previousVersion = userSubmission.getVersionNumber() - 1;

		if (previousVersion > 0) {

			return UserSubmissionService.findByUserTestProblemIdVersionNumber(
					userSubmission.getProblem().getProblemId(),
					userSubmission.getUserTest(), previousVersion);
		}

		return null;
	}

	/**
	 * Creates an updated SubmissionScore object with same submissionScoreId but
	 * with new properties
	 * 
	 * @param oldUserSubmission
	 * @param newUserSubmission
	 * @return
	 */
	public SubmissionScore getUpdatedSubmissionScore(
			UserSubmission oldUserSubmission, UserSubmission newUserSubmission) {

		SubmissionScore existingSubmissionScore = submissionScoreDAO
				.findByUserSubmission(oldUserSubmission);

		SubmissionScore newSubmissionScore = buildSubmissionScore(newUserSubmission);
		newSubmissionScore.setSubmissionScoreId(existingSubmissionScore
				.getSubmissionScoreId());

		return newSubmissionScore;
	}

	/**
	 * Creates SubmissionScore object from UserSubmission object by calculating
	 * the score
	 * 
	 * Note: Will not contain submissionScoreId
	 * @param userSubmission
	 * @return
	 */
	public SubmissionScore buildSubmissionScore(UserSubmission userSubmission) {

		SubmissionScore submissionScore = new SubmissionScore();
		
		submissionScore.setSubmissionScore(calculateSubmissionScore(userSubmission));
		submissionScore.setUserSubmission(userSubmission);
		
		return submissionScore;
	}

	public int calculateSubmissionScore(UserSubmission userSubmission) {

		List<TestCase> testCases =  testCaseService.getTestCaseByProblem(userSubmission.getProblem().getProblemId());
		List<Result> testCaseResults = resultAndUserSubmissionService.getResultBySubmissionId(userSubmission.getSubmissionId());
		
		int difficulty;
		int score = 0;;
		for (int i = 0; i < testCases.size(); i++) {
			
			if(testCaseResults.get(i).isTestCasebit() == 1){
				
				difficulty = Integer.parseInt(testCases.get(i).getTestCaseDifficulty());
				
				score = score + difficulty;
			}
			
		}
		
		return score;
	}

}
