package com.zycus.integration.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.model.User;

@Repository
@Transactional
public class UserDAO {

	@PersistenceContext
	private EntityManager manager;

	public void save(User userObject) {

		manager.persist(userObject);
	}

	public User getUserByID(int id) {

		return manager.find(User.class, id);
	}

	public List<User> getAllUsers() {

		List<User> userList = manager.createQuery("Select u from User u")
				.getResultList();
		return userList;
	}

	public void update(User userObject) {

		User persistentUser = manager.find(User.class, userObject.getUserId());
		persistentUser = userObject;

	}

	/**
	 * Returns Object of user having email = emailString or else returns null
	 * 
	 * @param emailString
	 * @return
	 */
	public User getUserByEmail(String emailString) {

		List<User> userList = null;
		userList = manager
				.createQuery("Select u from User u where u.email =:emailId")
				.setParameter("emailId", emailString).getResultList();

		if (userList.size() >= 1) {
			return userList.get(0);
		} else {
			return null;
		}
	}

	public boolean isEmailAvailable(String email) {

		long value = (Long) manager
				.createQuery(
						"Select COUNT(u) from User u where u.email =:emailId")
				.setParameter("emailId", email).getSingleResult();

		System.out.println(value);
		if (value == 1) {
			return true;
		} else {
			return false;
		}

	}

}
