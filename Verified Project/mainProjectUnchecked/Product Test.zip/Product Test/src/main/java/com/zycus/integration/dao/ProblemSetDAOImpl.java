package com.zycus.integration.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;




import com.zycus.model.ProblemSet;

@Repository
@Transactional
public class ProblemSetDAOImpl implements ProblemSetDAO{
	
	@PersistenceContext
	private EntityManager manager;
	
	
	/**
	 * save ProblemSet Object
	 * @param problemSet
	 * @return boolean
	 */
	public ProblemSet save(ProblemSet problemSet) {
		try{
			manager.persist(problemSet);
			return problemSet;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	

	
	
	/**
	 * get all the ProblemSet
	 * @return List of ProblemSet
	 */
	@SuppressWarnings("unchecked")
	public List<ProblemSet> getAllProblemSet(){
		List<ProblemSet> problemSetList = manager.createQuery("select ps from ProblemSet ps").getResultList();
		return problemSetList;
	}
	
	
	/**
	 * update ProblemSet
	 * @param problemSetObject
	 * @return boolean
	 */
	public boolean update(ProblemSet problemSetObject){
		try {
			
			manager.merge(problemSetObject);
			 return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}
	
	/**
	 * Find a problem set by sharedId
	 * @param sharedId
	 * @return problem set
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ProblemSet findBySharedId(String sharedId) {			 
		 List<ProblemSet> problemSets = (List<ProblemSet>) manager.createQuery("Select p from ProblemSet p where p.sharedId =:sharedId").setParameter("sharedId", sharedId).getResultList();
		 
		 if (problemSets.size() >= 1) {
				return problemSets.get(0);
			} else {
				return null;
			}
	}
	

	
	
	/**
	 * Find a problem set by problem set id
	 * @param problemSetId
	 * @return problem set
	 */
	public ProblemSet findByProblemId(int problemId) {
		ProblemSet problemSet=manager.find(ProblemSet.class, problemId);
		return problemSet;
	}
	
	/**
	 * Delete a problemSet object
	 * @param problemSet object
	 * @return boolean
	 */
	public boolean delete(ProblemSet problemSet){
		try {
			manager.remove(problemSet);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}






}
