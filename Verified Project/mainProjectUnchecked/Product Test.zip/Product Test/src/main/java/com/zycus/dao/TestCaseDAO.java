package com.zycus.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.model.TestCase;

@Repository
@Transactional
public class TestCaseDAO {
	
	@PersistenceContext
	private EntityManager manager;

	public void add(TestCase testcase) {
		manager.persist(testcase);
	}

	public void update(TestCase testcase) {
		manager.createQuery(
				"update testcase set input=?, output=?, problem=? where testCaseID=?")
				.setParameter(1, testcase.getInput())
				.setParameter(2, testcase.getOutput())
				.setParameter(3, testcase.getProblem()).executeUpdate();
	}

	public void delete(TestCase testcase) {
		manager.remove(testcase);
	}

	public TestCase getByID(int testcaseID) {
		return (TestCase) manager.find(TestCase.class, testcaseID);
	}

	@SuppressWarnings("unchecked")
	public List<String> getInputByProblem(int problemId) {
		return manager
				.createQuery(
						"Select t.input  From TestCase t where t.Problem.problemId=?")
				.setParameter(1, problemId).getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<String> getOutputByProblem(int Problem) {
		return manager
				.createQuery(
						"Select t.output From TestCase t where t.Problem.problemId=?")
				.setParameter(1, Problem).getResultList();
	}
	
	@SuppressWarnings("unchecked")
	public List<TestCase> getTestCaseByProblem(int problem_id)
	{
		return manager
				.createQuery(
						"Select t From TestCase t where t.problem_problem_id=?")
				.setParameter(1, problem_id).getResultList();
	}

}
