package com.zycus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.dao.TestCaseDAO;
import com.zycus.model.TestCase;

@Service
public class TestCaseService {

	@Autowired
	private TestCaseDAO dao;

	public void add(TestCase testcase) {
		//System.out.println(testcase);
		dao.add(testcase);
	}

	public void update(TestCase updatedTestCase) {
		dao.update(updatedTestCase);
	}

	public void delete(TestCase testcase) {
		dao.delete(testcase);
	}

	public TestCase getByID(int testCaseId) {
		return dao.getByID(testCaseId);
	}

	public List<String> getInputByProblem(int problemId) {
		return dao.getInputByProblem(problemId);
	}

	public List<String> getOutputByProblem(int problem) {
		return dao.getOutputByProblem(problem);
	}
	
	public List<TestCase> getTestCaseByProblem(int problem_id) 
	{
		return dao.getTestCaseByProblem(problem_id);
	} 
}
