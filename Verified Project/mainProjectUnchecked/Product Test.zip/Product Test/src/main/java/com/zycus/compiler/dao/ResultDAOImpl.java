package com.zycus.compiler.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TransactionRequiredException;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.zycus.compiler.utility.CustomCompilerException;
import com.zycus.model.Result;

@Repository
@Transactional
public class ResultDAOImpl implements ResultDAO {
	@PersistenceContext
	private EntityManager manager;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.dao.ResultDAO#getById(int)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<Result> getById(int submissionId) {
		List<Result> results = new ArrayList<Result>();

		try {
			results = manager
					.createQuery(
							"From Result table1 Where table1.userSubmission.submissionId = ?")
					.setParameter(1, submissionId).getResultList();
		} catch (IllegalArgumentException e) {
			throw new CustomCompilerException(
					CustomCompilerException.ILLEGAL_ARGUEMENT_EXCEPTION);
		}
		return results;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.dao.ResultDAO#saveResult(com.zycus.model.ResultEntity)
	 */
	@Override
	public void saveResult(Result result) {
		try {
			manager.persist(result);
		} catch (EntityExistsException e1) {
			throw new CustomCompilerException(
					CustomCompilerException.ENTITY_EXISTS_EXCEPTION);
		} catch (IllegalArgumentException e2) {
			throw new CustomCompilerException(
					CustomCompilerException.ILLEGAL_ARGUEMENT_EXCEPTION);
		} catch (TransactionRequiredException e3) {
			throw new CustomCompilerException(
					CustomCompilerException.TRANSACTION_REQUIRED_EXCEPTION);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.dao.ResultDAO#deleteResult(com.zycus.model.ResultEntity)
	 */
	@Override
	public void deleteResult(Result result) {
		try {
			manager.remove(result);
		} catch (IllegalArgumentException e2) {
			throw new CustomCompilerException(
					CustomCompilerException.ILLEGAL_ARGUEMENT_EXCEPTION);
		} catch (TransactionRequiredException e3) {
			throw new CustomCompilerException(
					CustomCompilerException.TRANSACTION_REQUIRED_EXCEPTION);
		}
	}
}