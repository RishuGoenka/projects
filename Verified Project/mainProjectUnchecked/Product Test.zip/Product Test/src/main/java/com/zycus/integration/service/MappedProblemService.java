package com.zycus.integration.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.integration.dao.MappedProblemsDAO;
import com.zycus.model.MappedProblems;
import com.zycus.model.Problem;
import com.zycus.model.ProblemSet;

@Service
public class MappedProblemService {
	@Autowired
	MappedProblemsDAO mappedProblemDao;
	
	/**
	 * map each problem to problem set
	 * @param problem
	 * @param problemSet
	 */
	public void addMappedProblem(Problem problem,ProblemSet problemSet){
		MappedProblems mappedProblems = new MappedProblems(problem, problemSet);
		mappedProblemDao.save(mappedProblems);
	}
	
	/**
	 * map list of problems to a problem set
	 * @param problems
	 * @param problemSet
	 */
	public void addProblemsList(List<Problem> problems,ProblemSet problemSet){
		for (Problem problem : problems) {
			addMappedProblem(problem, problemSet);
		}
	}
	
	/**
	 * find Problems in problem set by shared id 
	 * @param sharedId
	 * @return list of problems
	 */
	public List<Problem> findBySharedId(String sharedId) {
		return mappedProblemDao.findBySharedId(sharedId); 
	}
	
	/**
	 * find all problem set containing a problem
	 * @param problemId
	 * @return list of problem set
	 */
	public List<Problem> findByProblemId(int problemId){
		return mappedProblemDao.findByProblemId(problemId);
	}
}
