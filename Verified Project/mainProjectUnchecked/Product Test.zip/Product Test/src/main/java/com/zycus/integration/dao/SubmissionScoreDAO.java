package com.zycus.integration.dao;


import com.zycus.integration.model.SubmissionScore;
import com.zycus.model.UserSubmission;

public interface SubmissionScoreDAO {
	
	public boolean save(SubmissionScore submissionScore);
	public boolean update(SubmissionScore submissionScore);
	public SubmissionScore findById(int submsissionScoreId);
	public SubmissionScore findByUserSubmission(UserSubmission userSubmission);
}
