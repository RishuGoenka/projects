package com.zycus.compiler.service;

import java.io.IOException;
import java.util.List;

import com.zycus.compiler.utility.StatusEnum;
import com.zycus.model.Result;

public interface CompileExecuteService {

	public abstract StatusEnum compile(String pathName);

	public abstract Result execute(String pathName, List<String> inputList,
			List<String> outputList, int index) throws IOException;

	public abstract void saveCode(String code, String path) throws IOException,
			InterruptedException;

	public abstract void initializeEnvironment(String path) throws IOException;

}