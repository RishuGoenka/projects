package com.zycus.compiler.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.model.Result;

@Repository
public interface ResultDAO {

	public abstract List<Result> getById(int submissionId);

	public abstract void saveResult(Result result);

	public abstract void deleteResult(Result result);

}