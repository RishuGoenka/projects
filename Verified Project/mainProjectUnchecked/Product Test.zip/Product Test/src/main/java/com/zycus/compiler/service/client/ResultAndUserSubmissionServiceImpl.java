package com.zycus.compiler.service.client;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.compiler.service.ResultService;
import com.zycus.compiler.service.UserSubmissionService;
import com.zycus.model.Result;
import com.zycus.model.UserSubmission;
import com.zycus.model.UserTest;

@Service
public class ResultAndUserSubmissionServiceImpl implements ResultAndUserSubmissionService {

	@Autowired
	ResultService resultService;
	
	@Autowired
	UserSubmissionService userSubmissionService;
	
	
	/* (non-Javadoc)
	 * @see com.zycus.service.client.CompleteResultService#getCompleteResult(com.zycus.model.UserSubmission)
	 */
	@Override
	public List<Result> getResultBySubmissionId(int submissionId) {
		return resultService.getById(submissionId);
	}
	
	@Override
	public int getLatestVersionByUser(int problemId, UserTest userTest){
		return userSubmissionService.getLatestVersionForUserForProblem(
				problemId, userTest);
	}
	
	@Override
	public UserSubmission getLatestUserSubmission(int problemId, UserTest userTest) {
		return userSubmissionService.findByUserTestAndProblemId(problemId, userTest);
	}
	
}
