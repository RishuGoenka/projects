package com.zycus.integration.dao;

import java.util.List;

import com.zycus.model.User;
import com.zycus.model.UserTest;

public interface UserTestDAO {

	/** 
	 * save the userTest object
	 * @param userTestTestObject
	 * @return boolean
	 */
	public abstract boolean save(UserTest userTestObject);

	/**
	 * get the userTest by Id
	 * @param id
	 * @return UserTest Object
	 */
	public abstract UserTest getUserTestByID(int id);

	/**
	 * get all the userTests
	 * @return List of UserTests
	 */
	public abstract List<UserTest> getAllUserTests();

	/**
	 * Update UserTest
	 * @param userTestObject
	 * @return boolean
	 */
	public abstract boolean update(UserTest userTestObject);

	/**
	 * get all the users appearing for a test
	 * @return List of User
	 */
	public abstract List<User> getUsersByTest(int problemSetId);

	/**
	 * get the userTest by problemSetId and userId
	 * 
	 * @param id
	 * @return UserTest Object
	 */
	public abstract UserTest getUserTestByIDs(int problemSetId, int userId);

	

}