package com.zycus.compiler.service.client;

import java.util.List;

import com.zycus.model.Result;
import com.zycus.model.UserSubmission;
import com.zycus.model.UserTest;

public interface ResultAndUserSubmissionService {

	public abstract List<Result> getResultBySubmissionId(int submissionId);

	public abstract int getLatestVersionByUser(int problemId, UserTest userTest);

	public abstract UserSubmission getLatestUserSubmission(int problemId, UserTest userTest);

}