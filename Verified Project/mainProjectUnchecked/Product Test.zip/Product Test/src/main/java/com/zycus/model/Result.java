package com.zycus.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "result")
public class Result implements Serializable {

	private static final long serialVersionUID = 5150405260104361057L;

	@Id
	@GeneratedValue
	@Column(name="result_number")
	private int resultNumber;

	@ManyToOne
	private UserSubmission userSubmission;

	@Column(nullable=false, name="memory_used")
	private double memoryConsumed;

	@Column(nullable=false, name="time_taken")
	private double timeTaken;

	@Column(nullable=false, name="test_case_bit")
	private int testCasebit;

	public int getResultNumber() {
		return resultNumber;
	}

	public void setResultNumber(int resultNumber) {
		this.resultNumber = resultNumber;
	}

	public UserSubmission getUserSubmission() {
		return userSubmission;
	}

	public void setUserSubmission(UserSubmission userSubmission) {
		this.userSubmission = userSubmission;
	}

	public double getMemoryConsumed() {
		return memoryConsumed;
	}

	public void setMemoryConsumed(double memoryConsumed) {
		this.memoryConsumed = memoryConsumed;
	}

	public double getTimeTaken() {
		return timeTaken;
	}

	public void setTimeTaken(double timeTaken) {
		this.timeTaken = timeTaken;
	}

	public int isTestCasebit() {
		return testCasebit;
	}

	public void setTestCasebit(int testCasebit) {
		this.testCasebit = testCasebit;
	}

	@Override
	public String toString() {
		return "Result [resultNumber=" + resultNumber + ", userSubmission="
				+ userSubmission + ", memoryConsumed=" + memoryConsumed
				+ ", timeTaken=" + timeTaken + ", testCasebit=" + testCasebit
				+ "]";
	}
}
