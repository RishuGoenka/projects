package com.zycus.integration.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.integration.model.SubmissionScore;
import com.zycus.model.UserSubmission;

@Repository
@Transactional
public class SubmissionScoreDAOImpl implements SubmissionScoreDAO {

	@PersistenceContext
	private EntityManager manager;

	public SubmissionScoreDAOImpl() {

	}

	@Override
	public boolean save(SubmissionScore submissionScore) {

		try {
			manager.persist(submissionScore);

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public boolean update(SubmissionScore submissionScore) {
		try {

			manager.merge(submissionScore);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public SubmissionScore findById(int submissionScoreId) {

		return manager.find(SubmissionScore.class, submissionScoreId);
	}

	@Override
	public SubmissionScore findByUserSubmission(UserSubmission userSubmission) {

		
		List<SubmissionScore> submissionScores = (List<SubmissionScore>) manager.createQuery("select s from SubmissionScore s where s.userSubmission.submissionId = ?")
		.setParameter(1,userSubmission.getSubmissionId()).getResultList();
		
		if (submissionScores.size() > 0) {
			
			return submissionScores.get(0);
		}else{
			return null;
		}
		
	

	}

}
