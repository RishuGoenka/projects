package com.zycus.integration.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.compiler.service.client.ResultAndUserSubmissionService;
import com.zycus.model.Result;
import com.zycus.model.User;



@Controller
public class ProblemController {

	
	@Autowired
	private ResultAndUserSubmissionService resultService;
	

	
	/**
	 * Returns a json array of result list
	 * @param submissionId
	 * @return
	 */
	@RequestMapping(value = "/result/get/{id}", method=RequestMethod.GET)	
	public @ResponseBody List<Result> getResultList(@PathVariable("id") int submissionId) {
		
		List<Result> result = resultService.getResultBySubmissionId(submissionId);
		
		return result;
	}
	
}
