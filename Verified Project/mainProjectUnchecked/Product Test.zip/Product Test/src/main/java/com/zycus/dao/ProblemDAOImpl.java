package com.zycus.dao;


	import java.util.List;

	import javax.persistence.EntityManager;
	import javax.persistence.PersistenceContext;

	import org.springframework.stereotype.Repository;
	import org.springframework.transaction.annotation.Transactional;

	import com.zycus.model.Problem;

	@Repository
	@Transactional
	public class ProblemDAOImpl implements ProblemDAO {

		@PersistenceContext
	    private EntityManager manager;
		
		/* (non-Javadoc)
		 * @see com.zycus.dao.ProblemDAO#getAllEmployees()
		 */
		@Override
		public List<Problem> getAllProblems() 
	    {
			return manager.createQuery("Select p From Problem p", Problem.class).getResultList();
	    }
		
	    /* (non-Javadoc)
		 * @see com.zycus.dao.ProblemDAO#add(com.zycus.model.Problem)
		 */
	    @Override
		public void add(Problem Problem) 
	    {
	        manager.persist(Problem);
	    }
	    
	    /* (non-Javadoc)
		 * @see com.zycus.dao.ProblemDAO#update(com.zycus.model.Problem)
		 */
	    @Override
		public void update(Problem Problem) 
	    {
	        manager.createQuery("update Problem set Problemtext=?, Problemname=?, Problemcategory=?, difficulty=? where Problemid=?")
	        .setParameter(1, Problem.getProblemText())
	        .setParameter(2, Problem.getProblemName())
	        .setParameter(3, Problem.getProblemCategory())
	        .setParameter(4, Problem.getDifficulty())
	        .setParameter(5, Problem.getProblemId())
	        .executeUpdate();
	    }
	    
	    /*public void update(Problem updatedProblem) 
	    {
	       Problem Problem = (Problem) manager.find(Problem.class, updatedProblem.getProblemId());
	       Problem.setProblemText(updatedProblem.getProblemText());
	       Problem.setProblemName(updatedProblem.getProblemName());
	       Problem.setProblemCategory(updatedProblem.getProblemCategory());
	       Problem.setDifficulty(updatedProblem.getDifficulty());
	    }*/
	    
	    /* (non-Javadoc)
		 * @see com.zycus.dao.ProblemDAO#delete(com.zycus.model.Problem)
		 */
	    @Override
		public void delete(Problem Problem) 
	    {
	        manager.remove(Problem);
	    }
	    
	    /* (non-Javadoc)
		 * @see com.zycus.dao.ProblemDAO#getByID(int)
		 */
	    @Override
		public Problem getByID(int ProblemId)
	    {
	    	return (Problem) manager.find(Problem.class, ProblemId);
	    }
	    
	    /* (non-Javadoc)
		 * @see com.zycus.dao.ProblemDAO#getByCategory(java.lang.String)
		 */
	    @Override
		@SuppressWarnings("unchecked")
		public List<Problem> getByCategory(String ProblemCategory)
	    {
	    	return manager.createQuery("Select p From Problem p where p.ProblemCategory=?")
	    			.setParameter(1, ProblemCategory)
	    			.getResultList();
	    }
	    
	    /* (non-Javadoc)
		 * @see com.zycus.dao.ProblemDAO#getByName(java.lang.String)
		 */
	    @Override
		@SuppressWarnings("unchecked")
		public List<Problem> getByName(String Problemname)
	    {
	    	return manager.createQuery("Select p From Problem p where p.ProblemName=?")
	    			.setParameter(1, Problemname)
	    			.getResultList();
	    }
	    
	    /* (non-Javadoc)
		 * @see com.zycus.dao.ProblemDAO#getByDifficulty(java.lang.String)
		 */
	    @Override
		@SuppressWarnings("unchecked")
		public List<Problem> getByDifficulty(String difficulty)
	    {
	    	return manager.createQuery("Select p From Problem p where p.difficulty=?")
	    			.setParameter(1, difficulty)
	    			.getResultList();
	    }
	}

