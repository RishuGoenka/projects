jQuery(function($) {

	var sharedId = $('#test_shared_id').text();

	$.get("problems/get/" + sharedId, function(response) {

		if(response.length == 0) {
			
			$('#problem_h2').html("Wrong shared id");
		}else {
			
			$('#problem_h2').html("All the best");			
		}
		
		
		
		var problemTable = "";
		for (var i in response) {

			var id = i+1;
			var qid = response[i].problemId;
			var qName = response[i].problemName;

			problemTable += "<tr><td> " + id + "</td>"
					+ "<td> <a href=\"problem?problemId=" + qid + "\">" + qName
					+ "</a></td>" + "</tr>";
		}

		$('#problem_list_table').html(problemTable);

	})

});