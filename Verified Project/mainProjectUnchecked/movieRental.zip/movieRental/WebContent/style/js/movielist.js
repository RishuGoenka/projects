	
 	
/* 	
	function formReset() {
		$.ajax( {
			 type: "GET",
			 url: "getALLMovieList",
			 data: true,
			 success: function(response) {
				 var moviedesign = "<div class='container'> <form> <p>Select movie and add to cart:</p> <br>";
					for (var j in response) {
						moviedesign += "<label class='checkbox-inline' for='Checkboxes_";              
						moviedesign += response[j].movieTitle;   
						moviedesign += "'><input type='checkbox' name='Checkboxes' id='Checkboxes_";
						moviedesign += response[j].movieTitle;
						moviedesign += "' value='";
						moviedesign += response[j].movieTitle;
						moviedesign += "'><span class='glyphicon glyphicon-film'></span>  ";
						moviedesign += response[j].movieTitle;
						moviedesign += "   <strong>  - Rs. ";
						moviedesign += response[j].movieCost;
						moviedesign += "</strong></label> <br> ";
					}
					moviedesign += " <input type='button' class='btn btn-primary' value='Add Movie To Cart' onClick='onClickq12(this)'></form></div>";
					$("#mov").html(moviedesign); 
			 },
				error : function() { 
					alert("Somthing Went Wrong");
				}
			 });
 	}
 	
 	*/
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
