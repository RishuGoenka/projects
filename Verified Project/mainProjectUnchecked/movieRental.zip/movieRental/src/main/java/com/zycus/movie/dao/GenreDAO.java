package com.zycus.movie.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.movie.model.Genre;

@Repository
public interface GenreDAO {

	/**
	 * Save Genre Object passed to it
	 * 
	 * @param genreObj
	 * @return true/false
	 */
	public abstract boolean saveGenre(Genre genreObj);

	/**
	 * Update Genre Object passed to it
	 * 
	 * @param genreObj
	 * @return true/false
	 */
	public abstract	boolean updateGenre(Genre genreObj);

	/**
	 * Delete Genre Object passed to it
	 * 
	 * @param genreId
	 * @return true/false
	 */
	public abstract boolean deleteGenreById(int genreId);
	
	/**
	 * Genre Id is passed to it
	 * Null if Nothing Found
	 * 
	 * @param genreId
	 * @return genreObj
	 */
	public abstract Genre getGenreById(int genreId);
	
	/**
	 * Genre name is passed to it
	 * Null if Nothing Found
	 * 
	 * @param genreName
	 * @return genreObj
	 */
	public abstract Genre getGenreByName(String genreName);
	
	/**
	 * Genre name is passed to it
	 * 
	 * @param genreName
	 * @return true/false
	 */
	public abstract boolean isGenreAvailable(String genreName);
	
	/**
	 * List of all the Genres
	 * Null if Nothing Found
	 * 
	 * @return genreList
	 */
	public abstract List<Genre> getAllGenres();

	/**
	 * Count of the genre
	 * Zero if Nothing Found
	 * 
	 * @return
	 */
	public abstract int getNoOfGenres();

}
