package com.zycus.movie.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.movie.model.Genre;

@Repository
public abstract interface GenreService {

	/**
	 * Save Genre
	 * 
	 * @param genreObj
	 * @return
	 */
	public abstract boolean saveGenre(Genre genreObj);

	/**
	 * Update Genre
	 * 
	 * @param genreObj
	 * @return
	 */
	public abstract	boolean updateGenre(Genre genreObj);

	/**
	 * Delete Genre
	 * 
	 * @param genreId
	 * @return
	 */
	public abstract boolean deleteGenre(int genreId);
	
	/**
	 * Get Genre Object By Genre Id
	 * 
	 * @param genreId
	 * @return
	 */
	public abstract Genre getGenreById(int genreId);
	
	/**
	 * Get Genre Object By Genre Name
	 * 
	 * @param genreName
	 * @return
	 */
	public abstract Genre getGenreByName(String genreName);
	
	/**
	 * Check Genre Available or Not
	 * 
	 * @param genreName
	 * @return
	 */
	public abstract boolean isGenreAvailable(String genreName);
	
	/**
	 * List of all the Genre
	 * 
	 * @return
	 */
	public abstract List<Genre> getAllGenres();

	/**
	 * Count of all the Genre
	 * 
	 * @return
	 */
	public abstract int getNoOfGenres();

}
