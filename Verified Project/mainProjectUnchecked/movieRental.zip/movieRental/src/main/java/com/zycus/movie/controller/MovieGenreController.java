package com.zycus.movie.controller;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.movie.model.Genre;
import com.zycus.movie.model.Movie;
import com.zycus.movie.model.MovieGenre;
import com.zycus.movie.model.User;
import com.zycus.movie.service.GenreService;
import com.zycus.movie.service.MovieGenreService;
import com.zycus.movie.service.MovieService;

@Controller
public class MovieGenreController {

	@Autowired
	private MovieGenreService moviegenreService;

	@Autowired
	private GenreService genreService;

	@Autowired
	private MovieService movieService;


	/**
	 * Genre List
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/genreMovieList", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Movie> genreMovieList(HttpServletRequest request, HttpServletResponse response) {
		String genreName = request.getParameter("genre").trim();
		if ("All Movies".equals(genreName)) {
			List<Movie> movieList = movieService.getAllMovies();
			return movieList;
		}
		Genre genr = (Genre) genreService.getGenreByName(genreName);
		int genreId = (int) genr.getgenreId();
		List<?> movielist = moviegenreService.findMovieGenreByGenreId(genreId);
		List<Movie> mlist = new ArrayList<Movie>();
		Iterator<?> itr = movielist.iterator();
		while (itr.hasNext()) {
			Object element = itr.next();
			int id = (int) element;
			Movie movieObj = movieService.getMovieByID(id);
			mlist.add(movieObj);
		}
		return mlist;
	}

	/**
	 * Movie Genre List
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/movieGenreList", method = RequestMethod.GET)
	public @ResponseBody String movieGenreList(HttpServletRequest request, HttpServletResponse response) {
		String genreName = request.getParameter("glist").trim();
		String[] separate = genreName.split(" ");
		String movieTitle = request.getParameter("movieName").trim();
		int separatelength = separate.length;
		List<Genre> genrelist = new LinkedList<>();
		for (int i = 0; i < separatelength; i++) {
			if (separate[i].trim().isEmpty())
				continue;
			genrelist.add(genreService.getGenreByName(separate[i]));
		}
		Movie movieObj = movieService.getMovieByTitle(movieTitle);
		MovieGenre movieGenre = new MovieGenre();
		Iterator<Genre> itr = genrelist.iterator();
		while (itr.hasNext()) {
			Genre genreObj = itr.next();
			movieGenre.setMovie(movieObj);
			movieGenre.setgenre(genreObj);
			moviegenreService.saveMovieGenre(movieGenre);
		}
		String ok = "ok";
		return ok;
	}

	/**
	 * User Movie List
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/userMovieList", method = RequestMethod.GET)
	public @ResponseBody boolean userMovieList(HttpServletRequest request, HttpServletResponse response) {
		String movieTitle = request.getParameter("movieName").trim();
		HttpSession session = request.getSession();
		String[] separate = movieTitle.split("    ");
		Set<String> newList = new HashSet<>();
		for (String i : separate) {
			newList.add(i);
		}
		if (session.getAttribute("movieTitle") == null) {
			session.setAttribute("movieTitle", newList);
		} else {
			Set<String> oldList = (Set<String>) session.getAttribute("movieTitle");
			for (String i : oldList) {
				newList.add(i);
			}
			session.removeAttribute("movieTitle");
			session.setAttribute("movieTitle", newList);

			System.out.println(session.getAttribute("movieTitle"));
		}
		boolean flag = true;
		return flag;
	}

	/**
	 * Create Movie Page
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/createmovie")
	public String createmovie(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null || !("USER_A".equals(user.getUserRole()))) {
			session.invalidate();
			return "index";
		}
		return "createmovie";

	}
	
}
