package com.zycus.movie.dao;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.movie.model.Movie;
@Repository
public interface MovieDAO {

	/**
	 * Save Movie movieObj passed to it
	 * 
	 * @param movieObj
	 * @return true/false
	 */
	public abstract boolean saveMovie(Movie movieObj);
	
	/**
	 * Update Movie movieObj passed to it
	 * 
	 * @param movieObj
	 * @return true/false
	 */
	public abstract boolean updateMovie(Movie movieObj);

	/**
	 * Delete Movie movieObj passed to it
	 * 
	 * @param movieId
	 * @return true/false
	 */
	public abstract boolean deleteMovie(int movieId);

	/**
	 * Retrieve Movie Object MovieId passed to it
	 * Null if Nothing Found
	 * 
	 * @param movieId
	 * @return movieObj
	 */
	public abstract Movie getMovieById(int movieId);

	/**
	 * Retrieve Movie Object MovieTitle passed to it
	 * Null if Nothing Found
	 * 
	 * @param movieTitle
	 * @return movieObj
	 */
	public abstract Movie getMovieByTitle(String movieTitle);
	
	/**
	 * Check Movie with the Title Exist MovieTitle passed to it
	 * Null if Nothing Found
	 *
	 * @param movieTitle
	 * @return true/false
	 */
	public abstract boolean isMovieAvailable(String movieTitle);

	/**
	 * List of Movie with the Cost is Passed to it.
	 * Null if Nothing Found
	 * 
	 * @param movieCost
	 * @return movieList
	 */
	public abstract List<Movie> getMovieByCost(double movieCost);
	
	/**
	 * List of all the Movies
	 * Null if Nothing Found
	 * 
	 * @return
	 */
	public abstract List<Movie> getAllMovies();

	/**
	 * Movie Count
	 * Zero if nothing found
	 * 
	 * @return
	 */
	public abstract int getNoOfMovies();

	/**
	 * Search Movie with the Word passed to it
	 * Null if Nothing Found
	 * 
	 * @param name
	 * @return
	 */
	public abstract List<Movie> getSearchedMovie(String name);

}
