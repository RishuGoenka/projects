package com.zycus.movie.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.movie.model.DetailDTO;
import com.zycus.movie.model.Genre;
import com.zycus.movie.model.Movie;
import com.zycus.movie.model.User;
import com.zycus.movie.service.GenreService;
import com.zycus.movie.service.MovieGenreService;
import com.zycus.movie.service.MovieService;

@Controller
public class MovieController {

	@Autowired
	private MovieService movieService;

	@Autowired
	private MovieGenreService movieGenreService;

	@Autowired
	private GenreService genreService;

	/**
	 * Save Movie
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/saveMovie")
	public ModelAndView saveMovie(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		String title = request.getParameter("movieTitle").trim();
		Double cost = Double.parseDouble(request.getParameter("movieCost"));
		Movie movieObj = new Movie(title, cost);
		if (movieService.saveMovie(movieObj)) {
			modelAndView.addObject("successMessage", "SuccessFull Created Movie");
			modelAndView.addObject("movieNameMV", title);
			modelAndView.setViewName("genrelist");
		} else {
			modelAndView.setViewName("movie");
		}
		return modelAndView;
	}

	/**
	 * Movie List
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getALLMovieList", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Movie> getALLMovieList() {
		List<Movie> movieList = movieService.getAllMovies();
		return movieList;
	}

	/**
	 * Searched Movie List
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/getSerchedMovie", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Movie> getSerchedMovie(HttpServletRequest request, HttpServletResponse response) {
		String movieTitle = request.getParameter("movieTitle").trim();
		List<Movie> movieList = movieService.getSearchedMovie(movieTitle);
		return movieList;
	}

	/**
	 * User Movie List
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/getMyMovieDetails", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<DetailDTO> getMyMovieDetails(HttpServletRequest request, HttpServletResponse response) {
		String movieTitle = request.getParameter("movie").trim();
		String[] split = movieTitle.split("    ");
		System.out.println(split[0]);
		List<DetailDTO> movieDetailList = new ArrayList<>();
		Movie movieObj = movieService.getMovieByTitle(split[0]);
		int movieId = (int) movieObj.getMovieId();
		List<?> genrelist = movieGenreService.findGenreMovieByMovieId(movieId);
		List<Genre> glist = new ArrayList<Genre>();
		Iterator<?> itr = genrelist.iterator();
		while (itr.hasNext()) {
			Object element = itr.next();
			int id = (int) element;
			Genre genreObj = genreService.getGenreById(id);
			glist.add(genreObj);
		}
		DetailDTO dto = new DetailDTO(movieObj.getMovieTitle(), movieObj.getMovieCost(), "");
		movieDetailList.add(dto);
		for (Genre i : glist) {
			DetailDTO detailObj = new DetailDTO();
			detailObj.setMovieTitle("");
			detailObj.setMovieCost(0.0);
			detailObj.setGenre(i.getgenreName());
			movieDetailList.add(detailObj);
		}
		return movieDetailList;
	}

	/**
	 * Movie Page
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/movie")
	public String movie(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null || !("USER_A".equals(user.getUserRole()))) {
			session.invalidate();
			return "index";
		}
		return "movie";
	}

	/**
	 * Movie List Page
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/movielist")
	public String movielist(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null)
			return "index";
		return "movielist";
	}

}
