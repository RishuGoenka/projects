package com.zycus.movie.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.movie.model.Genre;
import com.zycus.movie.model.Movie;
import com.zycus.movie.model.User;

@Repository
@Transactional
public class MovieDAOImpl implements MovieDAO {
	@PersistenceContext
	private EntityManager manager;

	static Logger log = Logger.getLogger(MovieDAOImpl.class.getName());

	@Override
	public boolean saveMovie(Movie movieObj) {
		try {
			if (movieObj != null) {
				manager.persist(movieObj);
				return true;
			} else {
				log.error("Movie Object Found Null");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while saving the Movie", e);
			return false;
		}
	}

	@Override
	public boolean updateMovie(Movie movieObj) {
		try {
			if (movieObj != null) {
				manager.merge(movieObj);
				return true;
			} else {
				log.error("Movie Object Found Null");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while Updating the Movie", e);
			return false;
		}
	}

	@Override
	public boolean deleteMovie(int movieId) {
		try {
			if (movieId > 0) {
				Movie movieObj = manager.find(Movie.class, movieId);
				if (movieObj != null) {
					manager.remove(movieObj);
					return true;
				} else {
					log.error("Movie Object Found Null");
					return false;
				}
			} else {
				log.error("Movie with the Id Not Valid");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while deleting the Movie", e);
			return false;
		}
	}

	@Override
	public Movie getMovieById(int movieId) {
		try {
			if (movieId > 0) {
				return manager.find(Movie.class, movieId);
			} else {
				log.error("Movie with the Id Not Valid");
				return null;
			}
		} catch (Exception e) {
			log.error("Error while finding the Movie By Id", e);
			return null;
		}
	}

	@Override
	public Movie getMovieByTitle(String movieTitle) {
		try {
			if (movieTitle.isEmpty()) {
				log.error("Title not found");
				return null;
			} else {
				Movie movieObj = (Movie) manager.createQuery("Select m from Movie m where m.movieTitle =:movieTitle")
						.setParameter("movieTitle", movieTitle).getSingleResult();
				return movieObj;
			}
		} catch (Exception e) {
			log.error("Error while finding the Movie By Title", e);
			return null;
		}
	}

	@Override
	public boolean isMovieAvailable(String movieTitle) {
		try {
			if (movieTitle.isEmpty()) {
				log.error("Title not found");
				return false;
			} else {
				int value = (int) manager.createQuery("Select m from Movie m where m.movieTitle =:movieTitle")
						.setParameter("movieTitle", movieTitle).getResultList().size();
				System.out.println(value);
				if (value == 1)
					return true;
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error while finding the Movie By Title", e);
			return false;
		}
	}

	@Override
	public List<Movie> getMovieByCost(double movieCost) {
		try {
			List<Movie> movieList = manager.createQuery("select m from Movie m where m.movieCost = :movieCost")
					.setParameter("movieCost", movieCost).getResultList();
			return movieList;
		} catch (Exception e) {
			log.error("Error while retriving Movie List By Cost", e);
			return null;
		}
	}

	@Override
	public List<Movie> getAllMovies() {
		try {
			List<Movie> movieList = manager.createQuery("select m from Movie m").getResultList();
			return movieList;
		} catch (Exception e) {
			log.error("Error while retriving Movie List", e);
			return null;
		}
	}

	@Override
	public int getNoOfMovies() {
		try {
			return (int) manager.createQuery("select m from Movie m").getResultList().size();
		} catch (Exception e) {
			log.error("Error while retriving Movie Count", e);
			return 0;
		}
	}
	
	
	@Override
	public List<Movie> getSearchedMovie(String name){
		try{
			List<Movie> movieList = manager.createQuery("select m from Movie m where LOWER(m.movieTitle) like ? ").setParameter(1, "%" + name + "%").getResultList();
			return movieList;
		} catch (Exception e) {
			log.error("Error while serching Movie List ", e);
			return null;
		}
	}
}
