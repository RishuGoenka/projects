package com.zycus.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.movie.dao.GenreDAO;
import com.zycus.movie.model.Genre;

@Service
public class GenreServiceImpl implements GenreService {

	@Autowired
	private GenreDAO genreDAO;

	public boolean saveGenre(Genre genreObj) {
		if (genreDAO.isGenreAvailable(genreObj.getgenreName()))
			return false;
		return genreDAO.saveGenre(genreObj);
	}

	public boolean updateGenre(Genre genreObj) {
		if (genreObj != null)
			return genreDAO.updateGenre(genreObj);
		return false;
	}

	public boolean deleteGenre(int genreId) {
		if (genreId > 0)
			return genreDAO.deleteGenreById(genreId);
		return false;
	}

	public Genre getGenreById(int genreId) {
		if (genreId > 0)
			return genreDAO.getGenreById(genreId);
		return null;

	}

	public boolean isGenreAvailable(String genreName) {
		if (genreName.isEmpty())
			return false;
		return genreDAO.isGenreAvailable(genreName);

	}

	public Genre getGenreByName(String genreName) {
		if (genreName.isEmpty())
			return null;
		return genreDAO.getGenreByName(genreName);
	}

	public List<Genre> getAllGenres() {
		return genreDAO.getAllGenres();
	}

	public int getNoOfGenres() {
		return genreDAO.getNoOfGenres();
	}

}
