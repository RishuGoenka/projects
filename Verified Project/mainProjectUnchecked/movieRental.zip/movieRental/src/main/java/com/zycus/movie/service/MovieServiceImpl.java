package com.zycus.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.movie.dao.MovieDAO;
import com.zycus.movie.model.Movie;

@Service
public class MovieServiceImpl implements MovieService {

	@Autowired
	private MovieDAO movieDAO;

	public boolean saveMovie(Movie movieObj) {
		if (movieDAO.isMovieAvailable(movieObj.getMovieTitle()))
			return false;
		return movieDAO.saveMovie(movieObj);
	}

	public boolean updateMovie(Movie movieObj) {
		if (movieObj != null)
			return movieDAO.updateMovie(movieObj);
		return false;
	}

	public boolean deleteMovie(int movieId) {
		if (movieId > 0)
			return movieDAO.deleteMovie(movieId);
		return false;
	}

	public Movie getMovieByID(int movieId) {
		if (movieId > 0)
			return movieDAO.getMovieById(movieId);
		return null;
	}

	public Movie getMovieByTitle(String movieTitle) {
		if (movieTitle.isEmpty())
			return null;
		return movieDAO.getMovieByTitle(movieTitle);

	}

	public boolean isMovieAvailable(String movieTitle) {
		if (movieTitle.isEmpty())
			return false;
		return movieDAO.isMovieAvailable(movieTitle);
	}

	public List<Movie> getAllMovies() {
		return movieDAO.getAllMovies();
	}

	public List<Movie> getMovieByCost(double movieCost) {
		return movieDAO.getMovieByCost(movieCost);
	}

	public int getNoOfMovies() {
		return movieDAO.getNoOfMovies();
	}

	@Override
	public List<Movie> getSearchedMovie(String name) {
		return movieDAO.getSearchedMovie(name);
	}

}
