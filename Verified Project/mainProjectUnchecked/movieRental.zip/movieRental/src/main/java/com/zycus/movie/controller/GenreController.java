package com.zycus.movie.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.movie.model.Genre;
import com.zycus.movie.model.User;
import com.zycus.movie.service.GenreService;

@Controller
public class GenreController {

	@Autowired
	private GenreService genreService;

	/**
	 * Save Genre
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/saveGenre")
	public ModelAndView saveGenre(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		String genre = request.getParameter("genre");
		Genre genreObj = new Genre(genre);
		String successMessage = "SuccessFull Added : " + genre;
		if (genreService.saveGenre(genreObj)) {
			modelAndView.addObject("successMessage", successMessage);
			modelAndView.setViewName("genre");
		} else {
			modelAndView.addObject("failMessage", "Failed to Add Genre Exist");
			modelAndView.setViewName("genre");
		}
		return modelAndView;
	}

	/**
	 * Return Genre List
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getGenreList", method = RequestMethod.GET, produces = "application/json")
	private @ResponseBody List<Genre> getGenreList() {
		List<Genre> genrelist = genreService.getAllGenres();
		return genrelist;
	}

	/**
	 * Genre Page
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/genre")
	public String genre(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null || !("USER_A".equals(user.getUserRole()))) {
			session.invalidate();
			return "index";
		}
		return "genre";
	}
}
