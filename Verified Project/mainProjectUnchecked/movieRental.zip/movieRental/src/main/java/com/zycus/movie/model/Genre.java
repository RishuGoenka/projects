package com.zycus.movie.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Genre")
public class Genre implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "genre_id")
	private int genreId;
	
	@NotEmpty(message = "Cannot be left empty")
	@Column(name = "genre_name")
	private String genreName;

	public Genre() {
		super();
	}

	public Genre(String genreName) {
		super();
		this.genreName = genreName;
	}

	public int getgenreId() {
		return genreId;
	}

	public void setgenreId(int genreId) {
		this.genreId = genreId;
	}

	public String getgenreName() {
		return genreName;
	}

	public void setgenre(String genreName) {
		this.genreName = genreName;
	}

}
