jQuery(function($) {
	var userId;
	var test;
	var problemId;
	var version;

	var submission_id = $('#problem_set_id').text();

	$.getJSON("result/get/" + submission_id, function(resp) {

		if (resp.length === 0) {

			$('#compile_error').removeClass('hide');
			$('table').hide();
			return;
		}

		var testCases = resp.testCases;
		var user = testCases[0].userSubmission.userTest.user;
		userId = user.userId;
		test = testCases[0].userSubmission.userTest.userTestId;
		problemId = testCases[0].userSubmission.problem.problemId;
		version = testCases[0].userSubmission.versionNumber;

		$('#user_email').html(user.email)
		$('#user_name').html(user.firstName + " " + user.lastName);

		cases = [];
		problemNames = [];

		for (var i = 0; i < testCases.length; i++) {

			var res = testCases[i].testCasebit ? "Pass" : "Fail";
			var memoryConsumed = testCases[i].memoryConsumed;
			var problemName = testCases[i].userSubmission.problem.problemName;
			var timeTaken = testCases[i].timeTaken;
			var micro = '\u00B5';

			addToProblems(problemName)
			cases[problemName] += "<tr><td>" + (i + 1) + "</td><td>" + res + "</td><td>"
					+ memoryConsumed + " kB" + "</td><td>" + timeTaken + " "
					+ micro + "s" + "</td></tr>"
		}

		var panel = "";

		for (var i = 0; i < problemNames.length; i++) {

			panel += '<div class="panel panel-default">'
					+ '<div class="panel-heading">'
					+ '<h4 class="panel-title">'
					+ '<a data-toggle="collapse" data-parent="#accordion"'
					+ 'href="#collapse"'
					+ i
					+ '> '
					+ problemNames[i]
					+ '</a>'
					+ '</h4>'
					+ '</div>'
					+ '<div id="collapse'
					+ i
					+ '" class="panel-collapse collapse in">'
					+ '<div class="panel-body">'
					+ '<table id="sample_case_table" class="table">'
					+ '<thead>'
					+ '<tr>'
					+ '<th>Sr. no</th>'
					+ '<th>Pass/Fail</th>'
					+ '<th>Memory consumed</th>'
					+ '<th>Time taken</th>'
					+ '</tr>'
					+ '</thead>'
					+

					'<tbody>'
					+ cases[problemNames[i]]
					+ '</tbody>'
					+ '</table>' + '</div>' + '</div>' + '</div>';
		}

		$('#accordion').html(panel);

		$.ajax({
			type : "GET",
			url : "viewProgram",
			data : {
				userId : userId,
				problem : problemId,
				version : version,
				test : test
			},
			success : function(data) {
				console.log(data);
				// $('#latest_code').html(data);
			}
		});

	});
});

function addToProblems(problemName) {

	if (problemNames.indexOf(problemName) === -1) {

		cases[problemName] = "";
		problemNames.push(problemName);

	}
}
