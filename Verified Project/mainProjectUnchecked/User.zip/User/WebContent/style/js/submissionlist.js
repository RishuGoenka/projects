jQuery(function($) {

	$.getJSON("problems/get/" + sharedId, function(response) {
	
		var submissionTable = "";
		for (var i in response) {

			var id = i+1;
			var qid = response[i].problemId;
			var uid = response[i].userId;
			var tid = response[i].testId;
			var sid = response[i].version; 
			submissionTable +="<form><tr><td>" + id  + "</td><td>" + pid +"</td><td>" + uid +"</td><td>"+ tid +"</td><td>" + sid +
			"</td><td><button class='btn btn-primary' type='button' id='view' name='view' onclick='alert()'>View</button></td></tr></form>";
		}

		$('#submission_list_table').html(submissionTable);

	})

});

function viewSubmission() {
		$.get("test-starting", {
		test_shared_id : $("#test_shared_id").text()
		});
	}

function startTest() {
	$.get("test-starting", {

		test_shared_id : $("#test_shared_id").text()
	}, function(duration) {

		$('.countdown').data('duration', duration);
		buildCountDownTimer();
		$('#start_test_btn').remove();
	});
}