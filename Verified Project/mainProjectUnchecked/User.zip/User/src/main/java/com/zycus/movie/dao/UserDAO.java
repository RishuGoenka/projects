package com.zycus.movie.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.movie.model.User;

@Repository
@Transactional
public interface UserDAO {
	/**
	 * Saves Users object passed to it 
	 * @param userObject
	 * @return 
	 */
	public abstract boolean saveUser(User userObject);

	/**
	 * Saves Users object passed to it 
	 * @param userObject
	 * @return 
	 */
/*	public abstract void deleteUser(int userId);*/
	
	/**
	 * returns user Object of the user whose id is passed to is
	 * else return null
	 * @param id
	 * @return User
	 */
	/*public abstract User getUserByID(int userId);*/

	/**
	 * Return a list of all the users 
	 * if empty it return an empty list
	 * @return
	 */
/*	public abstract List<User> getAllUsers();*/

	/**
	 * Returns Object of user having email = emailString or else returns null
	 * 
	 * @param emailString
	 * @return User
	 */
	/*public abstract User getUserByEmail(String emailString);
	*/
	/**
	 * Returns true if the email already exist in the database
	 * 
	 * @param email
	 * @return true/false
	 */

/*	public abstract boolean isEmailAvailable(String email);*/

	/**
	 * get total number of users
	 * @return
	 */
/*	public long getNoOfUsers(); */
}
