package com.zycus.movie.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.movie.model.User;
import com.zycus.movie.service.UserService;

@Controller
@SessionAttributes("user")
public class UserController {

	@Autowired
	UserService userService;

	/**
	 * Registration Of user
	 * 
	 * @param user
	 * @param result
	 * @return
	 */
	/**
	 * @param user
	 * @param result
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView registerUser(
			@ModelAttribute("userObject") @Valid User user, BindingResult result) {

		ModelAndView modelAndView = new ModelAndView();
/*		if (result.hasErrors()) {
			return new ModelAndView("register");
		} else {*/
				if (userService.addUser(user)) {
					modelAndView.setViewName("forward:/login?registered");
					modelAndView.addObject("Success");
					return modelAndView;
				} /*else {
					modelAndView.setViewName("register");
					modelAndView.addObject("error",
							"This email Id already exist");
					modelAndView.addObject("userObject", user);
					return modelAndView;
				}*/
				return modelAndView;
				}


	/**
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView setUpRegisterForm() {
		ModelAndView modelAndView = new ModelAndView("register");
		User user = new User();
		modelAndView.addObject("userObject", user);
		return modelAndView;
	}

	/**
	 * @return ModelAndView
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logoutGet() {
		return new ModelAndView("forward:/");
	}

}
