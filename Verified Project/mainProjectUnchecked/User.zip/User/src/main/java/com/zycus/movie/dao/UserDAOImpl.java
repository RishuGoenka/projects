package com.zycus.movie.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.movie.model.User;

@Repository
@Transactional
public class UserDAOImpl implements UserDAO {

	@PersistenceContext
	private EntityManager manager;

	@Override
	public boolean saveUser(User userObject) {
		try {
			manager.persist(userObject);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/*@Override
	public void deleteUser(int userId) {
		manager.remove(manager.find(User.class, userId));
	}

	@Override
	public User getUserByID(int userId) {
		return manager.find(User.class, userId);
	}

	@Override
	public List<User> getAllUsers() {
		List<User> userList = manager.createQuery("Select u from User u").getResultList();
		return userList;
	}

	@Override
	public User getUserByEmail(String emailString) {

		List<User> userList = null;
		userList = manager.createQuery("Select u from User u where u.email_id =:emailId")
				.setParameter("emailId", emailString).getResultList();

		if (userList.size() >= 1) {
			return userList.get(0);
		} else {
			return null;
		}
	}

	@Override
	public boolean isEmailAvailable(String email) {

		long value = (Long) manager.createQuery("Select COUNT(u) from User u where u.email_id =:emailId")
				.setParameter("emailId", email).getSingleResult();

		System.out.println(value);
		if (value == 1) {
			return true;
		} else {
			return false;
		}

	}

	@Override
	public long getNoOfUsers() {
		long noOfUsers = (long) manager.createQuery("Select COUNT(u) from User u where u.user_role='ROLE_USER'")
				.getSingleResult();
		return noOfUsers;
	}*/

}
