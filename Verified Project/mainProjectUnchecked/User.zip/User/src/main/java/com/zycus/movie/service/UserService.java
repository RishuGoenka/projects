package com.zycus.movie.service;

import java.util.Date;

import org.apache.catalina.Authenticator;
import org.apache.catalina.security.SecurityConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zycus.movie.dao.UserDAO;
import com.zycus.movie.model.User;

@Component
public class UserService {

	@Autowired
	private UserDAO userDAO;

	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

	/**
	 * Finds a user by email id
	 * 
	 * @param email
	 * @return
	 */
/*	public User findByEmail(String email) {

		return userDAO.getUserByEmail(email);
	}*/

	/**
	 * Adds an user
	 * 
	 * @param user
	 * @return
	 */
	public boolean addUser(User user) {

		/*if (userDAO.isEmailAvailable(user.getEmail())) {
			return false;
		} else {*/
			user.setUserRole("ROLE_USER");
			userDAO.saveUser(user);
			return true;
		/*}*/
	}

/*	*//**
	 * Gets user id of current logged in user
	 * 
	 * @return
	 *//*
	public int getCurrentLoggedInUserId() {
		User user = getCurrentUser();
		return user == null ? 0 : user.getUserId();
	}

	*//**
	 * Gets current user object, null if he is not logged in
	 * 
	 * @return
	 *//*
	public User getCurrentUser() {

		Authenticator auth = SecurityConfig.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			User user = ((UserPrincipal) principal).getUser();
			return user;
		}
		return null;

	}*/

/*	public long getNoOfUsers() {
		return userDAO.getNoOfUsers();
	}*/

}
