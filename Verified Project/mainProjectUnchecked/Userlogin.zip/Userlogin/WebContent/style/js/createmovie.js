	$(document).ready(function() {
		$.ajax({
			type : "GET",
			url : "getALLMovieList",
			data : true,
			success : function(data) {
				var design = "<div id='tab' class='btn-group' data-toggle='buttons'>";
				for ( var i in data) {
					design += "<label>";
					design += "<input type='button' class='btn btn-info' onClick='onClickq12_3(this)' value=' ";
					design += data[i].movieTitle;
					design += "    ";
					design += data[i].movieCost;
					design += "' /></label> ";
				}
				design += "</div>";
				$("#mlist").html(design);
			},
			error : function() { 
				window.location.href = "404";
			}
		});
	});
		
	function onClickq12_3(buttonA) {
		
		var moviename = buttonA.value;
		$.ajax({
			type : "GET",
			url : "getMyMovieDetails",
			data : {movie:moviename},
			success : function(data) {
				var design = "<div>";
					design += "Movie Title : ";
					design += data.movieTitle;
					design += "<br> MovieCost : ";
					design += data.movieCost;
				design += "</div><br> <a href='createmovie' class='btn btn-primary' role='button'> Back to Movie List</a>";
				$("#mlist").html(design);
			},
			error : function() { 
				window.location.href = "404";
			}
		});
		
	}