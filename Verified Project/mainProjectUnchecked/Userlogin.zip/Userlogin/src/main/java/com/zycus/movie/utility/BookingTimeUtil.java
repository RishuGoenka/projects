package com.zycus.movie.utility;

import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

public class BookingTimeUtil {
	//static Date date = new Date();

	public static Date startDate(Date date) { 
		Date startTime = date;
		return startTime;
	}

	public static Date endDate(int bookDays, Date date) throws ParseException {
		Calendar calander = Calendar.getInstance();
		calander.setTime(date);
		calander.add(Calendar.DATE, bookDays); // number of days to add
		Date endTime = calander.getTime();
		return endTime;
	}

	public int day(int i) {
		if (i > 0 && i < 365)
			return i;
		return 0;
	}

}
