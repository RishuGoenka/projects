package com.zycus.movie.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/*import com.zycus.movie.service.BookingService;
import com.zycus.movie.service.GenreService;
import com.zycus.movie.service.MovieGenreService;
import com.zycus.movie.service.MovieService;*/
import com.zycus.movie.service.UserService;

public class DController {

	@Autowired
	private UserService userService;

/*	@Autowired
	private MovieService movieService;

	@Autowired
	private GenreService genreService;

	@Autowired
	private BookingService bookingService;

	@Autowired
	private MovieGenreService moviegenreService;*/

	@RequestMapping(value = "/save")
	public ModelAndView add()	{
		ModelAndView model = new ModelAndView("added");
		
		/* test for User */
		
//		User user = new User("User", "user@user.com", "pass","Role");
		
//		User userObj = userService.getUserByID(2);
//		System.out.println(userObj);
//		System.out.println(userService.getNoOfUsers());
//		System.out.println(userService.saveUser(user));
//		System.out.println(userService.getAllUsers());
//		System.out.println(userService.getUserByEmail("user@user.com"));
//		System.out.println(userService.getUserByEmailPassword("user@user.com", "pass"));
//		System.out.println(userService.isEmailAvailable("user@user.com"));
//		System.out.println(userService.getUserByID(2));
		
		/* test for Movie */
		
//		Movie movie = new Movie("M", 3);
			
//		movieService.getSearchedMovie("D");
//		Movie movie = movieService.getMovieByID(1);
//		System.out.println(movie);
//		System.out.println(movieService.saveMovie(movie));
//		System.out.println(movieService.getNoOfMovies());
//		System.out.println(movieService.getAllMovies());
//		System.out.println(movieService.getMovieByCost(765432).toString());
//		System.out.println(movieService.getMovieByTitle("MoviT").toString());
//		System.out.println(movieService.isMovieAvailable("mm"));
//		System.out.println(movieService.getMovieByID(1));		
		
		/* test for Genre */	
		
//		 Genre genre = new Genre("art"); 
		
//		 Genre genre = genreService.getGenreById(2);
//		System.out.println(genreService.saveGenre(genre));
//		System.out.println(genreService.getNoOfGenres());
//		System.out.println(genreService.getAllGenres());
//		System.out.println(genreService.getGenreByName("cat").toString());
//		System.out.println(genreService.isGenreAvailable("cat"));
//		System.out.println(genreService.getGenreById(1));		
		
		
//		System.out.println(userService.deleteUser(5));
//		System.out.println(movieService.deleteMovie(2));
//		System.out.println(genreService.deleteGenre(1));		
		
		/* test for MovieGenre */
		
//		MovieGenre moviegenreObj = new MovieGenre(movie,genre);
		
//		System.out.println(moviegenreService.saveMovieGenre(moviegenreObj));
//		System.out.println(moviegenreService.findMovieGenreByGenreId(2));
//		System.out.println(moviegenreService.findGenreMovieByMovieId(1));
//		System.out.println(moviegenreService.findByIDs(2, 1));
//		System.out.println(moviegenreService.delete(movie, genre));
		
		/* test for Booking */
		
//		Booking bookingobj = new Booking(user,movie,BookingTimeUtil.startDate(date),endDate(2, date),123.21);
			
//		System.out.println(bookingService.saveBooking(bookingobj));
//		System.out.println(bookingService.getBookingByID(2));
//		System.out.println(bookingService.getAllBookings());
//		System.out.println(bookingService.getAllBookingsByUserID(2));
//		System.out.println(bookingService.getAllBookingsByMovieID(5));
//		System.out.println(bookingService.getNoOfBookings());
//		System.out.println(bookingService.getNoOfBookingsByUserID(2));
//		System.out.println(bookingService.getNoOfBookingsByMovieID(5));
//		System.out.println(bookingService.deleteBooking(1));
		
		/* Design for Active and disabled */
		
		/*String design = "<div class='container'><h2>Genre : List</h2> <p>The genre for the movie:</p> <form>";
		for (Genre temp : genrelist) {
			design += "<div class='checkbox'><label><input type='checkbox' name='genrelist' value='"+ temp.getgenreName() +"'>" + temp.getgenreName()
					+ "</label></div>";
		}

		design = design + " <input type='button' class='btn btn-primary' value='Submit List' onClick='onClickq12_3(this)'></form></div>";
		return design;*/

		/*  <div class='checkbox disabled'> <label><input type='checkbox' value='' disabled>Option 3</label></div> */
		
		return model;
	}

}
