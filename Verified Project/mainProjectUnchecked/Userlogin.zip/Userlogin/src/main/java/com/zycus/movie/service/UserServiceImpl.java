package com.zycus.movie.service;

import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.movie.dao.UserDAO;
import com.zycus.movie.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;
	
	@Override
	public boolean saveUser(String name,String email,String password) {
		if (emailValid(email) && userDAO.isEmailAvailable(email))
			return false;
		else {
			User user = new User(name, email, password);
			return userDAO.saveUser(user);
		}
	}

	@Override
	public boolean deleteUser(int userId) {
		if (userId > 0)
			return userDAO.deleteUserById(userId);
		return false;

	}

	@Override
	public User getUserByID(int userId) {
		if (userId > 0)
			return userDAO.getUserById(userId);
		return null;

	}

	@Override
	public User getUserByEmail(String email) {
		if (email.isEmpty())
			return null;
		return userDAO.getUserByEmail(email);
	}

	@Override
	public User getUserByEmailPassword(String email, String password) {
		if (email.isEmpty() || password.isEmpty())
			return null;
		return userDAO.getUserByEmailPassword(email, password);
	}

	@Override
	public boolean isEmailAvailable(String email) {
		if (email.isEmpty())
			return false;
		return userDAO.isEmailAvailable(email);
	}

	@Override
	public List<User> getAllUsers() {
		return userDAO.getAllUsers();
	}

	@Override
	public int getNoOfUsers() {
		return userDAO.getNoOfUsers();
	}

	private boolean emailValid(String email) {
		return Pattern.matches("^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$", email);
	}
	
}


