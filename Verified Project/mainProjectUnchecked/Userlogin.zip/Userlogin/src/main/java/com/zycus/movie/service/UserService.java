package com.zycus.movie.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.movie.model.User;

@Repository
public abstract interface UserService {

	/**
	 * Save User
	 * 
	 * @param name
	 * @param email
	 * @param password
	 * @return
	 */
	public abstract boolean saveUser(String name,String email,String password);

	/**
	 * Delete User
	 * 
	 * @param userId
	 * @return
	 */
	public abstract boolean deleteUser(int userId);

	/**
	 * Get User By User Id
	 * 
	 * @param userId
	 * @return
	 */
	public abstract User getUserByID(int userId);

	/**
	 * Get User By Email Id
	 * 
	 * @param email
	 * @return
	 */
	public abstract User getUserByEmail(String email);

	/**
	 * Get User By Email Id and Password
	 * 
	 * @param email
	 * @param password
	 * @return
	 */
	public abstract User getUserByEmailPassword(String email,String password);
	
	/**
	 * Check weather Email Exist or not
	 * 
	 * @param email
	 * @return
	 */
	public abstract boolean isEmailAvailable(String email);
	
	/**
	 * Get Complete user List
	 * 
	 * @return
	 */
	public abstract List<User> getAllUsers();

	/**
	 * Get Total User Count
	 * 
	 * @return
	 */
	public abstract int getNoOfUsers(); 
	
}
