package com.zycus.movie.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.movie.model.User;
import com.zycus.movie.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	/**
	 * Register User Validation and Save
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView saveUser(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		if (userService.saveUser(name, email, password)) {
			modelAndView.addObject("successMessage", "SuccessFull Registerd");
			modelAndView.setViewName("login");
		} else {
			modelAndView.addObject("failMessage", "Failed to Register User Email Id Exist");
			modelAndView.setViewName("register");
		}
		return modelAndView;
	}

	/**
	 * Login User Validation and Forward
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView loginUser(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		User user = userService.getUserByEmailPassword(email, password);
		if (user != null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			String name = "Good to See you back ! Welcome" + user.getUserName() + "!";
			if ("USER_A".equals(user.getUserRole())) {
				modelAndView.addObject("successMessage", name);
				modelAndView.setViewName("createmovie");
			} else {
				modelAndView.addObject("successMessage", name);
				modelAndView.setViewName("movielist");
			}
		} else {
			modelAndView.addObject("failMessage", "Failed to Login User Either Pasword or Eamil is Wrong");
			modelAndView.setViewName("login");
		}
		return modelAndView;
	}

	/**
	 * View Profile
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/viewprofile")
	public String viewprofile(HttpServletRequest request) {
		return "viewprofile";
	}

	/**
	 * User Logout
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/logout")
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		return "index";
	}

	/**
	 * Home Page
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/index")
	public String index(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		return "index";
	}

	/**
	 * Login Page
	 * 
	 * @param request
	 * @return
	 */

	@RequestMapping(value = "/login")
	public String login(HttpServletRequest request) {
		return "login";
	}

	/**
	 * Register Page
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/register")
	public String register(HttpServletRequest request) {
		return "register";
	}

	/**
	 * User Logged in Home
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/home")
	public String home(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null)
			return "index";
		return "home";
	}

}
