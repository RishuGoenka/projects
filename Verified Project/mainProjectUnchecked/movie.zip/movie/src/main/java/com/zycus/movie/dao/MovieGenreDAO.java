package com.zycus.movie.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.movie.model.Genre;
import com.zycus.movie.model.Movie;
import com.zycus.movie.model.MovieGenre;

@Repository
public interface MovieGenreDAO {

	/**
	 * Save Movie with Genre moviegenre Object is passed to it.
	 * True when User Successfully Saved
	 * False when failed to save User
	 * 
	 * @param moviegenreObj
	 * @return true/false
	 */
	public abstract boolean saveMovieGenre(MovieGenre moviegenreObj);
	
	/**
	 * Update Movie with Genre moviegenre Object is passed to it.
	 * True when User Successfully Update
	 * False when failed to update User
	 * 
	 * @param moviegenreObj
	 * @return true/false
	 */
	public abstract boolean updateMovieGenre(MovieGenre moviegenreObj);
	
	/**
	 * Delete Movie with Genre moviegenre Object is passed to it.
	 * True when User Successfully Delete
	 * False when failed to delete User
	 * 
	 * @param moviegenreObj
	 * @return true/false
	 */
	public abstract boolean deleteMovieGenre(MovieGenre moviegenreObj);
	
	/**
	 * List of all the Movies with its Genre
	 * Return null if Not Found
	 * 
	 * @return userObj
	 */
	public abstract List<MovieGenre> getAllMovieGenre();

	/**
	 * List of all the Movies whose Genre Id is Passed
	 * Return null if Not Found
	 * 
	 * @param genreId
	 * @return
	 */
	public abstract List<Movie> findMovieGenreByGenreId(int genreId);

	/**
	 * List of all the Genre whose Movie Id is Passed
	 * Return null if Not Found
	 * 
	 * @param movieId
	 * @return
	 */
	public abstract List<Genre> findGenreMovieByMovieId(int movieId);

	/**
	 * MoviesGenre Object whose Movie Id and Genre id is passed
	 * Null if Nothing Found
	 * 
	 * @param genreId
	 * @param movieId
	 * @return
	 */
	public abstract MovieGenre findByIDs(int genreId, int movieId);

}
