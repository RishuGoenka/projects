package com.zycus.movie.service;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.movie.model.Movie;
@Repository
public abstract interface MovieService {

	/**
	 * Save Movie
	 * 
	 * @param movieObj
	 * @return
	 */
	public abstract boolean saveMovie(Movie movieObj);
	
	/**
	 * Update Movie
	 * 
	 * @param movieObj
	 * @return
	 */
	public abstract boolean updateMovie(Movie movieObj);

	/**
	 * Delete Movie
	 * 
	 * @param movieId
	 * @return
	 */
	public abstract boolean deleteMovie(int movieId);

	/**
	 * Get Movie By Movie Id
	 * 
	 * @param movieId
	 * @return
	 */
	public abstract Movie getMovieByID(int movieId);

	/**
	 * Get Movie By Movie Title
	 * 
	 * @param movieTitle
	 * @return
	 */
	public abstract Movie getMovieByTitle(String movieTitle);
	
	/**
	 * Check Movie with the Title Exist or not
	 * 
	 * @param movieTitle
	 * @return
	 */
	public abstract boolean isMovieAvailable(String movieTitle);

	/**
	 * List of Movies with the particular cost
	 * 
	 * @param movieCost
	 * @return
	 */
	public abstract List<Movie> getMovieByCost(double movieCost);
	
	/**
	 * List of all the Movies
	 * 
	 * @return
	 */
	public abstract List<Movie> getAllMovies();

	/**
	 * Total Count of Movie
	 * 
	 * @return
	 */
	public abstract int getNoOfMovies();
	
	/**
	 * List of movie as search result
	 * 
	 * @param name
	 * @return
	 */
	public abstract List<Movie> getSearchedMovie(String name);

}
