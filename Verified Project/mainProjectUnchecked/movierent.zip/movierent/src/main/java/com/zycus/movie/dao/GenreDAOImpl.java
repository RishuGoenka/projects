package com.zycus.movie.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.movie.model.Genre;

@Repository
@Transactional
public class GenreDAOImpl implements GenreDAO {
	@PersistenceContext
	private EntityManager manager;

	static Logger log = Logger.getLogger(GenreDAOImpl.class.getName());

	@Override
	public boolean saveGenre(Genre genreObj) {
		try {
			if (genreObj != null) {
				manager.persist(genreObj);
				return true;
			} else {
				log.error("Genre Object Found Null");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while saving the Genre", e);
			return false;
		}
	}

	@Override
	public boolean updateGenre(Genre genreObj) {
		try {
			if (genreObj != null) {
				manager.merge(genreObj);
				return true;
			} else {
				log.error("Genre Object Found Null");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while Upedating the Genre", e);
			return false;
		}
	}

	@Override
	public boolean deleteGenreById(int genreId) {
		try {
			if (genreId > 0) {
				Genre genreObj = manager.find(Genre.class, genreId);
				if (genreObj != null) {
					manager.remove(genreObj);
					return true;
				} else {
					log.error("Genre Object Found Null");
					return false;
				}
			} else {
				log.error("Genre with the Id Not Valid");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while deleting the Genre", e);
			return false;
		}
	}

	@Override
	public Genre getGenreById(int genreId) {
		try {
			if (genreId > 0) {
				return manager.find(Genre.class, genreId);
			} else {
				log.error("Genre with the Id Not Valid");
				return null;
			}
		} catch (Exception e) {
			log.error("Error while finding the Genre By Id", e);
			return null;
		}
	}

	@Override
	public Genre getGenreByName(String genreName) {
		try {
			if (genreName.isEmpty()) {
				log.error("GenreName not found");
				return null;
			} else {
				Genre genreObj = (Genre) manager.createQuery("select g from Genre g where g.genreName =:genreName")
						.setParameter("genreName", genreName).getSingleResult();
				return genreObj;
			}
		} catch (Exception e) {
			log.error("Error while finding the Genre By GenreName", e);
			return null;
		}
	}

	@Override
	public boolean isGenreAvailable(String genreName) {
		try {
			if (genreName.isEmpty()) {
				log.error("GenreName not found");
				return false;
			} else {
				int value = (int) manager.createQuery("select g from Genre g where g.genreName =:genreName")
						.setParameter("genreName", genreName).getResultList().size();
				if (value == 1)
					return true;
				return false;
			}
		} catch (Exception e) {
			log.error("Error While matching the Genre Name", e);
			return false;
		}
	}

	@Override
	public List<Genre> getAllGenres() {
		try {
			List<Genre> genreList = manager.createQuery("select g from Genre g").getResultList();
			return genreList;
		} catch (Exception e) {
			log.error("Error while retriving Genre List", e);
			return null;
		}
	}

	@Override
	public int getNoOfGenres() {
		try {
			return (int) manager.createQuery("select g from Genre g").getResultList().size();
		} catch (Exception e) {
			log.error("Error while retriving User Count", e);
			return 0;
		}
	}

}
