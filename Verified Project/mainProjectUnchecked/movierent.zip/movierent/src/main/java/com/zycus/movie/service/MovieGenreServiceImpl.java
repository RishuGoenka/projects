package com.zycus.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.movie.dao.MovieGenreDAO;
import com.zycus.movie.model.Genre;
import com.zycus.movie.model.Movie;
import com.zycus.movie.model.MovieGenre;

@Service
public class MovieGenreServiceImpl implements MovieGenreService {

	@Autowired
	private MovieGenreDAO moviegenreDAO;

	@Override
	public boolean saveMovieGenre(MovieGenre moviegenreObj) {
		if (moviegenreObj != null)
			return moviegenreDAO.saveMovieGenre(moviegenreObj);
		return false;
	}

	@Override
	public boolean updateMovieGenre(MovieGenre moviegenreObj) {
		if (moviegenreObj != null)
			return moviegenreDAO.updateMovieGenre(moviegenreObj);
		return false;
	}

	@Override
	public boolean deleteMovieGenre(MovieGenre moviegenreObj) {
		if (moviegenreObj != null)
			return moviegenreDAO.deleteMovieGenre(moviegenreObj);
		return false;
	}

	@Override
	public List<Movie> findMovieGenreByGenreId(int genreId) {
		if (genreId > 0)
			return moviegenreDAO.findMovieGenreByGenreId(genreId);
		return null;
	}

	@Override
	public List<Genre> findGenreMovieByMovieId(int movieId) {
		if (movieId > 0)
			return moviegenreDAO.findGenreMovieByMovieId(movieId);
		return null;
	}

	@Override
	public MovieGenre findByIDs(int genreId, int movieId) {
		if (genreId > 0 && movieId > 0)
			return moviegenreDAO.findByIDs(genreId, movieId);
		return null;
	}

	@Override
	public List<MovieGenre> getAllMovieGenre() {
		return moviegenreDAO.getAllMovieGenre();
	}

}
