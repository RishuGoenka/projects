package com.zycus.movie.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.movie.model.Genre;
import com.zycus.movie.model.Movie;
import com.zycus.movie.model.MovieGenre;

@Repository
public abstract interface MovieGenreService {

	/**
	 * Save Movie Genre Combination
	 * 
	 * @param moviegenreObj
	 * @return
	 */
	public abstract boolean saveMovieGenre(MovieGenre moviegenreObj);
	
	/**
	 * Update Movie Genre Combination
	 * 
	 * @param moviegenreObj
	 * @return
	 */
	public abstract boolean updateMovieGenre(MovieGenre moviegenreObj);
	
	/**
	 * Delete Movie Genre Combination
	 * 
	 * @param moviegenreObj
	 * @return
	 */
	public abstract boolean deleteMovieGenre(MovieGenre moviegenreObj);
	
	/**
	 * Get Complete List of Movie Genre Combination
	 * 
	 * @return
	 */
	public abstract List<MovieGenre> getAllMovieGenre();

	/**
	 * List of Movie for the particular Genre Id
	 * 
	 * @param genreId
	 * @return
	 */
	public abstract List<Movie> findMovieGenreByGenreId(int genreId);

	/**
	 * List of Genre for the particular Movie Id
	 * 
	 * @param movieId
	 * @return
	 */
	public abstract List<Genre> findGenreMovieByMovieId(int movieId);

	/**
	 * Find Particular Movie and Genre Id
	 * 
	 * @param genreId
	 * @param movieId
	 * @return
	 */
	public abstract MovieGenre findByIDs(int genreId, int movieId);
}
