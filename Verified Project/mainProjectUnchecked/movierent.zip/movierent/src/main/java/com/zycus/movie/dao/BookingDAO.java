package com.zycus.movie.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.movie.model.Booking;

@Repository
public interface BookingDAO {

	/**
	 * Save Booking Object passed to it
	 * 
	 * @param bookingObj
	 * @return true/false
	 */
	public abstract boolean saveBooking(Booking bookingObj);
	
	/**
	 * Update Booking Object passed to it
	 * 
	 * @param bookingObj
	 * @return true/false
	 */
	public abstract boolean updateBooking(Booking bookingObj);

	/**
	 * Delete Booking Object passed to it
	 * 
	 * @param bookingId
	 * @return true/false
	 */
	public abstract boolean deleteBooking(int bookingId);

	/**
	 * Booking Id passed to it
	 * 
	 * @param bookingId
	 * @return bookingObj
	 */
	public abstract Booking getBookingById(int bookingId);

	/**
	 * List of all the Bookings
	 * 
	 * 
	 * @return bookingList
	 */
	public abstract List<Booking> getAllBookings();

	/**
	 * List of all the Bookings for the User whose userId passed to it
	 * Null if Nothing Found
	 * 
	 * @param userId
	 * @return bookingList
	 */
	public abstract List<Booking> getAllBookingsByUserId(int userId);

	/**
	 * List of all the Bookings for the Movie whose movieId passed to it
	 * Null if Nothing Found
	 * 
	 * @param movieId
	 * @return bookingList
	 */
	public abstract List<Booking> getAllBookingsByMovieId(int movieId);

	/**
	 * count of all the Bookings
	 * Null if Nothing Found
	 * 
	 * @return
	 */
	public abstract int getNoOfBookings();

	/**
	 * count of all the Bookings for the User whose userId passed to it
	 * Zero if Nothing Found
	 * 
	 * @param userId
	 * @return
	 */
	public abstract int getNoOfBookingsByUserId(int userId);

	/**
	 * count of all the Bookings for the Movie whose movieId passed to it
	 * Zero if Nothing Found
	 * 
	 * @param movieId
	 * @return
	 */
	public abstract int getNoOfBookingsByMovieId(int movieId);
}
