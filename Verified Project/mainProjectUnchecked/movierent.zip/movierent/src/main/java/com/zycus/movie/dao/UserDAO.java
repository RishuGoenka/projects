package com.zycus.movie.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.movie.model.User;

@Repository
public interface UserDAO {

	/**
	 * Save User user Object is passed to it.
	 * True when User Successfully Saved
	 * False when failed to save User
	 * 
	 * @param userObj
	 * @return true/false
	 */
	public abstract boolean saveUser(User userObj);

	/**
	 * Delete User userId passed to it.
	 * True when User Successfully Deleted
	 * False when failed to Delete User
	 * 
	 * @param userId
	 * @return true/false
	 */
	public abstract boolean deleteUserById(int userId);

	/**
	 * Find user by userId is passed to it.
	 * Return null if Not Found
	 * 
	 * @param userId
	 * @return userObj
	 */
	public abstract User getUserById(int userId);

	/**
	 * Find user by Email is passed to it.
	 * Return null if Not Found
	 * 
	 * @param email
	 * @return userObj
	 */
	public abstract User getUserByEmail(String email);

	/**
	 * Find user by email and password is passed to it.
	 * Return null if Not Found
	 * 
	 * @param email
	 * @param password
	 * @return userObj
	 */
	public abstract User getUserByEmailPassword(String email,String password);
	
	/**
	 * Check if email exist email is passed to it.
	 * 
	 * @param email
	 * @return true/false
	 */
	
	public abstract boolean isEmailAvailable(String email);
	
	
	/**
	 * List of all the Users
	 * Return null if Not Found
	 * 
	 * @return userList
 	 */
	
	public abstract List<User> getAllUsers();
	
	/**
	 * Total Count of user 
	 * Return Zero if No Count
	 * 
	 * @return intCount
	 */
	public abstract int getNoOfUsers(); 
}
