package com.zycus.movie.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.movie.model.User;

@Repository
@Transactional
public class UserDAOImpl implements UserDAO {

	@PersistenceContext
	private EntityManager manager;
	
	static Logger log = Logger.getLogger(UserDAOImpl.class.getName());

	@Override
	public boolean saveUser(User userObj) {
		try {
			if (userObj != null) {
				manager.persist(userObj);
				return true;
			} else {
				log.error("User Object Found Null");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while saving the User", e);
			return false;
		}
	}

	@Override
	public boolean deleteUserById(int userId) {
		try {
			if (userId > 0) {
				User userObj = manager.find(User.class, userId);
				if (userObj != null) {
					manager.remove(userObj);
					return true;
				} else{
					log.error("User Object Found Null");
				return false;
				}
			} else {
				log.error("User with the Id Not Valid");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while deleting the User", e);
			return false;
		}
	}

	@Override
	public User getUserById(int userId) {
		try {
			if (userId > 0) {
				return manager.find(User.class, userId);
			} else {
				log.error("User with the Id Not Found");
				return null;
			}
		} catch (Exception e) {
			log.error("Error while finding the User By Id", e);
			return null;
		}
	}

	@Override
	public User getUserByEmail(String email) {
		try {
			if (email.isEmpty()) {
				log.error("Email not found");
				return null;
			} else {
				User userObj = (User) manager.createQuery("Select u from User u where u.email =:email")
						.setParameter("email", email).getSingleResult();
				return userObj;
			}
		} catch (Exception e) {
			log.error("Error while finding the User By Email", e);
			return null;
		}
	}

	@Override
	public User getUserByEmailPassword(String email, String password) {
		try {
			if (email.isEmpty() || password.isEmpty()) {
				log.error("Either Email Id or Password is wrong");
				return null;
			} else {
				User userObj = (User) manager
						.createQuery("Select u from User u where u.email =:email and u.password =:password")
						.setParameter("email", email).setParameter("password", password).getSingleResult();
				return userObj;
			}
		} catch (Exception e) {
			log.error("Error while matching Email and Password", e);
			return null;
		}
	}

	@Override
	public boolean isEmailAvailable(String email) {
		try {
			if (email.isEmpty()) {
				log.error("Email not found");
				return false;
			} else {
				int value = (int) manager.createQuery("select u from User u where u.email =:email")
						.setParameter("email", email).getResultList().size();
				if (value == 1)
					return true;
				return false;
			}
		} catch (Exception e) {
			log.error("Error While Matching Email", e);
			return false;
		}
	}

	@Override
	public List<User> getAllUsers() {
		try {
			List<User> userList = manager.createQuery("Select u from User u").getResultList();
			return userList;
		} catch (Exception e) {
			log.error("Error while retriving User List", e);
			return null;
		}
	}

	@Override
	public int getNoOfUsers() {
		try {
			int noOfUsers = (int) manager.createQuery("Select COUNT(u) from User u").getSingleResult();
			return noOfUsers;
		} catch (Exception e) {
			log.error("Error while retriving User Count", e);
			return 0;
		}
	}

}
