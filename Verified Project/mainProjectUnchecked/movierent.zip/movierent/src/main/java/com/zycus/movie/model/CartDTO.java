package com.zycus.movie.model;

import java.io.Serializable;

public class CartDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String movieTitle;
	private String startTime;
	private String endTime;
	private String totalCost;

	public CartDTO() {
		super();
	}

	public CartDTO(String movieTitle, String startTime, String endTime, String totalCost) {
		super();
		this.movieTitle = movieTitle;
		this.startTime = startTime;
		this.endTime = endTime;
		this.totalCost = totalCost;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(String totalCost) {
		this.totalCost = totalCost;
	}

}
