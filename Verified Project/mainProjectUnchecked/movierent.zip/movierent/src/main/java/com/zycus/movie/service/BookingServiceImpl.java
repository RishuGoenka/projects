package com.zycus.movie.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.movie.dao.BookingDAO;
import com.zycus.movie.model.Booking;

@Service
public class BookingServiceImpl implements BookingService {

	@Autowired
	private BookingDAO bookingDAO;

	public boolean saveBooking(Booking bookingObj) {
		if (bookingObj != null)
			return bookingDAO.saveBooking(bookingObj);
		return false;
	}

	public boolean updateBooking(Booking bookingObj) {
		if (bookingObj != null)
			return bookingDAO.updateBooking(bookingObj);
		return false;
	}

	public boolean deleteBooking(int bookingId) {
		if (bookingId > 0)
			return bookingDAO.deleteBooking(bookingId);
		return false;
	}

	public Booking getBookingByID(int bookingId) {
		if (bookingId > 0)
			return bookingDAO.getBookingById(bookingId);
		return null;
	}

	public List<Booking> getAllBookings() {
		return bookingDAO.getAllBookings();
	}

	public List<Booking> getAllBookingsByUserID(int userId) {
		if (userId > 0)
			return bookingDAO.getAllBookingsByUserId(userId);
		return null;
	}

	public List<Booking> getAllBookingsByMovieID(int movieId) {
		if (movieId > 0)
			return bookingDAO.getAllBookingsByMovieId(movieId);
		return null;
	}

	public int getNoOfBookings() {
		return bookingDAO.getNoOfBookings();
	}

	public int getNoOfBookingsByUserID(int userId) {
		if (userId > 0)
			return bookingDAO.getNoOfBookingsByUserId(userId);
		return userId;
	}

	public int getNoOfBookingsByMovieID(int movieId) {
		if (movieId > 0)
			return bookingDAO.getNoOfBookingsByMovieId(movieId);
		return movieId;
	}

}
