package com.zycus.movie.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Movie")
public class Movie implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "movie_id")
	private int movieId;
	
	@NotEmpty(message = "Cannot be left empty")
	@Column(name = "movie_title")
	private String movieTitle;
	
	@NotNull(message = "Cannot be left empty")
	@Column(name = "movie_cost")
	private Double movieCost;

	public Movie() {
		super();
	}

	public Movie(String movieTitle, Double movieCost) {
		super();
		this.movieTitle = movieTitle;
		this.movieCost = movieCost;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public double getMovieCost() {
		return movieCost;
	}

	public void setMovieCost(Double movieCost) {
		this.movieCost = movieCost;
	}

}
