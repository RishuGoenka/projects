package com.zycus.movie.model;

import java.io.Serializable;

public class DetailDTO implements Serializable {

	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	private String movieTitle;
	private Double movieCost;
	private String genre;

	public DetailDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DetailDTO(String movieTitle, Double movieCost, String genre) {
		super();
		this.movieTitle = movieTitle;
		this.movieCost = movieCost;
		this.genre = genre;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public Double getMovieCost() {
		return movieCost;
	}

	public void setMovieCost(Double movieCost) {
		this.movieCost = movieCost;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

}
