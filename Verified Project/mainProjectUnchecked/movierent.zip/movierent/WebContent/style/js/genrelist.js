/*<script>*/
	$(document)
			.ready(
					function() {
						$.ajax({
									type : "GET",
									url : "getGenreList",
									data : true,
									success : function(data) {
										var design = "<div class='container'> <form><p><div>Select Genre for the movie  : ${movieNameMV}</div></p> <br>";
										for ( var i in data) {
											design += "<label class='checkbox-inline' for='Checkboxes_";              
					design += data[i].genreName;   
					design += "'><input type='checkbox' name='Checkboxes' id='Checkboxes_";
					design += data[i].genreName;
					design += "' value='";
					design += data[i].genreName;
					design += "'>";
											design += data[i].genreName;
											design += "</label> <br> ";
										}
										design += " <input type='button' class='btn btn-primary' value='Submit List' onClick='onClickq12_3(this)'></form></div>";
										$("#glist").html(design);
									},
									error : function() {
										alert("Somthing Went Wrong");
									}
								});
					});

	function onClickq12_3(buttonA) {
		var favorite = [];
		$.each($("input[name='Checkboxes']:checked"), function() {
			favorite.push($(this).val());
		});
		var movieTitle = "${movieNameMV}";
		var genrelist = favorite.join(" ");
		$.ajax({
			type : "GET",
			url : "movieGenreList",
			data : {movieName : movieTitle,
				glist : genrelist
			},
			success : function(data) {
				
			}

		});
	}
/*</script>
<script>*/
	$(document).ready(
			function() {

				//When checkboxes/radios checked/unchecked, toggle background color
				$('.form-group').on('click','input[type=checkbox]',	function() {
							$(this).closest('.checkbox-inline, .checkbox')
									.toggleClass('checked');
						});

			});
/*</script>*/