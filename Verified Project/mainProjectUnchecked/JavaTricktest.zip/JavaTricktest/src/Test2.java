import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Test2  implements Test1{
	
	int a = 20;
public static <E, D> void main(String[] args) {
	List<String> a = new ArrayList<String>();
	List<String> ab = new LinkedList<String>();
	a.add("Ab");
	ab.add("aa");
	ab.add("bb");
	
	Test1 t = new Test1(){
		public void method1(){
			System.out.println("Hello");
		}
	};
	t.method1();

/*	List<Object> b = a; */

	List<String> dx = a;
	List<E> c = (List<E>) a; // fine
	
	List<D> e = (List<D>) a; // fine
	
	List<?> d = a;
	List de = a;
	
	
	
	a.add("sdasa");
	a.add("dsad");
	
	Iterator<String> itr = a.iterator();
	
while(itr.hasNext()){
	
/*		itr.remove();*/
		System.out.println();
		System.out.println(itr.next());
/*		itr.next();*/
		itr.remove();
}
	
	
	while (itr.hasNext()) {
	System.out.println(itr.next());
		
	}
	System.out.println(c);
	
	System.out.println(d);
	
	
	
	
	
	
	
	
	
	
	Set<?> set1 = new LinkedHashSet<>();
}
	


int display(){
	try{
		return 1;
	}catch(Exception e){
		return 2;
	}finally{
		return 3;
	}
}



@Override
public void method1() {
	System.out.println(a);
	
}




	
	

}
