import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class NewDateDifference {

public static void main(String[] args) {

	
	SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");
	
	Date dateObj = new Date();
	Date start = dateObj;
	System.out.println(start);
	
		Calendar calander = Calendar.getInstance();
		calander.setTime(start);
		calander.add(Calendar.DATE, 366); // number of days to add
		Date endTime = calander.getTime();

		System.out.println(endTime);

		
	long date = endTime.getTime() - start.getTime();

	System.out.println(date);
	
	long d = date / 1000 / 60 / 60 / 24;
	System.out.println(d);
	 System.out.println ("Days: " + date / 1000 / 60 / 60 / 24);
}
}