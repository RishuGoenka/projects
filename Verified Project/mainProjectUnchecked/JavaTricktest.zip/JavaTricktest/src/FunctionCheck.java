
public class FunctionCheck {

	public static void main(String[] args) {
		
		User user = new User();
		
		if(user.isFlag()){
			System.out.println("yes");
		}
	}
}
