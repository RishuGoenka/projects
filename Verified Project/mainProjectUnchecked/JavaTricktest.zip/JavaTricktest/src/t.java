import java.util.ArrayList;
import java.util.ListIterator;

public class t {
	public static void main(String[] args) {
		
	
	// Substitute appropriate type.
	ArrayList<Integer> a = new ArrayList<Integer>();

	// Add elements to list.
	a.add(1);
	a.add(2);
	a.add(3);

	// Generate an iterator. Start just after the last element.
	ListIterator<Integer> li = a.listIterator(a.size());

	// Iterate in reverse.
	while(li.hasPrevious()) {
	  System.out.println(li.previous());
	}
	
	}
}
