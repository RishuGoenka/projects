
public class Test5 extends Exception {

}
