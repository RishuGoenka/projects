import java.util.LinkedHashMap;
import java.util.Map;

public class ImmutableMainTest {

	public static void main(String[] args) {
		
		Map<ImmutableTest , Integer> test = new LinkedHashMap<ImmutableTest, Integer>();
		
		test.put(new ImmutableTest(1), 1);
		test.put(new ImmutableTest(1), 2);
		test.put(new ImmutableTest(1), 3);
		test.put(new ImmutableTest(1), 4);
		test.put(new ImmutableTest(2), 5);
		test.put(new ImmutableTest(3), 1);
		test.put(new ImmutableTest(4), 1);
		
		System.out.println(test);

		
	}

}
