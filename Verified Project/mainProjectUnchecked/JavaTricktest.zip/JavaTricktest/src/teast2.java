
public class teast2 {

	public teast2() {
		System.out.println("instance conse block is invoked");
		
		{System.out.println("instance initi 3 alizer block is invoked");} 
		
		
	}
	
	
	
	
	{System.out.println("instance initializer out block is invoked");}  
	
	
	
	public static void main(String[] args) {
		
		System.out.println("instance main 1 block is invoked");
		
		teast2 t = new teast2();
		{System.out.println("instance initi2alizer block is invoked");}  
		
		
		System.out.println("instance main block is invoked");
	
	}
	static {System.out.println("instance sts1ic block is invoked");}  
  
	static {System.out.println("instance sts2ic block is invoked");}  
	
	{System.out.println("instance initializer out 3 block is invoked");}  
	  
}
