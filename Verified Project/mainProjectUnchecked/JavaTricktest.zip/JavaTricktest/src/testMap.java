import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class testMap {

	public static void main(String[] args) {

		List<User> users = new ArrayList<>();
		
		users.add(new User("D",232));
		users.add(new User("A",2));
		users.add(new User("B",2));
		users.add(new User("C",11));
		users.add(new User("A",2));
		System.out.println(users);
		
		Map<User, Integer> mapList = new HashMap<>();
		
		int key = 0;
		for (User user : users) {
			System.out.println(user.hashCode());
			if (mapList.containsKey(user)) {
				key = mapList.get(user);
				key++;
				mapList.put(user, key);
				key = 0;
			} else {
				mapList.put(user, 1);
			}
		}
		System.out.println(mapList);

		
		for(Map.Entry<User, Integer> mapListItr : mapList.entrySet()){
			System.out.println(mapListItr);			
		}
		int value = 0;
		
/*		for (User user : users) {
			if(mapList.get(user) == null)
				break;
			value = mapList.get(user);
			if (value > 1) {
				mapList.remove(user);
			}
			value=0;
		}
		System.out.println(mapList);*/
		

	}
}
