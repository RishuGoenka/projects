
public interface Test1 {
	
	int a = 10;
	
	public abstract void method1();

}
