
public class SingletonTest {

	private static SingletonTest singletonObj;

	private SingletonTest() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public SingletonTest getinstance(){
		if(singletonObj == null)
			singletonObj =  new SingletonTest();
		return singletonObj;
	}
	
}
