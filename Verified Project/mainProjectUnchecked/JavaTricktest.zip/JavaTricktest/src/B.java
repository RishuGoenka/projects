
	class B extends A {
		
		static void out1(){
			System.out.println("B");
		}
		public static void main(String[] args) {
			A a = new B();
			a.out1();
		}
	}
