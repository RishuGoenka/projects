import java.util.HashSet;
import java.util.Set;

public class Name {
	private final String first;

	public Name(String first) {
		this.first = first;
	}

	public static void main(String[] args) {
		Set<Name> s = new HashSet<Name>();

		s.add(new Name("Mickey"));

		System.out.println(s.toString());
		System.out.println(s.contains(new Name("Mickey")));
	}

	@Override
	public String toString() {
		return "Name [first=" + first + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((first == null) ? 0 : first.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Name other = (Name) obj;
		if (first == null) {
			if (other.first != null)
				return false;
		} else if (!first.equals(other.first))
			return false;
		return true;
	}

}