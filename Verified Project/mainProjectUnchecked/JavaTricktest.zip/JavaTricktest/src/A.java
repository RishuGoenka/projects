
public class A {

	static void out1(){
		System.out.println("A");
	}
	
}
