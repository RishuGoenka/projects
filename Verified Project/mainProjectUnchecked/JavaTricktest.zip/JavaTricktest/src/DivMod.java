import java.io.BufferedReader;
import java.io.InputStreamReader;

class DivMod {
	
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	static int[][] screen = new int[][]{
									{ 00, 00, 00, 00, 00 },
									{ 00, 00, 00, 00, 00 },
									{ 00, 00, 00, 00, 00 },
									{ 00, 00, 00, 00, 00 },
									{ 00, 00, 00, 00, 00 }
								};
	static int player;

	static int player1;

	static int player2;
	
    public static void main(String args[] ) throws Exception {		
    	int count = 0;
		boolean val;
		do{
			count ++;
			System.out.println(count);
        String coordinate = br.readLine();
        String[] xy = coordinate.split(",");
        int x = Integer.parseInt(xy[0]);
        int y = Integer.parseInt(xy[1]);
        if(count < 7)
        	val = true;
        else
        	val = check(screen);
		}while(val);
		
        


    }

	private static boolean check(int[][] screen) {
		System.out.println(player1);
		System.out.println(player2);
		player1 = player2 = 0;
		for(int i = 0;i<5;i++){
			for(int j = 0;j<5;j++){
				if(screen[i][j]/10 == 1)
				player1 ++;
				else if(screen[i][j]/10 == 2)
				player2 ++;
			}
		}
		if( player1 == 0 || player2 == 0)
		return false;
		else return true;
	}
}
