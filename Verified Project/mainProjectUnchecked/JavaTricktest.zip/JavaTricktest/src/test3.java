public class test3 {
    public static void main(String[] args) {
        System.out.println(Math.min(Double.MIN_VALUE, 0.0d));
        
        float f = 0.1F;
        double d = 0.1D;
        for(int i =0; i<100;i++){
        System.out.println(f*i);
        System.out.println(d*i);
        }
}
}