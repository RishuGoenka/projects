import java.util.*;
import java.text.*;

public class HackTry {

	public static void main(String[] args) {
		string A = "He";
	        
	        string[] b= A.split("[!,?._'@\\s]+");
	       System.out.println(b.length);
	       for(String s : b)
	       System.out.println(s);
	}
	
}