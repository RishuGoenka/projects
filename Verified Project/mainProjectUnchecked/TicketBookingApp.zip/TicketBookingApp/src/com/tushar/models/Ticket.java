package com.tushar.models;

import java.io.Serializable;

public class Ticket implements Serializable {
	private Integer ticketId;
	private Customer customer;
	private Double totalAmount;
	private Column column;
	
	
	
	public Integer getTicketId() {
		return ticketId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Column getColumn() {
		return column;
	}
	public void setColumn(Column column) {
		this.column = column;
	}
	public Ticket(Customer customer, Double totalAmount, Column column) {
		super();
		this.customer = customer;
		this.totalAmount = totalAmount;
		this.column = column;
	}
	public Ticket() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
