package com.tushar.models;

import java.io.Serializable;

public class Column implements Serializable {
	
	
	private Integer columnId;
	private Integer columnNumber;
	private String statusOfColumn;
	private Row row;
	private Shows shows;
	public Integer getColumnNumber() {
		return columnNumber;
	}
	public void setColumnNumber(Integer columnNumber) {
		this.columnNumber = columnNumber;
	}
	public String getStatusOfColumn() {
		return statusOfColumn;
	}
	public void setStatusOfColumn(String statusOfColumn) {
		this.statusOfColumn = statusOfColumn;
	}
	public Row getRow() {
		return row;
	}
	public void setRow(Row row) {
		this.row = row;
	}
	public Shows getShows() {
		return shows;
	}
	public void setShows(Shows shows) {
		this.shows = shows;
	}
	public Integer getColumnId() {
		return columnId;
	}
	public Column(Integer columnNumber, String statusOfColumn, Row row,
			Shows shows) {
		super();
		this.columnNumber = columnNumber;
		this.statusOfColumn = statusOfColumn;
		this.row = row;
		this.shows = shows;
	}
	public Column() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	
	
	

	
	
}
