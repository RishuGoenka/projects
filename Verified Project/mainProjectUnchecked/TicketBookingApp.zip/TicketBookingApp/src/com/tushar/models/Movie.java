package com.tushar.models;

import java.io.Serializable;
import java.util.Comparator;
import java.util.List;

public class Movie implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer movieId;
	private String movieName;
	private Integer movieRating;
	private Theatre theatre;
	private String duration;
	
	

	public static Comparator<Movie> COMPARE_BY_NAME = new Comparator<Movie>()  {
		

		@Override
		public int compare(Movie m1, Movie m2) {
			// TODO Auto-generated method stub
			return m1.movieName.compareTo(m2.movieName);
		}
	};
	
	
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public Theatre getTheatre() {
		return theatre;
	}
	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public Integer getMovieRating() {
		return movieRating;
	}
	public void setMovieRating(Integer movieRating) {
		this.movieRating = movieRating;
	}

	public Integer getMovieId() {
		return movieId;
	}
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Movie(String movieName, Theatre theatre, String duration) {
		super();
		this.movieName = movieName;
		this.theatre = theatre;
		this.duration = duration;
	}

	

	
}
