package com.tushar.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Multiplex implements Serializable {
	private Integer multiplexId;
	private String multiplexName;
	private String multiplexLocation;
	
	

	public String getMultiplexName() {
		return multiplexName;
	}
	public void setMultiplexName(String multiplexName) {
		this.multiplexName = multiplexName;
	}
	public String getMultiplexLocation() {
		return multiplexLocation;
	}
	public void setMultiplexLocation(String multiplexLocation) {
		this.multiplexLocation = multiplexLocation;
	}
	public Integer getMultiplexId() {
		return multiplexId;
	}
	
	
}
