package com.tushar.models;

import java.io.Serializable;
import java.util.List;


public class Shows implements Serializable{
	/**
	 * 
	 */
private static final long serialVersionUID = 1L;
	private Integer showId;
	private String startTime;
	private String endTime;
	private Movie movie;
	private Seats seats;
	private Double costOfGold;
	private Double costOfPlatinum;
	private Double costOfSilver;

	
	

	public Seats getSeats() {
		return seats;
	}
	public void setSeats(Seats seats) {
		this.seats = seats;
	}
	public Double getCostOfGold() {
		return costOfGold;
	}
	public void setCostOfGold(Double costOfGold) {
		this.costOfGold = costOfGold;
	}
	public Double getCostOfPlatinum() {
		return costOfPlatinum;
	}
	public void setCostOfPlatinum(Double costOfPlatinum) {
		this.costOfPlatinum = costOfPlatinum;
	}
	public Double getCostOfSilver() {
		return costOfSilver;
	}
	public void setCostOfSilver(Double costOfSilver) {
		this.costOfSilver = costOfSilver;
	}
	public Integer getShowId() {
		return showId;
	}
	public void setShowId(Integer showId) {
		this.showId = showId;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Shows(String startTime, String endTime, Movie movie, Seats seats,
			Double costOfGold, Double costOfPlatinum, Double costOfSilver) {
		super();
		this.startTime = startTime;
		this.endTime = endTime;
		this.movie = movie;
		this.seats = seats;
		this.costOfGold = costOfGold;
		this.costOfPlatinum = costOfPlatinum;
		this.costOfSilver = costOfSilver;
	}
	public Shows() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	

	
	
	

	
	
}
