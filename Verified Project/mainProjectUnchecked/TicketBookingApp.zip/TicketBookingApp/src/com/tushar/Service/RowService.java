package com.tushar.Service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.tushar.controller.LoginController;
import com.tushar.daos.RowDAO;
import com.tushar.daos.SeatsDAO;
import com.tushar.models.Row;
import com.tushar.models.Seats;

public class RowService {

	final static Logger logger = Logger.getLogger(LoginController.class);
	private RowDAO rowDAO;
	private SeatsDAO seatDAO;
	private PlatformTransactionManager txManager;

	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public void setSeatDAO(SeatsDAO seatDAO) {
		this.seatDAO = seatDAO;
	}

	public void setRowDAO(RowDAO rowDAO) {
		this.rowDAO = rowDAO;
	}

	public void add(List<Character> name, List<Integer> columns,
			List<String> type, Integer seatId, Integer row) {
		Seats seat = seatDAO.findById(seatId);
		for (int i = 0; i < row; i++) {
			Row rowSave = new Row(name.get(i).toString(), type.get(i),
					columns.get(i), seat);
			TransactionDefinition def = new DefaultTransactionDefinition();
			TransactionStatus status = txManager.getTransaction(def);
			try {
				rowDAO.save(rowSave);
				txManager.commit(status);
			} catch (DataAccessException e) {
				txManager.rollback(status);
			}

		}

	}

}
