package com.tushar.Service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.tushar.controller.LoginController;
import com.tushar.daos.MultiplexDAO;
import com.tushar.daos.TheatreDAO;
import com.tushar.models.Multiplex;
import com.tushar.models.Theatre;

public class TheatreService {
	final static Logger logger = Logger.getLogger(LoginController.class);
	
	private TheatreDAO theatreDAO;
	private MultiplexDAO multiplexDAO;
	private PlatformTransactionManager txManager;
	
	
	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public void setMultiplexDAO(MultiplexDAO multiplexDAO) {
		this.multiplexDAO = multiplexDAO;
	}

	public void setTheatreDAO(TheatreDAO theatreDAO) {
		this.theatreDAO = theatreDAO;
	}
	
	public String save(Theatre theatre){
		if(theatre.getTheatreName().equals("")){
			return "Screen Name cannot be empty";
		}
		if(theatre.getMultiplex().getMultiplexName().equals("")){
			return "Select Multiplex";
		}
		Multiplex multiplex = multiplexDAO.findByName(theatre.getMultiplex().getMultiplexName()).get(0);
		if(theatreDAO.getByMultiplexAndTheatreName(multiplex, theatre.getTheatreName()).size()!=0){
			return "Screen already exist";
		}
		Theatre theatreToSave = new Theatre(theatre.getTheatreName(),multiplex);
		
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);
		try {
			theatreDAO.save(theatreToSave);
			txManager.commit(status);
		} catch (DataAccessException e) {
			txManager.rollback(status);
		}
		
		return "Screen is added ";
	}
	
	
	public Integer saveMultiplex(Multiplex multiplex){
		Integer id =null;
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);
		
		try {
			id = (Integer) multiplexDAO.save(multiplex);
			txManager.commit(status);
		} catch (DataAccessException e) {
			e.printStackTrace();
			txManager.rollback(status);
		}
		return id;
	}
	
	public String multiplexValidator(Multiplex multiplex){
		if(multiplex.getMultiplexName().equals("")){
			return "Theatre Name cannot be empty";
		}
		else if(multiplex.getMultiplexLocation().equals("")){
			return "Theatre Loaction cannot be empty";
		}
		return "0";
	}
	
	public List<Multiplex> getAllMultiplex(){
		return multiplexDAO.getAll();
	}
	
	public Theatre saveWhenEmpty(){
		Multiplex multiplex = new Multiplex();
		Theatre theatre = new Theatre(null,multiplex);
		return theatre;
	}
}
