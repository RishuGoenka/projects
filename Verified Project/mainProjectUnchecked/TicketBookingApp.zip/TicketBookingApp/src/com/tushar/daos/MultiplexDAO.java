package com.tushar.daos;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.tushar.models.Multiplex;

public class MultiplexDAO {
	private HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	
	public Serializable save(Multiplex multiplex){
		return template.save(multiplex);
	}
	public Multiplex findById(Integer id){
		return template.get(Multiplex.class, id);
	}
	
	public List<Multiplex> getAll(){
		return template.find("from Multiplex m");
	}
	
	public List<Multiplex> findByName(String name){
		return template.find("from Multiplex m where m.multiplexName = ?",name);
	}
	
}
