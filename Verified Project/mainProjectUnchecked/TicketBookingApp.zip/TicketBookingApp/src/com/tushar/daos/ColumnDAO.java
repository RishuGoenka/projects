package com.tushar.daos;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.tushar.models.Column;
import com.tushar.models.Row;
import com.tushar.models.Shows;

public class ColumnDAO {
	private HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public Serializable save(Column column){
		return template.save(column);
	}
	
	public List<Column> findByRowAndShow(Row row , Shows show){
		System.out.println("Hey in ColumnDAO ");
		return template.find("from Column c where c.row = ? and c.shows = ? ", row , show);
	}
	
	public Column findById(Integer id){
		return template.get(Column.class, id);
	}
	
	public void update(Column column){
		template.update(column);
	}
	
	public void delete(Column column){
		template.delete(column);
	}
	
	public List<Column> findByShow(Shows show){
		return template.find("from Column c where c.shows = ? ",show);
	}
	
}
