package com.tushar.daos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.tushar.models.Movie;
import com.tushar.models.Shows;

public class ShowDAO {
	private HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public Serializable save (Shows show){
		return template.save(show);
	}
	
	public void update (Shows show){
		template.save(show);
	}
	public Shows findById(Integer id){
		return template.get(Shows.class, id);
	}
	
	public void delete(Integer id){
		Shows show = findById(id);
		template.delete(show);
	}
	
	public ArrayList<Shows> getAllByMovieId(Movie movie){
		return (ArrayList<Shows>) template.find("from Shows s where s.movie=?",movie);
	}
}
