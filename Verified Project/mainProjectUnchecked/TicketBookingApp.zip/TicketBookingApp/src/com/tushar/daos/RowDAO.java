package com.tushar.daos;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.tushar.models.Row;
import com.tushar.models.Seats;

public class RowDAO {
	private HibernateTemplate template;
	
	
	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}


	public Serializable save(Row row){
		return template.save(row);
	}
	
	public List<Row> findBySeat(Seats seat){
		return template.find("from Row r where r.seats = ?",seat);
	}
	
	public List<Row> findBySeatAndTypeOfRow(Seats seat , String typeOfRow){
		return template.find("from Row r where r.seats =? and r.typeOfRow=?",seat,typeOfRow);
	}
	
	public Row findById(Integer id){
		return template.get(Row.class, id);
	}
}
