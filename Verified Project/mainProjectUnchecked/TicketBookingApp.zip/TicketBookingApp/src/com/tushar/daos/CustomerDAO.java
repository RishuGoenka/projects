package com.tushar.daos;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.tushar.models.Customer;

public class CustomerDAO {
	private HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public Serializable save(Customer customer){
		return template.save(customer);
	}
	
	public void update(Customer customer){
		template.update(customer);
	}
	
	public Customer findById(Integer id){
		return template.get(Customer.class, id);
	}
	
	public List<Customer> findByEmailAndPassowrd(String email , String password){
		return template.find("from Customer c where c.customerEmail = ? and c.password = ?",email,password);
	}
	
	public List<Customer> getAll(){
		return template.find("from Customer c ");
	}
}

