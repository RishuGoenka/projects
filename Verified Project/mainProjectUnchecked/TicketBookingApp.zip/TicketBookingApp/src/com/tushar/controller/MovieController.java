package com.tushar.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tushar.Service.MovieService;
import com.tushar.models.Movie;
import com.tushar.models.Multiplex;
import com.tushar.models.Theatre;

public class MovieController extends MultiActionController {
	
	final static Logger logger = Logger.getLogger(LoginController.class);
	private MovieService movieService;
	

	public void setMovieService(MovieService movieService) {
		this.movieService = movieService;
	}
	
	public ModelAndView displayForm(HttpServletRequest request ,HttpServletResponse response){
		Movie movie = movieService.saveWhenEmpty();
		
		List<Theatre> theatres = movieService.forDropDown();
		HttpSession session = request.getSession();
		session.setAttribute("theatresMC", theatres);
		
		ModelAndView mv = new ModelAndView("admin/addMovie");
		mv.addObject("movie", movie);
		return mv;
	}
	
	public ModelAndView add(HttpServletRequest request ,HttpServletResponse response , Movie movie){
		String message = null;
		ModelAndView mv = new ModelAndView("redirect:/movie/displayMovieForm.htm");
		String multiplexName = (String) request.getSession().getAttribute("multiplexName");
		System.out.println(request.getParameter("theatreName"));
		
		if(movie.getMovieName().equals("")){
			message = "Movie Name cannot be blank";
			mv.addObject("message",message);
			return mv;
		}else if(movie.getDuration().equals("")){
			message = "Movie Duration cannot be blank";
			mv.addObject("message",message);
			return mv;
		}
		
		movie.setDuration(request.getParameter("duration"));
		request.getSession().removeAttribute(multiplexName);
		Integer movieId = movieService.addMovie(movie,multiplexName);
		message = "Movie "+movie.getMovieName() + " is added with "+movieId + " Id";
		mv.addObject("message",message);
		return mv;
	}
	
	
	
	/**
	 * For Deleting the Movie..All Show associated to that movie should also be deleted..
	 * 
	 */
	String theatreName;
	public ModelAndView displayRemoveForm(HttpServletRequest request ,HttpServletResponse response){
		Movie movie = movieService.saveWhenEmpty();
		List<Theatre> theatres = movieService.forDropDown();
		HttpSession session = request.getSession();
		session.setAttribute("theatresMC", theatres);
		ModelAndView mv = new ModelAndView("admin/removeMovie");
		mv.addObject("movie", movie);
		return mv;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param movie
	 * @return
	 * 
	 * 		to display all the movie in particular theater..
	 */
	
	public ModelAndView displayMovieList(HttpServletRequest request ,HttpServletResponse response , Movie movie){
	
		
		if(theatreName==null){
			theatreName = movie.getTheatre().getTheatreName();
		}
		
		List<Movie> movies = movieService.getAllMovieInTheatre(theatreName);
		HttpSession session = request.getSession();
		session.setAttribute("moviesMC", movies);
		return new ModelAndView("redirect:/movie/displayRemoveForm.htm");
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param movie
	 * @return
	 * 
	 * 		for deleting the movie selected..
	 */
	
	public ModelAndView removeMovieFromAnchor(HttpServletRequest request ,HttpServletResponse response , Movie movie){
		String movieIdString = request.getParameter("movieId");
		movieService.removeMovie(movieIdString);
		return new ModelAndView("redirect:/movie/displayMovieList.htm");
	}
	
	/**
	 * For Getting Movie Through Ajax
	 */
	
	public ModelAndView displayMovieForm(HttpServletRequest request ,HttpServletResponse response){
		List<Multiplex> multiplexes = movieService.getMultiplex();
		ModelAndView mv = new ModelAndView("admin/addMovieAjax");
		Movie movie = movieService.saveWhenEmpty();
		mv.addObject("multiplexes",multiplexes);
		mv.addObject("movie",movie);
		return mv;
	}
	
	public ModelAndView selectTheatreToAddMovie(HttpServletRequest request ,HttpServletResponse response) throws IOException{
		String multiplexName = request.getParameter("multiplexName");
		List<Theatre> theatres = movieService.getTheatreByMultiplex(multiplexName);
		request.getSession().setAttribute("multiplexName", multiplexName);
		
		for(Theatre theatre : theatres){
			System.out.println(theatre.getTheatreName());
		}
		
		PrintWriter writer = null;
		GsonBuilder builder = new GsonBuilder();
		builder.registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY);
		Gson gson = builder.create();
		String jsonObject = gson.toJson(theatres);
		
		logger.info(jsonObject);
		
		
		try {
			writer = response.getWriter();
			writer.write(jsonObject);

		} finally {
			if (writer != null) {
				writer.flush();
				writer.close();
			}
		}
		
		return null;
	}
	
	public ModelAndView displayRemoveMovieForm(HttpServletRequest request ,HttpServletResponse response){
		List<Multiplex> multiplexes = movieService.getMultiplex();
		ModelAndView mv = new ModelAndView("admin/removeMovieAjax");
		Movie movie = movieService.saveWhenEmpty();
		mv.addObject("multiplexes",multiplexes);
		mv.addObject("movie",movie);
		return mv;
	}
	
	public ModelAndView getMovieList(HttpServletRequest request ,HttpServletResponse response) throws IOException{
		String theaterName = request.getParameter("theatreName");
		String multiplexName = request.getParameter("multiplexName");
		List<Movie> movies = movieService.getMovieList(theaterName,multiplexName);
		
		
		PrintWriter writer = null;
		GsonBuilder builder = new GsonBuilder();
		builder.registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY);
		Gson gson = builder.create();
		String jsonObject = gson.toJson(movies);
		
		System.out.println(jsonObject);
		
		
		try {
			writer = response.getWriter();
			writer.write(jsonObject);

		} finally {
			if (writer != null) {
				writer.flush();
				writer.close();
			}
		}
		
		return null;
	}
	

}
