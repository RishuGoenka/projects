package com.tushar.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.tushar.Service.TheatreService;
import com.tushar.models.Multiplex;
import com.tushar.models.Theatre;

public class TheatreController extends MultiActionController {
	
	final static Logger logger = Logger.getLogger(LoginController.class);
	
	private TheatreService theatreService;

	public void setTheatreService(TheatreService theatreService) {
		this.theatreService = theatreService;
	}
	
	public ModelAndView displayForm (HttpServletRequest request , HttpServletResponse response){
		ModelAndView mv = new ModelAndView("admin/addScreen");
		Theatre theatre = theatreService.saveWhenEmpty();
		List<Multiplex> multiplexes = theatreService.getAllMultiplex();
		mv.addObject("theatre" , theatre);
		mv.addObject("multiplexes",multiplexes);
		return mv;
	}
	
	public ModelAndView add(HttpServletRequest request , HttpServletResponse response , Theatre theatre){
		
		String validator = theatreService.save(theatre);
		ModelAndView mv = new ModelAndView("redirect:/theatre/displayForm.htm");
		mv.addObject("validator",validator);
		return mv;
	}
	
	public ModelAndView multiplexDisplayForm (HttpServletRequest request , HttpServletResponse response){
		ModelAndView mv = new ModelAndView("admin/addTheatre");
		mv.addObject("multiplex" , new Multiplex());
		return mv;
	}
	
	
	public ModelAndView addMultiplex(HttpServletRequest request , HttpServletResponse response, Multiplex multiplex){
		String validator = theatreService.multiplexValidator(multiplex);
		if(validator.equals("0")){
			
			System.out.println(multiplex.getMultiplexName());
			
			theatreService.saveMultiplex(multiplex);
			validator = "Theatre "+multiplex.getMultiplexName()+" is added";
		}
		ModelAndView mv = new ModelAndView("redirect:/theatre/multiplexDisplayForm.htm");
		mv.addObject("validator" , validator);
		return mv;
	}

}
