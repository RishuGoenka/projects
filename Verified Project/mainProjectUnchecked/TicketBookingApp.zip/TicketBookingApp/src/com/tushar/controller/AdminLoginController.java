package com.tushar.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.tushar.Service.CustomerService;
import com.tushar.models.AdminLogin;
import com.tushar.models.Customer;

public class AdminLoginController extends MultiActionController{
	
	final static Logger logger = Logger.getLogger(LoginController.class);
	
	private CustomerService customerService;

	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return 
	 * 			For simply displaying form for log in to the admin.
	 */

	public ModelAndView displayForm(HttpServletRequest request ,HttpServletResponse response){
		
		ModelAndView mv = new ModelAndView("admin/loginAdmin");
		mv.addObject("login", new AdminLogin());
		return mv;
		
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param adminLogin
	 * @return 
	 * 			Checking the authorization for the admin and in success displaying its home page.
	 */

	
	public ModelAndView adminHomePage(HttpServletRequest request ,HttpServletResponse response){
		return new ModelAndView("admin/adminHomePage");
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * 
	 * 		logging out the admin and invalidating all the sessions..
	 */
	
	public ModelAndView logout(HttpServletRequest request ,HttpServletResponse response){
		request.getSession().invalidate();
		request.getSession().removeAttribute("adminlogin");
		return new ModelAndView("redirect:/login/loginDisplayForm.htm");
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return 
	 * 			This for displaying the registration form for admin
	 */
	public ModelAndView adminRegisterDisplayForm(HttpServletRequest request ,HttpServletResponse response){
		Customer customer = customerService.loginDisplayForm();
		ModelAndView mv = new ModelAndView("admin/registerAdmin");
		mv.addObject("customer",customer);
		return mv;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @param customer
	 * @return
	 * 			Adding admin and setting its type as admin..
	 */
	
	public ModelAndView addAdmin(HttpServletRequest request ,HttpServletResponse response , Customer customer){
		String confirmPassword = request.getParameter("confirmPassword");
		Boolean check = customerService.checkPassword(confirmPassword , customer.getPassword());
		if(check == true){
			customer.setCustomerType("Admin");
			customerService.addCustomer(customer);
			ModelAndView mv = new ModelAndView("redirect:/adminlogin/adminHomePage.htm");
			HttpSession session = request.getSession();
			session.setAttribute("customerId", customer.getCustomerId());
			return mv;
		}
		
		ModelAndView mv = new ModelAndView("redirect:/adminlogin/adminRegisterDisplayForm.htm");
		mv.addObject("passwordMessage","Your Passwords do not match");
		return mv;
		
	}
}
