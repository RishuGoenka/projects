package com.tushar.controller;


import java.io.IOException;



import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;











import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tushar.Service.RowService;
import com.tushar.Service.SeatService;
import com.tushar.models.Multiplex;
import com.tushar.models.Seats;
import com.tushar.models.Theatre;


public class SeatController extends MultiActionController {
	
	final static Logger logger = Logger.getLogger(LoginController.class);
	private SeatService seatService;
	private RowService rowService;
	
	

	public void setRowService(RowService rowService) {
		this.rowService = rowService;
	}

	public void setSeatService(SeatService seatService) {
		this.seatService = seatService;
	}


	
	
	public ModelAndView displayForm(HttpServletRequest request ,HttpServletResponse response){
		Seats seats = seatService.saveWhenEmpty();
		ModelAndView mv = new ModelAndView("admin/seatSelectRows");
		mv.addObject("seats",seats);
		
		List<Theatre>theatres = new ArrayList<Theatre>();
		theatres = seatService.forDropDown();
		
		HttpSession session = request.getSession();
		session.setAttribute("theatresSC", theatres);
		
		return mv;
	}
	
	
	
	Integer rows;
	public ModelAndView selectTheatre(HttpServletRequest request ,HttpServletResponse response , Seats seat){
		String theatreName = seat.getTheatre().getTheatreName();
		logger.info(theatreName);
		return new ModelAndView("redirect:/seat/displayForm.htm");
	}
	

	public ModelAndView seatSelectRows(HttpServletRequest request ,HttpServletResponse response){
		String rowsNumber = request.getParameter("rowsNumber");
		try {
			rows = Integer.parseInt(rowsNumber);
		} catch (NumberFormatException e) {
			e.printStackTrace();
			ModelAndView mv = new ModelAndView("redirect:/seat/displaySeatForm.htm");
			mv.addObject("message","You have to enter a number in Number of Rows ");
			return mv;
		}
		
		String multiplexName = (String) request.getSession().getAttribute("multiplexName");
		Theatre theatre = seatService.findTheatreByName(request.getParameter("theatreName"),multiplexName);
		Seats seat = new Seats(rows , theatre);
		Integer seatId = seatService.add(seat);
		if(seatId==0){
			ModelAndView mv = new ModelAndView("redirect:/seat/displaySeatForm.htm");
			mv.addObject("message","You have already entered seats in this ");
			return mv;
		}
		List<Character>alphabets = new ArrayList<Character>();
		List<Character>alphabetsToAdd = new ArrayList<Character>();
		
		logger.info(seatId);
		request.getSession().setAttribute("seatId",seatId );
			char c;
		
		for( c= 65 ;c<(65+rows);c++ ){
			alphabets.add(c);
		}

		for(int i = alphabets.size();i>0;i--){
			alphabetsToAdd.add(alphabets.get(i-1));
			
		}
		
		

		request.getSession().removeAttribute(multiplexName);
		ModelAndView mv = new ModelAndView("admin/displayRowColumn");
		mv.addObject("alphabets",alphabetsToAdd);
		
		return mv;
	}
	
	
	public ModelAndView rowNumber(HttpServletRequest request ,HttpServletResponse response) throws IOException{
		

		List<Integer> columns = new ArrayList<Integer>();
		List<String> type = new ArrayList<String>();
		List<Character> name = new ArrayList<Character>();
		String typeString;
		String numberOfColumnsString;
		Integer numberOfColumns = null;
		char c;
		
	for (c = (65) ; c< 65+rows ; c++){
			
			numberOfColumnsString = request.getParameter("row"+c);
			try {
				numberOfColumns = Integer.parseInt(numberOfColumnsString);
			} catch (Exception e) {
				e.printStackTrace();
				ModelAndView mv = new ModelAndView("admin/displayRowColumn");
				mv.addObject("message","Enter only Numeric values in Number Of Columns");
				return mv;
			}
			
			columns.add(numberOfColumns);
			
			
			typeString = request.getParameter("type"+c);
			type.add(typeString);
			name.add(c);
			
		}
			Integer seatId = (Integer) request.getSession().getAttribute("seatId");
			rowService.add(name,columns,type,seatId,rows);
			request.getSession().removeAttribute("seatId");
			ModelAndView mv = new ModelAndView("admin/displayRowColumn");
			mv.addObject("message","Seats have been saved successfully");
		return mv;
	}
	
	public ModelAndView displaySeatForm(HttpServletRequest request ,HttpServletResponse response){
		
		List<Multiplex> multiplexes = seatService.getAllMultiplex();
		ModelAndView mv = new ModelAndView("admin/seatSelectRows");
		Seats seats = seatService.saveWhenEmpty();
		mv.addObject("seats",seats);
		mv.addObject("multiplexes",multiplexes);
		mv.addObject("message",request.getParameter("message"));
		return mv;
	}
	
	public ModelAndView selectTheatreToAddMovie(HttpServletRequest request ,HttpServletResponse response) throws IOException{
		String multiplexName = request.getParameter("multiplexName");
		logger.info("In Seat Controller "+multiplexName);
		
		
		List<Theatre> theatres = seatService.getTheatreByMultiplex(multiplexName);
		request.getSession().setAttribute("multiplexName", multiplexName);
		
		for(Theatre theatre : theatres){
			logger.info(theatre.getTheatreName());
		}
		
		PrintWriter writer = null;
		GsonBuilder builder = new GsonBuilder();
		builder.registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY);
		Gson gson = builder.create();
		String jsonObject = gson.toJson(theatres);
		
		logger.info(jsonObject);
		
		try {
			writer = response.getWriter();
			writer.write(jsonObject);

		} finally {
			if (writer != null) {
				writer.flush();
				writer.close();
			}
		}
		
		return null;
	}
}
