package com.zycus.enrollment.common.bo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="TBL_INTERMIDATEALIICE")
public class InterMidiateAlices {
	
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="INTERALAIS_ID")	
	private int interAliceId;
	
	@ManyToOne
	@JoinColumn(name="ALAIS_ID",referencedColumnName="ALAIS_ID")
	private Alais alais;
	
	@ManyToOne
	@JoinColumn(name="ALAISBUNDLE_ID",referencedColumnName="ALAISBUNDLE_ID")
	private AlaisBundle alaisBundle;
	
	
	public Alais getAlais() {
		return alais;
	}
	public void setAlais(Alais alais) {
		this.alais = alais;
	}
	public AlaisBundle getAlaisBundle() {
		return alaisBundle;
	}
	public void setAlaisBundle(AlaisBundle alaisBundle) {
		this.alaisBundle = alaisBundle;
	}
	public int getInterAliceId() {
		return interAliceId;
	}
	public void setInterAliceId(int interAliceId) {
		this.interAliceId = interAliceId;
	}
	
	

}
