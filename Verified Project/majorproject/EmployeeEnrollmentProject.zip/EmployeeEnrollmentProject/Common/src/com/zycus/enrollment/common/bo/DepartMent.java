package com.zycus.enrollment.common.bo;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;



import org.hibernate.annotations.GenericGenerator;



@Entity
@Table(name="TBL_DEPARTMENT1780")
public class DepartMent {
	
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="DEPARTMENT_ID")	
    private int departmentId;
	
	@Column(name="DEPARTMENT_NAME")
	private String departmentName;
    
	@Column(name="HOD_NAME")
	private String hodName;
   
    @OneToMany(mappedBy="departMent" ,targetEntity=Designation.class,fetch=FetchType.LAZY,cascade=CascadeType.ALL)
    private List<Designation> designation;
	
    public List<Designation> getDesignation() {
		return designation;
	}
	
    public void setDesignation(List<Designation> designation) {
		this.designation = designation;
	}
	
    public int getDepartmentId() {
		return departmentId;
	}
	
    public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}
	
    public String getDepartmentName() {
		return departmentName;
	}
	
    public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	
    public String getHodName() {
		return hodName;
	}
	
    public void setHodName(String hodName) {
		this.hodName = hodName;
	} 
	 
	
}
