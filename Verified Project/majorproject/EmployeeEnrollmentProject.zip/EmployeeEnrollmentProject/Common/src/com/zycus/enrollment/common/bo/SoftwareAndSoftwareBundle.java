package com.zycus.enrollment.common.bo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="TBL_SOFT1780")
public class SoftwareAndSoftwareBundle {
   
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="ID")	
    private  int softId;
	
	@ManyToOne
	@JoinColumn(name="SOFTWARE_ID",referencedColumnName="SOFTWARE_ID")
	private Software software;
	
	public int getSoftId() {
		return softId;
	}

	public void setSoftId(int softId) {
		this.softId = softId;
	}

	@ManyToOne
	@JoinColumn(name="SoftwareBundle_Id",referencedColumnName="SoftwareBundle_Id")
	private SoftwareBundle softwareBundle;
	/*public int getSoftwareAndSoftwareBundleId() {
		return softwareAndSoftwareBundleId;
	}

	public void setSoftwareAndSoftwareBundleId(int softwareAndSoftwareBundleId) {
		this.softwareAndSoftwareBundleId = softwareAndSoftwareBundleId;
	}
*/
	public Software getSoftware() {
		return software;
	}

	public void setSoftware(Software software) {
		this.software = software;
	}

	public SoftwareBundle getSoftwareBundle() {
		return softwareBundle;
	}

	public void setSoftwareBundle(SoftwareBundle softwareBundle) {
		this.softwareBundle = softwareBundle;
	}

	
	
	
	


}
