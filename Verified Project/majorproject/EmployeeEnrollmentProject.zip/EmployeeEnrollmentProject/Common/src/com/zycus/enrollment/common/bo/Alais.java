package com.zycus.enrollment.common.bo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="TBL_AlAIS")
public class Alais {
	
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="ALAIS_ID")	
	private int alaisId;
	
	@Column(name="ALAIS_NAME")
	private String alaisName;
	
	@OneToMany(mappedBy="alais" ,targetEntity=InterMidiateAlices.class,fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	private List<InterMidiateAlices> intermidiateList;
	
	public List<InterMidiateAlices> getIntermidiateList() {
		return intermidiateList;
	}
	public void setIntermidiateList(List<InterMidiateAlices> intermidiateList) {
		this.intermidiateList = intermidiateList;
	}
	public int getAlaisId() {
		return alaisId;
	}
	public void setAlaisId(int alaisId) {
		this.alaisId = alaisId;
	}
	public String getAlaisName() {
		return alaisName;
	}
	public void setAlaisName(String alaisName) {
		this.alaisName = alaisName;
	}
	

}
