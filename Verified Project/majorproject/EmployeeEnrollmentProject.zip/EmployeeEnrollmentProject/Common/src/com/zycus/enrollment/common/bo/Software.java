package com.zycus.enrollment.common.bo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="TBL_SOFTWAER1780")
public class Software {
	
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="SOFTWARE_ID")	
	private int softwareId;
	
	@Column(name="SOFTWARE_NAME")
	private String softwareName;
	
	@Column(name="SOFTWARE_DESCRIPTION")
	private String softwareDescription;
	
	@OneToMany(mappedBy="software" ,targetEntity=SoftwareAndSoftwareBundle.class,fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	private List<SoftwareAndSoftwareBundle> softwareAndSoftwareBundleList;
	
	public int getSoftwareId() {
		return softwareId;
	}
	
	public List<SoftwareAndSoftwareBundle> getSoftwareAndSoftwareBundleList() {
		return softwareAndSoftwareBundleList;
	}
	
	public void setSoftwareAndSoftwareBundleList(
			List<SoftwareAndSoftwareBundle> softwareAndSoftwareBundleList) {
		this.softwareAndSoftwareBundleList = softwareAndSoftwareBundleList;
	}
	
	public void setSoftwareId(int softwareId) {
		this.softwareId = softwareId;
	}
	
	public String getSoftwareName() {
		return softwareName;
	}
	
	public void setSoftwareName(String softwareName) {
		this.softwareName = softwareName;
	}
	
	public String getSoftwareDescription() {
		return softwareDescription;
	}
	
	public void setSoftwareDescription(String softwareDescription) {
		this.softwareDescription = softwareDescription;
	}

}
