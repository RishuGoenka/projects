package com.zycus.enrollment.common.bo;


import java.util.Comparator;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="TBL_EMPLOYEE1781")
public class Employee {
	
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="EMP_ID")
	private int employeeId;
	
	@Column(name="EMP_NAME")
	private String employeeName;
	
	@Column(name="EMP_ADDRESS")
	private String address;
	
	@Column(name="CONTACT_NUMBER")
	private long contactNumber;
	
	@Column(name="SEAT_NUMBER")
	private String seatNumber;
	
	@Column(name="DATE_OF_JOINING")
	private Date dateOfJoining;
	
	@Column(name="STATUS")
	private int status;
	
	
	@OneToOne
	@JoinColumn(name="DEPARTMENT_ID",referencedColumnName="DEPARTMENT_ID")
	private DepartMent department;
	
	@OneToOne
	@JoinColumn(name="DESIGNATION_ID",referencedColumnName="DESIGNATION_ID")
	private Designation designation;
	
	@OneToOne
	@JoinColumn(name="MANAGER_ID",referencedColumnName="EMP_ID")
	private Employee manager;
	
	@Column(name="MACHINE_NUMBER")
	private String machineNumber;
	
	@Column(name="APPROVEDBYHRDEPT")
	private Date approvedByHRDept;
	
	@Column(name="APPROVEDBYPMODEPT")
	private Date approvedByPMODept;
	
	@Column(name="APPROVEDBYITISDEPT")
	private Date approvedByITISDept;
	
	

	public Date getApprovedByHRDept() {
		return approvedByHRDept;
	}

	public void setApprovedByHRDept(Date approvedByHRDept) {
		this.approvedByHRDept = approvedByHRDept;
	}

	public Date getApprovedByPMODept() {
		return approvedByPMODept;
	}

	public void setApprovedByPMODept(Date approvedByPMODept) {
		this.approvedByPMODept = approvedByPMODept;
	}

	public Date getApprovedByITISDept() {
		return approvedByITISDept;
	}

	public void setApprovedByITISDept(Date approvedByITISDept) {
		this.approvedByITISDept = approvedByITISDept;
	}

	public String getMachineNumber() {
		return machineNumber;
	}

	public void setMachineNumber(String machineNumber) {
		this.machineNumber = machineNumber;
	}

	public Designation getDesignation() {
		return designation;
	}
	
	public void setDesignation(Designation designation) {
		this.designation = designation;
	}
	
	public Employee getManager() {
	
		return manager;
	}
	
	public void setManager(Employee manager) {
		this.manager = manager;
	}
	
	public DepartMent getDepartment() {
		return department;
	}
	
	public void setDepartment(DepartMent department) {
		this.department = department;
	}
	
	public Date getDateOfJoining() {
		return dateOfJoining;
	}
	
	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	
	public int getEmployeeId() {
		return employeeId;
	}
	
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}
	
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public long getContactNumber() {
		return contactNumber;
	}
	
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
	public String getSeatNumber() {
		return seatNumber;
	}
	
	public void setSeatNumber(String seatNumber) {
		this.seatNumber = seatNumber;
	}
	
	public int getStatus() {
		return status;
	}
	
	public void setStatus(int status) {
		this.status = status;
	}
	
	public static Comparator<Employee> SORT_BY_NAME= new Comparator<Employee>() {
        public int compare(Employee one,Employee other) {
            return one.employeeName.compareTo(other.employeeName);
        }


    };

    public static Comparator<Employee> SORT_BY_DOJ= new Comparator<Employee>() {
        public int compare(Employee one, Employee other) {
            return one.dateOfJoining.compareTo(other.dateOfJoining);
        }
    };
	

}
