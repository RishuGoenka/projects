package com.zycus.enrollment.common.bo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="TBL_SOFTWAREBUNDLE1780")
public class SoftwareBundle {
	
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="SOFTWAREBUNDLE_ID")
	private int softwareBundleId;
	
	@Column(name="SOFTWAREBUNDLE_NAME")
    private String softwareBundlename;
	
	@OneToMany(mappedBy="softwareBundle" ,targetEntity=SoftwareAndSoftwareBundle.class,fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	private List<SoftwareAndSoftwareBundle> softwareAndSoftwareBundleList;
	
	public int getSoftwareBundleId() {
		return softwareBundleId;
	}
	
	public void setSoftwareBundleId(int softwareBundleId) {
		this.softwareBundleId = softwareBundleId;
	}
	
	public String getSoftwareBundlename() {
		return softwareBundlename;
	}
	
	public void setSoftwareBundlename(String softwareBundlename) {
		this.softwareBundlename = softwareBundlename;
	}

	public List<SoftwareAndSoftwareBundle> getSoftwareAndSoftwareBundleList() {
		return softwareAndSoftwareBundleList;
	}

	public void setSoftwareAndSoftwareBundleList(
			List<SoftwareAndSoftwareBundle> softwareAndSoftwareBundleList) {
		this.softwareAndSoftwareBundleList = softwareAndSoftwareBundleList;
	} 

}
