package com.zycus.enrollment.common.bo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="TBL_ALAISBUNDLE1780")
public class AlaisBundle {
	
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="ALAISBUNDLE_ID")	
	private int alaisBundleId;
   
	@Column(name="ALAISBUNDLE_NAME")
	private String alaisbundleName;

	@OneToMany(mappedBy="alaisBundle" ,targetEntity=InterMidiateAlices.class,fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	private List<InterMidiateAlices> intermidiateList;

	public List<InterMidiateAlices> getIntermidiateList() {
		return intermidiateList;
	}

	public void setIntermidiateList(List<InterMidiateAlices> intermidiateList) {
		this.intermidiateList = intermidiateList;
	}

	public int getAlaisBundleId() {
		return alaisBundleId;
	}

	public void setAlaisBundleId(int alaisBundleId) {
		this.alaisBundleId = alaisBundleId;
	}

	public String getAlaisbundleName() {
		return alaisbundleName;
	}

	public void setAlaisbundleName(String alaisbundleName) {
		this.alaisbundleName = alaisbundleName;
	}
}
