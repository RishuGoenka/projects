package com.zycus.enrollment.common.bo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="TBL_DESIGNATION1780")
public class Designation {
	
	@Id
	@GenericGenerator(name="auto",strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="DESIGNATION_ID")	
	private int designationId;
	
	@Column(name="DESIGNATION_NAME")
	private String designationName;
	
	@ManyToOne
	@JoinColumn(name="DEPARTMENT_ID",referencedColumnName="DEPARTMENT_ID")
	private DepartMent departMent;
	
	@OneToOne
	@JoinColumn(name="ALIAS_BUNDLE_ID",referencedColumnName="ALAISBUNDLE_ID")
	private AlaisBundle alaisBundle;
	
	@OneToOne
	@JoinColumn(name="SOFTWARE_BUNDLE_ID",referencedColumnName="SOFTWAREBUNDLE_ID")
	private SoftwareBundle softwareBundle;
	
	@Column(name="GRADE")
	private String grade;
	

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public AlaisBundle getAlaisBundle() {
		return alaisBundle;
	}

	public void setAlaisBundle(AlaisBundle alaisBundle) {
		this.alaisBundle = alaisBundle;
	}

	public SoftwareBundle getSoftwareBundle() {
		return softwareBundle;
	}

	public void setSoftwareBundle(SoftwareBundle softwareBundle) {
		this.softwareBundle = softwareBundle;
	}

	public DepartMent getDepartMent() {
		return departMent;
	}
	
	public void setDepartMent(DepartMent departMent) {
		this.departMent = departMent;
	}
	
	public int getDesignationId() {
		return designationId;
	}
	
	public void setDesignationId(int designationId) {
		this.designationId = designationId;
	}
	
	public String getDesignationName() {
		return designationName;
	}
	
	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}
	
	
   
}
