package com.zycus.enrollment.service.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.AlaisBundle;
import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.SoftwareBundle;
import com.zycus.enrollment.service.exception.ServiceLayerException;

public interface IDesignationServices {

	public abstract void addDesignation(Designation designation)throws ServiceLayerException;

	public abstract List<Designation> getAllDesignations()throws ServiceLayerException;

	public abstract void addSoftwareBundletoDesignation(
			Designation designation, SoftwareBundle softwareBundle) throws ServiceLayerException;

	public abstract void addAliasBundletoDesignation(Designation designation,
			AlaisBundle alaisBundle) throws ServiceLayerException;

	public abstract void addDepartmenttoDesignation(DepartMent departMent,
			Designation designation)throws ServiceLayerException;

	public abstract void addGradeToDesignation(Designation designation, String grade)
			throws ServiceLayerException;
	public Designation getDesignationByName(String designationName,DepartMent departMent)throws ServiceLayerException;
	public Designation getDesignationBYId(int designatioId)throws ServiceLayerException;

	public void getAllDesignations(Designation designation,
			SoftwareBundle softwareBundle) throws ServiceLayerException;
}