package com.zycus.enrollment.service.impl;


import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.Employee;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IEmployeeDao;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.IEmployeeServices;

@Service("EmployeeServices")
public class EmployeeServices implements IEmployeeServices {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private IEmployeeDao iEmployeeDao;
	
	/* (non-Javadoc)
	 * @see com.zycus.Services.IEmployeeServices#addEmployee(com.zycus.pojos.Employee)
	 */
	Logger logger=Logger.getLogger(this.getClass().getName());
	
	
	public EmployeeServices() {
		logger.setLevel(Level.ERROR);
	}
	@Override
	public void addEmployee(Employee employee) throws ServiceLayerException 
	{
		
		try {
			iEmployeeDao.addEmployeebyHR(employee);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addEmployee in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in addEmployee in"+this.getClass().getName()+"caused by: ",e);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.Services.IEmployeeServices#getEmployeeDetailsById(int)
	 */
	@Override
	public Employee getEmployeeDetailsById(int empId) throws ServiceLayerException {
		Employee employee=null;
		 try {
			employee=iEmployeeDao.getEmployeeDetailsById(empId);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getEmployeeDetailsById in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in addEmployee in"+this.getClass().getName()+"caused by: ",e);
		}
		 return employee;
	} 
	
	@Override
	public List<Employee> getEmployeesSortedByName() throws ServiceLayerException {
		List<Employee> list=null;
	  try {
		list=iEmployeeDao.getEmployeesByName();
	} catch (DataBaseException e) {
		
		logger.error("Exception in caught in getEmployeesSortedByName in"+this.getClass().getName()+"caused by: ",e);
		throw new ServiceLayerException("in caught in getEmployeesSortedByName in"+this.getClass().getName()+"caused by: ",e);
	}
	  return list;
	}
	
	
	@Override
	public List<Employee> getEmployeeSortedByDOJ() throws ServiceLayerException {
		List<Employee> list=null;
		try {
			list= iEmployeeDao.getEmployeeSortedByDOJ();
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getEmployeeSortedByDOJ in"+this.getClass().getName()+"caused by:",e);
			throw new ServiceLayerException("in caught in getEmployeeSortedByDOJ in"+this.getClass().getName()+"caused by: ",e);
			
		}
		return list;
	}
	
	@Override
	public void updateEmployeeStatus(Employee employee,int status) throws ServiceLayerException {
		try {
			iEmployeeDao.updateEmployeeStatus(employee, status);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in updateEmployeeStatus in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in updateEmployeeStatus in"+this.getClass().getName()+"caused by: ",e);
		}
	}
	
	
	@Override
	public int getEmployeeStatus(Employee employee) throws ServiceLayerException {
		int status=0;
		try {
			 status=iEmployeeDao.getEmployeeStatus(employee);
		} catch (DataBaseException e) {
			
			logger.error("Exception in caught in getEmployeeStatus in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in getEmployeeStatus in"+this.getClass().getName()+"caused by: ",e);
		}
		return status;
	}


	
	@Override
	public void addDesignationEmployee(Designation designation,
			Employee employee) throws ServiceLayerException  {
		try {
			iEmployeeDao.addDesignationEmployee(designation, employee);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addDesignationEmployee in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in addDesignationEmployee in"+this.getClass().getName()+"caused by: ",e);
		}
	}

	
	@Override
	public List<Employee> getEmployeeByDesignation(Designation designation) throws ServiceLayerException 
	{
		List<Employee> list=null;
	  try {
		list=iEmployeeDao.getEmployeeByDesignation(designation);
	} catch (DataBaseException e) {
		
		logger.error("Exception in caught in getEmployeeByDesignation in"+this.getClass().getName()+"caused by: ",e);
		throw new ServiceLayerException("in caught in getEmployeeByDesignation in"+this.getClass().getName()+"caused by: ",e);
	}
	  return list;
	}
	
	@Override
	 public List<Employee> getEmployeeByStatus(int status) throws ServiceLayerException 
	 {
		 try {
			return iEmployeeDao.getEmployeeByStatus(status);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getEmployeeByStatus in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in getEmployeeByStatus in"+this.getClass().getName()+"caused by: ",e);
		}
	 }
	@Override
	public Employee addMachineToEmployee(Employee employee,String machineNumber) throws ServiceLayerException  {
		try {
			
			employee.setMachineNumber(machineNumber);
			iEmployeeDao.addEmployeebyHR(employee);
			return employee;
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addMachineToEmployee in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in addMachineToEmployee in"+this.getClass().getName()+"caused by: ",e);
		}

	}
	@Override
	public Employee addSeatNumber(Employee employee,String seatNumber) throws ServiceLayerException  {
		try {
			
			employee.setSeatNumber(seatNumber);
			iEmployeeDao.addEmployeebyHR(employee);
			return employee;
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addSeatNumber in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in addSeatNumber in"+this.getClass().getName()+"caused by: ",e);
		}
	}
	
	 public List<Employee> getALLEmployeeByDepartment(DepartMent departMent) throws ServiceLayerException
	 {
		 try {
			return iEmployeeDao.getALLEmployeeByDepartment(departMent);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getALLEmployeeByDepartment in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in getALLEmployeeByDepartment in"+this.getClass().getName()+"caused by: ",e);
		}
		 
	 }
}
