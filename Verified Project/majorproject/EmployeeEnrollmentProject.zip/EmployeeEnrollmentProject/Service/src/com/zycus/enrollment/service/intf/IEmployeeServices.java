package com.zycus.enrollment.service.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.Employee;
import com.zycus.enrollment.service.exception.ServiceLayerException;

public interface IEmployeeServices {

	public abstract void addEmployee(Employee employee)  throws ServiceLayerException;

	public abstract Employee getEmployeeDetailsById(int empId)  throws ServiceLayerException;

	public abstract List<Employee> getEmployeesSortedByName()  throws ServiceLayerException;

	public abstract List<Employee> getEmployeeSortedByDOJ()  throws ServiceLayerException;

	public abstract void updateEmployeeStatus(Employee employee, int status)  throws ServiceLayerException;

	public abstract int getEmployeeStatus(Employee employee)  throws ServiceLayerException;

	public abstract void addDesignationEmployee(Designation designation,
			Employee employee)  throws ServiceLayerException;

	public abstract List<Employee> getEmployeeByDesignation(
			Designation designation)  throws ServiceLayerException;

	 public List<Employee> getEmployeeByStatus(int status)  throws ServiceLayerException ;

	 public abstract Employee addMachineToEmployee(Employee employee, String machineNumber)  throws ServiceLayerException ;

	 public abstract Employee addSeatNumber(Employee employee, String seatNumber) throws ServiceLayerException ;
	 public List<Employee> getALLEmployeeByDepartment(DepartMent departMent) throws ServiceLayerException;
}