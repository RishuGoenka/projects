package com.zycus.enrollment.service.impl;

import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.enrollment.common.bo.AlaisBundle;
import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.SoftwareBundle;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IDesignationDao;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.IDesignationServices;

@Service("Designation")
public class DesignationServices implements IDesignationServices {
	
	@Autowired
	private IDesignationDao iDesignationDao;
	@Autowired 
	private SessionFactory sessionFactory;
	/* (non-Javadoc)
	 * @see com.zycus.Services.IDesignationServices#addDesignation(com.zycus.pojos.Designation)
	 */
	Logger logger=Logger.getLogger(this.getClass().getName());
	
	
	public DesignationServices() {
		logger.setLevel(Level.ERROR);
		
	}
	@Override
	public void addDesignation(Designation designation) throws ServiceLayerException {
		
		try {
			iDesignationDao.addDesignation(designation);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addAlaiseBundle in"+this.getClass().getName(),e);	
			throw new ServiceLayerException("in caught in addAlaiseBundle in"+this.getClass().getName()+"caused by: ",e);
		}
	}

	/* (non-Javadoc)
	 * @see com.zycus.Services.IDesignationServices#getAllDesignations()
	 */
	@Override
	public List<Designation> getAllDesignations() throws ServiceLayerException {
		List<Designation> list=null;
		try {
			list= iDesignationDao.getAllDesignations();
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getAllDesignations in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in getAllDesignations in"+this.getClass().getName()+"caused by: ",e);
		}
		return list;
	}
	
	
	@Override
	public void getAllDesignations(Designation designation,
			SoftwareBundle softwareBundle) throws ServiceLayerException  {
		try {
			iDesignationDao.addSoftwareBundletoDesignation(designation, softwareBundle);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getAllDesignations in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in getAllDesignations in"+this.getClass().getName()+"caused by: ",e);
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.Services.IDesignationServices#addAliasBundletoDesignation(com.zycus.pojos.Designation, com.zycus.pojos.AlaisBundle)
	 */
	@Override
	public void addAliasBundletoDesignation(Designation designation,
			AlaisBundle alaisBundle) throws ServiceLayerException  {
		
		try {
			iDesignationDao.addAliasBundletoDesignation(designation, alaisBundle);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addAliasBundletoDesignation in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in addAliasBundletoDesignation in"+this.getClass().getName()+"caused by: ",e);
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.Services.IDesignationServices#addDepartmenttoDesignation(com.zycus.pojos.DepartMent, com.zycus.pojos.Designation)
	 */
	@Override
	public void addDepartmenttoDesignation(DepartMent departMent,
			Designation designation) throws ServiceLayerException  {
		try {
			iDesignationDao.addDepartmenttoDesignation(departMent, designation);
		} catch(DataBaseException e) {
			logger.error("Exception in caught in addDepartmenttoDesignation in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in addDepartmenttoDesignation in"+this.getClass().getName()+"caused by: ",e);
		}
		
	}
	@Override
	public void addGradeToDesignation(Designation designation,String grade) throws ServiceLayerException{
		
		try {
			iDesignationDao.addGradeToDesignation(designation, grade);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addGradeToDesignation in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in addGradeToDesignation in"+this.getClass().getName()+"caused by: ",e);
		}
	}
	
	public Designation getDesignationByName(String designationName,DepartMent departMent) throws ServiceLayerException 
	{
		try {
			return iDesignationDao.getDesignationByNAme(designationName,departMent);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getDesignationByName in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in getDesignationByName in"+this.getClass().getName()+"caused by: ",e);
		}
		
	}
	
	public Designation getDesignationBYId(int designatioId) throws ServiceLayerException 
	{
		try {
			return iDesignationDao.getDesignationBYId(designatioId);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getDesignationBYId in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in getDesignationBYId in"+this.getClass().getName()+"caused by: ",e);
		}
		
	}

	@Override
	public void addSoftwareBundletoDesignation(Designation designation,
			SoftwareBundle softwareBundle) throws ServiceLayerException  {
		
		designation.setSoftwareBundle(softwareBundle);
		
		
		try {
			iDesignationDao.addDesignation(designation);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addSoftwareBundletoDesignation in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in addSoftwareBundletoDesignation in"+this.getClass().getName()+"caused by: ",e);
		}
	}
	
}
