package com.zycus.enrollment.service.impl;


import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.Employee;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IEmployeeDao;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.IDesignationServices;
import com.zycus.enrollment.service.intf.IEmployeeServices;
import com.zycus.enrollment.service.intf.IPMOService;


@Service("PMOService")
@Transactional
public class PMOService implements IPMOService {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private IEmployeeServices employeeServices;
	@Autowired
	private IEmployeeDao iEmployeeDao;
	@Autowired
	private IDesignationServices iDesignationServices;
	
	Logger logger=Logger.getLogger(this.getClass().getName());
	
	
	public PMOService() {
		logger.setLevel(Level.ERROR);
		
	}
	
	@Override
	public void addEmployeeDesignation(Designation designation,Employee employee) throws ServiceLayerException {
		
		 employeeServices.addDesignationEmployee(designation, employee);
		
	}
	
	
	@Override
	public void addSoftwareBundletoEmployee(Designation designation) {
		designation.getSoftwareBundle();
		
		
	}
	
	@Override
	public void addAliasBundleForDesignation(Designation designation) throws ServiceLayerException {
		try {
			designation.getAlaisBundle();
		} catch (Exception e) {
			logger.error("Exception in caught in addAliasBundleForDesignation in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in addAliasBundleForDesignation in"+this.getClass().getName()+"caused by: ",e); 
		}
	}
	
	
	@Override
	public List<Employee> getManagers(Designation designation,DepartMent departMent) throws ServiceLayerException {
		
		try {
			return iEmployeeDao.getManagerOfEmployee(departMent, designation);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getManagers in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in getManagers in"+this.getClass().getName()+"caused by: ",e); 
		}
	}
	
	
	@Override
	public void assignManager(Employee employee,Employee manager) throws ServiceLayerException {
		
		employee.setManager(manager);
		try {
			iEmployeeDao.addEmployeebyHR(manager);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in assignManager in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in assignManager in"+this.getClass().getName()+"caused by: ",e); 
		}
		
	}
	
	
	@Override
	public void assignGrade(Designation designation,String grade) throws ServiceLayerException {
		
		iDesignationServices.addGradeToDesignation(designation, grade);
	}
	
	
	@Override
	public void assignSeatNumber(Employee employee,String seatNumber) throws ServiceLayerException {
		employeeServices.addSeatNumber(employee, seatNumber);
	}

	

	
	
}
