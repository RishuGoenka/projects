package com.zycus.enrollment.service.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.Software;
import com.zycus.enrollment.common.bo.SoftwareAndSoftwareBundle;
import com.zycus.enrollment.common.bo.SoftwareBundle;
import com.zycus.enrollment.service.exception.ServiceLayerException;

public interface ISoftwareBundleServices {

	public abstract void addSoftwareBundle(SoftwareBundle softwareBundle) throws ServiceLayerException;

	public abstract void addSoftwareToSoftwareBundle(Software software,
			SoftwareBundle softwareBundle)throws ServiceLayerException;

	public abstract List<SoftwareBundle> getAllSoftwareBundle()throws ServiceLayerException;

	public abstract List<Software> getSoftwareBySoftwareBundle(
			SoftwareBundle softwareBundle)throws ServiceLayerException;
	public SoftwareBundle getSoftBundleById(int SoftBundleId) throws ServiceLayerException;
	public void add(SoftwareAndSoftwareBundle softwareAndSoftwareBundle)throws ServiceLayerException;
	public SoftwareBundle getSoftwareBundleByName(String name)throws ServiceLayerException;

}