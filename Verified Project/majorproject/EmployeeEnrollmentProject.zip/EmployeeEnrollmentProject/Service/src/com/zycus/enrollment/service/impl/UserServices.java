package com.zycus.enrollment.service.impl;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.User;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IUserDao;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.IUserServices;

@Service("UserServices")
public class UserServices implements IUserServices {
	
	
	@Autowired
	private IUserDao iUserDao;
	
	private Logger logger=Logger.getLogger(this.getClass().getName());
	
	
	public UserServices() {
		logger.setLevel(Level.ERROR);
		
	}
	@Override
	public User getUserAuthenticated(String userName,String password) throws ServiceLayerException 
	{ User user=null;
		 try {
			user=iUserDao.getUserAuthenticated(userName, password);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getUserAuthenticated in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("Caught in getUserAuthenticated in "+this.getClass().getName()+"caused by ",e); 
		}
		 return user;
		
	}
	@Override
	public boolean ifUserExist(String userName,String password) {
		try {
		return	iUserDao.ifUserExists(userName, password);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in ifUserExist in"+this.getClass().getName()+"caused by: ",e);
			
		}
		return false;
	}
	
	@Override
	public Designation getUserDesignation(User user) throws ServiceLayerException {
		Designation designation=null;
		try {
			  designation= iUserDao.getUserDesignation(user);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getUserDesignation in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("Caught in getUserDesignation in "+this.getClass().getName()+" caused by ",e); 
		}
		return designation;
	}

}
