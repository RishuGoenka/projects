package com.zycus.enrollment.service.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.Alais;
import com.zycus.enrollment.common.bo.AlaisBundle;
import com.zycus.enrollment.common.bo.InterMidiateAlices;
import com.zycus.enrollment.service.exception.ServiceLayerException;

public interface IAlaisBundleServices {

	public abstract void addAlaiseBundle(AlaisBundle alaisBundle) throws ServiceLayerException;

	public abstract void addAlaistoAlaisBundle(Alais alais,
			AlaisBundle alaisBundle) throws ServiceLayerException ;

	public abstract List<AlaisBundle> getAllAlaisBundle() throws ServiceLayerException;

	public abstract List<Alais> getAliasByAliasBundle(AlaisBundle alaisBundle) throws ServiceLayerException ;
	public AlaisBundle getAlaisBundleByID(int aliasId) throws ServiceLayerException;

	public abstract AlaisBundle getAlaisBundleByName(String bundleName);

	public abstract void addInternidiateAlais(
			InterMidiateAlices interMidiateAlices) throws ServiceLayerException;

}