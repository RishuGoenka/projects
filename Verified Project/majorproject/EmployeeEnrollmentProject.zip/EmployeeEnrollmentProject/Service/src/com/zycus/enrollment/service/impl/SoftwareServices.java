package com.zycus.enrollment.service.impl;

import java.util.List;



import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.enrollment.common.bo.Software;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.ISoftwareDao;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.ISoftwareServices;

@Service("SoftwareServices")

public class SoftwareServices implements ISoftwareServices {

	@Autowired
	private ISoftwareDao iSoftwareDao;
	
	Logger logger=Logger.getLogger(this.getClass().getName());
	
	
	public SoftwareServices() {
		logger.setLevel(Level.ERROR);
		
	}
	@Override
	public void addSoftware(Software software) throws ServiceLayerException 
	{
		try {
			iSoftwareDao.addSoftware(software);
		} catch (DataBaseException e) {
			
			logger.error("Exception in caught in addSoftware in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in addSoftware in"+this.getClass().getName()+"caused by: ",e);
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.Services.ISoftwareServices#getAllSoftwareList()
	 */
	@Override
	public List<Software> getAllSoftwareList() throws ServiceLayerException 
	{
		List<Software> list=null;
		try {
			list= iSoftwareDao.getAllSoftwareList();
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getAllSoftwareList in"+this.getClass().getName()+"caused by: ",e);
			throw new  ServiceLayerException("in getAllSoftwareList in"+this.getClass().getName()+"caused by:",e);
		}
	    return list;
	}
	
	@Override
	public Software getById(int id) throws ServiceLayerException{
		Software software=null;
		try {
			 software= iSoftwareDao.getSoftById(id);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getById in"+this.getClass().getName()+"caused by: ",e);
			throw new  ServiceLayerException("in getById in"+this.getClass().getName()+"caused by:",e);
		}
		return software;
	}
	
}
