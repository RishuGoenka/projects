package com.zycus.enrollment.service.impl;

import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.enrollment.common.bo.Alais;
import com.zycus.enrollment.common.bo.AlaisBundle;
import com.zycus.enrollment.common.bo.InterMidiateAlices;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IAlaisBundleDao;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.IAlaisBundleServices;




@Service("AlaisAndBundleServices")
public class AlaisAndBundleServices implements IAlaisBundleServices {
	
	@Autowired
	private IAlaisBundleDao iAlaisBundleDao;
	
	Logger logger=Logger.getLogger(this.getClass().getName());
	
	
	public AlaisAndBundleServices() {
		logger.setLevel(Level.ERROR);
	}

	public void addAlaiseBundle(AlaisBundle alaisBundle) throws ServiceLayerException
	{
		try {
			iAlaisBundleDao.addAlaiseBundle(alaisBundle);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addAlaiseBundle in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in addAlaiseBundle in"+this.getClass().getName()+"caused by: ",e); 
		}
		
	}
	
	public void addAlaistoAlaisBundle(Alais alais,AlaisBundle alaisBundle) throws ServiceLayerException 
	 {
		 try {
			iAlaisBundleDao.addSoftwareToSoftwareBundle(alais, alaisBundle);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addAlaistoAlaisBundle in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in addAlaistoAlaisBundle in"+this.getClass().getName()+"caused by: ",e); 
			
		}
	 }
	 
	 
	 /* (non-Javadoc)
	 * @see com.zycus.Services.IAlaisBundleServices#getAllAlaisBundle()
	 */
	public List<AlaisBundle> getAllAlaisBundle() throws ServiceLayerException {
		List<AlaisBundle> list=null;
			try {
				list= iAlaisBundleDao.getAllAlaisBundle();
			} catch (DataBaseException e) {
			
				logger.error("Exception in caught in getAllAlaisBundle in"+this.getClass().getName()+"caused by: ",e);
				throw new ServiceLayerException("in caught in getAllAlaisBundle in"+this.getClass().getName()+"caused by: ",e); 
			}
			return list;
		}
	
	
	public List<Alais> getAliasByAliasBundle(AlaisBundle alaisBundle) throws ServiceLayerException 
		{
		  List<Alais> list=null;
		  try {
			list= iAlaisBundleDao.getAliasByAliasBundle(alaisBundle);
		} catch (DataBaseException e) {
			
			logger.error("Exception in caught in getAliasByAliasBundle in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in getAliasByAliasBundle in"+this.getClass().getName()+"caused by: ",e); 
		}
		  
		  return list;
		}
	
	public AlaisBundle getAlaisBundleByID(int aliasId) throws ServiceLayerException 
	{
		try {
			return iAlaisBundleDao.getAlaisBundleByID(aliasId);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getAlaisBundleByID in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in getAlaisBundleByID in"+this.getClass().getName()+"caused by: ",e); 
		}
	}

	@Override
	public AlaisBundle getAlaisBundleByName(String alaisName)
	{
		return iAlaisBundleDao.getAlaisBundleByName(alaisName);
	}

	 public void addInternidiateAlais(InterMidiateAlices interMidiateAlices) throws ServiceLayerException
	 {
		 try {
			iAlaisBundleDao.addInternidiateAlais(interMidiateAlices);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getAlaisBundleByID in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in addInternidiateAlais in"+this.getClass().getName()+"caused by: ",e);
		}
	 }

}
