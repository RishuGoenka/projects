package com.zycus.enrollment.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IDepartMentDao;
import com.zycus.enrollment.dao.intf.IDesignationDao;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.IDepartmentServices;

@Service("DepartmentServices")

public class DepartmentServices implements IDepartmentServices {
	
	@Autowired
	private IDepartMentDao iDepartMentDao;
	@Autowired
	private IDesignationDao iDesignationDao;
	
	Logger logger=Logger.getLogger(this.getClass().getName());
	
	
	public DepartmentServices() {
		logger.setLevel(Level.ERROR);
	}

	
	@Override
	public void addDepartment(DepartMent departMent) throws ServiceLayerException 
    {
		try {
			iDepartMentDao.addDepartment(departMent);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addDepartment in"+this.getClass().getName(),e);
			throw new ServiceLayerException("in caught in addDepartment in"+this.getClass().getName()+"caused by: ",e);
		}
	}
	
	@Override
	public List<DepartMent> getAllDepartMents() throws ServiceLayerException 
	{
		List<DepartMent> list=null;
		try {
			 list= iDepartMentDao.getAllDepartMents();
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getAllDepartMents in"+this.getClass().getName(),e);	
			throw new ServiceLayerException("in caught in getAllDepartMents in"+this.getClass().getName()+"caused by: ",e);
		}
		return list;
	}
	
	public DepartMent getDepartMentById(int departmentId) throws ServiceLayerException  
	{
		DepartMent departMent=null;
		try {
			 departMent=iDepartMentDao.getDepartMentById(departmentId);
		} catch (DataBaseException e) {
			
			logger.error("Exception in caught in getDepartMentById in"+this.getClass().getName(),e);	
			throw new ServiceLayerException("in caught in getDepartMentById in"+this.getClass().getName()+"caused by: ",e);
		}
		return departMent;
	}
	

	public List<Designation> getDesignationbyDepartment(DepartMent departMent) throws ServiceLayerException {
		List<Designation> allDesignation=null;
		try {
			allDesignation = iDesignationDao.getAllDesignations();
		} catch (DataBaseException e) {
			
			logger.error("Exception in caught in getDesignationbyDepartment in"+this.getClass().getName(),e);	
			throw new ServiceLayerException("in caught in getDesignationbyDepartment in"+this.getClass().getName()+"caused by: ",e);
		}
		List<Designation>departmentDesignations=new ArrayList<Designation>();
		for(Designation de:allDesignation){
			
			
			if (de.getDepartMent().getDepartmentId()==departMent.getDepartmentId())
			{
				departmentDesignations.add(de);
				
			}
		}
		return departmentDesignations;
	}

}
