package com.zycus.enrollment.service.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.Alais;
import com.zycus.enrollment.service.exception.ServiceLayerException;

public interface IAlaisServices {

	public abstract void addAlais(Alais alais) throws ServiceLayerException;

	public abstract List<Alais> getAllAlias() throws ServiceLayerException;

	public abstract Alais getById(int id) throws ServiceLayerException; 

}