package com.zycus.enrollment.service.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.Software;
import com.zycus.enrollment.service.exception.ServiceLayerException;

public interface ISoftwareServices {

	public abstract void addSoftware(Software software) throws ServiceLayerException;

	public abstract List<Software> getAllSoftwareList() throws ServiceLayerException;

	public abstract Software getById(int id) throws ServiceLayerException;

}