package com.zycus.enrollment.service.impl;

import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.enrollment.common.bo.Software;
import com.zycus.enrollment.common.bo.SoftwareAndSoftwareBundle;
import com.zycus.enrollment.common.bo.SoftwareBundle;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.ISoftwareBundleDao;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.ISoftwareBundleServices;

@Service("SoftwareBundleServices")
public class SoftwareBundleServices implements ISoftwareBundleServices {
	
	@Autowired
	private ISoftwareBundleDao iSoftwareBundleDao;
	
	Logger logger=Logger.getLogger(this.getClass().getName());
	
	
	public SoftwareBundleServices() {
		logger.setLevel(Level.ERROR);
		
	}
	
	@Override
	public void addSoftwareBundle(SoftwareBundle softwareBundle) throws ServiceLayerException 
	{
		try {
			iSoftwareBundleDao.addSoftwareBundle(softwareBundle);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addSoftwareBundle in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in addSoftwareBundle in"+this.getClass().getName()+"caused by: ",e);
		}
		
	}

	
	@Override
	public void addSoftwareToSoftwareBundle(Software software,SoftwareBundle softwareBundle) throws ServiceLayerException 
	{
		try {
			iSoftwareBundleDao.addSoftwareToSoftwareBundle(software, softwareBundle);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in addSoftwareToSoftwareBundle in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in addSoftwareToSoftwareBundle in"+this.getClass().getName()+"caused by: ",e);
		}
	}
	
	
	@Override
	public List<SoftwareBundle> getAllSoftwareBundle() throws ServiceLayerException 
	{
		List<SoftwareBundle> list=null;
		try {
			 list=iSoftwareBundleDao.getAllSoftwareBundle();
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getAllSoftwareBundle in"+this.getClass().getName()+"caused by: ",e);	
			throw new ServiceLayerException("in caught in getAllSoftwareBundle in"+this.getClass().getName()+"caused by: ",e);
		}
		return list;
	}
	
	
	@Override
	public List<Software> getSoftwareBySoftwareBundle(SoftwareBundle softwareBundle) throws ServiceLayerException 
	{
		List<Software> list=null;
		try {
			 list=iSoftwareBundleDao.getSoftwareBySoftwareBundle(softwareBundle);
		} catch (DataBaseException e) {
			
			logger.error("Exception in caught in getSoftwareBySoftwareBundle in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in getSoftwareBySoftwareBundle in"+this.getClass().getName()+"caused by: ",e);
		}
		return list;
	}
	
	public SoftwareBundle getSoftBundleById(int SoftBundleId) throws ServiceLayerException 
	{
		
		try {
			return iSoftwareBundleDao.getSoftBundleById(SoftBundleId);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getSoftBundleById in"+this.getClass().getName()+"caused by: ",e);
			throw new ServiceLayerException("in caught in getSoftBundleById in"+this.getClass().getName()+"caused by: ",e);
		}
	}
	
	public void add(SoftwareAndSoftwareBundle softwareAndSoftwareBundle)
	{
		iSoftwareBundleDao.add(softwareAndSoftwareBundle);
	}
	public SoftwareBundle getSoftwareBundleByName(String name)
	{
		return iSoftwareBundleDao.getSoftwareBundleByName(name);
	}
	
}
