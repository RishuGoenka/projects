package com.zycus.enrollment.service.impl;

import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.enrollment.common.bo.Alais;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IAlaisDao;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.IAlaisServices;

@Service("AlaisServices")
public class AlaisServices implements IAlaisServices {
	
	@Autowired
	private  IAlaisDao iAlaisDao;
	
	/* (non-Javadoc)
	 * @see com.zycus.Services.IAlaisServices#addAlais(com.zycus.pojos.Alais)
	 */
		Logger logger=Logger.getLogger(this.getClass().getName());
	
	
	public AlaisServices() {
		logger.setLevel(Level.ERROR);
	}
	@Override
	public void addAlais(Alais alais) 
	{
		try {
			iAlaisDao.addDesignation(alais);
		} catch (DataBaseException e) {
			
			logger.error("Exception in caught in addAlais in"+this.getClass().getName(),e);
		}
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.Services.IAlaisServices#getAllAlias()
	 */
	@Override
	public List<Alais> getAllAlias() throws ServiceLayerException {
		List<Alais> list=null;
		try {
			  list= iAlaisDao.getAllAlias();
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getAllAlias in "+this.getClass().getName()+"caused by",e);
			throw new ServiceLayerException("in caught in getAllAlias in"+this.getClass().getName()+"caused by: ",e);
		}
		return list;
	}
	
	@Override
	public Alais getById(int id) throws ServiceLayerException{
		Alais al=null;
		try {
			al=iAlaisDao.getAlaiById(id);
		} catch (DataBaseException e) {
			logger.error("Exception in caught in getById in"+this.getClass().getName()+"caused by",e);
			throw new ServiceLayerException("in caught in getById in"+this.getClass().getName()+"caused by: ",e);
		}
		return al;
	}
	

}
