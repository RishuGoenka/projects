package com.zycus.enrollment.service.intf;

import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.User;
import com.zycus.enrollment.service.exception.ServiceLayerException;

public interface IUserServices {

	public abstract User getUserAuthenticated(String userName, String password) throws ServiceLayerException;

	public abstract Designation getUserDesignation(User user) throws ServiceLayerException;

	boolean ifUserExist(String userName, String password);

}