package com.zycus.enrollment.service.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.Employee;
import com.zycus.enrollment.service.exception.ServiceLayerException;

public interface IPMOService {

	public abstract void addEmployeeDesignation(Designation designation,
			Employee employee) throws ServiceLayerException;

	public abstract void addSoftwareBundletoEmployee(Designation designation)throws ServiceLayerException;

	public abstract void addAliasBundleForDesignation(Designation designation) throws ServiceLayerException;

	

	public abstract void assignManager(Employee employee, Employee manager) throws ServiceLayerException;

	

	public abstract void assignSeatNumber(Employee employee, String seatNumber) throws ServiceLayerException;

	List<Employee> getManagers(Designation designation, DepartMent departMent) throws ServiceLayerException;

	void assignGrade(Designation designation, String grade) throws ServiceLayerException;

}