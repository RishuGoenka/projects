package com.zycus.enrollment.service.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.service.exception.ServiceLayerException;

public interface IDepartmentServices {

	public abstract void addDepartment(DepartMent departMent)throws ServiceLayerException ;

	public abstract List<DepartMent> getAllDepartMents() throws ServiceLayerException ;
	public DepartMent getDepartMentById(int departmentId) throws ServiceLayerException;
	public List<Designation> getDesignationbyDepartment(DepartMent departMent) throws ServiceLayerException;

}