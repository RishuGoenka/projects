package com.zycus.enrollment.dao.exception;

public class DataBaseException extends Exception{

	public DataBaseException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public DataBaseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public DataBaseException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
