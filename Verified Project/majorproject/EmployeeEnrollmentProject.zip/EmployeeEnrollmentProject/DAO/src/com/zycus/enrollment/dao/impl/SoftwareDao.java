package com.zycus.enrollment.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.enrollment.common.bo.Software;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.ISoftwareDao;


@Repository("SoftwareDao")
@Transactional
public class SoftwareDao extends BaseDao implements ISoftwareDao {

	@Override
	public void addSoftware(Software software) throws DataBaseException
	{
		try {
			saveOrUpdate(software);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get addSoftware in SoftwareDao ",e);
		}
		
	}
	
	public List<Software> getAllSoftwareList() throws DataBaseException
	{
		try {
			return getAll(Software.class);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get getAllSoftwareList in SoftwareDao ",e);
		}
	}

	@Override
	public Software getSoftById(int id) throws DataBaseException {
		
		Software software=null;
		try {
			 software=get(Software.class, id);
		} catch (DataBaseException e) {
			throw new DataBaseException("Exception in get getAllSoftwareList in SoftwareDao ",e);
		}
		return software;
	}
	
	
	
}
