package com.zycus.enrollment.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.enrollment.common.bo.Alais;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IAlaisDao;


@Repository("AliasDao")
@Transactional
public class AliasDao extends BaseDao implements IAlaisDao {

	
	@Override
	public void addDesignation(Alais alais) throws DataBaseException{
		
		try
		{
		saveOrUpdate(alais);
		}
		catch(HibernateException db) {
			throw new DataBaseException("Exception in addDesignation at AlaiasDao ",db);
		}
		
		
	}
	
	
	@Override
	public List<Alais> getAllAlias() throws DataBaseException{
		List<Alais> list=null;
		try
		{
	      list=getAll(Alais.class);
		}
		catch (HibernateException db) {
			throw new DataBaseException("Exception in getAllAlais at AlaiasDao ",db);
		}
		
		return list;
	}
	
	@Override
	public Alais getAlaiById(int id) throws DataBaseException{
		try {
			return get(Alais.class, id);
		} catch (DataBaseException e) {
			throw new DataBaseException("Exception in  getById in AlaisDao ",e);
		}
	}
	
}
