package com.zycus.enrollment.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.enrollment.common.bo.Alais;
import com.zycus.enrollment.common.bo.AlaisBundle;
import com.zycus.enrollment.common.bo.InterMidiateAlices;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IAlaisBundleDao;



@Repository("AlaisBundleDao")
@Transactional

public class AlaisBundleDao extends BaseDao implements IAlaisBundleDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void addAlaiseBundle(AlaisBundle alaisBundle) throws DataBaseException
	{
		try
		{
	     	saveOrUpdate(alaisBundle);
		}
        
		catch (HibernateException e) {
			throw new DataBaseException("Exception at addAliasBundle in AlaisBundleDao",e);
		}
		
		
	}
	
	
	@Override
	public void addSoftwareToSoftwareBundle(Alais alais,AlaisBundle alaisBundle) throws DataBaseException
	{
		InterMidiateAlices interMidiateAlices=new InterMidiateAlices();
		interMidiateAlices.setAlais(alais);
		interMidiateAlices.setAlaisBundle(alaisBundle);
		
		try
		{
		  saveOrUpdate(interMidiateAlices);
		}
		catch (HibernateException db) {
			throw new DataBaseException("Exception in addSoftware To SoftwareBundle in AlaisBundleDao ",db);
		}
		
	
		
	}
	
	
	
	@Override
	public List<AlaisBundle> getAllAlaisBundle() throws DataBaseException
	{
		try
		{
		return getAll(AlaisBundle.class);
		}
		catch (HibernateException db) {
			throw new DataBaseException("Exception in addSoftware To SoftwareBundle in AlaisBundleDao ",db);
		}
	   
	}


	
	
	@Override
	public List<Alais> getAliasByAliasBundle(AlaisBundle alaisBundle) throws DataBaseException
	{
		List<Alais> listAlais=null;
		
		try {
		Session session=sessionFactory.getCurrentSession();
		Criteria criteria=session.createCriteria(InterMidiateAlices.class);
		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		criteria.add(Restrictions.eq("alaisBundle",alaisBundle));
		
		
		List<InterMidiateAlices> list=criteria.list();
		
		
		
			listAlais = new ArrayList<Alais>();
			for(InterMidiateAlices interMidiateAlices:list)
			{
				System.out.println(interMidiateAlices.getInterAliceId());
				listAlais.add(interMidiateAlices.getAlais());
			}
			
		}
	    catch (HibernateException e) {
			
			 throw new DataBaseException("Exception in get AllAlaisByBundle in AlaisBundleDao ",e);
		}
		

		
		return listAlais;
	}
	
	public AlaisBundle getAlaisBundleByID(int aliasId) throws DataBaseException
	{
		
		AlaisBundle alaisBundle=null;
		try {
			alaisBundle=get(AlaisBundle.class, aliasId);
		} catch (HibernateException e) {
			
			throw new DataBaseException("Exception ingetAlaisBundleByID in AlaisBundleDao ",e);
		}
		return alaisBundle;
	}


	@Override
	 public AlaisBundle getAlaisBundleByName(String alaisName)
    {
   	 Criteria criteria=sessionFactory.getCurrentSession().createCriteria(AlaisBundle.class);
   	 criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
   	 criteria.add(Restrictions.eq("alaisbundleName", alaisName));
   	 return (AlaisBundle) criteria.list().get(0);

    }

    public void addInternidiateAlais(InterMidiateAlices interMidiateAlices) throws DataBaseException
    {

   	 try {
			saveOrUpdate(interMidiateAlices);
		} catch (DataBaseException e) {
			throw new DataBaseException("Exception ingetAlaisBundleBYName in AlaisBundleDao ",e);
		}
    }
}
