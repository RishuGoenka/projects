package com.zycus.enrollment.dao.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.Employee;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IEmployeeDao;


@Repository("Employeedao")
@Transactional
public class EmployeeDao extends BaseDao implements IEmployeeDao{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public Employee addEmployeebyHR(Employee employee) throws DataBaseException{
		try {
			saveOrUpdate(employee);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get addEmployeebyHR in EmployeeDao ",e);
		}
		return employee;
	}
	
	
	@Override
	public Employee getEmployeeDetailsById(int empId) throws DataBaseException{
		  Employee employee=null;
		try {
			 employee=get(Employee.class, empId);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get getEmployeeDetailsById in EmployeeDao ",e);
		}
		return employee;
	}
	
	
	@Override
	public List<Employee> getEmployeeDetailsByName(String empName) throws DataBaseException{
		List<Employee> empList;
		try {
			empList = getAll(Employee.class);
		} catch (HibernateException e) {
		
			throw new DataBaseException("Exception in get getEmployeeDetailsByName in EmployeeDao ",e);
		}
		List<Employee> reqList=new ArrayList<Employee>();
		for(Employee employee:empList){
			if(employee.getEmployeeName().contains(empName)) reqList.add(employee);
		}
		return reqList;
	}
	
	@Override
	public List<Employee> getEmployeesByName() throws DataBaseException{
		List<Employee> employees;
		try {
			employees = getAll(Employee.class);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get getEmployeesByName in EmployeeDao ",e);
		}
		Collections.sort(employees,Employee.SORT_BY_NAME);
		return employees;
	}
	
	@Override
	public List<Employee> getEmployeeSortedByDOJ() throws DataBaseException{
		List<Employee> employees;
		try {
			employees = getAll(Employee.class);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get getEmployeeSortedByDOJ in EmployeeDao ",e);
		}
		Collections.sort(employees,Employee.SORT_BY_DOJ);
		return employees;
	}
	
	@Override
	public void updateEmployeeStatus(Employee employee,int status) throws DataBaseException{
		employee.setStatus(status);
		try {
			saveOrUpdate(employee);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get updateEmployeeStatus in EmployeeDao ",e);
		}
	}
	
	@Override
	public int getEmployeeStatus(Employee employee) throws DataBaseException{
		try {
			return employee.getStatus();
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get getEmployeeStatus in EmployeeDao ",e);
		}
	}


	@Override
	public Employee addDesignationEmployee(Designation designation,
			Employee employee) throws DataBaseException {
		employee.setDesignation(designation);
		try {
			saveOrUpdate(employee);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get addDesignationEmployee in EmployeeDao ",e);
		}
		return employee;
	}


	@Override
	public List<Employee> getEmployeeByDesignation(Designation designation) throws DataBaseException {
		List<Employee> allEmployees;
		try {
			allEmployees = getAll(Employee.class);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get getEmployeeByDesignation in EmployeeDao ",e);
		}
		List<Employee> reqEmployees= new ArrayList<Employee>();
		for(Employee emp:allEmployees){
			if(emp.getDesignation().getDesignationId()==designation.getDesignationId()) reqEmployees.add(emp);
		}
		return reqEmployees;
	}

	
     @SuppressWarnings("unchecked")
	@Override
	 public List<Employee> getEmployeeByStatus(int status) throws DataBaseException
	 {
		 try {
			List<Employee> list=null;
			 Session session=sessionFactory.getCurrentSession();
			 Criteria criteria=session.createCriteria(Employee.class);
			 criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			 criteria.add(Restrictions.eq("status", status));
			 list=criteria.list();
			 return list;
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get getEmployeeByStatus in EmployeeDao ",e);
		}
		 
		 
	 }
     
     @SuppressWarnings("unchecked")
	public List<Employee> getManagerOfEmployee(DepartMent departMent,Designation designation) throws DataBaseException
     {
    	 List<Employee> list;
    	 System.out.println(departMent.getDepartmentId());
    	 System.out.println(designation.getDesignationId());
    	 System.out.println("===============================================");
		try {
			Criteria criteria=sessionFactory.getCurrentSession().createCriteria(Employee.class);
			 criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			 criteria.add(Restrictions.eq("department",departMent));
			  criteria.add(Restrictions.eq("designation",designation));
			  list = criteria.list();
			  
		} catch (HibernateException e) {
			
			throw new DataBaseException("Exception in get getManagerOfEmployee in EmployeeDao ",e);
		}
		System.out.println(list);
    	  return list;
     }


	@Override
	public List<Employee> getALLEmployeeByDepartment(DepartMent departMent) throws DataBaseException {
		
		List<Employee> list;
		try {Criteria criteria=sessionFactory.getCurrentSession().createCriteria(Employee.class);
		 criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		 criteria.add(Restrictions.eq("department",departMent));
		  list = criteria.list();
				} catch (HibernateException e) {
					
					throw new DataBaseException("Exception in get getManagerOfEmployee in EmployeeDao ",e);
				}
		    	  return list;
		 
	}
	
	
}

