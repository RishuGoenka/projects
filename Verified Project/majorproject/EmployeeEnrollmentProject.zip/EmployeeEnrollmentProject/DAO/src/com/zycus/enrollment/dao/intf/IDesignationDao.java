package com.zycus.enrollment.dao.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.AlaisBundle;
import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.SoftwareBundle;
import com.zycus.enrollment.dao.exception.DataBaseException;



public interface IDesignationDao {

	public abstract void addDesignation(Designation designation)throws DataBaseException;

	public abstract List<Designation> getAllDesignations()throws DataBaseException;
	
	public abstract void addSoftwareBundletoDesignation(Designation designation,SoftwareBundle softwareBundle)throws DataBaseException;
	
	public abstract void addAliasBundletoDesignation(Designation designation,AlaisBundle alaisBundle)throws DataBaseException;
	
	public abstract void addDepartmenttoDesignation(DepartMent departMent,Designation designation)throws DataBaseException;

	public abstract void addGradeToDesignation(Designation designation, String grade)
			throws DataBaseException;

	public Designation getDesignationByNAme(String name,DepartMent departMent) throws DataBaseException;
	public Designation getDesignationBYId(int designatioId) throws DataBaseException;


	
}