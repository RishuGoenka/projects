package com.zycus.enrollment.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.enrollment.common.bo.AlaisBundle;
import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.SoftwareBundle;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IDesignationDao;



@Repository("Designationdao")
@Transactional
public class DesignationDao extends BaseDao implements IDesignationDao{

	@Autowired
	private SessionFactory sessionFactory;
	@Override
	public void addDesignation(Designation designation) throws DataBaseException{
		try {
			saveOrUpdate(designation);
		} catch (HibernateException db) {
			
			throw new DataBaseException("Exception in addDesignation at Designation Dao",db);
		}
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Designation> getAllDesignations() throws DataBaseException{
		
		try {
			List<Designation> list=null;
			Criteria criteria=sessionFactory.getCurrentSession().createCriteria(Designation.class);
			 criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			 list=criteria.list();
			return list;
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in getAllDesignations at Designation Dao",e);
		}
	}


	@Override
	public void addSoftwareBundletoDesignation(Designation designation,
			SoftwareBundle softwareBundle) throws DataBaseException {
		designation.setSoftwareBundle(softwareBundle);
		try {
			saveOrUpdate(designation);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in addSoftwareBundletoDesignation at Designation Dao",e);
		}
		
	}


	@Override
	public void addAliasBundletoDesignation(Designation designation,
			AlaisBundle alaisBundle) throws DataBaseException {
		designation.setAlaisBundle(alaisBundle);
		try {
			saveOrUpdate(designation);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in addAliasBundletoDesignation at Designation Dao",e);
		}
		
	}


	@Override
	public void addDepartmenttoDesignation(DepartMent departMent,
			Designation designation) throws DataBaseException {
		designation.setDepartMent(departMent);
		try {
			saveOrUpdate(designation);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in addDepartmenttoDesignation at Designation Dao",e);
		}
		
	}
	
	@Override
	public void addGradeToDesignation(Designation designation,String grade)throws DataBaseException{
		designation.setGrade(grade);
		try {
			saveOrUpdate(designation);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in addGradeToDesignation at Designation Dao",e);
		}
	}
	
	public Designation getDesignationByNAme(String name,DepartMent departMent) throws DataBaseException
	{
		try {
			Criteria criteria=sessionFactory.getCurrentSession().createCriteria(Designation.class);
			criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
			criteria.add(Restrictions.eq("designationName",name));
			criteria.add(Restrictions.eq("departMent", departMent));
			return (Designation) criteria.list().get(0);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in getDesignationByNAme at Designation Dao",e);
		}
		
	}
	
	public Designation getDesignationBYId(int designatioId) throws DataBaseException
	{
		Designation designation=null;
		
		 try {
			designation=get(Designation.class,designatioId);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in getDesignationBYId at Designation Dao",e);
		}
		 return designation;
	}




	
	
	
		
		
	}
	

