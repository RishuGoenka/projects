package com.zycus.enrollment.dao.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.Software;
import com.zycus.enrollment.common.bo.SoftwareAndSoftwareBundle;
import com.zycus.enrollment.common.bo.SoftwareBundle;
import com.zycus.enrollment.dao.exception.DataBaseException;



public interface ISoftwareBundleDao {

	public abstract void addSoftwareBundle(SoftwareBundle softwareBundle)throws DataBaseException;

	public abstract void addSoftwareToSoftwareBundle(Software software,
			SoftwareBundle softwareBundle)throws DataBaseException;

	public abstract List<SoftwareBundle> getAllSoftwareBundle()throws DataBaseException;
	public List<Software> getSoftwareBySoftwareBundle(SoftwareBundle softwareBundle)throws DataBaseException;
	public SoftwareBundle getSoftBundleById(int SoftBundleId) throws DataBaseException;

	public abstract SoftwareBundle getSoftwareBundleByName(String name);

	public abstract void add(SoftwareAndSoftwareBundle softwareAndSoftwareBundle);

}