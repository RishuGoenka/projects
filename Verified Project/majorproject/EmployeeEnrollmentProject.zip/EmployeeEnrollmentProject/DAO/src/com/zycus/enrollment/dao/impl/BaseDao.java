package com.zycus.enrollment.dao.impl;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.enrollment.dao.exception.DataBaseException;



@Repository("BaseDao")
@Transactional
public class BaseDao {

	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveOrUpdate(Object obj) throws DataBaseException{
	
		
		try {
			Session session= sessionFactory.getCurrentSession();
			
			session.saveOrUpdate(obj);
		} catch (HibernateException e) {
			
			throw new DataBaseException("Exception in addDesignation at basedao ",e);
		}
		
	}
	public void delete(Object obj) throws DataBaseException{
		
		
		try {
			Session session= sessionFactory.getCurrentSession();
			
			session.delete(obj);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in delete at basedao ",e);
			
		}
		
	}
	@SuppressWarnings("unchecked")
	public <E> E get(Class<E> className,Serializable pk) throws DataBaseException{
		
		
		E e=null;
		try {
			Session session= sessionFactory.getCurrentSession();
			
			e = (E) session.get(className, pk);
		} catch (HibernateException ex) {
			throw new DataBaseException("Exception in getClass at basedao ",ex);
		}
		
		return e;
	}
	@SuppressWarnings("unchecked")
	public <E> List<E> getAll(Class<E> type) throws DataBaseException{
		
		List<E> list=null;
		try {
			Session session=sessionFactory.getCurrentSession();
			Criteria criteria=session.createCriteria(type);
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        list = criteria.list();
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in getAll at basedao ",e);
		}
		
	return list;
		
		
	}
	
}
