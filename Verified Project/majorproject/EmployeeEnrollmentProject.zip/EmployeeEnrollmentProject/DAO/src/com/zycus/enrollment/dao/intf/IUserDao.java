package com.zycus.enrollment.dao.intf;

import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.User;
import com.zycus.enrollment.dao.exception.DataBaseException;



public interface IUserDao {

	public abstract User getUserAuthenticated(String email, String password)throws DataBaseException;

	public abstract Designation getUserDesignation(User user)throws DataBaseException;

	boolean ifUserExists(String username, String password)throws DataBaseException;

}