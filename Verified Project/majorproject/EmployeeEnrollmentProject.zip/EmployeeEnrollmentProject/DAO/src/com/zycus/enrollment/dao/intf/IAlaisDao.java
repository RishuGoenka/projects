package com.zycus.enrollment.dao.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.Alais;
import com.zycus.enrollment.dao.exception.DataBaseException;



public interface IAlaisDao {

	public abstract void addDesignation(Alais alais)throws DataBaseException;

	public abstract List<Alais> getAllAlias()throws DataBaseException;

	Alais getAlaiById(int id) throws DataBaseException;

}