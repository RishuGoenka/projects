package com.zycus.enrollment.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.enrollment.common.bo.Software;
import com.zycus.enrollment.common.bo.SoftwareAndSoftwareBundle;
import com.zycus.enrollment.common.bo.SoftwareBundle;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.ISoftwareBundleDao;


@Repository("SoftwareBundledao")
@Transactional
public class SoftwareBundleDao extends BaseDao implements ISoftwareBundleDao{

	
	@Autowired
	private SessionFactory sessionFactory;
	@Override
	public void addSoftwareBundle(SoftwareBundle softwareBundle) throws DataBaseException
	{
		try {
			saveOrUpdate(softwareBundle);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get addSoftwareBundle in SoftwareBundleDao ",e);
		}
		
	}
	/* (non-Javadoc)
	 * @see com.zycus.dao.ISoftwareBundleDao#addSoftwareToSoftwareBundle(com.zycus.pojos.Software, com.zycus.pojos.SoftwareBundle)
	 */
	@Override
	public void addSoftwareToSoftwareBundle(Software software,SoftwareBundle softwareBundle)throws DataBaseException
	{
		SoftwareAndSoftwareBundle softwareAndSoftwareBundle=new SoftwareAndSoftwareBundle();
		softwareAndSoftwareBundle.setSoftware(software);
		softwareAndSoftwareBundle.setSoftwareBundle(softwareBundle);
		try {
			saveOrUpdate(softwareAndSoftwareBundle);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get addSoftwareToSoftwareBundle in SoftwareBundleDao ",e);
		}
		
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.dao.ISoftwareBundleDao#getAllSoftwareBundle()
	 */
	@Override
	public List<SoftwareBundle> getAllSoftwareBundle() throws DataBaseException
	{
		try {
			return getAll(SoftwareBundle.class);
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get getAllSoftwareBundle in SoftwareBundleDao ",e);
		}
	}
	
	@Override
	public List<Software> getSoftwareBySoftwareBundle(SoftwareBundle softwareBundle) throws DataBaseException
	{
		List<Software> listSoftware=null;
		try {
			List<SoftwareAndSoftwareBundle> list=softwareBundle.getSoftwareAndSoftwareBundleList();
			
			
			listSoftware = new ArrayList<Software>();
			for(SoftwareAndSoftwareBundle softwareandBundle:list)
			{
				
				
				listSoftware.add(softwareandBundle.getSoftware());
			}
		} catch (HibernateException e) {
			
			throw new DataBaseException("Exception in getSoftwareBySoftwareBundle in SoftwareBundleDao",e);
		}
		
		return listSoftware;
	}
	
	public SoftwareBundle getSoftBundleById(int SoftBundleId) throws DataBaseException
	{
		SoftwareBundle softwareBundle=null;
		try {
			softwareBundle=get(SoftwareBundle.class, SoftBundleId);
		} catch (HibernateException e) {
			
			throw new DataBaseException("Exception in getSoftBundleById in SoftwareBundleDao",e);
		}
		return softwareBundle;
	}
	@Override
	public SoftwareBundle getSoftwareBundleByName(String name) {
		Criteria criteria=sessionFactory.getCurrentSession().createCriteria(SoftwareBundle.class);
		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY);
		criteria.add(Restrictions.eq("softwareBundlename", name));
		return (SoftwareBundle) criteria.list().get(0);
		
	}
	@Override
	public void add(SoftwareAndSoftwareBundle softwareAndSoftwareBundle) {
		try {
			saveOrUpdate(softwareAndSoftwareBundle);
		} catch (DataBaseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
