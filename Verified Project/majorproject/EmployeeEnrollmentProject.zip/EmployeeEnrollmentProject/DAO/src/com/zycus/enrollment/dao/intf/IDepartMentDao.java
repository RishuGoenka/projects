package com.zycus.enrollment.dao.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.dao.exception.DataBaseException;


public interface IDepartMentDao {

	public abstract void addDepartment(DepartMent departMent)throws DataBaseException;

	public abstract List<DepartMent> getAllDepartMents()throws DataBaseException;
	public DepartMent getDepartMentById(int depId) throws DataBaseException;

}