package com.zycus.enrollment.dao.impl;

import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IDepartMentDao;



@Repository("DepartmantDao")
@Transactional
public class DepartmentDao extends BaseDao implements IDepartMentDao {

	/* (non-Javadoc)
	 * @see com.zycus.dao.IDepartMentDao#addDepartment(com.zycus.pojos.DepartMent)
	 */
	@Override
	public void addDepartment(DepartMent departMent) throws DataBaseException{
		try {
			saveOrUpdate(departMent);
		} catch (HibernateException db) {
			
			throw new DataBaseException("Exception in addDepartment at DepartmentDao",db);
		}
		
		
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.dao.IDepartMentDao#getAllDepartMents()
	 */
	@Override
	public List<DepartMent> getAllDepartMents() throws DataBaseException{
		
		List<DepartMent> list=null;
			try {
				 list=getAll(DepartMent.class);
			}  catch (HibernateException db) {
				
				throw new DataBaseException("Exception in getAllDEpartment at DepartmentDao",db);
			}
			
			
			return list;
		
	}
	
	@Override
	public DepartMent getDepartMentById(int depId) throws DataBaseException
	{
		DepartMent departMent=null;
		 try {
			departMent=get(DepartMent.class,depId);
		} catch (HibernateException db) {
			 throw new DataBaseException("Exception in getDEpartment by DepartmentId at DepartmentDao",db);
		}
		
		 return departMent;
	}
}
