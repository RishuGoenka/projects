package com.zycus.enrollment.dao.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.Alais;
import com.zycus.enrollment.common.bo.AlaisBundle;
import com.zycus.enrollment.common.bo.InterMidiateAlices;
import com.zycus.enrollment.dao.exception.DataBaseException;



public interface IAlaisBundleDao {

	public abstract void addAlaiseBundle(AlaisBundle alaisBundle)throws DataBaseException;

	public abstract void addSoftwareToSoftwareBundle(Alais alais,
			AlaisBundle alaisBundle)throws DataBaseException;

	public abstract List<AlaisBundle> getAllAlaisBundle()throws DataBaseException;

	public abstract List<Alais> getAliasByAliasBundle(AlaisBundle alaisBundle)throws DataBaseException;
	public AlaisBundle getAlaisBundleByID(int aliasId) throws DataBaseException;

	public abstract void addInternidiateAlais(
			InterMidiateAlices interMidiateAlices) throws DataBaseException;

	public abstract AlaisBundle getAlaisBundleByName(String alaisName);

}