package com.zycus.enrollment.dao.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.Employee;
import com.zycus.enrollment.dao.exception.DataBaseException;


public interface IEmployeeDao {

	public abstract Employee addEmployeebyHR(Employee employee)throws DataBaseException;

	public abstract Employee getEmployeeDetailsById(int empId)throws DataBaseException;
	
	public abstract Employee addDesignationEmployee(Designation designation,Employee employee)throws DataBaseException;

	public abstract List<Employee> getEmployeeDetailsByName(String empName)throws DataBaseException;

	public abstract List<Employee> getEmployeesByName()throws DataBaseException;

	public abstract List<Employee> getEmployeeSortedByDOJ()throws DataBaseException;

	public abstract void updateEmployeeStatus(Employee employee, int status)throws DataBaseException;

	public abstract int getEmployeeStatus(Employee employee)throws DataBaseException;
	
	public abstract List<Employee> getEmployeeByDesignation(Designation designation)throws DataBaseException; 
	 public List<Employee> getEmployeeByStatus(int status) throws DataBaseException;
	 public List<Employee> getManagerOfEmployee(DepartMent departMent,Designation designation) throws DataBaseException;
   
	public abstract List<Employee> getALLEmployeeByDepartment(
			DepartMent departMent)throws DataBaseException;  
}