package com.zycus.enrollment.dao.intf;

import java.util.List;

import com.zycus.enrollment.common.bo.Software;
import com.zycus.enrollment.dao.exception.DataBaseException;


public interface ISoftwareDao {

	public abstract void addSoftware(Software software)throws DataBaseException;
	public List<Software> getAllSoftwareList()throws DataBaseException;
	public abstract Software getSoftById(int id)throws DataBaseException ;

}