package com.zycus.enrollment.dao.impl;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.User;
import com.zycus.enrollment.dao.exception.DataBaseException;
import com.zycus.enrollment.dao.intf.IUserDao;



@Repository("UserDao")
@Transactional
public class UserDao extends BaseDao implements  IUserDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public User getUserAuthenticated(String email,String password) throws DataBaseException{
		List<User> user=null;
		try {
			Session sess=sessionFactory.getCurrentSession();
			Criteria criteria=sess.createCriteria(User.class);
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			criteria.add(Restrictions.eq("userName", email));
			criteria.add(Restrictions.eq("password", password));
			
			 user=criteria.list();
			} catch (HibernateException e) {
			throw new DataBaseException("Exception in UserAuthentication in UserDao",e);
		}
		return user.get(0);
		
	}
	
	@Override
	public boolean ifUserExists(String username,String password) throws DataBaseException{
		
		boolean flag=false;
		try {
			List<User> listUser=getAll(User.class);
			for(User u:listUser){
				if(u.getUserName().equalsIgnoreCase(username) && u.getPassword().equals(password)) flag=true;
			}
			 
			
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in UserAuthentication in UserDao",e);
		}
		return flag;
	}
	
	@Override
	public Designation getUserDesignation(User user) throws DataBaseException{
		try {
			return user.getDesignation();
		} catch (HibernateException e) {
			throw new DataBaseException("Exception in get getUserDesignation in UserDao ",e);
		}
	}
}
