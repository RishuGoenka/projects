package com.zycus.enrollment.web.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginFilter implements Filter{

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse,
			FilterChain filterChain) throws IOException, ServletException {

		HttpServletRequest request=(HttpServletRequest)servletRequest;		

		HttpSession session=request.getSession(false);
		String uri=request.getRequestURI();
		if(uri.contains("CheckCredentials.do"))
		{
           filterChain.doFilter(servletRequest, servletResponse);

		}
		else
		{
			HttpServletResponse response=(HttpServletResponse)servletResponse;
			if(session==null || session.getAttribute("User")==null )
			{

				response.sendRedirect("index.jsp");
				return;

			}
			else{
				filterChain.doFilter(servletRequest, servletResponse);
              }


		}

		
		
		
	}

	@Override
	public void init(FilterConfig servletRequest) throws ServletException {
		
		
	}

	

}
