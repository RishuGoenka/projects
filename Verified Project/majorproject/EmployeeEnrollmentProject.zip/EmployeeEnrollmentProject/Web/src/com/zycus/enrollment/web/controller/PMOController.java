package com.zycus.enrollment.web.controller;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.enrollment.common.bo.Alais;
import com.zycus.enrollment.common.bo.AlaisBundle;
import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.Employee;
import com.zycus.enrollment.common.bo.InterMidiateAlices;
import com.zycus.enrollment.common.bo.Software;
import com.zycus.enrollment.common.bo.SoftwareAndSoftwareBundle;
import com.zycus.enrollment.common.bo.SoftwareBundle;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.IAlaisBundleServices;
import com.zycus.enrollment.service.intf.IAlaisServices;
import com.zycus.enrollment.service.intf.IDepartmentServices;
import com.zycus.enrollment.service.intf.IDesignationServices;
import com.zycus.enrollment.service.intf.IEmployeeServices;
import com.zycus.enrollment.service.intf.IPMOService;
import com.zycus.enrollment.service.intf.ISoftwareBundleServices;
import com.zycus.enrollment.service.intf.ISoftwareServices;
@Controller
@SessionAttributes({"Employee","designation","DepartmentOfUser"})
public class PMOController {
	
	@Autowired
	private IEmployeeServices iEmployeeServices;
	@Autowired
	private IDepartmentServices iDepartmentServices;
	@Autowired
	private IPMOService ipmoService;
	@Autowired
	private IDesignationServices iDesignationServices;
	@Autowired
	private ISoftwareBundleServices iSoftwareBundleServices;
	@Autowired
	private IAlaisBundleServices iAlaisBundleServices;
	@Autowired
	private ISoftwareServices iSoftwareServices;
	
	@Autowired
	private IAlaisServices iAlaisServices;
	
	private Logger logger=Logger.getLogger(this.getClass().getName());

	@RequestMapping(value="AddPMODEtails.do")
	public String addEmployeeDetailsByPMO(@RequestParam(value="employeeId")String employeeId,Map<String,Object> model)
	{ 
		String designationName=(String)model.get("designation");
		String target=null;
		if(designationName.equalsIgnoreCase("PMOHOD"))
		{
			
			Employee employee = null;
			try {
				employee = iEmployeeServices.getEmployeeDetailsById(Integer.parseInt(employeeId));
			} catch (NumberFormatException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			model.put("getEmployeeStep1Details", employee);
			model.put("Employee", employee);
			target="hodverify2.jsp";
			
		}
		else if(designationName.equalsIgnoreCase("ITIS"))
		{

			Employee employee = null;
			try {
				employee = iEmployeeServices.getEmployeeDetailsById(Integer.parseInt(employeeId));
			} catch (NumberFormatException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			model.put("getEmployeeStep3Details", employee);
			
			
		
			model.put("Employee", employee);
			target="form3.jsp";
		}
		else if(designationName.equalsIgnoreCase("ITISHOD"))
		{
			Employee employee = null;
			try {
				employee = iEmployeeServices.getEmployeeDetailsById(Integer.parseInt(employeeId));
			} catch (NumberFormatException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			model.put("getEmployeeStep3Details", employee);
			
			
		
			model.put("Employee", employee);
			target="hodverify3.jsp";
		}
		else{
			Employee employee = null;
			try {
				employee = iEmployeeServices.getEmployeeDetailsById(Integer.parseInt(employeeId));
			} catch (NumberFormatException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			model.put("getEmployeeStep1Details", employee);
			model.put("Employee", employee);
			DepartMent departMent=employee.getDepartment();
			List<Designation> listDesignation = null;
			try {
				listDesignation = iDepartmentServices.getDesignationbyDepartment(departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			model.put("listDesignation", listDesignation);
			Designation designation = null;
			try {
				designation = iDesignationServices.getDesignationByName("Manager",departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			List<Employee> employees = null;
			try {
				employees = ipmoService.getManagers(designation, departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}

			model.put("listOfManagers", employees);
			List<SoftwareBundle> softwareBundleList = null;
			try {
				softwareBundleList = iSoftwareBundleServices.getAllSoftwareBundle();
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			model.put("softwareBundleList", softwareBundleList);
			List<AlaisBundle> alaisList = null;
			try {
				alaisList = iAlaisBundleServices.getAllAlaisBundle();
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			model.put("alaisList", alaisList);
			target="from2.jsp";
		}
		return target;
		
	}

	
	@RequestMapping(value="ApproveByPMOHOD.do")
	public String addEmployeeByPMOHOD(@RequestParam("employeeId")String employeeId,Map<String,Object> model)
	{
		Employee employee = null;
		try {
			employee = iEmployeeServices.getEmployeeDetailsById(Integer.parseInt(employeeId));
		} catch (NumberFormatException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		
		Calendar cal=Calendar.getInstance();
		Date date=new Date(cal.getTimeInMillis());
		employee.setApprovedByPMODept(date);
		employee.setStatus(4);
		try {
			iEmployeeServices.addEmployee(employee);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		
		return "index.jsp";
	}
	
	@RequestMapping(value="ApproveByPMOHOD1.do")
	public String addEmployeeByPMOHODf(@RequestParam("employeeId")String employeeId,@RequestParam(value="designation")String desginationId,
	@RequestParam(value="manager")String manager,
	@RequestParam(value="seat")String seatNumber,
	@RequestParam(value="Grade")String grade,Map<String,Object> model)
	{
		
		Employee employee = null;
		try {
			employee = iEmployeeServices.getEmployeeDetailsById(Integer.parseInt(employeeId));
		} catch (NumberFormatException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		Designation designation = null;
		try {
			designation = iDesignationServices.getDesignationBYId(Integer.parseInt(desginationId));
		} catch (NumberFormatException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		employee.setDesignation(designation);
		designation.setGrade(grade);
		try {
			iDesignationServices.addDesignation(designation);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		Employee manager1 = null;
		try {
			manager1 = iEmployeeServices.getEmployeeDetailsById(Integer.parseInt(manager));
		} catch (NumberFormatException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		
		employee.setManager(manager1);
		employee.setSeatNumber(seatNumber);
		employee.setStatus(3);
		
		try {
			iEmployeeServices.addEmployee(employee);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		
		return "";
	}
	
	@RequestMapping(value="GotoSoftwareBuldle.do")
	public String gotoSoftwareBundle(Map<String,Object> model)
	{
		  List<SoftwareBundle> list = null;
		try {
			list = iSoftwareBundleServices.getAllSoftwareBundle();
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		  model.put("ListofSoftwareBundle", list);
		  return "SoftwareBundle.jsp";
		
		
	}
	@RequestMapping(value="getSoftwareList.do")
	public String gotoSoftware(Map<String,Object> model)
	{
		  List<SoftwareBundle> list = null;
		try {
			list = iSoftwareBundleServices.getAllSoftwareBundle();
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		  model.put("ListofSoftwareBundle", list);
		  return "SoftwareBundle.jsp";
		
		
	}
	@RequestMapping(value="getAllSoftware.do")
	public @ResponseBody String getAllSoftware(@RequestParam(value="softwareBundle")String softwareBundleId)
	{
		
		SoftwareBundle softwareBundle = null;
		try {
			softwareBundle = iSoftwareBundleServices.getSoftBundleById(Integer.parseInt(softwareBundleId));
		} catch (NumberFormatException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		
		String softwares=" ";
		List<Software> list = null;
		try {
			list = iSoftwareBundleServices.getSoftwareBySoftwareBundle(softwareBundle);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		for(Software s:list)
		{
			s.setSoftwareAndSoftwareBundleList(null);
			softwares+=s.getSoftwareName()+",";
		}
		
		return softwares;
	}
	@RequestMapping(value="gotoAlaisBundle")
	public String gotoAlaisBundle(Map<String,Object> model)
	{
		  List<AlaisBundle> listofAlaisBundle = null;
		try {
			listofAlaisBundle = iAlaisBundleServices.getAllAlaisBundle();
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		  model.put("ListofAlaisBundle", listofAlaisBundle);
		  return "AlaisBundle.jsp";
		
		
	}
	
	@RequestMapping(value="getAllAlais.do")
	public @ResponseBody String getAllAlais(@RequestParam(value="AlaisBundle")String alaisBundleId)
	{
		AlaisBundle alaisBundle=null;
		try {
			alaisBundle=iAlaisBundleServices.getAlaisBundleByID(Integer.parseInt(alaisBundleId));
		} catch (NumberFormatException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		String aliases = " ";
		List<Alais> list = null;
		try {
			list = iAlaisBundleServices.getAliasByAliasBundle(alaisBundle);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		for(Alais s:list)
		{
			s.setIntermidiateList(null);
			aliases+=s.getAlaisName()+",";
		}
		return aliases;
	}
	
	
	
	@RequestMapping(value="GotoCreateSoftwareBuldle.do")
	public String gotoChooseSoftwareBundle(Map<String,Object> model)
	{
		  List<Software> list = null;
		try {
			list = iSoftwareServices.getAllSoftwareList();
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		  model.put("SoftwareList", list);
		  model.put("IsCreated", "false");
		  return "CreateSoftwareBundle.jsp";
		
		
	}
	
	
	@RequestMapping(value="CreatesoftwareBuldle.do")
	public String gotoCreateSoftwareBundle(
			@RequestParam(value="softwareBundleName")String bundleName,
			@RequestParam(value="isoftware")String softwareList[],Map<String,Object> model)
	{
		
		SoftwareBundle softwareBundle=new SoftwareBundle();
		softwareBundle.setSoftwareBundlename(bundleName);
		try {
			iSoftwareBundleServices.addSoftwareBundle(softwareBundle);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		
		
		for(String software:softwareList)
		{
		   SoftwareAndSoftwareBundle softwareAndSoftwareBundle=new SoftwareAndSoftwareBundle();
		   try {
			softwareAndSoftwareBundle.setSoftwareBundle(iSoftwareBundleServices.getSoftwareBundleByName(bundleName));
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		   try {
			softwareAndSoftwareBundle.setSoftware(iSoftwareServices.getById(Integer.parseInt(software)));
		} catch (NumberFormatException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		   try {
			iSoftwareBundleServices.add(softwareAndSoftwareBundle);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		}
		model.put("IsCreated","True");
		List<Software> list = null;
		try {
			list = iSoftwareServices.getAllSoftwareList();
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		  model.put("SoftwareList", list);
		  DepartMent departMent=(DepartMent) model.get("DepartmentOfUser");
			List<Employee> employees = null;
			try {
				employees = iEmployeeServices.getALLEmployeeByDepartment(departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}

			model.put("listOfEmployee", employees);
			List<Designation> listDesignation = null;
			try {
				listDesignation = iDepartmentServices.getDesignationbyDepartment(departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			model.put("listDesignation", listDesignation);
			Designation designation = null;
			try {
				designation = iDesignationServices.getDesignationByName("Manager",departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			List<Employee> managers=null;
			try {
				managers=ipmoService.getManagers(designation, departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			model.put("listOfManagers", managers);
		
		return "pmoemployeelist.jsp";
		
	}
	
	@RequestMapping(value="gotoHomePMO.do")
	public String gotoHome(Map<String,Object> model)
	{
		DepartMent departMent=(DepartMent) model.get("DepartmentOfUser");
		List<Employee> employees = null;
		try {
			employees = iEmployeeServices.getALLEmployeeByDepartment(departMent);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		
		model.put("listOfEmployee", employees);
		List<Designation> listDesignation = null;
		try {
			listDesignation = iDepartmentServices.getDesignationbyDepartment(departMent);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		model.put("listDesignation", listDesignation);
		Designation designation = null;
		try {
			designation = iDesignationServices.getDesignationByName("Manager",departMent);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		List<Employee> managers = null;
		try {
			managers = ipmoService.getManagers(designation, departMent);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}

		model.put("listOfManagers", managers);

		  
		
		return "pmoemployeelist.jsp";
	}
	@RequestMapping(value="getGrade.do")
	public@ResponseBody String getGrade(@RequestParam(value="Designation")String designationId,Map<String,Object> model)
	{
		Designation designation = null;
		try {
			designation = iDesignationServices.getDesignationBYId(Integer.parseInt(designationId));
		} catch (NumberFormatException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		String grade=designation.getGrade();
		 
		  return grade;
		
		
	}
	
	@RequestMapping(value="GotoCreateAlaisBundle.do")
	public String gotoCreateAlaisBundle(Map<String,Object> model)
	{
		  List<Alais> list = null;
		try {
			list = iAlaisServices.getAllAlias();
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		  model.put("AlaisList", list);
		  model.put("IsCreated", "false");
		  return "CreateAlais.jsp";


	}



	@RequestMapping(value="CreatesAlaisBuldle.do")
	public String CreateAlaisBundle(
			@RequestParam(value="AlaisBundleBundleName")String bundleName,
			@RequestParam(value="alais")String alaisList[],Map<String,Object> model)
	{

		AlaisBundle alaisBundle=new AlaisBundle();
		alaisBundle.setAlaisbundleName(bundleName);
		try {
			iAlaisBundleServices.addAlaiseBundle(alaisBundle);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		 for(String alais:alaisList)
		 {
			InterMidiateAlices interMidiateAlices=new InterMidiateAlices();
			 AlaisBundle alaisBundle2=iAlaisBundleServices.getAlaisBundleByName(bundleName);
			 interMidiateAlices.setAlaisBundle(alaisBundle2);
			 Alais alais2 = null;
			try {
				alais2 = iAlaisServices.getById(Integer.parseInt(alais));
			} catch (NumberFormatException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			
			 interMidiateAlices.setAlais(alais2);
			 try {
				iAlaisBundleServices.addInternidiateAlais(interMidiateAlices);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
		 }



		  DepartMent departMent=(DepartMent) model.get("DepartmentOfUser");
			List<Employee> employees = null;
			try {
				employees = iEmployeeServices.getALLEmployeeByDepartment(departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}

			model.put("listOfEmployee", employees);
			List<Designation> listDesignation = null;
			try {
				listDesignation = iDepartmentServices.getDesignationbyDepartment(departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			model.put("listDesignation", listDesignation);
			Designation designation = null;
			try {
				designation = iDesignationServices.getDesignationByName("Manager",departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
	       
			List<Employee> managers = null;
			try {
				managers = ipmoService.getManagers(designation, departMent);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}

			model.put("listOfManagers", managers);



			return "pmoemployeelist.jsp";



	}
	@RequestMapping(value="ViewAllAlaisBundle.do")
	public String gotoViewAllAlaisBundle(Map<String,Object> model)
	{

		  try {
			model.put("AlaisBundleList", iAlaisBundleServices.getAllAlaisBundle());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		  return "AlaisBundle.jsp";


	}

}
