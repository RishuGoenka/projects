package com.zycus.enrollment.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zycus.enrollment.dao.impl.BaseDao;
import com.zycus.enrollment.service.intf.IAlaisBundleServices;
import com.zycus.enrollment.service.intf.ISoftwareBundleServices;
import com.zycus.enrollment.service.intf.IUserServices;

@Controller
public class Testcontroller {
	
	@Autowired
	@Qualifier("UserServices")
	private IUserServices iUserServices;
	
	@Autowired
	private BaseDao baseDao;
	
	@Autowired
	private IAlaisBundleServices iAlaisBundleServices;
	@Autowired
	private ISoftwareBundleServices iSoftwareBundleServices;
	
	@RequestMapping(value="/CheckCredentials1.do",method=RequestMethod.GET)
	public String  get()
	{
		return"form1.jsp";
	}
	

}
