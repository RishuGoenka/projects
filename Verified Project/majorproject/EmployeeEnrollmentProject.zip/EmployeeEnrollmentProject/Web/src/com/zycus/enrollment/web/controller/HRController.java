package com.zycus.enrollment.web.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;







import com.zycus.enrollment.common.bo.DepartMent;
import com.zycus.enrollment.common.bo.Designation;
import com.zycus.enrollment.common.bo.Employee;
import com.zycus.enrollment.common.bo.User;
import com.zycus.enrollment.dao.impl.BaseDao;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.intf.IDepartmentServices;
import com.zycus.enrollment.service.intf.IDesignationServices;
import com.zycus.enrollment.service.intf.IEmployeeServices;
import com.zycus.enrollment.service.intf.IPMOService;
import com.zycus.enrollment.service.intf.IUserServices;



@Controller
@SessionAttributes({"designation","DepartmentOfUser","User","Login error"})
public class HRController {

	private Logger logger=Logger.getLogger(HRController.class.getName());
	@Autowired
	private BaseDao baseDao;
	@Autowired
	private IDepartmentServices iDepartmentServices;
	@Autowired
	private IEmployeeServices iEmployeeServices;

	@Autowired
	private IUserServices iUserServices;
	@Autowired
	private IDesignationServices iDesignationServices;
	@Autowired
	private IPMOService ipmoService;

	@RequestMapping(value="CheckCredentials.do")

	public String getAllDepartMent(@RequestParam(value="username")String name, @RequestParam(value="password")String password,Map<String,Object> model,HttpServletRequest request)
	{

		model.put("Login error", "valid");
		if (iUserServices.ifUserExist(name, password)) {
			HttpSession session=request.getSession(true);
			User user = null;
			try {
				user = iUserServices.getUserAuthenticated(name, password);
			} catch (ServiceLayerException e) {
				logger.error(e);
				logger.error(e.fillInStackTrace());
			}
			DepartMent departMent = user.getDesignation().getDepartMent();


			model.put("DepartmentOfUser", departMent);
			model.put("User", user);
			String target = null;
			if (user.getDesignation().getDepartMent().getDepartmentName()
					.equalsIgnoreCase("HR")) {
				if (user.getDesignation().getDesignationName()
						.equalsIgnoreCase("Manager")) {
					model.put("designation", "HR");

					try {
						model.put("listOfEmployee",
								iEmployeeServices.getEmployeesSortedByName());
					} catch (ServiceLayerException e) {
						logger.error(e);
						logger.error(e.fillInStackTrace());
					}
					target = "hrhodemployeelist.jsp";
				} else if (user.getDesignation().getDesignationName()
						.equalsIgnoreCase("HOD")) {
					model.put("designation", "HOD");
					List<Employee> employeeList = null;
					try {
						employeeList = iEmployeeServices.getEmployeeByStatus(1);
					} catch (ServiceLayerException e) {
						logger.error(e);
						logger.error(e.fillInStackTrace());
					}
					model.put("listOfEmployee", employeeList);
					target = "HRHODVerfication.jsp";
				}
			} else if (user.getDesignation().getDesignationName()
					.equalsIgnoreCase("PMO")) {

				model.put("designation", "PMO");
				List<Employee> employees = null;
				try {
					employees = iEmployeeServices
							.getALLEmployeeByDepartment(departMent);
				} catch (ServiceLayerException e) {
					logger.error(e);
					logger.error(e.fillInStackTrace());
				}

				model.put("listOfEmployee", employees);
				List<Designation> listDesignation = null;
				try {
					listDesignation = iDepartmentServices
							.getDesignationbyDepartment(departMent);
				} catch (ServiceLayerException e) {
					logger.error(e);
					logger.error(e.fillInStackTrace());
				}
				model.put("listDesignation", listDesignation);
				Designation designation = null;
				try {

					designation = iDesignationServices.getDesignationByName(
							"Manager", departMent);
				} catch (ServiceLayerException e) {
					logger.error(e);
					logger.error(e.fillInStackTrace());
				}
				List<Employee> managers = null;
				try {

					managers = ipmoService.getManagers(designation, departMent);




				} catch (ServiceLayerException e) {
					logger.error(e);
					logger.error(e.fillInStackTrace());
				}

				model.put("listOfManagers", managers);
				target = "pmoemployeelist.jsp";

			} else if (user.getDesignation().getDesignationName()
					.equalsIgnoreCase("HOD")
					&& !(user.getDesignation().getDepartMent()
							.getDepartmentName().equalsIgnoreCase("ITIS"))) {

				model.put("designation", "PMOHOD");
				List<Employee> employees2 = null;
				List<Employee> employees3 = new ArrayList<Employee>();
				try {
					
					employees2 = iEmployeeServices.getALLEmployeeByDepartment(departMent);
				      
					 for(Employee employee:employees2)
					 {
						 
						 if(employee.getStatus()==3)
						 {
							 employees3.add(employee);
						 }
					 }
				} catch (ServiceLayerException e) {
					logger.error(e);
					logger.error(e.fillInStackTrace());
				}
				model.put("listOfEmployee", employees3);
				target = "DepartmerntHodVerification.jsp";
			}

			else if (user.getDesignation().getDepartMent().getDepartmentName()
					.equalsIgnoreCase("ITIS")) {
				if (user.getDesignation().getDesignationName()
						.equalsIgnoreCase("Manager"))

				{
					model.put("designation", "ITIS");
					List<Employee> employees = null;
					try {
						employees = iEmployeeServices
								.getEmployeeByStatus(4);
					} catch (ServiceLayerException e) {
						logger.error(e);
						logger.error(e.fillInStackTrace());
					}
					model.put("listOfEmployee", employees);
					target = "itisemployeelist.jsp";

				} else if (user.getDesignation().getDesignationName()
						.equalsIgnoreCase("HOD")) {
					model.put("designation", "ITISHOD");
					List<Employee> employees1 = null;
					try {
						employees1 = iEmployeeServices.getEmployeeByStatus(5);
					} catch (ServiceLayerException e) {
						logger.error(e);
						logger.error(e.fillInStackTrace());
					}
					model.put("listOfEmployee", employees1);
					target = "itisHodverification.jsp";

				}
			}
			return target;
		}else {
			model.put("Login error", "invalid");
			return "index.jsp";

		}


	}


	@InitBinder
	private void dateBinder(WebDataBinder binder) 
	{

		SimpleDateFormat dateFormat = new SimpleDateFormat("yy-MM-dd");


		CustomDateEditor editor = new CustomDateEditor(dateFormat, false);


		binder.registerCustomEditor(Date.class, editor);
	}
	@RequestMapping(value="SubmitStep1details.do")
	public String submitStep1details(@RequestParam(value="name")String name,@RequestParam("date") Date date,@RequestParam(value="address")String address,@RequestParam(value="Department")int departmentId,@RequestParam(value="contact")String contact,Map<String,Object> model)
	{

		Employee employee=new Employee();
		employee.setEmployeeName(name);
		employee.setAddress(address);
		DepartMent department = null;
		try {
			department = iDepartmentServices.getDepartMentById(departmentId);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		employee.setDepartment(department);
		employee.setContactNumber(Long.parseLong(contact));
		employee.setStatus(1);
		employee.setDateOfJoining(date);
		try {
			iEmployeeServices.addEmployee(employee);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		try {
			model.put("listOfEmployee", iEmployeeServices.getEmployeesSortedByName());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}



		return "hrhodemployeelist.jsp";
	}
	@RequestMapping(value="Approve.do")
	public String submitStep1details(@RequestParam(value="employeeId")String employeeId,Map<String,Object> model)
	{
		int empId=Integer.parseInt(employeeId);
		Employee employee = null;
		try {
			employee = iEmployeeServices.getEmployeeDetailsById(empId);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		model.put("getEmployeeStep1Details", employee);
		return "hodverfiy1.jsp";
	}


	@RequestMapping(value="ApprovalByHODOfHR.do")
	public String approvEmployee(@RequestParam(value="employeeId")String employeeId,Map<String,Object> model)
	{
		int empId=Integer.parseInt(employeeId);
		Employee employee = null;
		try {
			employee = iEmployeeServices.getEmployeeDetailsById(empId);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		Calendar cal= Calendar.getInstance();
		Date date=new Date(cal.getTimeInMillis());
		employee.setApprovedByHRDept(date);
		employee.setStatus(2);
		try {
			iEmployeeServices.addEmployee(employee);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		model.put("getEmployeeStep1Details", employee);
		return "index.jsp";
	}


	@RequestMapping(value="addNewEmployee.do")
	public String addNewEmployee(Map<String,Object> model)
	{
		List<DepartMent> list = null;
		try {
			list = iDepartmentServices.getAllDepartMents();
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		model.put("listOfDepartMent",list);
		return "form1.jsp";

	}

	@RequestMapping(value="gotoHome.do")
	public String gotoHome(Map<String,Object> model)
	{

		try {
			model.put("listOfEmployee", iEmployeeServices.getEmployeesSortedByName());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		return"hrhodemployeelist.jsp";

	}
	@RequestMapping(value="Logout.do")
	public String gotoLogin(Map<String,Object> model,HttpServletRequest request)
	{
		HttpSession session=request.getSession(false);
		session.invalidate();
		model.clear();
		return"redirect:index.jsp";

	}
	@RequestMapping(value="SortByName.do")
	public String sortEmployeeByName(Map<String,Object> model)
	{

		try {
			model.put("listOfEmployee", iEmployeeServices.getEmployeesSortedByName());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		return"hrhodemployeelist.jsp";

	}
	@RequestMapping(value="SortByDate.do")
	public String sortEmployeeByDate(Map<String,Object> model)
	{

		try {
			model.put("listOfEmployee", iEmployeeServices.getEmployeeSortedByDOJ());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		return"hrhodemployeelist.jsp";

	}
}
