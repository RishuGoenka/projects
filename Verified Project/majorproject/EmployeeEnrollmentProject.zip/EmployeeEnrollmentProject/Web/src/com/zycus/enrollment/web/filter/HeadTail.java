package filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.zycus.pojos.User;


public class HeadTail implements Filter{

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
				
		HttpServletRequest request=(HttpServletRequest)arg0;		
		StringBuilder stringBuilder=new StringBuilder(request.getRequestURI());
		HttpSession session=request.getSession(false);
		
		HttpServletResponse response=(HttpServletResponse)arg1;
		
		
	    if((stringBuilder.substring(25, stringBuilder.length())).equalsIgnoreCase("CheckCredentials.do"))
	    {
	    	
	    	arg2.doFilter(arg0, arg1);
	    	
	    }
	    else
	    {
	    	
	    	
	    	
	    	if(session==null || session.getAttribute("User")==null )
			{
				
				response.sendRedirect("index.jsp");
				return;
				
			}
			else{
				
			
			arg2.doFilter(arg0, arg1);
			
			
			}
		
	    	
	    }
		
		
		
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}

	

}
