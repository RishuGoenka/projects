package com.zycus.enrollment.web.filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class FilterXml implements Filter {

  
	@SuppressWarnings("unchecked")
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		
		chain.doFilter(request  , response);
		PrintWriter out = response.getWriter();
		response.setContentType("text/xml");
		out.print("<names>");
		ArrayList<String> list = (ArrayList<String>)request.getAttribute("list");
		for(String str:list){
			out.print("<name>"+str+"</name>");
		}
		out.print("</names>");
				response.flushBuffer();
	}


	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

}
