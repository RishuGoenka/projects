package com.zycus.enrollment.web.controller;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.enrollment.common.bo.Alais;
import com.zycus.enrollment.common.bo.AlaisBundle;
import com.zycus.enrollment.common.bo.Employee;
import com.zycus.enrollment.common.bo.Software;
import com.zycus.enrollment.common.bo.SoftwareBundle;
import com.zycus.enrollment.service.exception.ServiceLayerException;
import com.zycus.enrollment.service.impl.AlaisAndBundleServices;
import com.zycus.enrollment.service.impl.AlaisServices;
import com.zycus.enrollment.service.impl.SoftwareBundleServices;
import com.zycus.enrollment.service.impl.SoftwareServices;
import com.zycus.enrollment.service.intf.IEmployeeServices;

@Controller
@SessionAttributes("Employee")
public class ITISController {
	
	@Autowired
	private IEmployeeServices iEmployeeServices;
	
	private Logger logger=Logger.getLogger(this.getClass().getName());
	
	@Autowired
	private SoftwareServices iSoftwareServices;
	
	@Autowired
	private SoftwareBundleServices iSoftwareBundleServices;
	@Autowired
	private AlaisAndBundleServices iAlaisBundleServices;
	
	@Autowired
	private AlaisServices iAlaisServices;
	@RequestMapping(value="AddITISData.do")
	public String addEmployeeDataByITIS(@RequestParam(value="employeeId")String employeeId,
			@RequestParam(value="machinenos")String machineNumber,Map<String,Object> model)
	{
		Employee employee = null;
		try {
			employee = iEmployeeServices.getEmployeeDetailsById(Integer.parseInt(employeeId));
		} catch (NumberFormatException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		employee.setMachineNumber(machineNumber);
		employee.setStatus(5);
		try {
			iEmployeeServices.addEmployee(employee);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		return "index.jsp";
		
	}
	@RequestMapping(value="ApproveByITISHOD.do")
	public String updateEmloyeeDetailsByHOD(@RequestParam(value="employeeId")String employeeId,Map<String,Object> model)
	{
		Employee employee=null;
		try {
			
			employee = iEmployeeServices.getEmployeeDetailsById(Integer.parseInt(employeeId));
		
		} catch (NumberFormatException e1) {
			
		} catch (ServiceLayerException e1) {
			
			
		}
		Calendar cal=Calendar.getInstance();
		Date date=new Date(cal.getTimeInMillis());
		employee.setApprovedByITISDept(date);
		employee.setStatus(6);
		try {
			iEmployeeServices.addEmployee(employee);
			
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		return "index.jsp";
	}
	@RequestMapping(value="allBundle.do")
	public String getSoftwareBundle(Map<String,Object> model)
	{
		List<SoftwareBundle> listOfBundle = null;
		try {
			listOfBundle = iSoftwareBundleServices.getAllSoftwareBundle();
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		model.put("listOfBundle",listOfBundle);
		return "softwarelist.jsp";
	}
	@SuppressWarnings("unused")
	@RequestMapping(value="getSoftwares.do")
	public @ResponseBody List<Software> getSoftwares(@RequestParam(value="Bundleid")String bundleId,Map<String,Object> model,HttpServletResponse response)
	{
		int bndlId=Integer.parseInt(bundleId);

		SoftwareBundle softwareBundle = null;
		try {
			softwareBundle = iSoftwareBundleServices.getSoftBundleById(bndlId);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		
		List<Software> listofSoftware = null;
		try {
			listofSoftware = iSoftwareBundleServices.getSoftwareBySoftwareBundle(softwareBundle);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		

		model.put("listofSoftware", listofSoftware);
		return listofSoftware;
	}
	@RequestMapping(value="allAlais.do")
	public String getAlaisBundle(Map<String,Object> model)
	{
		List<AlaisBundle> listOfAlaisBundle = null;
		try {
			listOfAlaisBundle = iAlaisBundleServices.getAllAlaisBundle();
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		model.put("listOfAlaisBundle",listOfAlaisBundle);
		return "softwarelist.jsp";
	}
	@RequestMapping(value="getAlais.do")
	public String getAlais(@RequestParam(value="Bundleid")String bundleId,Map<String,Object> model,HttpServletResponse response)
	{
		int bndlId=Integer.parseInt(bundleId);

		AlaisBundle alaisBundle = null;
		try {
			alaisBundle = iAlaisBundleServices.getAlaisBundleByID(bndlId);
		} catch (ServiceLayerException e1) {
			logger.error(e1);
			logger.error(e1.fillInStackTrace());
		}
		
		List<Alais> listofAlais = null;
		try {
			listofAlais = iAlaisBundleServices.getAliasByAliasBundle(alaisBundle);
		} catch (ServiceLayerException e1) {
			logger.error(e1);
			logger.error(e1.fillInStackTrace());
		}
		String str="<table align='center' border='5'> <tr> <th>Alais ID</th><th> NAME</th></tr>";
		for(Alais s:listofAlais){
			str+="<tr> <td>"+ s.getAlaisId() +"</td> <td>"+s.getAlaisName()+"</td> </tr>";

		}
		str+="</table>";
		try {
			response.getWriter().write(str);
		} catch (IOException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
		model.put("listofAlais", listofAlais);
		return str;
	}
	@RequestMapping(value="addSoftware.do")
	public void addsoftware(@RequestParam(value="sname")String sName,@RequestParam(value="Sdesc")String desc){
		Software software=new Software();
		software.setSoftwareName(sName);
		software.setSoftwareDescription(desc);
		try {
			iSoftwareServices.addSoftware(software);
		} catch (ServiceLayerException e) {
			logger.error(e);
			logger.error(e.fillInStackTrace());
		}
	}

	@RequestMapping(value="addAlais.do")
	public void addAlais(@RequestParam(value="alname")String aname,@RequestParam(value="adesc")String adesc){
		Alais alais=new Alais();
		alais.setAlaisName(aname);
		iAlaisServices.addAlais(alais);
	}
	
	@RequestMapping(value="CreateSoftware.do")
	public String gotoCreateSoftwarePage()
	{

		return "AddAlais.jsp";
	}

	

}
