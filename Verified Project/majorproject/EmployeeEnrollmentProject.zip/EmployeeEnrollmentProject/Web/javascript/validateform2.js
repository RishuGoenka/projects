function validateManager()
{
	var letter =/^[A-Za-z ]+$/;
	var string = document.getElementById("manager").value;
	if(string == "")
	{
		document.getElementById("validateMsg").innerHTML="Manager should not be empty";
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			document.getElementById("validateMsg").innerHTML="Invalid Name";
			document.getElementById("manager").className = "error";
			return false;
		}
		else
		{
			document.getElementById("validateMsg").innerHTML="";
			document.getElementById("manager").className = "valid";
			return true;
		}
	}
}



function validateGrade()
{
	var letter =/^[A-Za-z0-9 ]+$/;
	var string = document.getElementById("grade").value;
	if(string == "")
	{
		document.getElementById("validateMsg").innerHTML="Grade should not be empty";
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			document.getElementById("validateMsg").innerHTML="Invalid Name";
			document.getElementById("grade").className = "error";
			return false;
		}
		else
		{
			document.getElementById("validateMsg").innerHTML="";
			document.getElementById("grade").className = "valid";
			return true;
		}
	}
}


function validateDesignation()
{
	var letter =/^[A-Za-z ]+$/;
	var string = document.getElementById("designation").value;
	if(string == "")
	{
		document.getElementById("validateMsg").innerHTML="Designstion should not be empty";
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			document.getElementById("validateMsg").innerHTML="Invalid Name";
			document.getElementById("designation").className = "error";
			return false;
		}
		else
		{
			document.getElementById("validateMsg").innerHTML="";
			document.getElementById("designation").className = "valid";
			return true;
		}
	}
}


function validateSeat()
{
	var letter =/^[A-Za-z0-9 ]+$/;
	var string = document.getElementById("seat").value;
	if(string == "")
	{
		document.getElementById("validateMsg").innerHTML="Seat Number should not be empty";
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			document.getElementById("validateMsg").innerHTML="Invalid Name";
			document.getElementById("seat").className = "error";
			return false;
		}
		else
		{
			document.getElementById("validateMsg").innerHTML="";
			document.getElementById("seat").className = "valid";
			return true;
		}
	}
}




function validateForm(form)
{
	if( validateSeat() && validateDesignation() && validateGrade() && validateManager() )
		return true;
	else
		return false;
}

