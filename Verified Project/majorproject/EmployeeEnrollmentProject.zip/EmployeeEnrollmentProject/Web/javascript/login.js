function validateName()
{
	var letter =/^[A-Za-z.]+$/;
	var string = document.getElementById("username").value;
	if(string == "")
	{
		alert("User Name should not be empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid User Name");
			
			return false;
		}
		else
		{
			
			return true;
		}
	}
	
}


function validatePassword()
{
	var letter =/^[A-Za-z0-9.@]+$/;
	var string = document.getElementById("password").value;
	if(string == "")
	{
		alert("Password should not be empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid Password");
			
			return false;
		}
		else
		{
			
			return true;
		}
	}
	
}



function validateForm()
{
	if( validateName() && validatePassword())
		return true;
	else
		
		return false;
}

