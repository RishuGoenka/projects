function validateName()
{
	var letter =/^[A-Za-z ]+$/;
	var string = document.getElementById("softwareAlaisName").value;
	if(string == "")
	{
		alert("Alais Bundle Name can never be Empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid Alais Bundle Name");
			
			return false;
		}
		else
		{
			
			return true;
		}
	}
	
}


function checkCheckBoxes() {

    
    var checkboxs=document.getElementsByName("alais");
    var okay=false;
    for(var i=0,l=checkboxs.length;i<l;i++)
    {
        if(checkboxs[i].checked)
        {
            okay=true;
        }
    }
    if(okay){
    	
    	return true;
    }
    else {
    	alert("Please check a checkbox");
    	return false;
    }
   
}



function validateAlaisForm()
{
	if( checkCheckBoxes()&& validateName())
		return true;
	else

		return false;
}
