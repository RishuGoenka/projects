function validateName()
{
	var letter =/^[A-Za-z ]+$/;
	var string = document.getElementById("name").value;
	if(string == "")
	{
		alert("Name should not be empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid Name");
			
			return false;
		}
		else
		{
			
			return true;
		}
	}
	
}

function validateNumber()
{
	var number =/^[0-9]+$/; 
	var num = document.getElementById("contact").value;
	if(num=="")
	{
		alert("Contact Number should not be empty");
		return false;
	}
	else
	{
		if(!number.test(num))
		{
			alert("Invalid Contact Number");
			 return false;
		}
		else
		{
			
			return true;
		}
	}
}

function validateAddress()
{
	var letter =/^[A-Za-z0-9 ]+$/;
	var string = document.getElementById("address").value;
	if(string == "")
	{
		alert("Address should not be empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid Address");
			return false;
		}
		else
		{
			
			return true;
		}
	}
}


function validateDate()
{
	
	var num = document.getElementById("datepicker").value;
	if(num=="")
	{
		alert("Date should not be empty");
		return false;
	}
	
		else
	   return true;
		
	
}







function validateForm()
{
	if( validateName() &&validateAddress()&&validateDate() && validateNumber())
		return true;
	else
		
		return false;
}

