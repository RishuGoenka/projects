function validateMachine()
{
	var letter =/^[A-Za-z0-9 ]+$/;
	var string = document.getElementById("machinenos").value;
	if(string == "")
	{
		document.getElementById("validateMsg").innerHTML="Machine Number should not be empty";
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			document.getElementById("validateMsg").innerHTML="Invalid Name";
			document.getElementById("machinenos").className = "error";
			return false;
		}
		else
		{
			document.getElementById("validateMsg").innerHTML="";
			document.getElementById("machinenos").className = "valid";
			return true;
		}
	}
}


function validateForm(form)
{
	if( validateMachine() )
		return true;
	else
		return false;
}
