 function validateSoftwareBundle()
{
	
	var letter =/^[A-Za-z ]+$/;
	var string = document.getElementById("softwareBundleName").value;
	if(string == "")
	{
		alert("Software Bundle Name can never be Empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid Software Bundle Name");

			return false;
		}
		else
		{

			return true;
		}
	}

}


function checkCheckBoxes() {
  

    var checkboxs=document.getElementsByName("isoftware");

    var okay=false;
    for(var i=0,l=checkboxs.length;i<l;i++)
    {
        if(checkboxs[i].checked)
        {
            okay=true;
        }
    }
    if(okay){

    	return true;
    }
    else {
    	alert("Please check a checkbox");
    	return false;
    }

}

function validateSoftwareForm()
{
	
	if(checkCheckBoxes() && validateSoftwareBundle())
		return true;
	else

		return false;
}


