function validateMachine()
{
	var letter =/^[A-Za-z0-9 ]+$/;
	var string = document.getElementById("machinenos").value;
	if(string == "")
	{
		alert("Machine should not be empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid Machine");
			return false;
		}
		else
		{
			
			return true;
		}
	}
}


function validateForm(form)
{
	if( validateMachine() )
		return true;
	else
		return false;
}
