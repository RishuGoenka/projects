function validateManager()
{
	var letter =/^[A-Za-z ]+$/;
	var string = document.getElementById("manager").value;
	if(string == "")
	{
		alert("Manager should not be empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid Manager");
			return false;
		}
		else
		{
			
			return true;
		}
	}
}



function validateGrade()
{
	var letter =/^[A-Za-z0-9 ]+$/;
	var string = document.getElementById("grade").value;
	if(string == "")
	{
		alert("Grade should not be empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid Grade");
			return false;
		}
		else
		{
			
			return true;
		}
	}
}


function validateDesignation()
{
	var letter =/^[A-Za-z ]+$/;
	var string = document.getElementById("designation").value;
	if(string == "")
	{
		alert("Designation should not be empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid Designation");
			return false;
		}
		else
		{
			
			return true;
		}
	}
}


function validateSeat()
{
	var letter =/^[A-Za-z0-9 ]+$/;
	var string = document.getElementById("seat").value;
	if(string == "")
	{
		alert("Seat should not be empty");
		return false;
	}
	else
	{
		if(!letter.test(string))
		{
			alert("Invalid Seat");
			return false;
		}
		else
		{
			
			return true;
		}
	}
}




function validateForm(form)
{
	if( validateSeat() && validateDesignation() && validateGrade() && validateManager() )
		return true;
	else
		return false;
}

