
	function validate(form){
		
 				var errors = [];
 
 				if ( !checkRadio(form.cardType) ) {
  					errors[errors.length] = "You must choose master card or visa";
 				}
 				if(!checkCardNo(form.cardNo.value)){
 					errors[errors.length]="Please Enter Card No of Length 12-16 digits .";
 					
 				}
 				if(!checkCVC(form.cvc.value)){
 					errors[errors.length]="Please Enter CVC of 4 Digits ."; 					
 				}
 				if(!checkExpirationDate(form.expirationDate.value)){
 					errors[errors.length]="Please Enter Valid Expiration Date (MM/YYYY)."; 					
 				}
 				if (errors.length > 0) {
 					alert(errors.length);
 					reportErrors(errors);
  					return false;
 				}
 
 				return true;
	}

			function checkRadio(radioButtons){
				
 				for (var i=0; i < radioButtons.length; i++) {
  					if (radioButtons[i].checked) {
   						return true;
  					}
 				}
 				return false;
			}

			function reportErrors(errors){
				var error="";
				document.getElementById("errors").innerHTML=error;
				for(var index=0;index<errors.length;index++){
					error+="<li>"+errors[index]+"</li>";
				}
				document.getElementById("errors").innerHTML=error;
			}
			
			function checkCardNo(cardNo){
				var card = /^\d{12,16}$/;  
				if(!cardNo.match(card) ){
					return false;
				}
				return true;
			}
			function checkCVC(cvc){
				var expDate = /^\d{3}$/;  
				if(!cvc.match(expDate) ){
					return false;
				}
				return true;
			}
			
			function checkExpirationDate(date){
				var expDate = /^(0[1-9]|1[0-2])\/[0-9]{4}$/;  
				if(!date.match(expDate) ){
					return false;
				}
				return true;
			}