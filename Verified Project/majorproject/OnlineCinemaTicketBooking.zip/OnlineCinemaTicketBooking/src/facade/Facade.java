package facade;

import java.util.List;

import org.apache.log4j.Logger;

import pojos.Cart;
import pojos.Ticket;
import pojos.User;
import dao.UserDAO;
import exceptions.FacadeException;
import exceptions.GetObjectException;
import exceptions.SaveOrUpdateException;
import exceptions.UserDAOException;
import factory.InstanceFactory;

public class Facade {

	Logger logger=Logger.getLogger(Facade.class);
	
	private UserDAO userDAO;
	public Facade(InstanceFactory instanceFactory) {
		super();
		userDAO=(UserDAO) instanceFactory.getResource("userDAO");		
	}
	
	//create cart and return it
	public Cart createCart(long userId){
		Cart cart=new Cart(userId);
		return cart;
	}
	
	//add item on cart given by ItemOnCart
	public void addToCart(Cart cart,Ticket ticket){
		cart.addItem(ticket);		
	}
	
	
	//remove item from cart
	public void removeItem(Cart cart,Ticket ticket){
		List<Ticket> tickets =cart.getTickets();
		for(int index=0;index<tickets.size();index++){
			if(tickets.get(index).getSeat().getSeatId()==ticket.getSeat().getSeatId() && tickets.get(index).getShow().getShowId()==ticket.getShow().getShowId()){
				cart.removeItem(tickets.get(index));
			}
		}
	}
	
	/*//get all Shows from the database and return as a list
	public List<String> getAllDistinctShows(Connection connection){
		  
		try {
			return showDAO.getDistinctShows(connection);
		} catch (ContactAdminException e) {
			e.printStackTrace();
		}
		return null;
		
	}*/
	
	
	
	//insert new user into database
	
	public void addUser(String userName,String addressLine1,String addressLine2,String city,String state,String country,int pinCode,String email,String password) throws SaveOrUpdateException{
		
		logger.info("Inside method addUser in class Facade");
			try {
				userDAO.addUser(userName,addressLine1,addressLine2,city,state,country,pinCode,email,password);
			} catch (UserDAOException e) {
				logger.error(e.fillInStackTrace());
				throw new SaveOrUpdateException("Error in method addUser in class Facade "+e);
			} 
		
	}
	
	//autheticate the user on the basis of userId and password
	
	public boolean getUserAuthenticated(long userId,String password) throws FacadeException{
		logger.info("Inside method getUserAuthenticated ");
		User user = null;
		try {
			user = userDAO.getObject(User.class, userId);
		} catch (GetObjectException e) {
			logger.error(e);
			throw new FacadeException("Error in method getUserAuthenticated in class Facade"+e );
		}
		if(user!=null){
			if(user.getPassword().equalsIgnoreCase(password)){
				return true;
			}
			else
				return false;
		}
		return false;
	}
	
	//finalize the order by calling the method on transactionDao
	
	/*public int checkOutUser(Cart cart,Connection connection){
		try {
			transactionDAO.finalizeOrder(cart,connection);
			return transactionDAO.getMaxKey(connection);
		} catch (ContactAdminException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	//get user on userId
	
	public User getUser(int userId,Connection connection){
		try {
			return userDAO.getUser(userId,connection);
		} catch (ContactAdminException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	//gt the list of bookings for particular showid
	public List<Booking> getBookings(int showId ,Connection connection){
		
		try {
			return bookingDAO.getBookings(showId, connection);
		} catch (ContactAdminException e) {
			e.printStackTrace();
		}
		return null;
	}
	// get All shows by show name
	public List<Show> getShowsByShowName(String showName,Connection connection){
		showName=showName.toUpperCase();
		try {
			return showDAO.getShowsByMovieName(showName, connection);
		} catch (ContactAdminException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	//get show by the show id
	public Show getShowById(int showId,Connection connection){
		
		try {
			return showDAO.getShow(showId, connection);
		} catch (ContactAdminException e) {
			e.printStackTrace();
		}
		return null;
		
	}

*/
}