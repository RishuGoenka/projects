package factory;

import java.util.HashMap;




import dao.MovieDAO;
import dao.ShowDAO;
import dao.UserDAO;
import facade.Facade;

public class InstanceFactory {

	private HashMap<String , Object> instances;

	
	public InstanceFactory() {
		instances=new HashMap<String, Object>();
		instances.put("userDAO", new UserDAO());
		instances.put("movieDAO", new MovieDAO());
		instances.put("showDAO", new ShowDAO());
		instances.put("facade", new Facade(this));
			
	}
	
	public Object getResource(String key){
		return instances.get(key);
	}
	
	
	
}
