package taglib;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import pojos.Cart;
import pojos.Ticket;

public class DisplayCart extends TagSupport {

	private static final long serialVersionUID = 1L;

	public int doStartTag() throws JspException {
		HttpSession session=this.pageContext.getSession();
		Cart cart=(Cart) session.getAttribute("cart");
		JspWriter out=this.pageContext.getOut();
		List <Ticket> tickets=cart.getTickets();
		DateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		DateFormat sdf1=new SimpleDateFormat("HH:mm");
		String showDate;
		String showTime;
		try {
			out.print("<table>");
			out.print("<tr><center><h4>Your Cart</h4></center></tr>");
			out.print("<tr><center><h4>User Id: "+cart.getUserId()+"</h4></center></tr>");
			out.print("<tr><th>Show Name</th><th>Date</th><th>Time</th><th>Screen</th><th>Class</th><th>Seat No</th><th>Price</th>");
			out.print("</tr>");
			for(Ticket ticket : tickets){
				showDate=sdf.format( ticket.getTime());
				showTime=sdf1.format( ticket.getTime());
				out.print("<tr>");
				out.print("<td>"+ ticket.getShowName() +"</td>");
				out.print("<td>"+ showDate+"</td>");
				out.print("<td>"+ showTime+"</td>");
				out.print("<td>"+ ticket.getScreen() +"</td>");
				out.print("<td>"+ ticket.getClasss() +"</td>");
				out.print("<td>"+ ticket.getSeatNo() +"</td>");
				out.print("<td>"+ ticket.getPrice() +"</td>");
				out.print("<td><button class='remove'id='"+ticket.getSeatNo()+"' showId='"+ticket.getShowID()+"'>Remove</button></td>");
				
			}
			out.print("<tr><td colspan='5'>Amount:"+cart.getAmount()+"</td></tr>");
			out.print("<tr><td colspan='5'><form action='/SahilCinemaTicketBooking/CheckOut.do'><input type='submit' value='CheckOut'></form> </td></tr>");
			out.print("</table>");
		} catch (IOException e) {
			e.printStackTrace();
		}	
		return SKIP_BODY;
	}
}
