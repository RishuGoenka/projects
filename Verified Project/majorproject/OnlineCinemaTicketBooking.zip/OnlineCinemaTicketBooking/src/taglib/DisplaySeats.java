package taglib;

import java.io.IOException;

import java.sql.Connection;
import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import facade.Facade;

import pojos.Booking;



public class DisplaySeats extends TagSupport {

	private static final long serialVersionUID = 1L;

	public int doStartTag() throws JspException {
		HttpSession session=this.pageContext.getSession();
		JspWriter out=this.pageContext.getOut();
		HttpServletRequest request=(HttpServletRequest) this.pageContext.getRequest();
		System.out.println("show id :"+request.getParameter("showId"));
		int showId=Integer.parseInt(request.getParameter("showId"));
		Facade facade=(Facade) session.getAttribute("facade");
		Connection connection=(Connection) session.getAttribute("connection");
		List <Booking> bookings=facade.getBookings(showId, connection);
		System.out.println("bookings size : "+bookings.size());
		//for platinum
		try {
			out.print("<div id='platinum'>");
			out.print("<h4>Platinum</h4>");
			outer: for(int index=100;index>70;index--){
						for(Booking booking :bookings){
							if(booking.getSeatNo()==index){
									out.print("<button class='booked' id='"+index+"'>"+index+"</button>");
									if(index==91 ||index==81){
										out.print("<br>");
									}
									continue outer;
							}
							
						}
						out.print("<button class='platinum' id='"+index+"'>"+index+"</button>");
						
						if(index==91 ||index==81){
							out.print("<br>");
						}			
			}
			out.print("</div>");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		//for gold
		try {
			out.print("<div id='gold'>");
			out.print("<h4>Gold</h4>");
			outer: for(int index=70;index>30;index--){
						for(Booking booking :bookings){
							if(booking.getSeatNo()==index){
									out.print("<button class='booked' id='"+index+"'>"+index+"</button>");
									continue outer;
							}
							
						}
						out.print("<button class='gold' id='"+index+"'>"+index+"</button>");
						
						if(index==61 ||index==51 ||index==41){
							out.print("<br>");
						}			
			}
			out.print("</div>");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		//for silver
		try {
			out.print("<div id='silver'>");
			out.print("<h4>Silver</h4>");
			outer: for(int index=30;index>0;index--){
						for(Booking booking :bookings){
							if(booking.getSeatNo()==index){
									out.print("<button class='booked' id='"+index+"'>"+index+"</button>");
									continue outer;
							}
							
						}
						out.print("<button class='silver' id='"+index+"'>"+index+"</button>");
						
						if(index==21 ||index==11){
							out.print("<br>");
						}			
			}
			out.print("</div>");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		
		return SKIP_BODY;
	}
}
