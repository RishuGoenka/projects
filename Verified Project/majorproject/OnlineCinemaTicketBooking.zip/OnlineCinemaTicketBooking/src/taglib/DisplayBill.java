package taglib;

import java.io.IOException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import pojos.Cart;
import pojos.Ticket;


public class DisplayBill extends TagSupport {

	private static final long serialVersionUID = 1L;

	public int doStartTag() throws JspException {
		HttpSession session=this.pageContext.getSession();
		Cart cart=(Cart) session.getAttribute("cart");
		JspWriter out=this.pageContext.getOut();
		String billId=(String) this.pageContext.getRequest().getAttribute("billId");
		List <Ticket> tickets=cart.getTickets();
		DateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		String date=sdf.format(new Date());
		DateFormat sdf1=new SimpleDateFormat("HH:mm");
		String showDate;
		String showTime;
		try {
			out.print("<table>");
			out.print("<tr><center><h4>User Id: "+cart.getUserId()+" Bill No : "+billId+" Date : "+date+"</h4></center></tr>");
			out.print("<tr><th>Show Name</th><th>Date</th><th>Time</th><th>Screen</th><th>Class</th><th>Seat No</th><th>Price</th>");
			out.print("</tr>");
			for(Ticket ticket : tickets){
				showDate=sdf.format( ticket.getTime());
				showTime=sdf1.format( ticket.getTime());
				out.print("<tr>");
				out.print("<td>"+ ticket.getShowName() +"</td>");
				out.print("<td>"+ showDate+"</td>");
				out.print("<td>"+ showTime+"</td>");
				out.print("<td>"+ ticket.getScreen() +"</td>");
				out.print("<td>"+ ticket.getClasss() +"</td>");
				out.print("<td>"+ ticket.getSeatNo() +"</td>");
				out.print("<td>"+ ticket.getPrice() +"</td>");
			}
			out.print("<tr><td colspan='5'>Amount:"+cart.getAmount()+"</td></tr>");
			out.print("</table>");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return SKIP_BODY;
	}
}
