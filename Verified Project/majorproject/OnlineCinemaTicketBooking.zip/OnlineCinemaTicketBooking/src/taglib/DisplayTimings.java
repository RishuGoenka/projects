package taglib;

import java.io.IOException;
import java.sql.Connection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import facade.Facade;

import pojos.Show;

public class DisplayTimings extends TagSupport {

	private static final long serialVersionUID = 1L;

	public int doStartTag() throws JspException {
		HttpSession session=this.pageContext.getSession();
		JspWriter out=this.pageContext.getOut();
		HttpServletRequest request=(HttpServletRequest) this.pageContext.getRequest();
		String showName=request.getParameter("showName");
		Facade facade=(Facade) session.getAttribute("facade");
		Connection connection=(Connection) session.getAttribute("connection");
		List <Show> shows=facade.getShowsByShowName(showName, connection);
		try {
			out.print("<table border='3px'>");
			out.print("<tr><th rowspan='2'>Date</th><th rowspan='2'>Time</th><th colspan='3'>Price</th>");
			out.print("</tr>");
			out.print("<tr>");
			out.print("<th>Platinum</th>");
			out.print("<th>Gold</th>");
			out.print("<th>Silver</th>");
			out.print("</tr>");
			DateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
			DateFormat sdf1=new SimpleDateFormat("HH:mm");
			String date;
			String time;
			for(Show show : shows){
				date=sdf.format(show.getShowTime());
				time=sdf1.format(show.getShowTime());
				out.print("<tr>");
				out.print("<td class='timming'id='"+show.getShowId()+"'>"+ date+"</td>");
				out.print("<td class='timming'>"+ time+"</td>");
				out.print("<td>"+show.getPricePlatinum()+"</td>");
				out.print("<td>"+show.getPriceGold()+"</td>");
				out.print("<td>"+show.getPriceSilver()+"</td>");
				out.print("</tr>");
				
			}
		} catch (IOException e) {
			e.printStackTrace();
		}	
		return SKIP_BODY;
	}
}
