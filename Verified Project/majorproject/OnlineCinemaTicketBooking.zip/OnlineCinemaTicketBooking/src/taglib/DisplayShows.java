package taglib;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;



import facade.Facade;

public class DisplayShows extends TagSupport {
	
	private static final long serialVersionUID = 1L;

	public int doStartTag() throws JspException {
		JspWriter out=this.pageContext.getOut();
		HttpSession session=this.pageContext.getSession();
		Facade facade=(Facade)session.getAttribute("facade");
		Connection connection=(Connection) session.getAttribute("connection");
		List<String> shows=facade.getMovies(connection);
		try {
			out.print("<table border='3px'>");
			out.print("<tr>");
			out.print("<th>Currently Showing</th>");
			out.print("</tr>");
			for(String show :shows){
				out.print("<tr>");
				out.print("<td class='shows'>");
				out.print(show);	
				out.print("</td>");
				out.print("</tr>");
			}	
			out.print("</table>");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return SKIP_BODY;
	}	
}
