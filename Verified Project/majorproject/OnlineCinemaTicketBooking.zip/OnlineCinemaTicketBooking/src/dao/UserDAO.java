package dao;

import org.apache.log4j.Logger;

import exceptions.SaveOrUpdateException;
import exceptions.UserDAOException;
import pojos.Address;
import pojos.User;

public class UserDAO extends BaseDAO {
	Logger logger=Logger.getLogger(UserDAO.class);
	
	
	public void addUser(String userName,String addressLine1,String addressLine2,
		String city,String state,String country,int pinCode,String email,String password) throws UserDAOException{
		
		logger.info("Inside method addUser in class UserDAO");
		
		Address address=new Address();
		address.setAddressLine1(addressLine1);
		address.setAddressLine2(addressLine2);
		address.setCity(city);
		address.setCountry(country);
		address.setState(state);
		address.setPincode(pinCode);
		User user=new User();
		user.setAddress(address);
		user.setEmail(email);
		user.setName(userName);
		user.setPassword(password);		
		try {
			saveOrUpdate(user);
		} catch (SaveOrUpdateException e) {
			logger.error(e.fillInStackTrace());
			throw new UserDAOException("Error in adding a new User in Method addUser in UserDAO",e);
			
		}	
	}

}
