package dao;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import exceptions.MovieDAOException;
import factory.HibernateUtil;

import pojos.Movie;

public class MovieDAO extends BaseDAO{


	Logger logger = Logger.getLogger(MovieDAO.class);
	@SuppressWarnings("unchecked")
	public List<Movie> getMovies() throws MovieDAOException{

		logger.info("Inside method getMovies in class MovieDAO");
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session =sessionFactory.getCurrentSession();
		session.beginTransaction();
		Calendar date=Calendar.getInstance();
		date.add(Calendar.DATE, -30);
		Date validDate=new Date(date.getTimeInMillis());
		Query query= session.createQuery("from Movie where releaseDate > :validDate");
		try{
			query.setDate("validDate", validDate);
			session.getTransaction().commit();
			return query.list();
		}
		catch(Exception ex){
			logger.error(ex.fillInStackTrace());
			throw new MovieDAOException("Error in method getMovies in class MovieDAO ",ex);
		}		

	}

}
