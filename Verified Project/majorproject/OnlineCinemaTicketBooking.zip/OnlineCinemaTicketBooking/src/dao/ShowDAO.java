package dao;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import exceptions.GetObjectException;
import exceptions.ShowDAOException;
import factory.HibernateUtil;

import pojos.Movie;
import pojos.Show;
import pojos.Ticket;

public class ShowDAO extends BaseDAO {

	Logger logger=Logger.getLogger(ShowDAO.class);
	
	@SuppressWarnings("unchecked")
	public List<Show> getShowsByMovieID(int movieId) throws GetObjectException, ShowDAOException{

		logger.info("Inside method getShowsByMovieID in class ShowDAO");
		MovieDAO movieDAO=new MovieDAO();

		Movie movie=movieDAO.getObject(Movie.class, movieId);
		
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session =sessionFactory.getCurrentSession();
		session.getTransaction().begin();
		Query query= session.createQuery("from Show where movie = :movie and showDate >= :todaysDate");
		try{
			query.setEntity("movie", movie);
			query.setDate("todaysDate",new Date());
			List<Show> shows=query.list();
			session.getTransaction().commit();
			return shows;
		}
		catch(Exception ex){
			logger.info(ex.fillInStackTrace());
			throw new ShowDAOException("Exception In Method GetShowsByMovieId in ShowDAO",ex);
		}			
	}

	@SuppressWarnings("unchecked")
	public List<Show> getShowsBetweenTwoDates(int movieId,Date startDate,Date endDate) throws GetObjectException, ShowDAOException{
		
		logger.info("Inside method getShowsBetweenTwoDates in class ShowDAO");
		MovieDAO movieDAO=new MovieDAO();

		Movie movie=movieDAO.getObject(Movie.class, movieId);
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session =sessionFactory.getCurrentSession();
		session.getTransaction().begin();
		Query query= session.createQuery("from Show where movie = :movie and showDate >= :startDate and showDate <= :endDate");
		try{
			query.setEntity("movie", movie);
			query.setDate("startDate",startDate);
			query.setDate("endDate",endDate);
			List<Show> shows=query.list();
			session.getTransaction().commit();
			return shows;
		}
		catch(Exception ex){
			logger.error(ex.fillInStackTrace());
			throw new ShowDAOException("Exception In Method GetShowsBetweenTwoDates in ShowDAO",ex);
		}			
	}

	@SuppressWarnings("unchecked")
	public List<Ticket> getBookedTicketsForShow(Long showId) throws ShowDAOException{
		
		logger.info("Inside method getBookedTicketsForShow in class ShowDAO");
					
			SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
			Session session =sessionFactory.getCurrentSession();
			session.getTransaction().begin();
			Query query= session.createQuery("from Show s join fetch s.bookedTickets where s.showId=:showId");

			try {
			query.setLong("showId", showId);
			List<Show> shows=query.list();
			session =sessionFactory.getCurrentSession();
			List<Ticket> tickets=(List<Ticket>) shows.get(0).getBookedTickets();
			System.out.println(session.hashCode());
			session.getTransaction().commit();
			return tickets;
		}
		catch(Exception ex){
			logger.error(ex.fillInStackTrace());
			throw new ShowDAOException("Failed to get the Booked ticket for a show in Method GetBookedTicketsForShow in ShowDao "+ex);
		}
					

	}

}

