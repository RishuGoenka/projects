package dao;
import java.io.Serializable;


import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import exceptions.GetObjectException;
import exceptions.SaveOrUpdateException;
import factory.HibernateUtil;

public class BaseDAO {
	Logger logger=Logger.getLogger(BaseDAO.class);
	
	public void saveOrUpdate(Object obj) throws SaveOrUpdateException{
		
		logger.info("Inside method saveOrUpdate in class BaseDAO"+obj.toString());
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();	
		Session session=sessionFactory.getCurrentSession();
		Transaction tx=session.beginTransaction();
		try{
			session.saveOrUpdate(obj);		
			tx.commit();
		}
		catch(Exception ex){			
			tx.rollback();
			logger.error(ex.fillInStackTrace());
			throw new SaveOrUpdateException("Error in save or update inside BAseDAO class "+ex);
		}
	}


	@SuppressWarnings("unchecked")
	public <E> E getObject(Class<E> classname,Serializable pk) throws GetObjectException{

		logger.info("Inside method getObject in class BaseDAO");
		
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.getCurrentSession();
		Transaction tx=session.beginTransaction();
		E e=(E) session.get(classname,pk);
		try{
			tx.commit();
		}
		catch(Exception ex){
			tx.rollback();
			logger.error(ex.fillInStackTrace());
			throw new GetObjectException("Error in getting object in BAseDAO class "+ex);
		}
		return e;
	}


}
