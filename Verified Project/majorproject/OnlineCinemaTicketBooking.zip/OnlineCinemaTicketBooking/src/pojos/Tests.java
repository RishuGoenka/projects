package pojos;





import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.apache.log4j.Logger;
import org.junit.Test;

import dao.BaseDAO;
import dao.MovieDAO;
import dao.ShowDAO;
import exceptions.GetObjectException;
import exceptions.SaveOrUpdateException;
import exceptions.ShowDAOException;

public class Tests {

	@Test
	public void testUser(){
		BaseDAO dao=new BaseDAO();
		Address add=new Address();
		add.setAddressLine1("north bomba society");
		add.setAddressLine2("juhu tara road");
		add.setCity("mumbai");
		add.setCountry("India");
		add.setState("Maharashtra");
		add.setPincode(400049);
		User user=new User();
		user.setAddress(add);
		user.setEmail("d@g.com");
		user.setName("dhwani");
		user.setPassword("123");
		try {
			dao.saveOrUpdate(user);
		} catch (SaveOrUpdateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void addMovies(){
		BaseDAO dao=new BaseDAO();
		Movie movie=new Movie();
		movie.setName("Chennai Express");
		movie.setDescription("Comedy/Romance");
		movie.setDuration(110);
		movie.setReleaseDate(java.sql.Date.valueOf("2013-8-15"));
		Certificate certificate = null;
		try {
			certificate = dao.get(Certificate.class, 1L);
		} catch (GetObjectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		movie.setCertificate(certificate);
		try {
			dao.saveOrUpdate(movie);
		} catch (SaveOrUpdateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Test
	public void getMovieList(){
		MovieDAO dao=new MovieDAO();
		List<Movie> movies=dao.getMovies();
		for(Movie movie : movies){
			System.out.println(movie.getMovieId()+movie.getName());
		}
	}
	
	@Test 
	public void getShowsOfMovie(){
		ShowDAO dao=new ShowDAO();
		try {
			for(Show show : dao.getShowsByMovieID(1)){
				System.out.println(show);
			}
		} catch (GetObjectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ShowDAOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void addShows() throws ParseException{
		ShowDAO dao=new ShowDAO();
		MovieDAO mdao=new MovieDAO();
		Show show=new Show();
		show.setCapacity(100);
		Movie movie = null;
		try {
			movie = mdao.get(Movie.class, 3);
		} catch (GetObjectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(movie.getMovieId());
		show.setMovie(movie);
		Screen screen = null;
		try {
			screen = dao.get(Screen.class, 1);
		} catch (GetObjectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		show.setScreen(screen);
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		String date="11/12/2013 10:10:00";
		java.util.Date date1=sdf.parse(date);
		show.setShowDate(date1);
		try {
			dao.saveOrUpdate(show);
		} catch (SaveOrUpdateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Test
	public void getShowsByMovieID(){
		ShowDAO dao=new ShowDAO();
		try {
			try {
				for(Show show : dao.getShowsByMovieID(3)){
					System.out.println(show.getShowDate());
				}
			} catch (ShowDAOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (GetObjectException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void getShowsBetweenDate() throws ParseException {
		ShowDAO dao=new ShowDAO();
		String date1="12/07/2013";
		String date2="12/09/2014";
		Logger logger=Logger.getLogger(Test.class);
		logger.debug("test");
		Date startDate=(Date) new SimpleDateFormat("dd/MM/yyyy").parse(date1);
		Date endDate=(Date) new SimpleDateFormat("dd/MM/yyyy").parse(date2);
		try {
			try {
				for(Show show : dao.getShowsBetweenTwoDates(3, startDate, endDate)){
					System.out.println(show.getShowId());
				}
			} catch (ShowDAOException e) {
				logger.error(e);
				e.printStackTrace();
			}
		} catch (GetObjectException e) {
			logger.debug(e.getStackTrace());
			e.printStackTrace();
		}
	}
	@Test
	public void getBookedTickets(){
		ShowDAO dao=new ShowDAO();
		try {
			for(Ticket ticket : dao.getBookedTicketsForShow(4L)){
				System.out.println(ticket.getSeat().getSeatId());
			}
		} catch (ShowDAOException e) {
			e.printStackTrace();
		}
	}
	
	
	
}
