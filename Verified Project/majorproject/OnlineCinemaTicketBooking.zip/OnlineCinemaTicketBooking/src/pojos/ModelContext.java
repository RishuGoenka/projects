package pojos;

import java.util.HashMap;

public class ModelContext {
		
		private HashMap<String ,Object> bundle;
		
		public ModelContext(){
			bundle =new HashMap<String , Object>();
		}
		
		public void setResource(String key , Object value){
			bundle.put(key, value);
		}
			
		public Object getResource(String key){
			return bundle.get(key);
		}
}
