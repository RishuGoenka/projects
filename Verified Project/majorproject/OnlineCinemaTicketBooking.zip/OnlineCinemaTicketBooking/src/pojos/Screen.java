package pojos;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="cinema_screen_1772")
public class Screen {
	
	private int screenId;
	private String screenName;
	private int capacity;
	private Set<Seat> seats=new HashSet<Seat>();
	
	public Screen() {
		super();
	}

	@Id
	@GenericGenerator(name="screen",strategy="increment")
	@GeneratedValue(generator="screen")
	@Column(name="screen_id")
	public int getScreenId() {
		return screenId;
	}

	public void setScreenId(int screenId) {
		this.screenId = screenId;
	}
	
	@Column(name="screen_name")
	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	@ManyToMany(cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	@JoinTable(name="screen_seat_1772",joinColumns={@JoinColumn(name="screen_id")},inverseJoinColumns={@JoinColumn(name="seat_id")})
	public Set<Seat> getSeats() {
		return seats;
	}

	public void setSeats(Set<Seat> seats) {
		this.seats = seats;
	}
	
	
	
	
	
	

}
