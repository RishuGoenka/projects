package pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="cinema_seatType_1772")
public class SeatType {
	
	private int seatTypeId;
	private String type;
	private String description;
	
	public SeatType() {
		super();
	}

	@Id
	@GenericGenerator(name="seatType",strategy="increment")
	@GeneratedValue(generator="seatType")
	@Column(name="seatType_id")
	public int getSeatTypeId() {
		return seatTypeId;
	}

	public void setSeatTypeId(int seatTypeId) {
		this.seatTypeId = seatTypeId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	

}
