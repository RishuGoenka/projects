package pojos;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="cinema_cost_1772")
public class Cost {
	
	private int rate;
	
	private CostKey costKey;
	
	@EmbeddedId
	public CostKey getCostKey() {
		return costKey;
	}

	public void setCostKey(CostKey costKey) {
		this.costKey = costKey;
	}
	
	@Embeddable
	public static class CostKey implements Serializable{
		
		private static final long serialVersionUID = 1L;
		private Screen screen;
		private Show show1;
		
		@ManyToOne(cascade=CascadeType.ALL)
		@JoinColumn(name="show_id",referencedColumnName="show_id")
		public Show getShow1() {
			return show1;
		}
		public void setShow1(Show show) {
			this.show1 = show;
		}
		@ManyToOne
		@JoinColumn(name="screen_id")
		public Screen getScreen() {
			return screen;
		}
		public void setScreen(Screen screen) {
			this.screen = screen;
		}
		
		
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}
	
}
