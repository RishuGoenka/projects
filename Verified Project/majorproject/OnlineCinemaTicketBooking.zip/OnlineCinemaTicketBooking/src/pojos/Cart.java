package pojos;

import java.util.ArrayList;

public class Cart {
	private long userId;
	private ArrayList<Ticket> items;
	private  float amount=0;
	public Cart(long userId2) {
		this.userId = userId2;
		items=new ArrayList<Ticket>();
	}
	public void addItem(Ticket ticket){
		items.add(ticket);
		calculateCartValue();
	}
	public void removeItem(Ticket ticket){
		items.remove(ticket);
		calculateCartValue();
	}
	
	
	
	public void calculateCartValue(){
		Ticket ticket;
		this.amount=0;
		for(int index=0;index<items.size();index++){
			ticket=items.get(index);
			amount+=ticket.getPrice();
		}
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public ArrayList<Ticket> getTickets() {
		return items;
	}
	public void setItems(ArrayList<Ticket> items) {
		this.items = items;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	
	
	
}
