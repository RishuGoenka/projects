package servlets;


import facade.Facade;
import factory.InstanceFactory;
import interfaces.IModel;

import java.io.IOException;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Models.ModelCheckCredentials;

import Models.ModelAddTicket;
import Models.ModelFinalizeOrder;
import Models.ModelLogout;
import Models.ModelRegister;
import Models.ModelRemoveTicket;

import Models.ModelCheckDuplicateUserName;


import pojos.Cart;
import pojos.ModelContext;


public class FrontController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	InstanceFactory instanceFactory;
	private Facade facade;
	
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
	}
	
	
	@Override
	public void init() throws ServletException {
		super.init();
		instanceFactory=new InstanceFactory();
		facade=new Facade(instanceFactory);
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher requestDispatcher=null;
		String command=getCommand(request.getRequestURI());
		ModelContext modelContext=new ModelContext();
		modelContext.setResource("request", request);
		modelContext.setResource("response", response);
		modelContext.setResource("instanceFactory", instanceFactory);
		modelContext.setResource("facade", facade);
		
		
		if(command.equalsIgnoreCase("login")||command.equals("*")){
			requestDispatcher=request.getRequestDispatcher("/login");
			requestDispatcher.forward(request, response);
		}
		if(command.equalsIgnoreCase("CheckCredentials")){
			IModel model=new ModelCheckCredentials();
			String validity=model.modelData(modelContext);
			
			if(validity.equalsIgnoreCase("valid")){
				requestDispatcher=request.getRequestDispatcher("/welcome");
				requestDispatcher.forward(request, response);
			}
			else {
				requestDispatcher=request.getRequestDispatcher("/login");
				requestDispatcher.forward(request, response);
			}
			
		}
		if(command.equalsIgnoreCase("timming")){
			requestDispatcher=request.getRequestDispatcher("/timmings");
			response.setContentType("text/html");
	        response.setHeader("Cache-Control", "no-cache");
	        requestDispatcher.include(request, response);
		}
		if(command.equalsIgnoreCase("seats")){
			System.out.println("in fron controller seats");
			requestDispatcher=request.getRequestDispatcher("/seats");
			response.setContentType("text/html");
	        response.setHeader("Cache-Control", "no-cache");
	        requestDispatcher.include(request, response);
		}
		
		if(command.equalsIgnoreCase("book")){
			IModel model=new ModelAddTicket();
			model.modelData(modelContext);
			requestDispatcher=request.getRequestDispatcher("/cart");
			response.setContentType("text/html");
	        response.setHeader("Cache-Control", "no-cache");
	        requestDispatcher.include(request, response);
		}
		if(command.equalsIgnoreCase("remove")){
			IModel model=new ModelRemoveTicket();
			model.modelData(modelContext);
			requestDispatcher=request.getRequestDispatcher("/cart");
			response.setContentType("text/html");
	        response.setHeader("Cache-Control", "no-cache");
	        requestDispatcher.include(request, response);
		}
		
		if(command.equalsIgnoreCase("CheckOut")){
			requestDispatcher=request.getRequestDispatcher("/checkout");
			requestDispatcher.forward(request, response);
		}
		if(command.equalsIgnoreCase("FinalizeOrder")){
			IModel model=new ModelFinalizeOrder();
			String billId=model.modelData(modelContext);
			request.setAttribute("billId", billId);
			requestDispatcher=request.getRequestDispatcher("/bill");
			requestDispatcher.forward(request, response);
		}
	
		if(command.equalsIgnoreCase("logout")){
			IModel model=new ModelLogout();
			model.modelData(modelContext);
			
			requestDispatcher=request.getRequestDispatcher("/login");
			requestDispatcher.forward(request, response);
		}
		if(command.equalsIgnoreCase("register")){
			
			requestDispatcher=request.getRequestDispatcher("/register");
			requestDispatcher.forward(request, response);
		}
		if(command.equalsIgnoreCase("submit")){
			IModel model=new ModelRegister();
			String registerStatus=model.modelData(modelContext);
			if(registerStatus.equalsIgnoreCase("userAdded")){				
				requestDispatcher=request.getRequestDispatcher("/submit");				
				requestDispatcher.forward(request, response);
			}
			else {
				requestDispatcher=request.getRequestDispatcher("/invaliduser");
				requestDispatcher.forward(request, response);
			}			
		}
		
		if(command.equalsIgnoreCase("shopAgain")){
			HttpSession session=request.getSession();
			Cart cart=(Cart) session.getAttribute("cart");
			cart.getTickets().clear();
			cart.setAmount(0);
			requestDispatcher=request.getRequestDispatcher("/welcome");
			requestDispatcher.forward(request, response);
		}
		
		if(command.equalsIgnoreCase("CheckUserId")){
			ModelCheckDuplicateUserName duplicacy=new ModelCheckDuplicateUserName();
			String validity=duplicacy.model(modelContext);
			response.setContentType("text/html");
	        response.setHeader("Cache-Control", "no-cache");
	        response.getWriter().write(validity); 
		}
		
	}
	
	//extract the command from URI
	private String getCommand(String URI){
		int index=URI.lastIndexOf('/');
		int dotPosition=URI.lastIndexOf('.');
		String servlet=URI.substring(index+1,dotPosition);
		return servlet;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	

}
