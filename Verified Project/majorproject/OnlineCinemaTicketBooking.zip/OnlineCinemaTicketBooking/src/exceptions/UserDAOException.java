package exceptions;

public class UserDAOException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public UserDAOException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	
	public UserDAOException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
