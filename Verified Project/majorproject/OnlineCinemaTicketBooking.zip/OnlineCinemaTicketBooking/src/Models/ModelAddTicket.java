package Models;

import java.sql.Connection;

import interfaces.IModel;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import facade.Facade;

import pojos.Cart;
import pojos.Show;
import pojos.Ticket;

import pojos.ModelContext;

public class ModelAddTicket implements IModel{


	@Override
	public String modelData(ModelContext modelContext) {
		
		HttpServletRequest request=(HttpServletRequest) modelContext.getResource("request");
		int showId=Integer.parseInt(request.getParameter("showId"));
		int seatNo=Integer.parseInt(request.getParameter("seatNo"));
		String classs=request.getParameter("class");
		HttpSession session =request.getSession(false);
		Facade facade=(Facade)session.getAttribute("facade");
		Connection connection=(Connection) session.getAttribute("connection");
		Cart cart=(Cart) session.getAttribute("cart");
		Show show=facade.getShowById(showId, connection);

		Ticket ticket=new Ticket(cart.getUserId(),showId,show.getShowName(),show.getScreen(),seatNo,show.getPrice(classs),classs,show.getShowTime());
		for(Ticket tickets : cart.getTickets()){
			if(tickets.getSeatNo()==ticket.getSeatNo()&& tickets.getShowID()==ticket.getShowID()){
				return null;
			}
			
		}
		
		facade.addToCart(cart, ticket);
		return null;
	}
	
	
}
