package Models;

import interfaces.IModel;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import javax.sql.DataSource;

import pojos.ModelContext;



public class ModelCheckDuplicateUserName implements IModel {


@Override
public String model(ModelContext modelContext) {
	ResultSet rs=null;
	PreparedStatement stmt=null;
	Connection connection1 = null;
	try {
		Context initContext = new InitialContext();
		Context envContext  = (Context)initContext.lookup("java:/comp/env");
		DataSource ds = (DataSource)envContext.lookup("jdbc/myoracle");
		connection1 = ds.getConnection();
	} catch (NamingException e1) {
		e1.printStackTrace();
	} catch (SQLException e1) {
		e1.printStackTrace();
	} 
	HttpServletRequest request=(HttpServletRequest)modelContext.getResource("request");
	int userId=Integer.parseInt(request.getParameter("userId"));
	try {
		String qry="SELECT USERID,USERNAME,USERADDRESS,EMAIL,PASSWORD FROM USERS1772 WHERE USERID=?";
		
		stmt=connection1.prepareStatement(qry);
		stmt.setInt(1, userId);
		rs=stmt.executeQuery();
		if(rs.next()){				
			return "User Already Exists";
		}
		else
			return "UserId Available";
	}catch (SQLException e) {
		
	}
	
	finally{
		try {
			if(rs!=null)
				rs.close();
		} catch (SQLException e) {
			
		}
	}
	return null;
}
}
