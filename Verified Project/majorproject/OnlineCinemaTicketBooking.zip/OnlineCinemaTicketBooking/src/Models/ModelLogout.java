package Models;

import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import pojos.ModelContext;
import interfaces.IModel;

public class ModelLogout implements IModel {

	public String model(ModelContext modelContext) {
		HttpServletRequest request =(HttpServletRequest)modelContext.getResource("request");
		HttpSession session=request.getSession();
		Connection connection=(Connection) session.getAttribute("connection");
		if(session!=null){
			session.invalidate();
			if(connection!=null){
				try {
					System.out.println("Closing Connection : "+connection);
					connection.close();
					System.out.println("Connection Close Succesful: ");
					connection=null;
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			
		}
		
		
		return null;
	}

}
