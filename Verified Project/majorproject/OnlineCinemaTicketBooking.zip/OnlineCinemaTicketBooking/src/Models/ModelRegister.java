package Models;

import javax.servlet.ServletRequest;

import org.apache.log4j.Logger;




import exceptions.SaveOrUpdateException;

import facade.Facade;
import factory.InstanceFactory;
import pojos.ModelContext;
import interfaces.IModel;

public class ModelRegister implements IModel {

	Logger logger =Logger.getLogger(ModelRegister.class);
	
	public String modelData(ModelContext modelContext) {
		logger.info("Inside method modelData in class ModelContext");
		ServletRequest request=(ServletRequest) modelContext.getResource("request");
		InstanceFactory instanceFactory=(InstanceFactory) modelContext.getResource("instanceFactory");
		Facade facade=(Facade)instanceFactory.getResource("facade");
		
		
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String email=request.getParameter("email");
		String addressLine1=request.getParameter("addressLine1");
		String addressLine2=request.getParameter("addressLine2");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String country=request.getParameter("country");
		int pincode=Integer.parseInt(request.getParameter("pincode"));
		try {
			facade.addUser(userName, addressLine1, addressLine2, city, state, country, pincode, email, password);
		} catch (SaveOrUpdateException e) {
			logger.error(e.fillInStackTrace());
		}			
		return "userAdded";
	
		
		
	}

}
