package Models;

import java.sql.Connection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import facade.Facade;
import pojos.Cart;
import pojos.ModelContext;
import interfaces.IModel;

public class ModelFinalizeOrder implements IModel {

	@Override
	public String model(ModelContext modelContext) {
		HttpServletRequest request=(HttpServletRequest) modelContext.getResource("request");
		HttpSession session=request.getSession();
		Connection connection=(Connection) session.getAttribute("connection");
		Facade facade=(Facade) session.getAttribute("facade");
		Cart cart=(Cart) session.getAttribute("cart");
		String billId=Integer.toString(facade.checkOutUser(cart, connection));		
		return billId;
	}

}
