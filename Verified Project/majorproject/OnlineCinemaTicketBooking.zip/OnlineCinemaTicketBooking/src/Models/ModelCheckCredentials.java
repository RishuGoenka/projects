package Models;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import exceptions.FacadeException;
import facade.Facade;
import factory.InstanceFactory;

import pojos.Cart;
import pojos.ModelContext;
import pojos.User;
import interfaces.IModel;

public class ModelCheckCredentials implements IModel {

	Logger logger=Logger.getLogger(ModelCheckCredentials.class);
	public String modelData(ModelContext modelContext) {
		HttpServletRequest request=(HttpServletRequest)modelContext.getResource("request");
		long userId=Long.parseLong(request.getParameter("userId"));
		String password=request.getParameter("password");
		boolean authentication = false;
		User userProfile=null;
		InstanceFactory instanceFactory=(InstanceFactory) modelContext.getResource("instanceFactory");
		Facade facade=(Facade) modelContext.getResource("facade");
		try {
			authentication =facade.getUserAuthenticated(userId, password);
		} catch (FacadeException e) {
			logger.error(e.fillInStackTrace());
		}

		if(authentication){
			
			HttpSession session=request.getSession(true);
			session.setAttribute("profile", userProfile);
			session.setAttribute("instanceFactory", instanceFactory);
			session.setAttribute("facade", facade);
			session.setAttribute("userProfile", userProfile);
			Cart cart=facade.createCart(userId);
			session.setAttribute("cart", cart);
			return "valid";
		}
		else{
			return "invalid";
		}
	}

}
