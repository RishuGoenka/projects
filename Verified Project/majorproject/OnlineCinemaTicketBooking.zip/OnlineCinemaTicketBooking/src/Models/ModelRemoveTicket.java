package Models;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import facade.Facade;


import pojos.Cart;
import pojos.ModelContext;
import pojos.Ticket;
import interfaces.IModel;

public class ModelRemoveTicket implements IModel {

	@Override
	public String modelData(ModelContext modelContext) {
		HttpServletRequest request=(HttpServletRequest) modelContext.getResource("request");
		int showId=Integer.parseInt(request.getParameter("showId"));
		int seatNo=Integer.parseInt(request.getParameter("seatNo"));
		HttpSession session =request.getSession(false);
		Facade facade=(Facade)session.getAttribute("facade");
		Cart cart=(Cart) session.getAttribute("cart");
		ArrayList<Ticket> tickets = cart.getTickets();
		Ticket ticket=null;
		for(int index=0;index<tickets.size();index++){
			ticket=tickets.get(index);
			if(ticket.getSeatNo()==seatNo&& ticket.getShowID()==showId){
				facade.removeItem(cart, ticket);
			}
			
		}
		
		return null;	
	}

	

}
