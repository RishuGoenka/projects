package interfaces;



import pojos.ModelContext;

public interface IModel {
	public String modelData(ModelContext modelContext);
}
