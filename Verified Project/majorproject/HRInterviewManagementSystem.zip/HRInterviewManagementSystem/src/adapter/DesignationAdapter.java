package adapter;

import java.lang.reflect.Type;

import pojos.Designation;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class DesignationAdapter implements JsonSerializer<Designation> {
		  
		@Override
		  public JsonElement serialize(Designation desig, Type type, JsonSerializationContext jsc) {
		    JsonObject jsonObject = new JsonObject();
		    jsonObject.addProperty("desig_id", desig.getDesignationId());
		    jsonObject.addProperty("desig_name", desig.getDesignationType());
		    return jsonObject;      
		  }

		
}
