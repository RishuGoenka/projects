package exceptions;

public class BaseDAOException extends Exception {

	private static final long serialVersionUID = 1L;

	public BaseDAOException() {
		// TODO Auto-generated constructor stub
	}

	public BaseDAOException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BaseDAOException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public BaseDAOException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
