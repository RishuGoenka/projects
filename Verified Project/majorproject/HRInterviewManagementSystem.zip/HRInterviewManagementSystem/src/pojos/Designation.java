package pojos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class Designation implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Integer designationId=null;
	private String designationType=null;
	private Department department;
	private List<User> users=new ArrayList<User>(); 
	public Integer getDesignationId() {
		return designationId;
	}
	public void setDesignationId(Integer designationId) {
		this.designationId = designationId;
	}
	public String getDesignationType() {
		return designationType;
	}
	public void setDesignationType(String designationType) {
		this.designationType = designationType;
	}
	public void setUsers(List<User> users) {
		this.users = users;
	}
	public List<User> getUsers() {
		return users;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	
	
}
