package pojos;

import java.io.Serializable;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;

public class Event implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Integer eventId=null;
	private String eventLocation=null;
	private String eventRound=null;	
	private String requiredDesignations=null;
	private Date scheduledOn=null;
	private Date scheduledTill=null;
	private List<User> registeredUsers=new ArrayList<User>();
	private Integer requiredMembers=null;
	private Integer footFall=null;
	private Department department=null;
	private String description;
	public Integer getEventId() {
		return eventId;
	}
	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}
	public String getEventLocation() {
		return eventLocation;
	}
	public void setEventLocation(String eventLocation) {
		this.eventLocation = eventLocation;
	}
	public String getEventRound() {
		return eventRound;
	}
	public void setEventRound(String eventRound) {
		this.eventRound = eventRound;
	}
	public Date getScheduledOn() {
		return scheduledOn;
	}
	public void setScheduledOn(Date scheduledOn) {
		this.scheduledOn = scheduledOn;
	}
	public Date getScheduledTill() {
		return scheduledTill;
	}
	public void setScheduledTill(Date scheduledTill) {
		this.scheduledTill = scheduledTill;
	}
	public List<User> getRegisteredUsers() {
		return registeredUsers;
	}
	public void setRegisteredUsers(List<User> registeredUsers) {
		this.registeredUsers = registeredUsers;
	}
	public Integer getRequiredMembers() {
		return requiredMembers;
	}
	public void setRequiredMembers(Integer requiredMembers) {
		this.requiredMembers = requiredMembers;
	}
	public Integer getFootFall() {
		return footFall;
	}
	public void setFootFall(Integer footFall) {
		this.footFall = footFall;
	}
	public void setRequiredDesignations(String requiredDesignations) {
		this.requiredDesignations = requiredDesignations;
	}
	public String getRequiredDesignations() {
		return requiredDesignations;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getDescription() {
		return description;
	}
	
	
	
	
	
	
	
	
}
