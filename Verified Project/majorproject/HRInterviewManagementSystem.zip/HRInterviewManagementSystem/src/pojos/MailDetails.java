package pojos;

import java.io.Serializable;
import java.util.Date;

public class MailDetails implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Integer mailDetailsId=null;
	private User sentBy=null;
	private Event event=null;
	private User contactedUser=null;
	private Date mailingDate=null;
	public Integer getMailDetailsId() {
		return mailDetailsId;
	}
	public void setMailDetailsId(Integer mailDetailsId) {
		this.mailDetailsId = mailDetailsId;
	}
	public User getSentBy() {
		return sentBy;
	}
	public void setSentBy(User sentBy) {
		this.sentBy = sentBy;
	}
	public Event getEvent() {
		return event;
	}
	public void setEvent(Event event) {
		this.event = event;
	}
	public User getContactedUser() {
		return contactedUser;
	}
	public void setContactedUser(User contactedUser) {
		this.contactedUser = contactedUser;
	}
	public Date getMailingDate() {
		return mailingDate;
	}
	public void setMailingDate(Date mailingDate) {
		this.mailingDate = mailingDate;
	}
	@Override
	public String toString() {
		return "MailDetails [mailDetailsId=" + mailDetailsId + ", sentBy="
				+ sentBy.getUserId() + ", event=" + event.getEventId() + ", contactedUser="
				+ contactedUser.getUserId() + ", mailingDate=" + mailingDate + "]";
	}
	
	
	
	
	
}
