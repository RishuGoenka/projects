package pojos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Department implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private Integer departmentId=null;
	private String departmentName=null;
	private User headOfDepartment=null;
	private User pointOfContact=null;
	private List<Designation> designations=new ArrayList<Designation>();

	public Integer getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public User getHeadOfDepartment() {
		return headOfDepartment;
	}
	public void setHeadOfDepartment(User headOfDepartment) {
		this.headOfDepartment = headOfDepartment;
	}
	public User getPointOfContact() {
		return pointOfContact;
	}
	public void setPointOfContact(User pointOfContact) {
		this.pointOfContact = pointOfContact;
	}
	public List<Designation> getDesignations() {
		return designations;
	}
	public void setDesignations(List<Designation> designations) {
		this.designations = designations;
	}
	
	
	
	

}
