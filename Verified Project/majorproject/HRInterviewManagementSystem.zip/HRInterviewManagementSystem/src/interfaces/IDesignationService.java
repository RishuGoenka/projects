package interfaces;

import java.util.List;

import exceptions.ServiceLayerException;
import pojos.Designation;

public interface IDesignationService {

	public abstract List<Designation> getAllDesignations() throws ServiceLayerException;

	public abstract Designation getDesignation(Integer desgId)  throws ServiceLayerException;

	public abstract void deleteDesignation(Integer desgId) throws ServiceLayerException;

	public abstract void addDesignation(String desigName,Integer deptId) throws ServiceLayerException;

	public abstract void updateDesignation(Integer desgId, String desigName,Integer deptId) throws ServiceLayerException;

	public abstract List<Designation> getAllDesignationsByDept(Integer deptId) throws ServiceLayerException;

	

}