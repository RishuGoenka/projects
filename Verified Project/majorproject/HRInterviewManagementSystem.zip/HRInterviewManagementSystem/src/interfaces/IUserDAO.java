package interfaces;

import java.io.Serializable;
import java.util.List;

import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import pojos.User;

public interface IUserDAO {

	public abstract List<User> getAllUsersByUserId(List<Integer> userIds) throws DataFetchException;

	public abstract void addorUpdateUser(User user) throws DataFetchException;

	public abstract void deleteUser(User user) throws DataFetchException;

	public abstract List<User> getAllUser() throws DataFetchException;

	public abstract User getUser(User user) throws DataFetchException;
	public abstract void saveOrUpdate(Object obj)throws BaseDAOException;

	public abstract <T> T getObject(Class<T> className,Serializable pk) throws BaseDAOException;

	public abstract User getUserByHexId(String userId)  throws DataFetchException;

	User getUserWithEventsByUserId(Integer userId) throws DataFetchException;



}