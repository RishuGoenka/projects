package interfaces;

import java.util.List;

import exceptions.ServiceLayerException;
import pojos.Department;
import pojos.User;

public interface IDepartmentService {

	public abstract void deleteDepartment(int deptId) throws ServiceLayerException;


	public abstract List<Department> getAllDepartments() throws ServiceLayerException;


	public abstract Department getDepartment(Integer deptId) throws ServiceLayerException;


	public abstract void addorUpdate(Integer deptId, String deptName,
			Integer hodId, Integer spocId) throws ServiceLayerException;

	public abstract void addorUpdate(String deptName, Integer hodId,
			Integer spocId) throws ServiceLayerException;


	public abstract User getSpoc(Integer deptId) throws ServiceLayerException;


	public abstract User getHod(Integer deptId) throws ServiceLayerException;


}