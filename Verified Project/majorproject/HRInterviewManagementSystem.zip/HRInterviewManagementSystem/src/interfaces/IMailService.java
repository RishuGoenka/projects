package interfaces;

import java.io.IOException;

import exceptions.MailDeliveryFailedException;
import exceptions.ServiceLayerException;
import pojos.Event;
import pojos.User;

public interface IMailService {

	public abstract String mailSelectedUsers(String userIds,
			Integer departmentId, Integer eventId) throws ServiceLayerException;

	public abstract void updateSentmails(User sentBy, User contactedUser,
			Event event) throws ServiceLayerException;



	

	boolean sendMailToUser(User from, User to, Event event, String context)
			throws IOException, MailDeliveryFailedException;

}