package interfaces;

import java.io.Serializable;
import java.util.List;

import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import pojos.Role;

public interface IRoleDAO {

	public abstract void addorUpdateRole(Role role) throws DataFetchException;

	public abstract void deleteRole(Role role) throws DataFetchException;

	public abstract List<Role> getAllRole() throws DataFetchException;
	public abstract void saveOrUpdate(Object obj)throws BaseDAOException;


	public abstract <T> T getObject(Class<T> className,Serializable pk)throws BaseDAOException;

	public abstract Role getRoleByName(String roleName)throws BaseDAOException, DataFetchException;

}