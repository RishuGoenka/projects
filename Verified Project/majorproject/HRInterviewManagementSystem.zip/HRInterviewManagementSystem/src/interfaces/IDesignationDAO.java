package interfaces;

import java.io.Serializable;
import java.util.List;

import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import pojos.Designation;

public interface IDesignationDAO {

	public abstract List<Designation> getAllDesignations() throws DataFetchException;

	public abstract Designation getDesignation(int desgId) throws DataFetchException;

	public abstract void addorUpdate(Designation designation) throws DataFetchException;

	public abstract void deleteDesignation(Designation designation) throws DataFetchException;
	public abstract void saveOrUpdate(Object obj)throws BaseDAOException;

	public abstract <T> T getObject(Class<T> className,Serializable pk)throws BaseDAOException;

	List<Designation> getAllDesignations(Integer deptId)
			throws DataFetchException;

	public abstract Designation getDesignationByNameAndId(String string,
			Integer departmentId) throws DataFetchException;
}