package interfaces;

import java.io.Serializable;
import java.util.List;

import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import pojos.Department;
import pojos.User;

public interface IDepartmentDAO {

	public abstract User getSpocForDepartment(Integer departmentId) throws DataFetchException;

	public abstract void addorUpdate(Department department) throws DataFetchException;

	public abstract void deleteDepartment(Department dept) throws DataFetchException;

	public abstract List<Department> getAllDepartment() throws DataFetchException;

	public abstract Department getDept(String deptName) throws DataFetchException;
	public abstract void saveOrUpdate(Object obj) throws BaseDAOException;

	public abstract <T> T getObject(Class<T> className,Serializable pk) throws BaseDAOException;

	User getHodForDepartment(Integer departmentId) throws DataFetchException;

}