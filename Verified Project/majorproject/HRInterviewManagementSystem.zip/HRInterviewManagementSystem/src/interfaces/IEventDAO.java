package interfaces;

import java.io.Serializable;
import java.util.List;

import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import pojos.Department;
import pojos.Event;
import pojos.MailDetails;
import pojos.User;

public interface IEventDAO {

	public abstract Event getRegisteredUsersForEvent(Event event) throws DataFetchException;

	public abstract List<MailDetails> getMailedUsersForEvent(Event event) throws DataFetchException;

	public abstract List<User> getUnMailedUsersForEvent(Event event) throws DataFetchException;

	public abstract List<Event> getAllScheduledEventsForDepartment(
			Department department) throws DataFetchException;

	public abstract Integer addorUpdateEvent(Event event) throws DataFetchException;

	public abstract List<Event> getAllScheduledEvents() throws DataFetchException;

	public abstract List<Event> getAllOngoingEvents() throws DataFetchException;
	public abstract void saveOrUpdate(Object obj)throws BaseDAOException;

	public abstract <T> T getObject(Class<T> className,Serializable pk)throws BaseDAOException;
	


}