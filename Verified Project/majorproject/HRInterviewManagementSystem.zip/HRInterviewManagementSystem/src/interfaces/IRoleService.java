package interfaces;

import java.util.List;

import exceptions.ServiceLayerException;
import pojos.Role;

public interface IRoleService {

	public abstract List<Role> getAllRoles() throws ServiceLayerException;

	public abstract Role getRole(Integer roleId)  throws ServiceLayerException;

	public abstract void addRole(String roleName)  throws ServiceLayerException;

	public abstract void deleteRole(Integer roleId)  throws ServiceLayerException;

	public abstract void updateRole(Integer roleId, String roleName)  throws ServiceLayerException;

}