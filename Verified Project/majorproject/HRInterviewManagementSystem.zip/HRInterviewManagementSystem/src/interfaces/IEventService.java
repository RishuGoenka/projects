package interfaces;

import java.util.Date;
import java.util.List;

import exceptions.ServiceLayerException;
import pojos.Department;
import pojos.Event;
import pojos.MailDetails;
import pojos.User;

public interface IEventService {

	public abstract Event getRegisteredUsersForEvent(Integer eventId) throws ServiceLayerException;

	public abstract List<MailDetails> getMailedUsersForEvent(Integer eventId) throws ServiceLayerException;

	public abstract List<User> getUnMailedUsersForEvent(Integer eventId) throws ServiceLayerException;

	public abstract Event getEvent(Integer eventId) throws ServiceLayerException;

	public abstract List<Event> getAllEventsForDepartment(Integer departmentId) throws ServiceLayerException;

	public abstract void addorUpdateEvent(Event event) throws ServiceLayerException;

	public abstract List<Event> getAllScheduledEvents() throws ServiceLayerException;

	public abstract List<Event> getAllOngoingEvents() throws ServiceLayerException;

	public abstract Integer addorUpdateEvent(String description,
			String eventLocation, String eventRound, Department department,
			Date scheduledOn, Date scheduledTill, Integer requiredMembers,
			String[] desgs, Integer footFall) throws ServiceLayerException;

	public abstract Event getEventFromEventId(int eventId) throws ServiceLayerException;

	public abstract void addorUpdateEvent(Integer eventId, String description,
			String eventLocation, String eventRound, Department department,
			Date scheduledOn, Date scheduledTill, Integer requiredMembers,
			String[] desgs, Integer footFall) throws ServiceLayerException;
	
	boolean registerUserToEvent(Integer userId, Integer eventId) throws ServiceLayerException;

}