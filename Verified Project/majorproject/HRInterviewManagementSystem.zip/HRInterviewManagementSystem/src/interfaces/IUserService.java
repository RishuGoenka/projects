package interfaces;

import java.util.List;

import exceptions.ServiceLayerException;
import pojos.User;

public interface IUserService {

	public abstract List<User> getAllUser() throws ServiceLayerException;

	public abstract void deleteUser(Integer userId) throws ServiceLayerException;

	public abstract void addUser(String userName, String email, long contactNo,
			Integer departmentId, String[] designationId, Integer roleId) throws ServiceLayerException;

	public abstract User getUser(Integer userId) throws ServiceLayerException;

	public abstract void updateUser(Integer userId, String userName,
			String email, long contactNo, Integer departmentId,
			String[] designation, Integer roleId) throws ServiceLayerException;

	public abstract User getUserByHexId(String userId) throws ServiceLayerException;

	User getUserWithEventsByUserId(Integer userId) throws ServiceLayerException;


	
}