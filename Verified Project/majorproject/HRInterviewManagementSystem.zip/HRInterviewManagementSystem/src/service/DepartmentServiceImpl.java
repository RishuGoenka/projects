package service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import daos.BaseDAO;
import exceptions.DataFetchException;
import exceptions.ServiceLayerException;
import pojos.Department;
import pojos.Designation;
import pojos.Role;
import pojos.User;
import interfaces.IDepartmentDAO;
import interfaces.IDepartmentService;
import interfaces.IDesignationDAO;
import interfaces.IRoleDAO;
import interfaces.IUserDAO;

@Service("departmentService")
public class DepartmentServiceImpl implements IDepartmentService  {
	
	private static Logger log = Logger.getLogger(BaseDAO.class.getName());
	
	@Autowired
	private IDepartmentDAO departmentDao;
	
	@Autowired
	private IUserDAO userDao;

	@Autowired
	private IRoleDAO roleDao;
	
	@Autowired
	private IDesignationDAO designationDao;


	@Override
	public User getSpoc(Integer deptId) throws ServiceLayerException
	{
		log.debug("In method getSpocDepartment in class DepartmentServiceImpl");
		try {
			return departmentDao.getSpocForDepartment(deptId);
		} catch (DataFetchException e) {
			log.error(e);
			throw new ServiceLayerException("Error in getting the spoc for department In method getSpocDepartment in class DepartmentServiceImpl",e);
		}
	}
	
	@Override
	public User getHod(Integer deptId) throws ServiceLayerException
	{
		log.debug("In method getHod in class DepartmentServiceImpl");
		try {
			return departmentDao.getSpocForDepartment(deptId);
		} catch (DataFetchException e) {
			log.error(e);
			throw new ServiceLayerException("Error in getting the spoc for department In method getHod in class DepartmentServiceImpl",e);
		}
	}
	
	@Override
	public void deleteDepartment(int deptId) throws ServiceLayerException
	{
		log.debug("In method deleteDepartment in class DepartmentServiceImpl");
		
			try {
				Department dept = departmentDao.getObject(Department.class, deptId);
				departmentDao.deleteDepartment(dept);
			} catch (Exception e) {
				log.error(e);
				throw new ServiceLayerException("Error in deleting the department In method deleteDepartment in class DepartmentServiceImpl",e);
			} 
		 
	}
	
	
	
	@Override
	public List<Department> getAllDepartments() throws ServiceLayerException
	{
		log.debug("In method getAllDepartment in class DepartmentServiceImpl");
		try {
			return departmentDao.getAllDepartment();
		} catch (Exception e) {
			log.error(e);
			throw new ServiceLayerException("Error  In method getAllDepartment in class DepartmentServiceImpl",e);
		}
	}
	
	
	
	@Override
	public Department getDepartment(Integer deptId) throws ServiceLayerException
	{
		log.debug("In method getDepartment in class DepartmentServiceImpl");
		try {
			return departmentDao.getObject(Department.class,deptId);
		} catch (Exception e) {
			log.error(e);
			throw new ServiceLayerException("Error in getting the department In method getDepartment in class DepartmentServiceImpl",e);
		}
	}


	@Override
	public void addorUpdate(Integer deptId, String deptName, Integer hodId,
			Integer spocId) throws ServiceLayerException  {
		log.debug("In method addOrUpdate in class DepartmentServiceImpl");
		
		try {
			Department department = departmentDao.getObject(Department.class, deptId);
			department.setDepartmentName(deptName);
			User hod = departmentDao.getObject(User.class, hodId);
			department.setHeadOfDepartment(hod);
			User spoc = departmentDao.getObject(User.class, spocId);
			hod.setDepartment(department);
			spoc.setDepartment(department);
			department.setPointOfContact(spoc);
			
			departmentDao.addorUpdate(department);
		} catch (Exception e) {
			
				log.error(e);
				throw new ServiceLayerException("Error in addOrupdate the department In method addorUpdateDepartment in class DepartmentServiceImpl",e);
		} 
	}

	
	@Override
	public void addorUpdate(String deptName, Integer hodId, Integer spocId) throws ServiceLayerException {
		
		log.debug("In method addOrUpdate in class DepartmentServiceImpl");
		try {
			Department department = new Department();
			department.setDepartmentName(deptName);
			User hod = userDao.getUser(userDao.getObject(User.class, hodId));
			User spoc = departmentDao.getObject(User.class, spocId);
			department.setHeadOfDepartment(hod);
			department.setPointOfContact(spoc);
			departmentDao.addorUpdate(department);
			
			hod.setDepartment(departmentDao.getDept(deptName));
			spoc.setDepartment(departmentDao.getDept(deptName));
			
			Designation designation = designationDao.getDesignationByNameAndId("HOD",departmentDao.getDept(deptName).getDepartmentId());
			boolean desgPresent=false;
			for(Designation desg : hod.getDesignations()){
				if(desg.getDesignationId()==designation.getDesignationId()){
					desgPresent=true;
				}
			}
			if(!desgPresent){
				hod.getDesignations().add(designation);
			}
			userDao.addorUpdateUser(hod);
			
			Role role=roleDao.getRoleByName("SPOC_USER");
			spoc.setRole(role);
			userDao.addorUpdateUser(spoc);
		} catch (Exception e) {			
				log.error(e);
				throw new ServiceLayerException("Error in updating the department In method addOrUpdate in class DepartmentServiceImpl",e);
		 } 
		
		
		
		
	}
	
	}
