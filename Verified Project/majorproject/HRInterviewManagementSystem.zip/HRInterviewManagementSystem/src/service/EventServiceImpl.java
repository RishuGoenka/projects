

package service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import exceptions.ServiceLayerException;
import pojos.Department;
import pojos.Designation;
import pojos.Event;
import pojos.MailDetails;
import pojos.User;
import interfaces.IDesignationService;
import interfaces.IEventDAO;
import interfaces.IEventService;
import interfaces.IUserDAO;

@Service("eventService")
public class EventServiceImpl implements IEventService  {

	private static Logger log = Logger.getLogger(EventServiceImpl.class.getName());

	@Autowired
	@Qualifier("eventDAO")
	private IEventDAO eventDAO;

	@Autowired
	@Qualifier("designationService")
	private IDesignationService designationService;
	
	@Autowired
	private IUserDAO userDAO;


	@Override
	public Event getRegisteredUsersForEvent(Integer eventId) throws ServiceLayerException {

		log.debug("In Method getRegisteredUsersForEvent In class EventServiceImpl");
		try {
			Event event=eventDAO.getObject(Event.class, eventId);

			return eventDAO.getRegisteredUsersForEvent(event);
		} catch (Exception e) {
			log.error(e);
			throw new ServiceLayerException("Error while fething registered users for event",e);
		}

	}

	@Override
	public List<MailDetails> getMailedUsersForEvent(Integer eventId) throws ServiceLayerException {

		log.debug("In Method getmailedUsersForEvent In class EventServiceImpl");
		try {
			Event event=eventDAO.getObject(Event.class, eventId);
			return eventDAO.getMailedUsersForEvent(event);
		} catch (Exception e) {
			log.error(e);
			throw new ServiceLayerException("Error while fething mailed users for event",e);
		}

	}

	@Override
	public List<User> getUnMailedUsersForEvent(Integer eventId) throws ServiceLayerException {

		log.debug("In Method getUnmailedUsersForEvent In class EventServiceImpl");
		try {
			Event event=eventDAO.getObject(Event.class, eventId);
			return eventDAO.getUnMailedUsersForEvent(event);
		} catch (Exception e) {
			log.error(e);
			throw new ServiceLayerException("Error while fething unmailed users for event",e);
		}

	}
	@Override
	public Event getEvent(Integer eventId) throws ServiceLayerException{
		log.debug("In Method getEvent In class EventServiceImpl");

		try {
			return eventDAO.getObject(Event.class, eventId);
		} catch (BaseDAOException e) {
			log.error(e);
			throw new ServiceLayerException("Error while fething event by eventID",e);
		}


	}

	@Override
	public List<Event> getAllEventsForDepartment(Integer departmentId) throws ServiceLayerException{
		log.debug("In Method getAllEventsforDepartment In class EventServiceImpl");
		try {
			Department department=eventDAO.getObject(Department.class, departmentId);
			return eventDAO.getAllScheduledEventsForDepartment(department);
		} catch (Exception e) {
			log.error(e);
			throw new ServiceLayerException("Error while fething events for department",e);
		} 

	}


	@Override
	public void addorUpdateEvent (Event event) throws ServiceLayerException
	{	
		try {
			log.debug("In Method addOrupdateEvent In class EventServiceImpl");
			eventDAO.addorUpdateEvent(event);
		} catch (DataFetchException e) {
			log.error(e);
			throw new ServiceLayerException("Error while adding or updating event ",e);
		}
	}

	@Override
	public List<Event> getAllScheduledEvents() throws ServiceLayerException
	{	
		log.debug("In Method getAllScheduledEvents In class EventServiceImpl");
		try {
			return eventDAO.getAllScheduledEvents();
		} catch (DataFetchException e) {
			log.error(e);
			throw new ServiceLayerException("Error while fething scheduled events",e);
		}
	}

	@Override
	public List<Event> getAllOngoingEvents() throws ServiceLayerException
	{	
		log.debug("In Method getallOngoingEvents In class EventServiceImpl");
		try {
			return eventDAO.getAllOngoingEvents();
		} catch (DataFetchException e) {
			log.error(e);
			throw new ServiceLayerException("Error while fething all ongoing events",e);
		}
	}

	@Override
	public Integer addorUpdateEvent(String description,String eventLocation, String eventRound,
			Department department, Date scheduledOn, Date scheduledTill,
			Integer requiredMembers, String[] desgs, Integer footFall) throws ServiceLayerException {
		log.debug("In Method addOrUpdateEvent In class EventServiceImpl");

		Event event=new Event();
		event.setDescription(description);
		event.setDepartment(department);
		event.setEventLocation(eventLocation);
		event.setEventRound(eventRound);
		event.setFootFall(footFall);
		event.setRequiredMembers(requiredMembers);
		event.setScheduledOn(scheduledOn);
		event.setScheduledTill(scheduledTill);
		String designations="";
		Designation designation=null;
		for(int i=0;i<desgs.length;i++){

			designation=designationService.getDesignation(Integer.parseInt(desgs[i]));


			if(i<desgs.length-1)
				designations+=designation.getDesignationType()+",";
			else
				designations+=designation.getDesignationType();
		}
		event.setRequiredDesignations(designations);
		try {
			return eventDAO.addorUpdateEvent(event);
		} catch (DataFetchException e) {
			log.error(e);
			throw new ServiceLayerException(e.getMessage(),e);
		}
	}

	@Override
	public Event getEventFromEventId(int eventId) throws ServiceLayerException{
		log.error("In Method getEventFromEventId In class EventServiceImpl");
		try {
			return eventDAO.getObject(Event.class, eventId);
		} catch (BaseDAOException e) {
			log.error(e);
			throw new ServiceLayerException("Error while fething events from EventId",e);
		}
	}

	@Override
	public void addorUpdateEvent(Integer eventId, String description,
			String eventLocation, String eventRound, Department department,
			Date scheduledOn, Date scheduledTill, Integer requiredMembers,
			String[] desgs, Integer footFall) throws ServiceLayerException {

		log.debug("In Method addOrUpdateEvent In class EventServiceImpl");
		Event event=new Event();
		event.setEventId(eventId);
		event.setDescription(description);
		event.setDepartment(department);
		event.setEventLocation(eventLocation);
		event.setEventRound(eventRound);
		event.setFootFall(footFall);
		event.setRequiredMembers(requiredMembers);
		event.setScheduledOn(scheduledOn);
		event.setScheduledTill(scheduledTill);
		String designations="";
		Designation designation=null;
		for(int i=0;i<desgs.length;i++){

			designation=designationService.getDesignation(Integer.parseInt(desgs[i]));

			if(i<desgs.length-1)
				designations+=designation.getDesignationType()+",";
			else
				designations+=designation.getDesignationType();
		}
		event.setRequiredDesignations(designations);
		try {
			eventDAO.addorUpdateEvent(event);
		} catch (DataFetchException e) {
			log.error(e);
			throw new ServiceLayerException(e.getMessage(),e);
		}
	}

	@Override
	public boolean registerUserToEvent(Integer userId, Integer eventId)
			throws ServiceLayerException {
		log.debug("In Method registerUserToEvent In class EventServiceImpl");
		try {
			User user=userDAO.getUserWithEventsByUserId(userId);
			Event event=eventDAO.getObject(Event.class, eventId);
			event=eventDAO.getRegisteredUsersForEvent(event);
			if(event.getRegisteredUsers().size()==event.getRequiredMembers())
				return false;
			else if(event.getScheduledOn().before(new Date()))
				return false;
			else
			{
				boolean eventPresent=false;
				for(Event events : user.getEvents()){
					if(events.getEventId()==event.getEventId()){
						eventPresent=true;
					}
				}
				if(!eventPresent){
					user.getEvents().add(event);
				}
				
				userDAO.saveOrUpdate(user);
				return true;
			}
		} catch (Exception e) {
			log.error(e);
			throw new ServiceLayerException(e.getMessage(),e);	
		}
	}




}
