package service;

import interfaces.IDepartmentDAO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import interfaces.IEventDAO;
import interfaces.IMailService;
import interfaces.IUserDAO;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import exceptions.MailDeliveryFailedException;
import exceptions.ServiceLayerException;
import pojos.Event;
import pojos.MailDetails;
import pojos.User;

@Service("mailService")
public class MailServiceImpl implements IMailService {
	
	private static Logger log = Logger.getLogger(MailServiceImpl.class.getName());
	
	@Autowired
	private IDepartmentDAO departmentDAO;
	
	@Autowired
	private IEventDAO eventDAO;
	
	@Autowired
	private IUserDAO userDAO;
	
	@Override
	public String mailSelectedUsers(String userIds,Integer departmentId,Integer eventId) throws ServiceLayerException{
		log.debug("In method mailSelectedUser in class MailserviceImpl");
			
			try {
				User sentBy=departmentDAO.getSpocForDepartment(departmentId);
				Event event=eventDAO.getObject(Event.class, eventId);
				StringTokenizer stringTokenizer=new StringTokenizer(userIds,",");
				List<Integer> usersToMail=new ArrayList<Integer>();
				while(stringTokenizer.hasMoreElements()){
					usersToMail.add(Integer.parseInt(stringTokenizer.nextToken()));
				}
				List<User> users=userDAO.getAllUsersByUserId(usersToMail);			
				for(User contactedUser : users){
					this.sendMailToUser(sentBy, contactedUser, event,"SPOC");
					this.updateSentmails(sentBy, contactedUser, event);
				}
		
			} catch (MailDeliveryFailedException e) {
				log.error("Error in method mailSelectedUsers in class MailServiceImpl");
				return "Sorry Something Went Wrong While Mailing The Checked Users";
			}catch (Exception e) {
				log.error(e);
				throw new ServiceLayerException("Error in method mailSelectedUser in class MailserviceImpl",e);
			}
			return "Mails Sent To selected Employees successfully";
	
		
		
	}
	
	
	@Override
	public void updateSentmails(User sentBy,User contactedUser,Event event) throws ServiceLayerException{
		try {
			MailDetails mailDetails=new MailDetails();
			mailDetails.setContactedUser(contactedUser);
			mailDetails.setEvent(event);
			mailDetails.setMailingDate(new Date());
			mailDetails.setSentBy(sentBy);
			eventDAO.saveOrUpdate(mailDetails);
		} catch (Exception e) {
			log.error("Error in method mailSelectedUsers in class MailServiceImpl");
			throw new ServiceLayerException("Error in method updatesentMail in class MailserviceImpl",e);
		}
	}
	
	
	@Override
	public boolean  sendMailToUser(User from,User to,Event event,String context) throws IOException, MailDeliveryFailedException{

		
		       log.debug("In method sendMailToUser in class MailServiceImpl"); 
				Properties properties = new Properties();
				InputStream stream = null;
				try 
				{
					File file = new File(this.getClass().getClassLoader().getResource("Mailcredentials.properties").getPath());
					System.out.println(this.getClass().getClassLoader().getResource("Mailcredentials.properties").getPath());
					if( ! file.isFile())
					{
						throw new FileNotFoundException("Mail Properties file does not exists");
					}
					stream = new FileInputStream(file);
					properties.load(stream);
					log.debug("FileInputStream opened");
				} 
				catch (Exception e)
				{
					log.error(e);
					throw new IOException(" Error in reading the Mailcredential.properties file...!");
				}
				
				final String username=properties.getProperty("username");
				final String password=properties.getProperty("password");
				String subject=properties.getProperty("subject");
				String mailMessage=properties.getProperty("mailMessage");
		        Session session = Session.getInstance(properties,
		          new javax.mail.Authenticator() {
		            protected PasswordAuthentication getPasswordAuthentication() {
		                return new PasswordAuthentication(username, password);
		            }
		          });
		        
		        session.setDebug(true);

		        try {

		            Message message = new MimeMessage(session);
		            message.setFrom(new InternetAddress(from.getEmail()));
		            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to.getEmail()));
		           
		            message.setSubject(subject);
		            String link="";
		            if(context.equalsIgnoreCase("HR"))
		            	link=properties.getProperty("baseLink");
		            else if(context.equalsIgnoreCase("SPOC"))
		            	 link=properties.getProperty("linkForOtherUsers");
		            message.setText(mailMessage+"\n"+link+event.getEventId());

		            Transport.send(message);

		            return true;

		        } catch (MessagingException e) {
		        	log.error(e);
		            throw new MailDeliveryFailedException("Mail can't be delivered",e);
		        }
		        
		        
		        finally
				{
					if(stream != null)
					{
						stream.close();
						stream = null;
						log.debug("FileInputStream closed Properly");
					}
				}
		 }
		
	
	

}
