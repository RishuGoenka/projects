package service;

import interfaces.IUserDAO;
import interfaces.IUserService;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import exceptions.DataFetchException;
import exceptions.ServiceLayerException;
import pojos.Department;
import pojos.Designation;
import pojos.Role;
import pojos.User;

@Service("UserService")
public class UserServiceImpl implements IUserService   {
	
	private static Logger log = Logger.getLogger(UserServiceImpl.class.getName());

	@Autowired
	@Qualifier("userDAO")
	private IUserDAO userDao;
	
	public List<User> getAllUser() throws ServiceLayerException
	{
		log.debug("In method getAllUsers in class UserServiceImpl");
		try {
			return userDao.getAllUser();
		} catch (DataFetchException e) {
			log.error(e);
            throw new ServiceLayerException("Error while getting list of users",e);
		}
	}
	@Override
	public void deleteUser(Integer userId) throws ServiceLayerException
	{
		log.debug("In method deleteUser in class UserServiceImpl");
		User user;
		try {
			user = userDao.getObject(User.class, userId);
			userDao.deleteUser(user);
		} catch (Exception e) {
			log.error(e);
            throw new ServiceLayerException("Error while deleting user",e);
		}
		
	}
	@Override
	
	public void addUser(String userName,String email, long contactNo,Integer departmentId, String[] designationId, Integer roleId) throws ServiceLayerException
	{
		log.debug("In method addUser in class UserServiceImpl");
		try {
			Department dept = userDao.getObject(Department.class, departmentId);
			Role role = userDao.getObject(Role.class, roleId);
			User user = new User();
			user.setUserName(userName);
			user.setRole(role);
			user.setEmail(email);
			user.setDepartment(dept);
			user.setContactNo(contactNo);
			List<Designation> designationList = user.getDesignations();
			for(int i=0;i<designationId.length;i++)
			{
				designationList.add(userDao.getObject(Designation.class, Integer.parseInt(designationId[i])));
			}
			user.setDesignations(designationList);
			userDao.addorUpdateUser(user);
		} catch (Exception e) {
			log.error(e);
            throw new ServiceLayerException("Error while adding user",e);
		}
	}
	@Override
	public User getUser(Integer userId) throws ServiceLayerException
	{
		log.debug("In method getUser in class UserServiceImpl");
		
		try {
			User user = userDao.getObject(User.class, userId);
			return userDao.getUser(user);
		} catch (Exception e) {
			log.error(e);
            throw new ServiceLayerException("Error while getting user by userId",e);
		}
	}

	@Override
	public void updateUser(Integer userId,String userName,String email, long contactNo,Integer departmentId, String[] designation,Integer roleId) throws ServiceLayerException
	{
		log.debug("In method updateUser in class UserServiceImpl");
		try {
			Department dept = userDao.getObject(Department.class, departmentId);
			Role role = userDao.getObject(Role.class, roleId);
			User user = userDao.getObject(User.class, userId);
			user.setUserName(userName);
			user.setRole(role);
			user.setEmail(email);
			user.setDepartment(dept);
			user.setContactNo(contactNo);
			List<Designation> designationList = new ArrayList<Designation>();
			for(int i=0;i<designation.length;i++)
			{
				designationList.add(userDao.getObject(Designation.class, Integer.parseInt(designation[i])));
			}
			user.setDesignations(designationList);
			userDao.addorUpdateUser(user);
		} catch (Exception e) {
			log.error(e);
            throw new ServiceLayerException("Error while updatingUser",e);
		}
		
	}
	@Override
	public User getUserByHexId(String userId) throws ServiceLayerException{
		log.debug("In method gettingUserbyHexCode in class UserServiceImpl");

		try {
			return userDao.getUserByHexId(userId);
		} catch (DataFetchException e) {
			log.error(e);
            throw new ServiceLayerException("Error while gettingUserbyHexCode",e);
		}
	}
	
	@Override
	public User getUserWithEventsByUserId(Integer userId ) throws ServiceLayerException{
		log.debug("In method getUserWithEventsByUserId in class UserServiceImpl");

		try {
			return userDao.getUserWithEventsByUserId(userId);
		} catch (DataFetchException e) {
			log.error(e);
            throw new ServiceLayerException("Error while getUserWithEventsByUserId",e);
		}
	}
}

