package service;

import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import exceptions.ServiceLayerException;
import pojos.Department;
import pojos.Designation;
import interfaces.IDesignationDAO;
import interfaces.IDesignationService;


@Service("designationService")
public class DesignationServiceImpl implements IDesignationService {
	
	private static Logger log = Logger.getLogger(DesignationServiceImpl.class.getName());
	
	@Autowired
	private IDesignationDAO designationDAO;
	
	@Override
	public List<Designation> getAllDesignations() throws ServiceLayerException
	{
		log.debug("In method getAllDesignations in class DesignationServiceImpl");
		try {
			return designationDAO.getAllDesignations();
		} catch (DataFetchException e) {
			log.error(e);
			throw new ServiceLayerException("Error fetching list of All Designations",e);
		}
	}
	
	@Override
	public List<Designation> getAllDesignationsByDept(Integer deptId) throws ServiceLayerException
	{
		log.debug("In method getAllDesignations in class DesignationServiceImpl");
		try {
			return designationDAO.getAllDesignations(deptId);
		} catch (DataFetchException e) {
			log.error(e);
			throw new ServiceLayerException("Error fetching list of All Designations",e);
		}
	}
	
	@Override
	public Designation getDesignation(Integer desgId) throws ServiceLayerException
	{
		log.debug("In method getDesignation in class DesignationServiceImpl");
		try {
			return designationDAO.getObject(Designation.class, desgId);
		} catch (BaseDAOException e) {
			log.error(e);
			throw new ServiceLayerException("Error while fetching designation with designationId Designations",e);
		}
	}

	@Override
	public void deleteDesignation(Integer desgId) throws ServiceLayerException 
	{
		log.debug("In method deleteDesignation in class DesignationServiceImpl");
		try {
			Designation designation = designationDAO.getObject(Designation.class, desgId);
			designationDAO.deleteDesignation(designation);
		} catch (Exception e) {
			log.error(e);
			throw new ServiceLayerException("Error while Deleting Designations",e);
		} 
	}

	@Override
	public void addDesignation(String desigName,Integer deptId) throws ServiceLayerException
	{
		log.debug("In method addDesignation in class DesignationServiceImpl");
		try {
			Designation designation = new Designation();
			designation.setDesignationType(desigName);
			Department dept = designationDAO.getObject(Department.class, deptId);
			designation.setDepartment(dept);
			designationDAO.addorUpdate(designation);
		} catch (DataFetchException e) {
			log.error(e);
			throw new ServiceLayerException("Error while adding Designation",e);
		} catch (BaseDAOException e) {
			log.error(e);
			throw new ServiceLayerException("Error while adding Designation in BaseDao",e);
		}
	}

	@Override
	public void updateDesignation(Integer desgId, String desigName,Integer deptId) throws ServiceLayerException 
	{
		log.debug("In method updateDesignation in class DesignationServiceImpl");
		try {
			Designation designation =designationDAO.getObject(Designation.class, desgId);
			designation.setDesignationType(desigName);
			Department department=designationDAO.getObject(Department.class, deptId);
			designation.setDepartment(department);
			designationDAO.addorUpdate(designation);
		} catch (Exception e) {
			log.error(e);
			throw new ServiceLayerException("Error updating Designation",e);
		}
	}
}
