package service;

import java.util.List;

import interfaces.IRoleDAO;


import interfaces.IRoleService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import exceptions.ServiceLayerException;
import pojos.Role;

@Service("roleService")
public class RoleServiceImpl implements IRoleService {
	

	private static Logger log = Logger.getLogger(RoleServiceImpl.class.getName());

	@Autowired
	private IRoleDAO roleDAO;
	
	public List<Role> getAllRoles() throws ServiceLayerException
	{
		log.debug("In Method getAllRoles In class RoleServiceImpl");
		try {
			return roleDAO.getAllRole();
		} catch (DataFetchException e) {
			log.error(e);
            throw new ServiceLayerException("Error while getting  All roles",e);
		}
	}

	@Override
	public Role getRole(Integer roleId) throws ServiceLayerException {
		
		log.debug("In Method getRole In class RoleServiceImpl");
		
		try {
			return roleDAO.getObject(Role.class, roleId);
		} catch (BaseDAOException e) {
			log.error(e);
            throw new ServiceLayerException("Error while getting role with roleId",e);
		}
	}

	@Override
	public void addRole(String roleName) throws ServiceLayerException 
	{
		
		log.debug("In Method addrole In class RoleServiceImpl");
		try {
			Role role = new Role();
			role.setRoleName(roleName);
			roleDAO.addorUpdateRole(role);
		} catch (DataFetchException e) {
			log.error(e);
            throw new ServiceLayerException("Error while adding Role",e);
		}
	}

	@Override
	public void deleteRole(Integer roleId) throws ServiceLayerException
	{
		
		log.debug("In Method deleteRole In class RoleServiceImpl");
		Role role;
		try {
			role = roleDAO.getObject(Role.class, roleId);
			roleDAO.deleteRole(role);
		} catch (Exception e) {
			log.error(e);
            throw new ServiceLayerException("Error while deleting Role",e);
		}
		
	}

	@Override
	public void updateRole(Integer roleId, String roleName) throws ServiceLayerException 
	{
		log.debug("In Method updateRole In class RoleServiceImpl");
		try {
			Role role = roleDAO.getObject(Role.class, roleId);
			role.setRoleName(roleName);
			roleDAO.addorUpdateRole(role);
		} catch (Exception e) {
			log.error(e);
            throw new ServiceLayerException("Error while updating Role",e);
		} 
	}
}
