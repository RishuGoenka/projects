package controllers;

import java.util.List;

import interfaces.IEventService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import pojos.Event;
import pojos.MailDetails;
import pojos.User;

public class SpocController extends MultiActionController {
	
	@Autowired
	private IEventService eventService;
	
	
	public ModelAndView status(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView model=new ModelAndView("eventStatus");
		Integer eventId=Integer.parseInt(request.getParameter("eventId"));
		List<MailDetails> mailDetails=eventService.getMailedUsersForEvent(eventId);
		model.addObject("mailDetails", mailDetails);
		for(MailDetails m:mailDetails){
			System.out.println(m.toString());
		}
		List<User> users=eventService.getUnMailedUsersForEvent(eventId);
		model.addObject("users", users);
		Event event= eventService.getRegisteredUsersForEvent(eventId);
		model.addObject("event", event);
		if(request.getParameter("loadScript")!=null){
			model.addObject("loadScript","yes" );
		}
		return model;
	}
	
	public ModelAndView events(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView model=new ModelAndView("spocPage");
		Integer departmentId=Integer.parseInt(request.getParameter("departmentId"));
		System.out.println(departmentId);
		
		List<Event> events= eventService.getAllEventsForDepartment(departmentId);
		model.addObject("events", events);
		return model;
	}
	
	

}
