package controllers;

import interfaces.IEventService;
import interfaces.IUserService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;




import com.zycus.management.sso.filter.SSOFilter;
import com.zycus.management.tenant.AuthenticatedUser;

import pojos.Event;
import pojos.User;


public class OtherController extends MultiActionController {
	
	@Autowired
	private IEventService eventService;
	
	@Autowired
	private IUserService userService;
	
	public ModelAndView getEventDetails(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView modelAndView=new ModelAndView("eventDetails");
		Integer eventId=Integer.parseInt(request.getParameter("eventId"));
		Event event= eventService.getRegisteredUsersForEvent(eventId);
		modelAndView.addObject("event",event);
		AuthenticatedUser authenticatedUser=(AuthenticatedUser) request.getSession().getAttribute(SSOFilter.AUTHENTICATED_USER);
		String userId=authenticatedUser.getUser().getId();
		User authUser=userService.getUserByHexId(userId);
		authUser=userService.getUserWithEventsByUserId(authUser.getUserId());
		modelAndView.addObject("user",authUser);
		return modelAndView;
	}
	
	public void registerForEvent(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		ModelAndView modelAndView = new ModelAndView("eventDetails");
		int eventId=Integer.parseInt(request.getParameter("eventId"));
		Event event= eventService.getRegisteredUsersForEvent(eventId);
		modelAndView.addObject("event",event);
		int userId=Integer.parseInt(request.getParameter("userId"));
		User user= userService.getUserWithEventsByUserId(userId);
		modelAndView.addObject("user",user);
		boolean status=eventService.registerUserToEvent(userId, eventId);
		if(status){
			response.getWriter().write("Registered Successfully");
		}
		else{
			response.getWriter().write("Something Went Wrong While Registering. Please check The Event status again To see If Registrations Are Full");
		}
			response.getWriter().flush();
		
	}
	
	
}
