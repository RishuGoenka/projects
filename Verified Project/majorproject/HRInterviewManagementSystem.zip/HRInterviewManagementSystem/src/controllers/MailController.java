package controllers;




import interfaces.IMailService;





import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;


public class MailController extends MultiActionController  {


	@Autowired
	@Qualifier("mailService")
	private IMailService mailService;

	public void mail(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String userIds = request.getParameter("users");
		Integer eventId=Integer.parseInt(request.getParameter("eventId"));
		Integer departmentId=Integer.parseInt(request.getParameter("departmentId"));
		String status=mailService.mailSelectedUsers(userIds, departmentId, eventId);

		response.setContentType("test/html");

		response.getWriter().write(status);
		response.getWriter().flush();


	}}
