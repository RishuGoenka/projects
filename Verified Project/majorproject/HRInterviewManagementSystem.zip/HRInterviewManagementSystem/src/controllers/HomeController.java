package controllers;

import interfaces.IUserService;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import pojos.User;

import com.zycus.management.authorization.Role;
import com.zycus.management.sso.filter.SSOFilter;
import com.zycus.management.tenant.AuthenticatedUser;
import com.zycus.management.tenant.TenantManagementSystem;


public class HomeController extends AbstractController {
	
	@Autowired
	private IUserService userService;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		AuthenticatedUser tmsUser = (AuthenticatedUser)request.getSession().getAttribute(SSOFilter.AUTHENTICATED_USER);
		ModelAndView modelAndView = null;
		Set<Role> setOfRoles=tmsUser.getUser().getUserAuthorizationContext("HRIMS").roles();
		for(Role role:setOfRoles){
			if(role.getName().equals("HR_USER")){
				modelAndView = new ModelAndView("redirect:/hr/hrPage.do");
				return modelAndView;
			}
			else if(role.getName().equals("SPOC_USER")){
				User user=userService.getUserByHexId(tmsUser.getUser().getId());
				System.out.println(tmsUser.getUser().getId());
				Integer departmentId=user.getDepartment().getDepartmentId();
				modelAndView = new ModelAndView("redirect:/spoc/events.do?departmentId="+departmentId);
				return modelAndView;
			}
			else if(role.getName().equals("ADMIN")){
				modelAndView = new ModelAndView("redirect:/admin/admin.do");
				return modelAndView;
			}
		}
		
			modelAndView = new ModelAndView("/other.do");
			return modelAndView;
		
		
	}
}