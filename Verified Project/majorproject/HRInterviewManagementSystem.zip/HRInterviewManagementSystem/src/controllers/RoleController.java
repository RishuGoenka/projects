package controllers;

import interfaces.IRoleService;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import pojos.Role;

public class RoleController extends MultiActionController {
	
	@Autowired
	private IRoleService roleService;
	
	
	public ModelAndView addRolePage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView model=new ModelAndView("addRole");
		return model;
	}
	
	public ModelAndView addRole(HttpServletRequest request,
			HttpServletResponse response) throws Exception {	
		String roleName = request.getParameter("roleName");
		if(request.getParameter("roleId")!= null)
		{
			int roleId = Integer.parseInt(request.getParameter("roleId"));
			roleService.updateRole(roleId, roleName);
		}
		else{
			roleService.addRole(roleName);
		}
		ModelAndView model=new ModelAndView("role");
		return model;

	}

	public ModelAndView getAllRole(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model = new ModelAndView("role");
		List<Role> roleList = roleService.getAllRoles();
		model.addObject("roleList",roleList);
		return model;
	}

	public ModelAndView updateRolePage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model=new ModelAndView("updateRole");
		int roleId = Integer.parseInt(request.getParameter("roleId"));
		Role role = roleService.getRole(roleId);
		model.addObject("Role", role);
		return model;
	}
	
	public ModelAndView deleteRole(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model=new ModelAndView("role");
		int roleId = Integer.parseInt(request.getParameter("roleId"));
		roleService.deleteRole(roleId);
		return model;
	}


}
