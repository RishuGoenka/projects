package controllers;


import interfaces.IDepartmentService;
import interfaces.IDesignationService;
import interfaces.IRoleService;
import interfaces.IUserService;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import pojos.Department;
import pojos.Designation;
import pojos.Role;
import pojos.User;


public class AdminController extends MultiActionController {

	@Autowired
	private IUserService userService;
	@Autowired
	private IDesignationService designationService;
	@Autowired
	private IDepartmentService departmentService;
	@Autowired
	private IRoleService roleService;

	public ModelAndView admin(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model=new ModelAndView("admin");
		return model;
	}

	//User Operations
	public ModelAndView addUser(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		System.out.println("aa gya meiiiii");
		String userName = request.getParameter("userName");
		String email = request.getParameter("email");
		long contactNo = Long.parseLong(request.getParameter("contact"));
		Integer department = Integer.parseInt(request.getParameter("department"));
		String[] designation = request.getParameterValues("designation");
		Integer roleId = Integer.parseInt(request.getParameter("role"));
		if(request.getParameter("userId")!= null)
		{
			Integer userId = Integer.parseInt(request.getParameter("userId"));
			userService.updateUser(userId,userName,email,contactNo,department,designation,roleId);
		}
		else
			userService.addUser(userName,email,contactNo,department,designation,roleId);
		return null;
	}

	public ModelAndView addUserPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model = new ModelAndView("addUser");
		List<Department> deptList = departmentService.getAllDepartments();
		List<Role> roleList = roleService.getAllRoles();
		model.addObject("deptList", deptList);
		model.addObject("roleList", roleList);
		return model;
	}

	public ModelAndView getAllUser(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model = new ModelAndView("user");
		System.out.println(userService);
		List<User> userList = userService.getAllUser();
		model.addObject("userList",userList);
		return model;
	}

	public ModelAndView deleteUser(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model=new ModelAndView("user");
		System.out.println(userService);
		Integer userId = Integer.parseInt(request.getParameter("userId"));
		userService.deleteUser(userId);
		return model;
	}

	public ModelAndView updateUserPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		System.out.println("updtae user page");
		ModelAndView model=new ModelAndView("updateUser");
		Integer userId = Integer.parseInt(request.getParameter("userId"));
		List<Department> deptList = departmentService.getAllDepartments();
		List<Role> roleList = roleService.getAllRoles();
		List<Designation> designationList = designationService.getAllDesignations();
		model.addObject("designationList",designationList);
		for(Designation d : designationList)
		{
			System.out.println(d.getDesignationType());
		}
		model.addObject("deptList", deptList);
		model.addObject("roleList", roleList);
		User user = userService.getUser(userId);
		model.addObject("User", user);
		return model;
	}


	
	

}
