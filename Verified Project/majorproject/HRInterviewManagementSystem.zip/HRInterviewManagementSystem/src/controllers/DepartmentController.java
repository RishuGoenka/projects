package controllers;

import interfaces.IDepartmentService;
import interfaces.IDesignationService;
import interfaces.IUserService;


import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;
import adapter.DesignationAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import pojos.Department;
import pojos.Designation;
import pojos.User;

public class DepartmentController extends MultiActionController {

	@Autowired
	private IDepartmentService departmentService;
	@Autowired
	private IUserService userService;
	@Autowired
	private IDesignationService designationService;
	
	public ModelAndView addDepartmentPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView model=new ModelAndView("addDepartment");
		List<User> users = userService.getAllUser();
		model.addObject("userList", users);
		return model;
	}
	
	public ModelAndView addDepartment(HttpServletRequest request,
			HttpServletResponse response) throws Exception {	
		
		String deptName = request.getParameter("departmentName");
		Integer hodId = Integer.parseInt(request.getParameter("hod")); 
		Integer spocId = Integer.parseInt(request.getParameter("spoc"));
		if(request.getParameter("deptId")!= null)
		{
			Integer deptId = Integer.parseInt(request.getParameter("deptId"));
			departmentService.addorUpdate(deptId, deptName, hodId, spocId);
		}
		else{
			departmentService.addorUpdate(deptName, hodId, spocId);
		}
		ModelAndView model=new ModelAndView("department");
		return model;

	}

	public ModelAndView getAllDepartment(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model = new ModelAndView("department");
		List<Department> deptList = departmentService.getAllDepartments();
		model.addObject("departments",deptList);
		return model;
	}

	public void getAllDesignation(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Integer deptId = Integer.parseInt(request.getParameter("deptId"));
		List<Designation> desigList = designationService.getAllDesignationsByDept(deptId);
		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson = gsonBuilder.registerTypeAdapter(Designation.class, new DesignationAdapter()).create();
		String desig = gson.toJson(desigList);
		response.getWriter().write(desig);
		response.getWriter().flush();

	}

	public ModelAndView updateDepartmentPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model=new ModelAndView("updateDepartment");
		Integer deptId = Integer.parseInt(request.getParameter("deptId"));
		Department dept = departmentService.getDepartment(deptId);
		model.addObject("department",dept);
		List<User> users = userService.getAllUser();
		model.addObject("userList", users);
		return model;
	}
	
	public ModelAndView deleteDepartment(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model=new ModelAndView("department");
		Integer deptId = Integer.parseInt(request.getParameter("deptId"));
		departmentService.deleteDepartment(deptId);
		return model;
	}
	
}
