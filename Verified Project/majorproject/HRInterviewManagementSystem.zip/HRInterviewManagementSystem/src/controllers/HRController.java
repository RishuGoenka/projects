package controllers;

import interfaces.IDepartmentService;
import interfaces.IDesignationService;
import interfaces.IEventService;
import interfaces.IMailService;
import interfaces.IUserService;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import adapter.DesignationAdapter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.zycus.management.sso.filter.SSOFilter;
import com.zycus.management.tenant.AuthenticatedUser;

import pojos.Department;
import pojos.Designation;
import pojos.Event;
import pojos.User;

public class HRController extends MultiActionController{


	@Autowired
	private IEventService eventService;

	@Autowired
	private IDepartmentService departmentService;

	@Autowired
	private IDesignationService designationService;

	@Autowired
	private IMailService mailService;

	@Autowired
	private IUserService userService;

	public ModelAndView hrPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		//	log.error("aaya");
		ModelAndView model=new ModelAndView("hrPage");
		return model;
	}

	public ModelAndView addEventPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		List<Department> departments=departmentService.getAllDepartments();
		request.setAttribute("departments", departments);
		List<Designation> designations=designationService.getAllDesignationsByDept(departments.get(0).getDepartmentId());
		request.setAttribute("designations", designations);
		RequestDispatcher dispatcher=request.getRequestDispatcher("/WEB-INF/jsp/addEvent.jsp");
		dispatcher.include(request, response);
		return null;
	}

	public void addEvent(HttpServletRequest request,
			HttpServletResponse response) throws Exception {


		String eventLocation=(request.getParameter("eventLocation"));
		String eventRound=(request.getParameter("eventRound"));
		String description=request.getParameter("description");
		Integer footfall;
		if(request.getParameter("footFall").length()==0)
			footfall=0;
		else
			footfall=Integer.parseInt(request.getParameter("footFall"));
		Department department=departmentService.getDepartment(Integer.parseInt(request.getParameter("department")));
		String[] desgs=request.getParameterValues("designations"); 
		Integer requiredMembers=(Integer.parseInt(request.getParameter("requiredMembers")));
		SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
		Date scheduledOn=sdf.parse(request.getParameter("scheduledOn"));
		Date scheduledTill=sdf.parse(request.getParameter("scheduledTill"));
		Integer eventId=eventService.addorUpdateEvent(description,eventLocation,eventRound,department,scheduledOn,scheduledTill,requiredMembers,desgs,footfall);
		AuthenticatedUser authenticatedUser=(AuthenticatedUser) request.getSession().getAttribute(SSOFilter.AUTHENTICATED_USER);
		String userId=authenticatedUser.getUser().getId();
		User from=userService.getUserByHexId(userId);
		User to=userService.getUser(department.getPointOfContact().getUserId());
		mailService.sendMailToUser(from, to, eventService.getEvent(eventId),"HR");
		mailService.updateSentmails(from, to, eventService.getEvent(eventId));
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.write("<html><body>Event added Successfully</body></html>");
		out.flush();
	}

	public ModelAndView listAllEvents(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		request.setAttribute("scheduledEvents", eventService.getAllScheduledEvents());
		request.setAttribute("ongoingEvents", eventService.getAllOngoingEvents());
		RequestDispatcher dispatcher=request.getRequestDispatcher("/WEB-INF/jsp/listAllEvents.jsp");
		dispatcher.include(request, response);
		return null;
	}

	public ModelAndView updateEventPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Integer eventId=Integer.parseInt(request.getParameter("eventId"));
		Event event=eventService.getEventFromEventId(eventId);
		request.setAttribute("event", event);
		System.out.println(event.getDescription());
		List<Department> departments=departmentService.getAllDepartments();
		request.setAttribute("departments", departments);
		List<Designation> designations=designationService.getAllDesignationsByDept(event.getDepartment().getDepartmentId());
		request.setAttribute("designations", designations);
		RequestDispatcher dispatcher=request.getRequestDispatcher("/WEB-INF/jsp/updateEvent.jsp");
		dispatcher.include(request, response);
		return null;
	}

	public ModelAndView updateEvent(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		Integer eventId=Integer.parseInt(request.getParameter("eventId"));
		String eventLocation=(request.getParameter("eventLocation"));
		String eventRound=(request.getParameter("eventRound"));
		String description=request.getParameter("description");
		Integer footfall;
		if(request.getParameter("footFall").length()==0)
			footfall=0;
		else
			footfall=Integer.parseInt(request.getParameter("footFall"));		
		Department department=departmentService.getDepartment(Integer.parseInt(request.getParameter("department")));
		String[] desgs=request.getParameterValues("designations"); 
		Integer requiredMembers=(Integer.parseInt(request.getParameter("requiredMembers")));
		SimpleDateFormat sdf=new SimpleDateFormat("MM/dd/yyyy");
		Date scheduledOn=sdf.parse(request.getParameter("scheduledOn"));
		Date scheduledTill=sdf.parse(request.getParameter("scheduledTill"));
		eventService.addorUpdateEvent(eventId,description,eventLocation,eventRound,department,scheduledOn,scheduledTill,requiredMembers,desgs,footfall);
		AuthenticatedUser authenticatedUser=(AuthenticatedUser) request.getSession().getAttribute(SSOFilter.AUTHENTICATED_USER);
		String userId=authenticatedUser.getUser().getId();
		User from=userService.getUserByHexId(userId);
		User to=userService.getUser(department.getPointOfContact().getUserId());
		mailService.sendMailToUser(from, to, eventService.getEvent(eventId),"HR");
		mailService.updateSentmails(from, to, eventService.getEvent(eventId));
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.print("<html><body>Event updated Successfully</body></html>");
		out.flush();
		return null;
	}

	public void getAllDesignation(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		System.out.println("Here it is");
		Integer deptId = Integer.parseInt(request.getParameter("deptId"));
		List<Designation> desigList = designationService.getAllDesignationsByDept(deptId);
		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson = gsonBuilder.registerTypeAdapter(Designation.class, new DesignationAdapter()).create();
		String desig = gson.toJson(desigList);
		response.getWriter().write(desig);
		response.getWriter().flush();

	}

}
