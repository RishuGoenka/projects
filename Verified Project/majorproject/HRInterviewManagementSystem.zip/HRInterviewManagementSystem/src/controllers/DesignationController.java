package controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import interfaces.IDepartmentService;
import interfaces.IDesignationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import pojos.Department;
import pojos.Designation;

public class DesignationController extends MultiActionController {

	@Autowired
	private IDesignationService designationService;
	@Autowired
	private IDepartmentService departmentService;
	
	public ModelAndView addDesignationPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		ModelAndView model=new ModelAndView("addDesignation");
		List<Department> deptList = departmentService.getAllDepartments();
		model.addObject("deptList", deptList);
		return model;
	}
	
	public ModelAndView addDesignation(HttpServletRequest request,
			HttpServletResponse response) throws Exception {	
	
		String desgName = request.getParameter("designationName");

		Integer deptId = Integer.parseInt(request.getParameter("department"));
		if(request.getParameter("desgId")!= null)
		{
			Integer desgId = Integer.parseInt(request.getParameter("desgId"));
			designationService.updateDesignation(desgId, desgName,deptId);
		}
		else{
			designationService.addDesignation(desgName,deptId);
		}
		ModelAndView model=new ModelAndView("designation");
		return model;

	}

	public ModelAndView getAllDesignation(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model = new ModelAndView("designation");
		List<Designation> designations = designationService.getAllDesignations();
		model.addObject("designationList",designations);
		return model;
	}

	public ModelAndView updateDesignationPage(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model=new ModelAndView("updateDesignation");
		Integer desgId = Integer.parseInt(request.getParameter("desgId"));
		Designation designation = designationService.getDesignation(desgId);
		model.addObject("designation",designation);
		List<Department> deptList = departmentService.getAllDepartments();
		model.addObject("deptList", deptList);
		return model;
	}
	
	public ModelAndView deleteDesignation(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView model=new ModelAndView("designation");
		Integer desgId = Integer.parseInt(request.getParameter("desgId"));
		designationService.deleteDesignation(desgId);
		return model;
	}
	
}
