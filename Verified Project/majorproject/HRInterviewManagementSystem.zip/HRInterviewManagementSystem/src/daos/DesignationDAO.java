package daos;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import pojos.Designation;
import interfaces.IDesignationDAO;

@Repository("designationDAO")
@Transactional
public class DesignationDAO extends BaseDAO implements  IDesignationDAO {

	private static Logger log = Logger.getLogger(DesignationDAO.class.getName());


	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<Designation> getAllDesignations() throws DataFetchException{

		Session session= sessionFactory.getCurrentSession();
		log.debug("In method getAllDesignations in class DesignationDAO");
		try {
			Query query=session.createQuery("from Designation d left join fetch d.department");
			List<Designation> designations= query.list();
			return  designations;
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getAllDesignations in class DesignationDAO",e);

		}
		
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Designation> getAllDesignations(Integer deptId) throws DataFetchException{

		Session session= sessionFactory.getCurrentSession();
		log.debug("In method getAllDesignations in class DesignationDAO");
		try {
			Query query=session.createQuery("from Designation d where d.department=:deptId");
			query.setInteger("deptId", deptId);
			List<Designation> designations= query.list();
			return  designations;
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getAllDesignations in class DesignationDAO",e);

		}
		
	}

	@Override
	public Designation getDesignation(int desgId) throws DataFetchException
	{	
		Session session= sessionFactory.getCurrentSession();
		log.debug("In method getDesignation in class DesignationDAO");
		try{
			Query query=session.createQuery("from Designation d join fetch d.department");
			return (Designation) query.uniqueResult();
		}catch(HibernateException e){
			log.error(e);
			throw new DataFetchException("Error in method getDesignation in class DesignationDAO",e);
		}
		
		
	}
	
	@Override
	public void addorUpdate(Designation designation) throws DataFetchException {
		
		log.debug("In method addorUpdate in class DesignationDAO");
		try {
			saveOrUpdate(designation);
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method addorUpdate in class DesignationDAO",e);
		}	
		catch (BaseDAOException e) {
			log.error(e);
			throw new DataFetchException("Error in method addOrUpdate in class BaseDAO",e);
		}
	}

	@Override
	public void deleteDesignation(Designation designation) throws DataFetchException {
		
		log.debug("In method deleteDesignation in class DesignationDAO");
		try {
			deleteObject(designation);
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method deleteDesignation in class DesignationDAO",e);
		}
		catch (BaseDAOException e) {
			log.error(e);
			throw new DataFetchException("Error in method delete in class BaseDAO",e);
		}
		
	}
	
	@Override
	public Designation getDesignationByNameAndId(String designationType,Integer departmentId) throws DataFetchException {

		Query query = null;
		log.debug("In method getDesignationByName in class DesignationDAO");
		try{
			Session session = sessionFactory.getCurrentSession();
			query = session.createQuery("from Designation d where d.designationType =:designationtype and d.department.departmentId=:departmentId ");
			query.setString("designationtype", designationType);
			query.setInteger("departmentId", departmentId);
			return (Designation) query.uniqueResult();

		}
		catch(HibernateException e)
		{
			log.error(e);
			throw new DataFetchException("Error in method getDesignationByName in class DesignationDAO",e);
		}
		
	}

}
