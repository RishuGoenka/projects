package daos;

import interfaces.IRoleDAO;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import pojos.Role;

@Repository("roleDAO")
@Transactional
public class RoleDAO extends BaseDAO implements IRoleDAO{

	@Autowired
	private SessionFactory sessionFactory;
	private static Logger log = Logger.getLogger(EventDAO.class.getName());
	
	public void addorUpdateRole(Role role) throws DataFetchException
	{
		log.debug("In method addorUpdateRole in class RoleDAO");
		try 
		{
			saveOrUpdate(role);
		} 
		catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method addorUpdateRole in class RoleDAO",e);
		}
		catch (BaseDAOException e) {
			log.error(e);
			throw new DataFetchException("Error in method getObject in class BaseDAO",e);
		}
		
	}
	
	public void deleteRole( Role role) throws DataFetchException
	{
		log.debug("In method deleteRole in class RoleDAO");
		try {
			deleteObject(role);
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method deleteRole in class RoleDAO",e);
		}
		catch (BaseDAOException e) {
			log.error(e);
			throw new DataFetchException("Error in method getObject in class BaseDAO",e);
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<Role> getAllRole() throws DataFetchException
	{
		Query query=null;
		log.debug("In method getAllRole in class RoleDAO");
		try {
			Session session = sessionFactory.getCurrentSession();
			query = session.createQuery("from Role");
			return query.list();
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getAllRole in class RoleDAO",e);
		}
		
	}
	
	@Override
	public Role getRoleByName(String roleName) throws DataFetchException{
		Query query=null;
		log.debug("In method getRoleByName in class RoleDAO");
		try {
			Session session=sessionFactory.getCurrentSession();
			query =session.createQuery("from Role where roleName=:roleName");
			query.setString("roleName", roleName);

		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getRoleByName in class RoleDAO",e);
		}
		return (Role) query.list().get(0);
	}
}
