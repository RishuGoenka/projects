package daos;

import interfaces.IDepartmentDAO;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import pojos.Department;
import pojos.User;

@Repository("departmentDAO")
@Transactional
public class DepartmentDAO extends BaseDAO implements IDepartmentDAO {


	private static Logger log = Logger.getLogger(DepartmentDAO.class.getName());

	@Autowired
	private SessionFactory sessionFactory;
	

	@Override
	public User getSpocForDepartment(Integer departmentId) throws DataFetchException{
		log.debug("In method getSpocForDepartment in class DepartmentDAO");
		try {
			Session session=sessionFactory.getCurrentSession();
			Query query=session.createQuery("from Department d "
					+ "left join fetch d.pointOfContact where  d.departmentId=:departmentId");
			query.setInteger("departmentId", departmentId);
			Department department= (Department) query.uniqueResult();
			return department.getPointOfContact();
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getSpocForDepartment in class DepartmentDAO",e);
		}
	}

	@Override
	public User getHodForDepartment(Integer departmentId) throws DataFetchException{
		log.debug("In method getHodForDepartment in class DepartmentDAO");
		try {
			Session session=sessionFactory.getCurrentSession();
			Query query=session.createQuery("from Department d "
					+ "left join fetch d.headOfDepartment where  d.departmentId=:departmentId");
			query.setInteger("departmentId", departmentId);
			Department department= (Department) query.uniqueResult();
			return department.getPointOfContact();
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getHodForDepartment in class DepartmentDAO",e);
		}
	}

	public void addorUpdate(Department department) throws DataFetchException
	{
		log.debug("In method addOrUpdate in class DepartmentDAO");
		try {
			saveOrUpdate(department);
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method addOrUpdate in class DepartmentDAO",e);
		} catch (BaseDAOException e) {
			log.error(e);
			throw new DataFetchException("Error in method addOrUpdate in class BaseDAO",e);
		}
	}
	

	@Override
	public void deleteDepartment(Department dept) throws DataFetchException
	{
		log.debug("In method deleteDepartment in class DepartmentDAO");
		try {
			deleteObject(dept);
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method deleteDepartment in class DepartmentDAO",e);
		} catch (BaseDAOException e) {
			log.error(e);
			throw new DataFetchException("Error in method deleteObject in class BaseDAO",e);
		}
	}
	
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Department> getAllDepartment() throws DataFetchException
	{
		log.debug("In method getAllDepartment in class DepartmentDAO");
		Query query = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			 query = session.createQuery("from Department d join fetch d.headOfDepartment join fetch d.pointOfContact ");
			 return query.list();
			
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getAllDepartment in class DepartmentDAO",e);
		}
		
	}

	@Override
	public Department getDept(String deptName) throws DataFetchException {
		
		log.debug("In method getDept in class DepartmentDAO");
			Query query=null;
			try {
				Session session=sessionFactory.getCurrentSession();
				query =session.createQuery("from Department d where d.departmentName =:departmentName");
				query.setString("departmentName", deptName);

				return (Department) query.uniqueResult();
				
			} catch (HibernateException e) {
				log.error(e);
				throw new DataFetchException("Error in method getDept in class DepartmentDAO",e);
			}
		}
}

