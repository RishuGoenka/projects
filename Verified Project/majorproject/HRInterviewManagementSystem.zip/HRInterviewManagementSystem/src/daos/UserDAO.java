package daos;


import interfaces.IUserDAO;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import pojos.User;

@Repository("userDAO")
@Transactional
public class UserDAO extends BaseDAO implements IUserDAO {

	@Autowired
	private SessionFactory sessionFactory;
	private static Logger log = Logger.getLogger(EventDAO.class.getName());
	
	@Override
	@SuppressWarnings("unchecked")
	public List<User> getAllUsersByUserId(List<Integer> userIds) throws DataFetchException{
		log.debug("In method getAllUsersByUserId in class UserDAO");
		try {
			Session session=sessionFactory.getCurrentSession();
			StringBuffer query=new StringBuffer();
			query.append("from User u where u.userId in (");
			for(Integer integer : userIds){
				query.append(" :user"+integer+",");
			}
			String qry="";
			if(query.toString().endsWith(",")){
				qry=query.substring(0, query.length()-1);				
			}
			qry+=")";
			Query HQLQuery=session.createQuery(qry);
			for(int index=0;index<userIds.size(); index++){
				HQLQuery.setInteger("user"+userIds.get(index), userIds.get(index));
			}

			return HQLQuery.list();
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getAllUsersByUserId in class UserDAO",e);
		}
			
	}
	
	public void addorUpdateUser( User user) throws DataFetchException
	{
		log.debug("In method addorUpdateUser in class UserDAO");
		try {
			saveOrUpdate(user);
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method addorUpdateUser in class UserDAO",e);
		}
		catch (BaseDAOException e) {
			log.error(e);
			throw new DataFetchException("Error in method getObject in class BaseDAO",e);
		}
	}
	
	public void deleteUser( User user) throws DataFetchException
	{
		log.debug("In method deleteUser in class UserDAO");
		try {
			deleteObject(user);
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method deleteUser in class UserDAO",e);
		}	
		catch (BaseDAOException e) {
			log.error(e);
			throw new DataFetchException("Error in method getObject in class BaseDAO",e);
		}
	}
	
	@SuppressWarnings("unchecked")
	public List<User> getAllUser() throws DataFetchException
	{
		Query query=null;
		log.debug("In method getAllUser in class UserDAO");
		try {
			Session session = sessionFactory.getCurrentSession();
			query = session.createQuery("from User");
			return query.list(); 
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getAllUser in class UserDAO",e);
		}
		
	}
	
	public User getUser(User user) throws DataFetchException
	{
		Query query=null;
		log.debug("In method getUser in class UserDAO");
		try {
			Session session = sessionFactory.getCurrentSession();
			query = session.createQuery("from User u left join fetch u.designations where u.userId =:userId ");
			query.setInteger("userId", user.getUserId());
			return (User)query.uniqueResult();
			
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getUser in class UserDAO",e);
		}
		
	}

	@Override
	public User getUserByHexId(String userId) throws DataFetchException {
		Query query=null;
		log.debug("In method getUserByHexCode in class UserDAO");
		try {
			Session session = sessionFactory.getCurrentSession();
			query = session.createQuery("from User u where u.hexCode =:userHexCode");
			query.setString("userHexCode", userId);
			return (User)query.uniqueResult();
			
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getUserByHexId in class UserDAO",e);
		}
		
	}
	
	@Override
	public User getUserWithEventsByUserId(Integer userId ) throws DataFetchException{
		Session session=sessionFactory.getCurrentSession();
		log.debug("In method getRegisteredUsersForEvent in class EventDAO");
		try {
			Query query=session.createQuery("from User u left join fetch u.events where u.userId=:userId");
			query.setInteger("userId", userId);
			return (User) query.uniqueResult();
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getRegisteredUsersForEvent in class EventDAO",e);
		}
	}
	
}
