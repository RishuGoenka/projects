package daos;

import interfaces.IEventDAO;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sun.org.apache.bcel.internal.generic.GETSTATIC;

import exceptions.BaseDAOException;
import exceptions.DataFetchException;
import pojos.Department;
import pojos.Event;
import pojos.MailDetails;
import pojos.User;

@Repository("eventDAO")
@Transactional
public class EventDAO extends BaseDAO implements IEventDAO  {

	private static Logger log = Logger.getLogger(EventDAO.class.getName());


	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;	
	
	@Override
	public Event getRegisteredUsersForEvent(Event event) throws DataFetchException{

		Session session=sessionFactory.getCurrentSession();
		log.debug("In method getRegisteredUsersForEvent in class EventDAO");
		try {
			Query query=session.createQuery("from Event e join fetch e.department left join fetch e.registeredUsers where e.eventId=:eventId");
			query.setInteger("eventId", event.getEventId());
			return (Event) query.uniqueResult();
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getRegisteredUsersForEvent in class EventDAO",e);

		}
	
	}
	@Override
	@SuppressWarnings("unchecked")
	public List<MailDetails> getMailedUsersForEvent(Event event) throws DataFetchException{

		Session session=sessionFactory.getCurrentSession();
		log.debug("In method getMailedUsersForEvent in class EventDAO");
		User spoc=null;
		
		try {
			event=this.getObject(Event.class, event.getEventId());
			spoc=this.getObject(User.class, event.getDepartment().getPointOfContact().getUserId());
			 
			Query query=session.createQuery("select distinct md from MailDetails md left join fetch md.contactedUser u "
					+ "left join fetch u.designations where md.event=:event and md.sentBy=:spoc");
			query.setEntity("event", event);
			query.setEntity("spoc", spoc);
			return  query.list();
		} catch (Exception e) {
			log.error(e);
			throw new DataFetchException("Error in method getMailedUsersForEvent in class EventDAO",e);

		}
	
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<User> getUnMailedUsersForEvent(Event event) throws DataFetchException{
		Session session= sessionFactory.getCurrentSession();
		log.debug("In method getUnMailedUsersForEvent in class EventDAO");
		try {
			String requiredDesignations=event.getRequiredDesignations();
			System.out.println(requiredDesignations);
			Query query=session.createQuery("select distinct u from User u left join fetch u.designations where u.department=:department and u.userId not in"
					+ "(select m.contactedUser.userId from MailDetails m where m.event=:event  )");
			query.setEntity("department", event.getDepartment());
			query.setEntity("event", event);
			return  query.list();
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getUnMailedUsersForEvent in class EventDAO",e);
		}
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Event> getAllScheduledEventsForDepartment(Department department) throws DataFetchException{
		log.debug("In method getAllScheduledEventsForDepartment in class EventDAO");
		try{
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Event e where e.scheduledTill >= :currentDate and e.department = :department");
			query.setDate("currentDate",new Date());
			query.setEntity("department",department);
			return query.list();
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getAllScheduledEventsForDepartment in class EventDAO",e);
		}
		
	}
	
	@Override
	public Integer addorUpdateEvent (Event event) throws DataFetchException
	{	
		Session session=sessionFactory.getCurrentSession();
		log.debug("In method addorUpdateEvent in class EventDAO");
		try {
			session.merge(event);
			Query query = session.createQuery("select max(e.eventId) from Event e");
			Integer eventId= (Integer) query.uniqueResult();
			return eventId;
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method addorUpdateEvent in class EventDAO",e);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Event> getAllScheduledEvents() throws DataFetchException{
		log.debug("In method getAllScheduledEvents in class EventDAO");
		try{
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Event e join fetch e.department where e.scheduledOn > :date ");
			query.setDate("date",new Date());
			return query.list();
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getAllScheduledEvents in class EventDAO",e);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Event> getAllOngoingEvents() throws DataFetchException{
		log.debug("In method getAllOngoingEvents in class EventDAO");
		try{
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from Event e join fetch e.department where e.scheduledTill >= :date and e.scheduledOn <= :date1");
			query.setDate("date",new Date());
			query.setDate("date1",new Date());
			return query.list();
		} catch (HibernateException e) {
			log.error(e);
			throw new DataFetchException("Error in method getAllOngoingEvents in class EventDAO",e);
		}
	}
	
/*	@Override
	public User registerUserToEvent(User user) throws DataFetchException{

		log.debug("In method registerUserToEvent in class EventDAO");
		try {
			Session session = sessionFactory.getCurrentSession();
			Query query = session.createQuery("from User u join fetch u.events where u.userId = :userId");
			query.setInteger("userId",user.getUserId());
			return (User) query.uniqueResult();
			
		} catch (Exception e) {
			log.error(e);
			throw new DataFetchException("Error while registering user to event",e);
		}

	}*/
}
