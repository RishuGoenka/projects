package daos;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import exceptions.BaseDAOException;

@Repository("baseDAO")
@Transactional
public class BaseDAO {
	
	private static Logger log = Logger.getLogger(BaseDAO.class.getName());
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void saveOrUpdate(Object obj) throws BaseDAOException{
		
		log.debug("In Method saveOrUpdate In class BaseDAO");
		
		try {
			Session session=sessionFactory.getCurrentSession();		
			session.merge(obj);
		} catch (HibernateException e) {
			log.error(e);
			throw new BaseDAOException("Error while saveOrUpdate In BaseDAO",e);
		}
		
	}

	@SuppressWarnings("unchecked")
	public <T> T getObject(Class<T> className,Serializable pk) throws BaseDAOException{
		
		log.debug("In Method getObject In class BaseDAO");
		try {
			Session session=sessionFactory.getCurrentSession();		
			return (T)session.get(className, pk);
		} catch (HibernateException e) {
			log.error(e);
			throw new BaseDAOException("Error while getObject In BaseDAO",e);
		}

	}
	
	public void deleteObject(Object obj) throws BaseDAOException{
		
		log.debug("In Method deleteObject In class BaseDAO");
		try {
			Session session=sessionFactory.getCurrentSession();		
			session.delete(obj);
		} catch (HibernateException e) {
			log.error(e);
			throw new BaseDAOException("Error while deleteObject In BaseDAO",e);
		}
		
	}
}
