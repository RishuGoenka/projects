$(document).ready(function(){

	$("body").on("click", "#user", function(){

		var url="../admin/getAllUser.do";
		$("#grid").load(url);
		$("#grid").show();
		$("#forms").hide();
	});

	$("body").on("click", "#role", function(){

		var url="../role/getAllRole.do";
		$("#grid").load(url);
		$("#grid").show();
		$("#forms").hide();
	});

	$("body").on("click", "#designation", function(){

		var url="../desg/getAllDesignation.do";
		$("#grid").load(url);
		$("#grid").show();
		$("#forms").hide();
	});

	$("body").on("click", "#department", function(){

		var url="../dept/getAllDepartment.do";
		$("#grid").load(url);
		$("#grid").show();
		$("#forms").hide();
	});

	$("body").on("click", "#dept1", function(){

		var deptId=$(this).val();
	
		var url="../dept/getAllDesignation.do?deptId="+encodeURIComponent(deptId);
		$.getJSON(url,function(data){
			$("#desg").html("");
			$.each(data, function (index, designation) {
				$("#desg").append('<option value="'+designation.desig_id+'">'+designation.desig_name+'</option>');				
			});
			$("#desgSelection").show();
		});
	});
	

	$("body").on("click", ".role", function(){
		var roleFunction = $(this).attr("value");
		if(roleFunction == "updateRolePage")
		{
			var roleId=$(this).attr("id");
			var url="../role/updateRolePage.do?roleId="+encodeURIComponent(roleId);
			$("#forms").load(url);
			$("#grid").show();
			$("#forms").show();
		}
		else if(roleFunction == "deleteRole")
		{
			var roleId=$(this).attr("id");
			var url="../role/deleteRole.do?roleId="+encodeURIComponent(roleId);
			$("#forms").load(url,function(data){
				$("#forms").hide();
				$("#grid").load("../role/getAllRole.do");
				alert(data);
				$("#grid").show();
			});
		}
		else if(roleFunction == "saveRole")
		{
			if( validateRoleForm() == true)
			{
				var roleName = $("#roleName").val();
				var url="../role/addRole.do?roleName="+encodeURIComponent(roleName);
				$("#forms").load(url,function(data){
					$("#forms").hide();
					$("#grid").load("../role/getAllRole.do");
					$("#grid").show();
				});
			}

		}
		else if(roleFunction == "addRole")
		{

			var url="../role/addRolePage.do";
			$("#forms").load(url);
			$("#grid").show();
			$("#forms").show();
		}
		else if(roleFunction == "updateRole")
		{
			var roleId=$(this).attr("id");
			var roleName = $("#roleName").val();
			var url="../role/addRole.do?roleName="+encodeURIComponent(roleName)+"&roleId="+encodeURIComponent(roleId);
			$("#forms").load(url,function(data){
				$("#forms").hide();
				$("#grid").load("../role/getAllRole.do");
				$("#grid").show();
			});
		}


	});

	$("body").on("click", ".user", function(){

		var userFunction = $(this).attr("value");
		if(userFunction == "updateUserPage")
		{
			var userId = $(this).attr("id");
			var url="../admin/updateUserPage.do?userId="+encodeURIComponent(userId);
			$("#forms").load(url);
			$("#grid").show();
			$("#forms").show();
		}
		else if(userFunction == "deleteUser")
		{
			var userId = $(this).attr("id");
			var url="./deleteUser.do?userId="+encodeURIComponent(userId);
			$("#forms").load(url,function(data){
				$("#forms").hide();
				$("#grid").load("../admin/getAllUser.do");
				alert(data);
				$("#grid").show();
			});

		}

		else if(userFunction == "addUser")
		{
			var url="./addUserPage.do";
			$("#forms").load(url);
			$("#grid").show();
			$("#forms").show();
		}
		else if(userFunction == "updateUser")
		{
			var userId=$(this).attr("id");
			var form=$("#updateForm");
			var data=form.serialize();
			var url="./addUser.do?userId="+encodeURIComponent(userId)+"&"+data;
			$("#forms").load(url,function(data){
				$("#forms").hide();
				$("#grid").load("../admin/getAllUser.do");
				$("#grid").show();
			});

		}



	});

	$("body").on("click", ".designation", function(){

		var desgFunction = $(this).attr("value");
		if(desgFunction == "updateDesignationPage")
		{
			var desgId = $(this).attr("id");
			var url="../desg/updateDesignationPage.do?desgId="+encodeURIComponent(desgId);
			$("#forms").load(url);
			$("#grid").show();
			$("#forms").show();
		}
		else if(desgFunction == "deleteDesignation")
		{
			var desgId = $(this).attr("id");
			var url="../desg/deleteDesignation.do?desgId="+encodeURIComponent(desgId);
			$("#forms").load(url,function(data){
				$("#forms").hide();
				$("#grid").load("../desg/getAllDesignation.do");
				alert(data);
				$("#grid").show();
			});
		}
		else if(desgFunction == "saveDesignation")
		{
			if(validateDesigForm() == true)
			{
				var form=$("#Desig");
				var data=form.serialize();
				var url="../desg/addDesignation.do?"+data;
				$("#forms").load(url,function(data){
					$("#forms").hide();
					$("#grid").load("../desg/getAllDesignation.do");
					$("#grid").show();
				});
			}

		}
		else if(desgFunction == "addDesignation")
		{
			var url="../desg/addDesignationPage.do";
			$("#forms").load(url);
			$("#forms").show();
		}
		else if(desgFunction == "updateDesignation")
		{
			var form=$("#updateDesig");
			var data=form.serialize();
			var desgId=$(this).attr("id");
			var url="../desg/addDesignation.do?desgId="+desgId+"&"+data;
			$("#forms").load(url,function(data){
				$("#forms").hide();
				$("#grid").load("../desg/getAllDesignation.do");
				$("#grid").show();
			});
		}


	});

	$("body").on("click", "#saveUser", function(){
		if( validateUser() == true)
		{
			var form=$("#addUserForm");
			var data=form.serialize();
			var url="/HRInterviewManagementSystem/admin/addUser.do?"+data;
			$("#forms").load(url,function(data){
				$("#forms").hide();
				$("#grid").load("../admin/getAllUser.do");
				$("#grid").show();
			});
		}

	});

	$("body").on("click", ".department", function(){

		var deptFunction = $(this).attr("value");
		if(deptFunction == "updateDepartmentPage")
		{
			var deptId = $(this).attr("id");
			var url="../dept/updateDepartmentPage.do?deptId="+encodeURIComponent(deptId);
			$("#forms").load(url);
			$("#grid").show();
			$("#forms").show();
		}
		else if(deptFunction == "deleteDepartment")
		{
			var deptId = $(this).attr("id");
			var url="../dept/deleteDepartment.do?deptId="+encodeURIComponent(deptId);
			$("#forms").load(url,function(data){
				$("#forms").hide();
				$("#grid").load("../dept/getAllDepartment.do");
				alert(data);
				$("#grid").show();
			});
		}
		else if(deptFunction == "saveDepartment")
		{
			if( validateDeptForm() == true)
			{
				var form = $("#Dept").serialize();
				var url="../dept/addDepartment.do?"+form;
				$("#forms").load(url,function(data){
					$("#forms").hide();
					$("#grid").load("../dept/getAllDepartment.do");
					$("#grid").show();
				});
			}

		}
		else if(deptFunction == "addDepartment")
		{
			var url="../dept/addDepartmentPage.do";
			$("#forms").load(url);
			$("#forms").show();
		}
		else if(deptFunction == "updateDepartment")
		{
			var deptId=$(this).attr("id");
			var data = $("#updateDept").serialize();
			var url="../dept/addDepartment.do?deptId="+encodeURIComponent(deptId)+"&"+data;
			$("#forms").load(url,function(data){
				$("#forms").hide();
				$("#grid").load("../dept/getAllDepartment.do");
				$("#grid").show();
			});
		}
	});
	
});
