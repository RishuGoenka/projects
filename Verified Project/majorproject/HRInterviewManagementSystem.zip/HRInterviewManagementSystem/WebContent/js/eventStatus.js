
$(document).ready(function(){	
		$("body").on("click", "#submitCheckedUsers", function(){
			var userIds =$('input:checkbox[name=unMailedUsers]:checked');
			if(userIds.length!=0){
				
				var eventId =$("#eventId").val();
				var departmentId =$("#departmentId").val();
				var data = "users=";
				$(userIds.each(function() {
					data+=($(this).val()+",");
				}));
				
				var url="/HRInterviewManagementSystem/mail/mail.do?eventId="+encodeURIComponent(eventId)+"&departmentId="+encodeURIComponent(departmentId);
				$.post(url,data,function(data){		
					eventId =$("#eventId").val();
					departmentId =$("#departmentId").val();
					var url="/HRInterviewManagementSystem/spoc/status.do?eventId="+encodeURIComponent(eventId)+"&loadScript=no";	
					$("#eventStatus").load(url,function(data1){				   
						alert("Mails Sent To Checked Users");
					});

				});
				
			}
			else{
				alert("Please check Atleast 1 Employee To Send email");				
			}
			
		});
});
			