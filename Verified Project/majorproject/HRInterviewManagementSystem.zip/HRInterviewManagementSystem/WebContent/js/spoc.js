$(document).ready(function(){
			$("body").on("click", ".events", function(){
					
				   var eventId =$(this).attr("id");
				   var url="/HRInterviewManagementSystem/spoc/status.do?eventId="+encodeURIComponent(eventId)+"&loadScript=no";		
				   $("#eventStatuss").load(url);
			 });
});

