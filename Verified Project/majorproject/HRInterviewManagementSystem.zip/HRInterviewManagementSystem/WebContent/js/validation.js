function validateUser(){

	var form = document.getElementById("addUserForm");
	var errors = [];

	if ( !checkUserName(form.userName.value) ) {
		errors[errors.length] = "Please Enter Correct user Name of Length 5-20 characters";
	}
	if(!checkUserEmail(form.email.value)){
		errors[errors.length]="Please Enter Correct Email(abc@zycus.net) .";

	}
	if(!checkUserContact(form.contact.value)){
		errors[errors.length]="Please Enter Contact No. of 10 digits ."; 					
	}
	if(!checkDesignation()){
		errors[errors.length]="Please Select atleast one Designation ."; 					
	}

	if (errors.length > 0) {
		reportErrors(errors);
		return false;
	}

	return true;
}

function validateDeptForm(){

	var form = document.getElementById("Dept");
	var errors = [];

	if ( !checkUserName(form.departmentName.value) ) {
		errors[errors.length] = "Please Enter Correct Department Name of Length 9-20 characters";
	}

	if (errors.length > 0) {
		reportErrors(errors);
		return false;
	}

	return true;
}

function validateDesigForm(){

	var form = document.getElementById("Desig");
	var errors = [];

	if ( !checkDesignationName(form.designationName.value) ) {
		errors[errors.length] = "Please Enter Correct Designation of Length 9-20 characters";
	}

	if (errors.length > 0) {
		reportErrors(errors);
		return false;
	}

	return true;
}

function validateRoleForm(){

	var form = document.getElementById("Role");
	var errors = [];

	if ( !checkRoleName(form.roleName.value) ) {
		errors[errors.length] = "Please Enter Correct Role of Length 9-20 characters";
	}

	if (errors.length > 0) {
		reportErrors(errors);
		return false;
	}

	return true;
}



function checkDesignationName(desgName){

	var name =  /^[A-Za-z\s]{5,20}$/; 
	if(!desgName.match(name) ){
		return false;
	}
	return true;
}

function checkUserName(userName){

	var name =  /^[A-Za-z][A-Za-z.\s]{3,20}$/; 
	if(!userName.match(name) ){
		return false;
	}
	return true;
}

function checkUserEmail(Email){

	var email = /^[a-zA-Z][a-zA-Z0-9._-]{0,20}[a-zA-Z0-9]@zycus.net$/;
	if(!Email.match(email) ){
		return false;
	}
	return true;
}

function checkUserContact(Contact){

	var contact = /^[0-9]{10}$/; 
	if(!Contact.match(contact) ){
		return false;
	}
	return true;
}

function checkDesignation(){

	var designation = document.getElementById("desg");
	if(designation.value!="") {
		return true;
	}

	return false;
}

function checkDepartmentName(deptName){

	var name =  /^[A-Za-z]{5,20}$/; 
	if(!deptName.match(name) ){
		return false;
	}
	return true;
}

function checkDesignationName(desgName){

	var name =  /^[A-Za-z][A-Za-z\s]{5,20}$/; 
	if(!desgName.match(name) ){
		return false;
	}
	return true;
}

function checkRoleName(roleName){

	var name =  /^[A-Za-z\s_-]{5,20}$/; 
	if(!roleName.match(name) ){
		return false;
	}
	return true;
}


function reportErrors(errors){
	var msg = "There were some problems...\n";
	var numError;
	for (var i = 0; i<errors.length; i++) {
		numError = i + 1;
		msg += "\n" + numError + ". " + errors[i];
	}
	alert(msg);
}
