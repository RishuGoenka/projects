function validateAddEvent(){

	var form = document.getElementById("formToValidate");
	var errors = [];

	if(!checkScheduledOn(form.scheduledOn.value)){
		if(new Date(form.scheduledOn.value)<new Date())
			errors[errors.length]="Date On should be greater than Today's Date";
		else
			errors[errors.length]="Enter Proper Date for Date From field"; 	
	}

	if(!checkScheduledTill(form.scheduledTill.value)){
		if(new Date(form.scheduledTill.value)<new Date(form.scheduledOn.value))
			errors[errors.length]="Date Till Should be greater than Date From";
		else if(new Date(form.scheduledTill.value)<new Date())
			errors[errors.length]="Date Till Should be greater than Today's Date";
		else
			errors[errors.length]="Enter Proper Date for Date Till field"; 	
	}

	if ( !checkDescription(form.description.value) ) {
		errors[errors.length] = "Please Enter Correct description between 8-20 characters";
	}

	if(!checkDesignation()){
		errors[errors.length]="Please Select atleast one Designation ."; 					
	}

	if(!checkRequiredMembers(form.requiredMembers.value)){
		errors[errors.length]="Please Enter Correct No of Required Members";
	}

	if(!checkEventLocation(form.eventLocation.value)){
		errors[errors.length]="Please Enter Correct Location."; 					
	}

	if(!checkDepartment()){
		errors[errors.length]="Please Enter a Department"; 	
	}

	if(!checkEventRound(form.eventRound.value)){
		errors[errors.length]="Please Enter Correct Event Round"; 	
	}

	if(!checkFootFall(form.footFall.value)){
		errors[errors.length]="Please Enter Correct FootFall"; 	
	}

	if (errors.length > 0) {
		reportErrors(errors);
		return false;
	}

	return true;
}

function checkScheduledOn(scheduledOn){
	var name = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(20)\d\d$/;
	if(scheduledOn.match(name)) {
		if(new Date(scheduledOn)<new Date()){
			alert("Date On should be greater than Today's Date");
			return false;
		}
		return true;
	}
	return false;

}

function checkScheduledTill(scheduledTill){
	var scheduledOn = document.getElementById("scheduledOn");
	var name = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(20)\d\d$/;
	if(!scheduledTill.match(name)) {
		return false;
	}else{
		fromdate = scheduledOn.value;
		todate = scheduledTill;
		date1 = new Date(fromdate);
		date2 = new Date(todate);
		if (date2<date1) {
			alert("To date Should be greater than From date");
			return false;
		}
		if(date2<new Date()){
			alert("Date Till should be greater than Today's Date");
			return false;
		}
	}
	return true;
}

function checkDesignation(){

	var designation = document.getElementById("desg");
	if(designation.value!="") {
		return true;
	}

	return false;
}

function checkDescription(description){

	var name = /^[a-zA-Z0-9 ]{8,50}$/; 
	if(description.match(name)){
		return true;
	}

	return false;
}

function checkRequiredMembers(requiredMembers){

	var name = /^[1-9]$/;
	if(requiredMembers.match(name)) {
		return true;
	}

	return false;
}

function checkDepartment(){

	var department = document.getElementById("dept");
	if(department.value!="") {
		return true;
	}

	return false;
}

function checkEventLocation(location){

	var name = /^[a-zA-Z ]{3,50}$/;
	if(location.match(name)) {
		return true;
	}
	return false;

}

function checkEventRound(round){

	var name = /^[1-5]$/;
	if(round.match(name)) {
		return true;
	}

	return false;

}

function checkFootFall(footFall){

	var name = /^([0-9]{1,3})|()$/;
	if(footFall.match(name)) {
		return true;
	}
	return false;
}

function reportErrors(errors){
	var msg = "There were some problems...\n";
	var numError;
	for (var i = 0; i<errors.length; i++) {
		numError = i + 1;
		msg += "\n" + numError + ". " + errors[i];
	}
	alert(msg);
}