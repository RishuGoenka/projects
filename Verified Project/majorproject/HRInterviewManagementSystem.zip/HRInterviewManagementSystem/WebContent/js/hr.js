
$(document).ready(function(){
	$("body").on("click", "#addEvent", function(){
		jQuery.ajax({
			async:false,
			cache:false,
			url:"/HRInterviewManagementSystem/hr/addEventPage.do",
			success:function(data){
				jQuery('#main').html(data);
					jQuery( "#scheduledOn" ).datepicker();
					jQuery( "#scheduledTill" ).datepicker();
			}
		});
		//$('#main').load(url);
	});
	
	$("body").on("click", "#dept1", function(){
		
		var deptId=$(this).val();
		var url="/HRInterviewManagementSystem/hr/getAllDesignation.do?deptId="+encodeURIComponent(deptId);
		$.getJSON(url,function(data){
			$("#desg").empty();
			$.each(data, function (index, designation) {
				$("#desg").append('<option value="'+designation.desig_id+'">'+designation.desig_name+'</option>');});
		});
	});
	
	$("body").on("click", "#listAllEvents", function(){
		var url="/HRInterviewManagementSystem/hr/listAllEvents.do";
		$('#main').load(url);
	});
	
	
	$("body").on("click", "#submitEvent", function(){
	    var form = $('.addEventForm');
	    var var_form_data=form.serialize();
	    if(validateAddEvent()){
	    	var url="/HRInterviewManagementSystem/hr/addEvent.do?"+var_form_data;
	    	$('#main').load(url);
	    }
	});
	
	$("body").on("click", "#updateEvent", function(){
	    var updateId = $(this).attr("value");
	    var url="/HRInterviewManagementSystem/hr/updateEventPage.do?eventId="+encodeURIComponent(updateId);
	    $("#eventUpdationForm").load(url,function(data){
			jQuery( "#scheduledOn" ).datepicker();
			jQuery( "#scheduledTill" ).datepicker();	
		});
	});
	
	$("body").on("click", "#update", function(){
	    var form = $('.updateEventForm');
	    var var_form_data=form.serialize();
	    var url="/HRInterviewManagementSystem/hr/updateEvent.do?"+var_form_data;
	    if(validateAddEvent()){
	    $("#eventUpdationForm").load(url,function(){
	     url="/HRInterviewManagementSystem/hr/listAllEvents.do";
			$('#main').load(url);	    
	    });
	    }
	});
});
	