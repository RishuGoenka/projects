
$(document).ready(function(){

	$("body").on("click", "#registerForEvent", function(){

		var userId=$('.user').attr("id");
		var eventId=$(this).val();
		var url="/HRInterviewManagementSystem/other/registerForEvent.do?userId="+encodeURIComponent(userId)+"&eventId="+encodeURIComponent(eventId);
		$('#registrationStatus').load(url,function(data){

			url="/HRInterviewManagementSystem/other/getEventDetails.do?eventId="+encodeURIComponent(eventId);
			$("#eventStatus").load(url,function(){
				alert(data);
			});
		});
	});

});