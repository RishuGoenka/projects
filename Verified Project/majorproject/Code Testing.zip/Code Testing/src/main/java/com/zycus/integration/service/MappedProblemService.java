package com.zycus.integration.service;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.integration.dao.MappedProblemsDAO;
import com.zycus.integration.model.MappedProblems;
import com.zycus.integration.model.ProblemSet;
import com.zycus.problem.model.Problem;

@Service
public class MappedProblemService {
	@Autowired
	MappedProblemsDAO mappedProblemDao;
	
	/**
	 * map each problem to problem set
	 * @param problem
	 * @param problemSet
	 */
	public void addMappedProblem(Problem problem,ProblemSet problemSet){
		MappedProblems mappedProblems = new MappedProblems(problem, problemSet);
		mappedProblemDao.save(mappedProblems);
	}
	
	/**
	 * map list of problems to a problem set
	 * @param problems
	 * @param problemSet
	 */
	public void addProblemsList(Set<Problem> problems,ProblemSet problemSet){
		for (Problem problem : problems) {
			addMappedProblem(problem, problemSet);
		}
	}
	
	/**
	 * find Problems in problem set by shared id 
	 * @param sharedId
	 * @return list of problems
	 */
	public List<Problem> findBySharedId(String sharedId) {
		return mappedProblemDao.findProblemBySharedId(sharedId); 
	}
	
	/**
	 * find all problem set containing a problem
	 * @param problemId
	 * @return list of problem set
	 */
	public List<ProblemSet> findProblemSetByProblemId(int problemId){
		return mappedProblemDao.findProblemSetsByProblemId(problemId);
	}
	
	/**
	 * find Problems in problem set by problem set id 
	 * @param problem set id 
	 * @return list of problems
	 */

	public Set<Problem> findProblemInSet(int problemSetId) {
		
		return mappedProblemDao.findProblemByProblemSetId(problemSetId);
	}

	public boolean validateProblemId(int problemSetId,int problemId) {
		
	
		List<ProblemSet> problemSetList = findProblemSetByProblemId(problemId);
		for (ProblemSet problemSet : problemSetList) {
			if (problemSet.getProblemSetId() == problemSetId) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * delete each problem to problem set
	 * @param problem
	 * @param problemSet
	 */
	public boolean deleteMappedProblem(ProblemSet problemSet,Problem problem){
		return mappedProblemDao.delete(problemSet,problem);
	}
	
	/**
	 * find mappedProblems by problem set id and problem id
	 * @param problem
	 * @param problemSet
	 */
	public MappedProblems findByIds(ProblemSet problemSet,Problem problem){		
		return mappedProblemDao.findByIDs(problemSet.getProblemSetId(), problem.getProblemId());
	}	
}
