package com.zycus.integration.dao;

import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.zycus.integration.model.MappedProblems;
import com.zycus.integration.model.ProblemSet;
import com.zycus.problem.model.Problem;

@Repository
public interface MappedProblemsDAO {
	public abstract boolean save(MappedProblems mappedProblems);
	public abstract List<Problem> findProblemBySharedId(String sharedId);
	public abstract Set<Problem> findProblemByProblemSetId(int problemSetId);
	public abstract List<ProblemSet> findProblemSetsByProblemId(int problemId);
	public abstract MappedProblems findByIDs(int problemSet,int problem);
	public abstract boolean delete(ProblemSet problemSet, Problem problem);
}
