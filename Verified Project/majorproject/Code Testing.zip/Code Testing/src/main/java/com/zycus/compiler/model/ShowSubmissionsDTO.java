package com.zycus.compiler.model;

public class ShowSubmissionsDTO {

private int submissionId;
private int problemId;
private int testId;
private int userId;
private int submissionNumber;
public int getSubmissionId() {
	return submissionId;
}
public void setSubmissionId(int submissionId) {
	this.submissionId = submissionId;
}
public int getProblemId() {
	return problemId;
}
public void setProblemId(int problemId) {
	this.problemId = problemId;
}

public int getTestId() {
	return testId;
}
public void setTestId(int testId) {
	this.testId = testId;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public int getSubmissionNumber() {
	return submissionNumber;
}
public void setSubmissionNumber(int submissionNumber) {
	this.submissionNumber = submissionNumber;
}

public ShowSubmissionsDTO(int submissionId, int problemId, int testId,
		int userId, int submissionNumber) {
	super();
	this.submissionId = submissionId;
	this.problemId = problemId;
	this.testId = testId;
	this.userId = userId;
	this.submissionNumber = submissionNumber;
}
public ShowSubmissionsDTO() {
	super();
}
@Override
public String toString() {
	return "ShowSubmissionsDTO [submissionId=" + submissionId + ", problemId="
			+ problemId + ", testId=" + testId + ", userId=" + userId
			+ ", submissionNumber=" + submissionNumber + "]";
}



}
