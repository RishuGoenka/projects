package com.zycus.problem.dao;

import java.util.List;

import com.zycus.problem.model.Problem;
import com.zycus.problem.model.TestCase;

public interface TestCaseDAO {

	public abstract void add(TestCase testcase);

	public abstract void update(TestCase testcase);

	public abstract void delete(TestCase testcase);
	
	public abstract void deleteByProblem(Problem problem); 

	public abstract TestCase getByID(int testcaseID);

	public abstract List<String> getInputByProblem(int problemId);

	public abstract List<String> getOutputByProblem(int Problem);

	public abstract List<TestCase> getTestCaseByProblem(int problem_id);

}