package com.zycus.compiler.service;

import java.util.List;

import com.zycus.compiler.model.UserSubmission;
import com.zycus.integration.model.UserTest;

public interface UserSubmissionService {

	public abstract UserSubmission getById(int submissionId);

	public abstract void saveUserSubmission(UserSubmission submission);

	public abstract void deleteUserSubmission(UserSubmission submission);

	public abstract int getLatestVersionForUserForProblem(int problemId,
			UserTest userTest);

	public abstract UserSubmission findByUserTestAndProblemId(int problemId,
			UserTest userTest);

	public abstract UserSubmission findByUserTestProblemIdVersionNumber(
			int problemId, UserTest userTest, int versionNumber);

	public abstract List<UserSubmission> getAllUserSubmission(int problemId,
			UserTest userTest);

}