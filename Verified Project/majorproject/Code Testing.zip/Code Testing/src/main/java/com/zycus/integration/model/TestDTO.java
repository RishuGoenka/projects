package com.zycus.integration.model;

import java.util.Set;

import com.zycus.problem.model.Problem;


public class TestDTO {
	
	private ProblemSet problemSet;
	
	private Set<Problem> setOfProblems;

	public TestDTO() {
		// TODO Auto-generated constructor stub
	}

	public ProblemSet getProblemSet() {
		return problemSet;
	}

	public void setProblemSet(ProblemSet problemSet) {
		this.problemSet = problemSet;
	}

	public Set<Problem> getSetOfProblems() {
		return setOfProblems;
	}

	public void setSetOfProblems(Set<Problem> setOfProblems) {
		this.setOfProblems = setOfProblems;
	}

	public TestDTO(ProblemSet problemSet, Set<Problem> setOfProblems) {
		super();
		this.problemSet = problemSet;
		this.setOfProblems = setOfProblems;
	}

	

	
}
