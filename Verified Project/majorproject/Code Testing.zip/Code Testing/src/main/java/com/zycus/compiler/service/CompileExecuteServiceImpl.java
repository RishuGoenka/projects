package com.zycus.compiler.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.zycus.compiler.model.Result;
import com.zycus.compiler.utility.PathUtil;
import com.zycus.compiler.utility.StatusEnum;

@Service
public class CompileExecuteServiceImpl implements CompileExecuteService {
	private final String CONFIG_LOCATION = "C:" + File.separator
			+ "Program Files" + File.separator + "Apache Software Foundation"
			+ File.separator + "Tomcat 7.0" + File.separator + "Files"
			+ File.separator + "config" + File.separator + "Run.java";

	private final long TIMEOUT_IN_MILLISECONDS = 3000l;

	@Override
	public StatusEnum compile() {
		ProcessBuilder p = new ProcessBuilder("javac", "Run.java");
		setProperties(p);
		try {
			return compileResult(p, true);
		} catch (IOException | InterruptedException e) {
			System.out.println("in compile() " + e);
		}
		return StatusEnum.COMPILE_ERROR;
	}

	/*
	 * (non-Javadoc) Executes the command in the process builder and checks for
	 * errors
	 * 
	 * @return the StatusEnum of the compilation whether successfull or not
	 */
	private StatusEnum compileResult(ProcessBuilder p, boolean compiled)
			throws IOException, InterruptedException {
		Process pp = p.start();
		InputStream is = pp.getInputStream();
		compiled = getErrorIfAny(compiled, is);
		pp.waitFor();
		is.close();
		if (!compiled)
			return StatusEnum.COMPILE_ERROR;
		return StatusEnum.COMPILE_SUCCESS;
	}

	/*
	 * (non-Javadoc)
	 * @return true if the compilation was successfull, false otherwise
	 */
	private boolean getErrorIfAny(boolean compiled, InputStream is)
			throws IOException {
		String temp;
		BufferedReader b = new BufferedReader(new InputStreamReader(is));
		while ((temp = b.readLine()) != null) {
			compiled = false;
			System.out.println(temp);
		}
		return compiled;
	}

	
	@Override
	public Result execute(String input, String output) throws Exception {
		ProcessBuilder p = new ProcessBuilder("java", "Run");
		setProperties(p);
		try {
			return runResult(input, output, p);
		} catch (IOException | InterruptedException ioe) {
			System.err.println("in execute() " + ioe);
		}
		return null;
	}

	/*
	 * (non-Javadoc)
	 * Executes the program and calculates the time taken by the program
	 * @return the result object with all attributes of the executed program 
	 * 
	 */
	private Result runResult(String input, String output, ProcessBuilder p)
			throws Exception, InterruptedException {
		long startTime = System.nanoTime();
		Process process = runProgram(p, input);
		long endTime = System.nanoTime();
		if (process.exitValue() != 0)
			return getResultObject(
					(long) ((endTime - startTime) / (Math.pow(10, 3))), 0, 0L);
		else {
			return successfullyCompiled(output, startTime, process, endTime);
		}
	}

	private Result successfullyCompiled(String output, long startTime,
			Process process, long endTime) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(
				process.getInputStream()));
		List<String> outputs = new ArrayList<String>();
		getListOfOutputs(br, outputs);
		long memoryUsed = Long.parseLong(outputs.get(outputs.size() - 1));
		return resultOfExecution(output, startTime, endTime, br, outputs, memoryUsed);
	}

	private Result resultOfExecution(String output, long startTime, long endTime,
			BufferedReader br, List<String> outputs, long memoryUsed)
			throws IOException {
		if (outputs.size() > 1) {
			br.close();
			String programOutput = getProgramOutput(outputs);
			int testCasebit = isTestCasePass(output, programOutput);
			return getResultObject(
					(long) ((endTime - startTime) / (Math.pow(10, 3))),
					testCasebit, memoryUsed);
		} else {
			return getResultObject(
					(long) ((endTime - startTime) / (Math.pow(10, 3))), 0,
					memoryUsed);
		}
	}

	private String getProgramOutput(List<String> outputs) {
		StringBuilder output = new StringBuilder();
		for (int i = 0; i < outputs.size() - 1; i++) {
			output.append(outputs.get(i));
		}
		return output.toString();
	}

	private void getListOfOutputs(BufferedReader br, List<String> outputs)
			throws IOException {
		String out = br.readLine();
		outputs.add(out);
		try {
			while (!out.equals(null)) {
				out = br.readLine();
				if (!out.equals(null))
					outputs.add(out);
			}
		} catch (Exception e) {
		}
	}

	private void setProperties(ProcessBuilder p) {
		p.directory(new File(PathUtil.getPath()));
		p.redirectErrorStream(true);
	}

	private Process runProgram(ProcessBuilder p, String input)
			throws Exception, InterruptedException {
		Process process;
		process = p.start();
		OutputStream outputStream = process.getOutputStream();
		outputStream.write(input.getBytes());
		outputStream.flush();
		outputStream.close();

		synchronized (process) {
			process.wait(TIMEOUT_IN_MILLISECONDS);
		}
		try {
			process.exitValue();
		} catch (IllegalThreadStateException ex) {
			process.destroy();
		}

		return process;
	}

	private int isTestCasePass(String output, String result) {
		int testCasebit = 0;
		if (result.equals(output))
			testCasebit = 1;
		return testCasebit;
	}

	private Result getResultObject(long timeTaken, int testCasebit,
			long memoryUsed) {
		Result result = new Result();
		result.setTestCasebit(testCasebit);
		result.setMemoryConsumed(memoryUsed);
		result.setTimeTaken(timeTaken);
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.zycus.service.CompileExecuteService2#saveCode(java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public void saveCode(String code, String path) throws InterruptedException,
			IOException {
		initializeEnvironment(path);
		File file = new File(path + "Main.java");
		FileWriter fw = new FileWriter(file);
		fw.write(code);
		fw.close();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.zycus.service.CompileExecuteService2#initializeEnvironment(java.lang
	 * .String)
	 */
	@Override
	public void initializeEnvironment(String path) throws IOException {
		File destination = new File(path + "Run.java");
		File source = new File(this.CONFIG_LOCATION);
		Files.copy(source.toPath(), destination.toPath(),
				StandardCopyOption.REPLACE_EXISTING);
	}

}
