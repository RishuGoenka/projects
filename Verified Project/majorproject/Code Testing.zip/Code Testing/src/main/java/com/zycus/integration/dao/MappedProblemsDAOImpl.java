package com.zycus.integration.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.integration.model.MappedProblems;
import com.zycus.integration.model.ProblemSet;
import com.zycus.problem.model.Problem;

@Transactional
@Repository
public class MappedProblemsDAOImpl implements MappedProblemsDAO {

	@PersistenceContext
	EntityManager manager;

	public MappedProblemsDAOImpl() {
		// TODO Auto-generated constructor stub

	}

	/**
	 * Save Mapped Problem
	 * 
	 * @param mappedProblems
	 */
	@Override
	public boolean save(MappedProblems mappedProblems) {
		try {
			manager.persist(mappedProblems);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * find the test by id
	 * 
	 * @param sharedId
	 * @return List of Problem
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<Problem> findProblemBySharedId(String sharedId) {

		List<Problem> problems = (List<Problem>) manager
				.createQuery(
						"Select p.problem from MappedProblems p where p.problemSet.sharedId =:sharedId")
				.setParameter("sharedId", sharedId).getResultList();
		return problems;

	}

	/**
	 * Find a List of problem set by problem id
	 * 
	 * @param problemSetId
	 * @return problem set
	 */
	@Override
	public List<ProblemSet> findProblemSetsByProblemId(int problemId) {
		@SuppressWarnings("unchecked")
		List<ProblemSet> problemSet = (List<ProblemSet>) manager
				.createQuery(
						"Select p.problemSet from MappedProblems p where p.problem.problemId =:problemId")
				.setParameter("problemId", problemId).getResultList();
		return problemSet;
	}

	/**
	 * find the problems in problem set by id
	 * 
	 * @param problemSetId
	 * @return List of Problem
	 */

	@Override
	public Set<Problem> findProblemByProblemSetId(int problemSetId) {
		@SuppressWarnings("unchecked")
		Set<Problem> problems = new HashSet<Problem>( manager
				.createQuery(
						"Select p.problem from MappedProblems p where p.problemSet.problemSetId =:problemSetId")
				.setParameter("problemSetId", problemSetId).getResultList());
		return problems;
	}

	@Override
	public boolean delete(ProblemSet problemSet,Problem problem) {
		
		List<MappedProblems> mappedProblems = manager.createQuery(""
				+ "select m from MappedProblems m where m.problemSet.problemSetId =:problemSetId and m.problem.problemId =:problemId")
				.setParameter("problemSetId", problemSet.getProblemSetId())
				.setParameter("problemId", problem.getProblemId())
				.getResultList();
		
		
		if(mappedProblems.size()<1){
			return false;
		}else{
			
			manager.remove(mappedProblems.get(0));
			return true;
		}
}

	@Override
	public MappedProblems findByIDs(int problemSetId, int problemId) {
		
		List<MappedProblems> mappedProblems = manager.createQuery(""
				+ "select m from MappedProblems m where m.problemSet.problemSetId =:problemSetId and m.problem.problemId =:problemId")
				.setParameter("problemSetId", problemSetId)
				.setParameter("problemId", problemId)
				.getResultList();
		if(mappedProblems.size()<1){
			return null;
		}else
			return mappedProblems.get(0);
	}

}
