package com.zycus.integration.model;

import java.util.List;

import com.zycus.compiler.model.Result;

public class ResultDTO {

	
	public List<Result> testCases;
	


	public List<Result> getTestCases() {
		return testCases;
	}

	public void setTestCases(List<Result> testCases) {
		this.testCases = testCases;
	}

	
}
