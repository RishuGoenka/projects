package com.zycus.compiler.service;

import java.io.IOException;

import com.zycus.compiler.model.Result;
import com.zycus.compiler.utility.StatusEnum;

public interface CompileExecuteService {

	/**
	 * Compiles the program
	 * @return if the compilation succeeded or failed
	 */
	public abstract StatusEnum compile();

	/**
	 * Executes the program
	 * @param input
	 * @param output
	 * @return result object with all attributes
	 * @throws IOException
	 * @throws Exception
	 */
	public abstract Result execute(String input,
			String output) throws IOException, Exception;

	/**
	 * Saves the code in the path specified
	 * @param code
	 * @param path
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws Exception
	 */
	public abstract void saveCode(String code, String path) throws IOException,
			InterruptedException, Exception;

	/**
	 * Initialize the required environment for execution
	 * @param path
	 * @throws IOException
	 * @throws Exception
	 */
	public abstract void initializeEnvironment(String path) throws IOException, Exception;

}