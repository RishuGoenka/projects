package com.zycus.compiler.model;

import java.util.List;

import com.zycus.integration.model.User;
import com.zycus.problem.model.Problem;

public class CompleteResult {

	private int submissionId;
	private User user;
	private int versionNumber;
	private List<Problem> problems;

	public int getSubmissionId() {
		return submissionId;
	}

	public void setSubmissionId(int submissionId) {
		this.submissionId = submissionId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}

	public List<Problem> getProblems() {
		return problems;
	}

	public void setProblems(List<Problem> problems) {
		this.problems = problems;
	}

	public CompleteResult(int submissionId, User user, int versionNumber,
			List<Problem> problems) {
		super();
		this.submissionId = submissionId;
		this.user = user;
		this.versionNumber = versionNumber;
		this.problems = problems;
	}

	public CompleteResult() {
		super();
	}

	@Override
	public String toString() {
		return "CompleteResult [submissionId=" + submissionId + ", user="
				+ user + ", versionNumber=" + versionNumber + ", problems="
				+ problems + "]";
	}


}
