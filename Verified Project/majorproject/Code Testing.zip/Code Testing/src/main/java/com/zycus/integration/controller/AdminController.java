package com.zycus.integration.controller;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.zycus.compiler.model.Result;
import com.zycus.compiler.model.UserSubmission;
import com.zycus.compiler.service.UserSubmissionService;
import com.zycus.compiler.service.client.ResultAndUserSubmissionService;
import com.zycus.integration.dao.DataTableDAO;
import com.zycus.integration.model.ProblemSet;
import com.zycus.integration.model.ProblemSetDataTableParam;
import com.zycus.integration.model.ReportDTO;
import com.zycus.integration.model.ResultDTO;
import com.zycus.integration.model.TestDTO;
import com.zycus.integration.service.*;
import com.zycus.integration.utility.ProblemSetDataTablesParamUtility;

@Controller
@RequestMapping(value = "/admin")
public class AdminController {

	@Autowired
	private SubmissionScoreService submissionScoreService;

	@Autowired
	private ProblemSetService problemSetService;

	@Autowired
	private MappedProblemService mappedProblemService;

	@Autowired
	private UserSubmissionService userSubmissionService;

	@Autowired
	private UserTestService userTestService;

	@Autowired
	private UserService userService;

	@Autowired
	private ResultAndUserSubmissionService resultService;

	@Autowired
	private DataTableService dataTableService;

	@RequestMapping(value = "/report")
	public String viewReport() {

		return "admin/report";
	}

	/**
	 * @return
	 */
	@RequestMapping(value = "/admin_home")
	public ModelAndView viewAdminHome() {
		ModelAndView modelAndView =  new ModelAndView( "admin/admin_home");
		long totalUser = userService.getNoOfUsers();
		long totalProblems= dataTableService.sizeOfProblems();
		long totalTests = problemSetService.sizeOfProblemSet();
		modelAndView.addObject("totaluser", totalUser);
		modelAndView.addObject("totalproblems", totalProblems);
		modelAndView.addObject("totalTests", totalTests);
		return modelAndView;
	}

	/**
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/report/get")
	@ResponseBody
	public List<ReportDTO> getReport(HttpServletRequest request,
			HttpServletResponse response) {

		String sharedId = request.getParameter("sharedId");
		int maxResults = Integer.parseInt(request.getParameter("noOfResults"));
		String searchType = request.getParameter("searchType");
		String search = request.getParameter("search");

		ProblemSet problemSet = problemSetService
				.findProblemSetBySharedId(sharedId);

		if (problemSet == null) {

			return null;
		}

		if (searchType.equals("top"))

			return submissionScoreService.getReportList(
					problemSet.getProblemSetId(), maxResults);
		else

			return submissionScoreService.searchReportListByUsernameOrEmail(
					problemSet.getProblemSetId(), search);
	}

	/**
	 * @param request
	 * @param response
	 * @return TestDTO
	 */
	@RequestMapping(value = "/test/get")
	@ResponseBody
	public TestDTO getTest(HttpServletRequest request,
			HttpServletResponse response) {

		String problemSetIdString = request.getParameter("problemSetId");
		int problemSetId = Integer.parseInt(problemSetIdString);

		ProblemSet problemSet = problemSetService
				.findProblemSetById(problemSetId);

		if (problemSet == null) {

			return null;
		}

		TestDTO testDTO = new TestDTO();

		testDTO.setProblemSet(problemSet);
		testDTO.setSetOfProblems(mappedProblemService
				.findProblemInSet(problemSetId));

		System.out.println(testDTO.getSetOfProblems());
		return testDTO;
	}

	@RequestMapping(value = "/viewtest", method = RequestMethod.GET)
	public ModelAndView viewTest(HttpServletRequest request,
			HttpServletResponse response) {

		int problemSetId = Integer.parseInt(request
				.getParameter("problemSetId"));
		ModelAndView modelAndView = new ModelAndView("/admin/view-test");

		modelAndView.addObject("problemSetId", problemSetId);
		return modelAndView;

	}

	@RequestMapping(value = "/viewTestList", method = RequestMethod.GET)
	public ModelAndView viewTestList(HttpServletRequest request) {

		ModelAndView modelAndView = new ModelAndView("/admin/view-test-list");

		String msg = (String) request.getAttribute("msg");
		
		if(msg != null && !msg.isEmpty()){
			modelAndView.addObject("msg",msg);
			System.out.println("message :"+msg);
		}
		return modelAndView;

	}

	/**
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping(path = "/getTestList", method = RequestMethod.GET)
	public void findProblemSetLists(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		System.out.println("Hello in controller");
		ProblemSetDataTableParam param = ProblemSetDataTablesParamUtility
				.getParam(request);

		String sEcho = param.sEcho;
		int iTotalRecords; // total number of records (unfiltered)
		int iTotalDisplayRecords; // value will be set when code filters
									// companies by keyword

		// find sorting column index
		final int sortColumnIndex = param.iSortColumnIndex;

		// set sort direction
		final String sortDirection = param.sSortDirection.equals("asc") ? "desc"
				: "asc";

		// find total records in database
		iTotalRecords = (int) problemSetService.sizeOfProblemSet();

		List<ProblemSet> problemsets = new LinkedList<ProblemSet>();

		String columns[] = { "problemSetName", "sharedId", "duration" };
		if (param.sSearch == "") {
			problemsets = problemSetService.noSearch(param, sortColumnIndex,
					sortDirection, columns);
			iTotalDisplayRecords = iTotalRecords;
		} else {
			iTotalDisplayRecords = (int) problemSetService.searchCount(
					param.sSearch, param.iDisplayLength, param.iDisplayStart,
					sortDirection, sortColumnIndex, columns);
			problemsets = problemSetService.newSearch(param, sortColumnIndex,
					sortDirection, columns);
		}

		try {
			JsonObject jsonResponse = new JsonObject();
			jsonResponse.addProperty("sEcho", sEcho);
			jsonResponse.addProperty("iTotalRecords", iTotalRecords);
			jsonResponse.addProperty("iTotalDisplayRecords",
					iTotalDisplayRecords);
			Gson gson = new Gson();
			jsonResponse.add("aaData", gson.toJsonTree(problemsets));

			response.setContentType("application/Json");
			response.getWriter().print(jsonResponse.toString());
			System.out.println("Json response " + jsonResponse);
		} catch (JsonIOException e) {
			e.printStackTrace();
			response.setContentType("text/html");
			response.getWriter().print(e.getMessage());
		}
	}

	/**
	 * Shows result page
	 * 
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/view_result", method = RequestMethod.GET)
	public ModelAndView viewResult(HttpServletRequest request,
			HttpServletResponse response) throws Exception {

		ModelAndView mv = new ModelAndView("admin/result");

		String submissionId = request.getParameter("submissionId");

		UserSubmission userSubmission = userSubmissionService.getById(Integer
				.parseInt(submissionId));

		if (userSubmission == null) {

			return new ModelAndView("forward:/admin/report");
		}

		int problemSetId = userSubmission.getUserTest().getProblemSet()
				.getProblemSetId();
		int userId = userService.getCurrentLoggedInUserId();

		long remTime = userTestService.getRemainingTime(userTestService
				.findUserTest(userId, problemSetId));

		mv.addObject("submissionId", submissionId);
		mv.addObject("problemSetId", request.getParameter("problemSetId"));
		mv.addObject("sharedId", userSubmission.getUserTest().getProblemSet()
				.getSharedId());
		mv.addObject("remTime", remTime);
		mv.addObject("problemId", userSubmission.getProblem().getProblemId());
		return mv;
	}

	/**
	 * Returns a JSON array of result list
	 * 
	 * @param submissionId
	 * @return
	 */
	@RequestMapping(value = "/result/get/{id}", method = RequestMethod.GET)
	public @ResponseBody ResultDTO getResultList(
			@PathVariable("id") int problemSetId) {

		List<Result> testCases = resultService
				.getResultByProblemSetId(problemSetId);

		ResultDTO resultDTO = new ResultDTO();

		resultDTO.setTestCases(testCases);

		return resultDTO;
	}
	
	
}
