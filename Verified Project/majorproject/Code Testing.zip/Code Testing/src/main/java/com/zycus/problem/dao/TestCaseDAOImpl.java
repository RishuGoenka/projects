package com.zycus.problem.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.problem.model.Problem;
import com.zycus.problem.model.TestCase;

@Repository
@Transactional
public class TestCaseDAOImpl implements TestCaseDAO {
	
	@PersistenceContext
	private EntityManager manager;

	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.TestCaseDAO#add(com.zycus.model.TestCase)
	 */
	@Override
	public void add(TestCase testcase) {
		manager.persist(testcase);
	}

	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.TestCaseDAO#update(com.zycus.model.TestCase)
	 */
	@Override
	public void update(TestCase testcase) {
		manager.createQuery(
				"update testcase set input=?, output=?, problem=? where testCaseID=?")
				.setParameter(1, testcase.getInput())
				.setParameter(2, testcase.getOutput())
				.setParameter(3, testcase.getProblem()).executeUpdate();
	}

	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.TestCaseDAO#delete(com.zycus.model.TestCase)
	 */
	@Override
	public void delete(TestCase testcase) {
		manager.remove(manager.merge(testcase));
	}
	
	@Override
	public void deleteByProblem(Problem problem) {
		manager.createQuery(
				"delete from TestCase t where t.problem.problemId=?")
				.setParameter(1, problem.getProblemId()).executeUpdate();
	}

	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.TestCaseDAO#getByID(int)
	 */
	@Override
	public TestCase getByID(int testcaseID) {
		return (TestCase) manager.find(TestCase.class, testcaseID);
	}

	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.TestCaseDAO#getInputByProblem(int)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<String> getInputByProblem(int problemId) {
		return manager
				.createQuery(
						"Select t.input  From TestCase t where t.problem.problemId=?")
				.setParameter(1, problemId).getResultList();
	}

	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.TestCaseDAO#getOutputByProblem(int)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<String> getOutputByProblem(int problemId) {
		return manager
				.createQuery(
						"Select t.output From TestCase t where t.problem.problemId=?")
				.setParameter(1, problemId).getResultList();
	}
	
	/* (non-Javadoc)
	 * @see com.zycus.dao.impl.TestCaseDAO#getTestCaseByProblem(int)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public List<TestCase> getTestCaseByProblem(int problemId)
	{
		return manager
				.createQuery(
						"Select t From TestCase t where t.problem.problemId=?")
				.setParameter(1, problemId).getResultList();
	}

}
