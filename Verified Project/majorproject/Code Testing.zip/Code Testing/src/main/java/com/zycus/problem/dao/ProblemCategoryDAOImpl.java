package com.zycus.problem.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.problem.model.ProblemCategory;

@Repository
@Transactional
public class ProblemCategoryDAOImpl implements ProblemCategoryDAO {

	@PersistenceContext
	private EntityManager manager;

	@Override
	public List<ProblemCategory> getAllCategory() {
		return manager.createQuery(
				"Select category From ProblemCategory category",
				ProblemCategory.class).getResultList();
	}

	@Override
	public ProblemCategory getById(int categoryId) {
		return (ProblemCategory) manager
				.find(ProblemCategory.class, categoryId);
	}

	@Override
	public void delete(ProblemCategory category) {
		manager.remove(manager.merge(category));
	}

	@Override
	public void add(ProblemCategory category) {
		manager.persist(category);
	}

	@Override
	public void update(ProblemCategory category) {
		manager.merge(category);
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<ProblemCategory> searchCategory(String keyString) {
		return manager
				.createQuery(
						"Select category From ProblemCategory category Where category.categoryName like ")
				.setParameter(1, "%" + keyString + "%").getResultList();
	}
}