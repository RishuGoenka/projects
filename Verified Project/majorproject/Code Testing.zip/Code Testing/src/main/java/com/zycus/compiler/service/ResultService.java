package com.zycus.compiler.service;

import java.util.List;

import com.zycus.compiler.dao.ResultDAO;
import com.zycus.compiler.model.Result;

public interface ResultService {

	public abstract void setResultDao(ResultDAO resultDao);

	public abstract List<Result> getById(int submissionId);

	public abstract void saveResult(Result result);

	public abstract void deleteResult(Result result);

	public abstract Result getSingleResult(int submissionId, int testCaseId);

	public abstract List<Result> getByProblemSetId(int submissionId);

}