package com.zycus.compiler.service;

import java.util.concurrent.Callable;

import com.zycus.compiler.model.Result;


public class ProcessTask implements Callable<Result> {

	CompileExecuteService compileExecuteService = new CompileExecuteServiceImpl();

	private String input;
	private String output;

	public ProcessTask(String input, String output) {
		this.input = input;
		this.output = output;
	}

	@Override
	public Result call() throws Exception {
		Result result = compileExecuteService.execute(input, output);
		return result;
	}

}