package com.zycus.problem.dao;

import java.util.List;

import com.zycus.problem.model.ProblemCategory;

public interface ProblemCategoryDAO {

	public abstract List<ProblemCategory> getAllCategory();

	public abstract ProblemCategory getById(int categoryId);

	public abstract void delete(ProblemCategory category);

	public abstract void add(ProblemCategory category);

	public abstract void update(ProblemCategory category);

	public abstract List<ProblemCategory> searchCategory(String keyString);

}