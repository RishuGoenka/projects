package com.zycus.problem.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.problem.dto.BulkProblemDTO;
import com.zycus.problem.dto.BulkTestCaseDTO;
import com.zycus.problem.dto.TestCaseDTO;
import com.zycus.problem.model.Problem;
import com.zycus.problem.model.TestCase;
import com.zycus.problem.service.ProblemService;
import com.zycus.problem.service.TestCaseService;
import com.zycus.problem.utility.BulkQuestionRead;
import com.zycus.problem.utility.BulkTestCaseRead;
import com.zycus.problem.utility.TestCaseRead;

@Controller
@RequestMapping("/admin")
public class FileUploadController {

	@Autowired
	TestCaseService testService;

	@Autowired
	ProblemService problemService;

	@RequestMapping(value = "/bulk-test-case-redirect", method = RequestMethod.GET)
	public ModelAndView bulkTestCaseUpload(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mv = new ModelAndView("admin/test-case");
		mv.addObject("problemId", request.getParameter("problemId"));
		return mv;
	}
	
	@RequestMapping(value = "/bulk-upload-redirect", method = RequestMethod.GET)
	public ModelAndView bulkUpload(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mv = new ModelAndView("admin/bulk-upload");
		return mv;
	}

	@RequestMapping(value = "/upload-file", method = RequestMethod.POST)
	public @ResponseBody ModelAndView uploadTestCase(
			@RequestParam("file") MultipartFile file, HttpServletRequest request) {

		String name = "Test Case.docx";
		String failedTestCaseFileName = "Failed Test Case.txt";

		ModelAndView mv = new ModelAndView("redirect:view-test-cases");
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();

				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();

				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath()
						+ File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();
				TestCaseRead tr = new TestCaseRead();
				
				
				List<List<TestCaseDTO>> allTestCases = tr.read(serverFile.toString().replace("\\", "/"));
				List<TestCaseDTO> completeTestCases = allTestCases.get(0);
				List<TestCaseDTO> incompleteTestCases = allTestCases.get(1);
			
				Iterator<TestCaseDTO> iterator = completeTestCases.iterator();
				TestCaseDTO testCaseDto;
				TestCase testCase;
				while (iterator.hasNext()) 
				{
					testCaseDto = (TestCaseDTO) iterator.next();
					testCase = new TestCase(testCaseDto.getInput(),
							testCaseDto.getOutput(),
							(Problem) (problemService.getByID(Integer.parseInt(request.getParameter("problemId")))), 
							testCaseDto.getTestCaseDifficulty());
					testService.add(testCase);
				}
				File serverFileFailed = new File(dir.getAbsolutePath()+ File.separator + failedTestCaseFileName);
				FileWriter writer = new FileWriter(serverFileFailed.toString().replace("\\", "/")); 
				for(TestCaseDTO failedTestCase : incompleteTestCases )
				{
						  writer.write(failedTestCase.toString()+"\r\n");
				}
				writer.close();
				
				mv.addObject("msg", "You successfully uploaded file=" + name);
			} catch (Exception e) {
				mv.addObject(
						"msg",
						"You failed to upload " + name + " => "
								+ e.getMessage());
				e.printStackTrace();
			}
		} else {
			mv.addObject("msg", "You failed to upload " + name
					+ " because the file was empty.");
		}
		mv.addObject("problemId", request.getParameter("problemId"));
		return mv;
	}

	@RequestMapping(value = "/bulk-upload-file", method = RequestMethod.POST)
	public @ResponseBody ModelAndView bulkUpload(
			@RequestParam("file") MultipartFile[] files) {

		String failedQuestionsFileName = "Failed Questions.txt";
		String failedTestCasesFileName = "Failed Test Cases.txt";

		String names[] = { "Question Set.docx", "Test Case Set.docx" };
		ModelAndView mv = new ModelAndView("redirect:get-all");
		if (files.length != names.length)
			mv.addObject("msg", "Mandatory information missing");

		BulkQuestionRead bqr = new BulkQuestionRead();
		BulkTestCaseRead btcr = new BulkTestCaseRead();
		List<List<BulkProblemDTO>> questions = null;
		List<List<BulkTestCaseDTO>> testCases = null;
		String message = "";
		for (int i = 0; i < files.length; i++) {
			MultipartFile file = files[i];
			String name = names[i];
			try {
				byte[] bytes = file.getBytes();

				// Creating the directory to store file
				String rootPath = System.getProperty("catalina.home");
				File dir = new File(rootPath + File.separator + "tmpFiles");
				if (!dir.exists())
					dir.mkdirs();

				// Create the file on server
				File serverFile = new File(dir.getAbsolutePath()
						+ File.separator + name);
				BufferedOutputStream stream = new BufferedOutputStream(
						new FileOutputStream(serverFile));
				stream.write(bytes);
				stream.close();

				if (i == 0) {
					questions = bqr.read(serverFile.toString().replace("\\","/"));
				} else {
					testCases = btcr.read(serverFile.toString().replace("\\","/"));
				}

				message = message + "You successfully uploaded file=" + name
						+ "<br />";
				mv.addObject("msg", message);
			} catch (Exception e) {
				mv.addObject("msg", "You failed to upload " + name);
			}
		}

		HashMap<String, Problem> problemMap = new HashMap<String, Problem>();

		Problem individualProblem;
		List<BulkProblemDTO> questionscomplete = questions.get(0);
		List<BulkProblemDTO> questionsincomplete = questions.get(1);
			for (BulkProblemDTO problem : questionscomplete) 
			{
				individualProblem = new Problem(problem.getQuestionDescription(),problem.getQuestionName(),
						problem.getQuestionCategory(), problem.getDifficulty());				
				if(problemMap.containsKey(problem.getQuestionNo())==false)
				{
					problemService.add(individualProblem);
				    problemMap.put(problem.getQuestionNo(), individualProblem);
				}
				else
				{
					BulkProblemDTO temporary=new BulkProblemDTO();
					temporary.setQuestionName(individualProblem.getProblemName());
					temporary.setQuestionCategory(individualProblem.getProblemCategory());
					temporary.setQuestionDescription(individualProblem.getProblemText());
					temporary.setDifficulty(individualProblem.getDifficulty());					
					questionsincomplete.add(temporary);
				}
			}
			
			String rootPath = System.getProperty("catalina.home");
			File dir = new File(rootPath + File.separator + "tmpFiles");
			if (!dir.exists())
				dir.mkdirs();
			
			FileWriter writer;
			try {
				File serverFileFailedQuestions = new File(dir.getAbsolutePath()+ File.separator + failedQuestionsFileName);
				writer = new FileWriter(serverFileFailedQuestions.toString().replace("\\", "/"));

				for(BulkProblemDTO incompleteProblems : questionsincomplete)
				{
					writer.write(incompleteProblems.toString()+"\r\n");
				}
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		TestCase individualTestCase;
		List<BulkTestCaseDTO> completeTestCases = testCases.get(0);
		List<BulkTestCaseDTO> incompleteTestCases = testCases.get(1);
		
		for (BulkTestCaseDTO testcase : completeTestCases)
		{
			if (problemMap.get(testcase.getQuestionNo()) != null)
			{
				individualTestCase = new TestCase(testcase.getInput(),
						testcase.getOutput(), problemMap.get(testcase
								.getQuestionNo()),
						testcase.getTestCaseDifficulty());
				testService.add(individualTestCase);
			}
		}
		
		try {
			File serverFileFailedTestCases = new File(dir.getAbsolutePath()+ File.separator + failedTestCasesFileName);
			writer = new FileWriter(serverFileFailedTestCases.toString().replace("\\", "/"));

			
			for (BulkTestCaseDTO incompleteTestcase : incompleteTestCases)
			{
				writer.write(incompleteTestcase.toString()+"\r\n");
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return mv;
	}
}
