package com.zycus.compiler.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.zycus.integration.model.UserTest;
import com.zycus.problem.model.Problem;

@Entity
@Table(name = "submission")
public class UserSubmission implements Serializable {

	private static final long serialVersionUID = -2860477707632724889L;

	@Id
	@GeneratedValue
	@Column(name="submission_id")
	private int submissionId;

	@ManyToOne
	private Problem problem;

	@ManyToOne
	private UserTest userTest;

	@Column(nullable = false, name="version_number")
	private int versionNumber;

	public int getSubmissionId() {
		return submissionId;
	}

	public UserTest getUserTest() {
		return userTest;
	}

	public void setUserTest(UserTest userTest) {
		this.userTest = userTest;
	}

	public Problem getProblem() {
		return problem;
	}

	public void setProblem(Problem problem) {
		this.problem = problem;
	}

	public int getVersionNumber() {
		return versionNumber;
	}

	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}

	public UserSubmission() {
		super();
		// TODO Auto-generated constructor stub
	}

	public UserSubmission(int submissionId, Problem problem, UserTest userTest,
			int versionNumber) {
		super();
		this.submissionId = submissionId;
		this.problem = problem;
		this.userTest = userTest;
		this.versionNumber = versionNumber;
	}

	@Override
	public String toString() {
		return "UserSubmissionEntity [submissionId=" + submissionId
				+ ", problem=" + problem + ", versionNumber=" + versionNumber
				+ "]";
	}

}
