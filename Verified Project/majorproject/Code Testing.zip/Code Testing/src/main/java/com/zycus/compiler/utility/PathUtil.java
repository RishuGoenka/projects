package com.zycus.compiler.utility;

import java.io.File;

public class PathUtil {
	private static String path;

	public static String getPath() {
		return path;
	}

	public String setPath(int versionNumber, int userId, int problemId,
			int userTestId) {
		path = createPathName(versionNumber, userId, problemId, userTestId);
		createDirectory(path);
		return path;
	}

	private String createPathName(int versionNumber, int userId, int problemId,
			int userTestId) {
		return System.getProperty("catalina.home") + File.separator + "Files"
				+ File.separator + "entries" + File.separator + problemId
				+ File.separator + userId + File.separator + userTestId
				+ File.separator + versionNumber + File.separator;
	}

	public String getPathForUser(int versionNumber, int userId, int problemId,
			int userTestId) {
		return System.getProperty("catalina.home") + File.separator + "Files"
				+ File.separator + "entries" + File.separator + problemId
				+ File.separator + userId + File.separator + userTestId
				+ File.separator + versionNumber + File.separator + "Main.java";
	}

	public void createDirectory(String path) {
		File folder = new File(path);
		if (folder.exists() == false)
			folder.mkdirs();
	}
}
