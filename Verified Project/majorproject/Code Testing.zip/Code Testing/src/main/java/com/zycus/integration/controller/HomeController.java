package com.zycus.integration.controller;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.compiler.model.Result;
import com.zycus.integration.model.User;
import com.zycus.integration.model.UserPrincipal;

@Controller
public class HomeController {

	/*
	 * @RequestMapping(value={"/", "/home"}, method = RequestMethod.GET) public
	 * ModelAndView home(){
	 * 
	 * ModelAndView model = new ModelAndView("home"); model.addObject("msg",
	 * "hello world"); new Result(); return model; }
	 */

	/**
	 * @return ModelAndView
	 */
	@RequestMapping(value = { "/hello" }, method = RequestMethod.GET)
	public ModelAndView hello() {

		ModelAndView model = new ModelAndView("hello");
		Object principal = SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();
		User user = ((UserPrincipal) principal).getUser();
		model.addObject("username", user.getFirstName());
		return model;
	}

	/**
	 * @return ModelAndView
	 */
	@RequestMapping(value = { "/login", "/" })
	public ModelAndView login() {

		Authentication auth = SecurityContextHolder.getContext()
				.getAuthentication();

		if (auth == null) {
			ModelAndView model = new ModelAndView("login");
			model.addObject("user", new User());
			return model;
		}

		if (!(auth instanceof AnonymousAuthenticationToken)
				&& auth.getAuthorities().toString().contains("ROLE_USER")) {
			return new ModelAndView("redirect:/newTest");
		} 
		else if (!(auth instanceof AnonymousAuthenticationToken)
				&& auth.getAuthorities().toString().contains("ROLE_ADMIN")) {

			return new ModelAndView("redirect:/admin/admin_home");
		}

		ModelAndView model = new ModelAndView("login");
		model.addObject("user", new User());

		return model;
	}

	@RequestMapping("/404")
	public String error404() {

		return "404";
	}

	@RequestMapping("/500")
	public String error500() {

		return "500";
	}

}