package com.zycus.problem.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table (name="problem")
public class Problem implements Serializable {
	
	private static final long serialVersionUID = -5433178729946475203L;
	@Id
	@GeneratedValue
	@Column(name="problem_id")
	private int problemId;
	
	@NotNull
	@Column(name="problem_text", columnDefinition="TEXT")
	@NotEmpty(message="cannot be empty")
	private String problemText;
	
	@Column(name="problem_name")
	@NotEmpty(message="cannot be empty")
	private String problemName;
	
	@Column(name="problem_category" )
	@NotEmpty(message="cannot be empty")
	private String problemCategory;
	
	@Column(name="difficulty")
	@Pattern(regexp="[1-9]{1}", message="must be between 1 to 9")
	@NotEmpty(message="cannot be empty")
	private String difficulty;
	
	public Problem( String problemText, String problemName,
			String problemCategory, String difficulty) {
		super();
		this.problemText = problemText;
		this.problemName = problemName;
		this.problemCategory = problemCategory;
		this.difficulty = difficulty;
	}
	public Problem() {
		super();
	}
	public int getProblemId() {
		return problemId;
	}
	public void setProblemId(int problemId) {
		this.problemId = problemId;
	}
	public String getProblemText() {
		return problemText;
	}
	public void setProblemText(String problemText) {
		this.problemText = problemText;
	}
	public String getProblemName() {
		return problemName;
	}
	public void setProblemName(String problemName) {
		this.problemName = problemName;
	}
	public String getProblemCategory() {
		return problemCategory;
	}
	public void setProblemCategory(String problemCategory) {
		this.problemCategory = problemCategory;
	}
	public String getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}
	@Override
	public String toString() {
		return "Problem [problemId=" + problemId + ", problemText="
				+ problemText + ", problemName=" + problemName
				+ ", problemCategory=" + problemCategory + ", difficulty="
				+ difficulty + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((difficulty == null) ? 0 : difficulty.hashCode());
		result = prime * result
				+ ((problemCategory == null) ? 0 : problemCategory.hashCode());
		result = prime * result + problemId;
		result = prime * result
				+ ((problemName == null) ? 0 : problemName.hashCode());
		result = prime * result
				+ ((problemText == null) ? 0 : problemText.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Problem other = (Problem) obj;
		if (difficulty == null) {
			if (other.difficulty != null)
				return false;
		} else if (!difficulty.equals(other.difficulty))
			return false;
		if (problemCategory == null) {
			if (other.problemCategory != null)
				return false;
		} else if (!problemCategory.equals(other.problemCategory))
			return false;
		if (problemId != other.problemId)
			return false;
		if (problemName == null) {
			if (other.problemName != null)
				return false;
		} else if (!problemName.equals(other.problemName))
			return false;
		if (problemText == null) {
			if (other.problemText != null)
				return false;
		} else if (!problemText.equals(other.problemText))
			return false;
		return true;
	}
}
