package com.zycus.problem.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.problem.model.ProblemCategory;
import com.zycus.problem.service.ProblemCategoryService;

@Controller
@RequestMapping("/admin")
public class CategoryController {

	@Autowired
	ProblemCategoryService categoryService;

	@RequestMapping(value = "/addProblemCategory", method = RequestMethod.GET)
	public ModelAndView viewAddCategoryPage(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView model = new ModelAndView("admin/add-category");
		model.addObject("category", new ProblemCategory());
		return model;
	}

	@RequestMapping(value = "/addProblemCategory", method = RequestMethod.POST)
	public ModelAndView addNewCategory(HttpServletRequest request,
			HttpServletResponse response,
			@ModelAttribute(name = "category") ProblemCategory category) {

		ModelAndView model = new ModelAndView("admin/add-category");
		if (category.getCategoryName().equals("")) {
			model.addObject("msg",
					"Category Not added, Please Enter valid Category Name");
		} else {
			categoryService.add(category);
			model.addObject("msg", "Category Added");
		}
		return model;
	}

	@RequestMapping(value = "/view-category", method = RequestMethod.GET)
	public ModelAndView viewAllCategories(HttpServletRequest request,
			HttpServletResponse response) {

		ModelAndView model = new ModelAndView("admin/view-category");
		List<ProblemCategory> categoryList = categoryService.getAllCategory();
		model.addObject("list", categoryList);
		return model;
	}

	@RequestMapping(value = "/edit-category", method = RequestMethod.GET)
	public ModelAndView editCategory(HttpServletRequest request,
			HttpServletResponse response) {
		int categoryId = Integer.parseInt(request.getParameter("id"));
		String categoryName = request.getParameter("category");
		ModelAndView model = new ModelAndView("admin/view-category");
		if (categoryName.equals("")) {
			model.addObject("msg",
					"Category Not updated, Please Enter valid Category Name");
		} else {
			ProblemCategory category = new ProblemCategory();
			category.setCategoryId(categoryId);
			category.setCategoryName(categoryName);
			categoryService.update(category);
			model.addObject("msg", "Category updated successfully");
		}
		return model;
	}

	@RequestMapping(value = "/remove-category", method = RequestMethod.GET)
	public ModelAndView deleteCategory(HttpServletRequest request,
			HttpServletResponse response) {
		int categoryId = Integer.parseInt(request.getParameter("id"));

		ModelAndView model = viewAllCategories(request, response);
		if (categoryId <= 0) {
			model.addObject("msg", "Category Not deleted, Please try again");
		} else {
			ProblemCategory category = new ProblemCategory();
			category.setCategoryId(categoryId);
			categoryService.delete(category);
			model.addObject("msg", "Category deleted successfully");
		}
		return model;
	}
}
