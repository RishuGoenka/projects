package com.zycus.integration.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.compiler.model.UserSubmission;
import com.zycus.integration.model.ProblemSet;
import com.zycus.integration.model.SubmissionScore;
import com.zycus.integration.model.UserTest;

@Repository
@Transactional
public class SubmissionScoreDAOImpl implements SubmissionScoreDAO {

	@PersistenceContext
	private EntityManager manager;

	public SubmissionScoreDAOImpl() {

	}

	@Override
	public boolean save(SubmissionScore submissionScore) {

		try {
			manager.persist(submissionScore);

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public boolean update(SubmissionScore submissionScore) {
		try {

			manager.merge(submissionScore);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public SubmissionScore findById(int submissionScoreId) {

		return manager.find(SubmissionScore.class, submissionScoreId);
	}

	@Override
	public SubmissionScore findByUserSubmission(UserSubmission userSubmission) {

		List<SubmissionScore> submissionScores = (List<SubmissionScore>) manager
				.createQuery(
						"select s from SubmissionScore s where s.userSubmission.submissionId = ?")
				.setParameter(1, userSubmission.getSubmissionId())
				.getResultList();

		if (submissionScores.size() > 0) {

			return submissionScores.get(0);
		} else {
			return null;
		}

	}

	public List<Object[]> findByProblemSet(ProblemSet problemSet,
			int maxResults) {

		System.out.println("Running query");
		Query query = manager
				.createQuery("select s.submissionScore,s.userSubmission.userTest.user.firstName,"
						+ "s.userSubmission.userTest.user.lastName, s.userSubmission.userTest.user.email, s.userSubmission  "
						+ " from SubmissionScore s, Result r where s.userSubmission.userTest.problemSet.problemSetId = ?"
						+ " and s.userSubmission.submissionId=r.userSubmission.submissionId "
						+ " group by r.userSubmission.submissionId "
						+ " order by s.submissionScore desc, sum(r.memoryConsumed),sum(r.timeTaken) ");

		query.setParameter(1, problemSet.getProblemSetId());
		query.setMaxResults(maxResults);

		
		return query.getResultList();
	}



	public List<Object[]> findByProblemSetAndSearchByNameOrEmail(
			ProblemSet problemSet, String search) {

		Query query = manager
				.createQuery("select s.submissionScore,s.userSubmission.userTest.user.firstName,"
						+ "s.userSubmission.userTest.user.lastName, s.userSubmission.userTest.user.email, s.userSubmission"
						+ " from SubmissionScore s, Result r where s.userSubmission.userTest.problemSet.problemSetId = ?"
						+ " and s.userSubmission.submissionId=r.userSubmission.submissionId "
						+ " and ("
						+ "       s.userSubmission.userTest.user.firstName LIKE ? or "
						+ "       s.userSubmission.userTest.user.lastName  LIKE ? or "
						+ "       s.userSubmission.userTest.user.email LIKE ? "
						+ "     ) "
						+ " group by s.userSubmission.submissionId "
						+ " order by s.submissionScore desc, sum(r.memoryConsumed),sum(r.timeTaken) ");

		query.setParameter(1, problemSet.getProblemSetId());
		query.setParameter(2, "%" + search + "%");
		query.setParameter(3, "%" + search + "%");
		query.setParameter(4, "%" + search + "%");

		return query.getResultList();
	}


}
