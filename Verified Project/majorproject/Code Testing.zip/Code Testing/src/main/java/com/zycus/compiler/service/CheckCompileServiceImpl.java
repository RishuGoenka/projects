package com.zycus.compiler.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.springframework.stereotype.Service;

import com.zycus.compiler.utility.PathUtil;

@Service
public class CheckCompileServiceImpl implements  CheckCompileService {
	
	
	/* (non-Javadoc)
	 * @see com.zycus.compiler.service.CheckCompileService#compile()
	 */
	@Override
	public String compile() {
		ProcessBuilder processBuilder = new ProcessBuilder("javac", "Run.java");
		setProperties(processBuilder);
		try {
			return compileResult(processBuilder);
		} catch (IOException | InterruptedException e) {
			System.out.println("in compile() " + e);
		}
		return "";
	}
	
	/* (non-Javadoc)
	 * Executes the command in the process builder
	 * @return the result of the compilation if successfull or not(error message)
	 */
	private String compileResult(ProcessBuilder processBuilder)
			throws IOException, InterruptedException {
		Process process = processBuilder.start();
		InputStream inputStream = process.getInputStream();
		return getResult(true, process, inputStream);
	}

	/* (non-Javadoc)
	 *  Checks if there are any errors in compilation (gets it from the inputStream of the process)
	 *  @return error message if any else successfull message
	 */
	private String getResult(boolean compiled, Process process, InputStream inputStream) throws IOException, InterruptedException {
		String result = "";
		String str;
		BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
		while ((str = br.readLine()) != null) {
			compiled = false;
			result += str + "\n";
		}
		process.waitFor();
		inputStream.close();
		if (!compiled)
			return result;
		return "Compilation Successfull";
	}
	
	/* (non-Javadoc)
	 * Set necessary properties of the ProcessBuiler
	 */
	private void setProperties(ProcessBuilder p) {
		p.directory(new File(PathUtil.getPath()));
		p.redirectErrorStream(true);
	}

}
