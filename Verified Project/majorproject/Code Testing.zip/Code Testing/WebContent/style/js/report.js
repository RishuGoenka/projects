jQuery(function($) {

	$('#fetch_report').on(
			'click',
			function() {

				 data = $('#fetch_report_form').serializeArray();

				 data.push({
					 
					 name: 'searchType',
					 value: $('.tab-content .active').attr('id')
				 }) ;
				 
				$.ajax({
					type : "GET",
					async : false,
					url : 'report/get',
					data : data,
					beforeSend : function(xhr) {

						//HARDCODE: csrf must be present at 3rd position in array
						xhr.setRequestHeader(data[2].name, data[2].value);
					},
					success : function(resp) {

						
						if(resp === "") {
							
							
							$('#error_message').show();
						}else {
							
							$('#error_message').hide();							
						}
						var rows = "";

						for (var i = 0; i < resp.length; i++) {

							var name = resp[i].userFirstName + " " + resp[i].userLastName;
							var email = resp[i].userEmail;
							var score = resp[i].problemSetScore;
							var submissionId = resp[i].userSubmission.submissionId;
							var problemSetId = 	resp[i].userSubmission.userTest.problemSet.problemSetId;

							
							rows += "<tr><td>" + (i + 1) + "</td><td>" + name
									+ "</td><td>" + email + "</td><td>" + score
									+ "</td><td><a class='btn btn-info' target='_blank' " +
									   "href='view_result?submissionId="+submissionId+"&problemSetId="+problemSetId+"'>" +
									   "view</a></td></tr>"
						}

						$('#report_table').html(rows);
						
						if(resp.length === 0) {
							
							$('#empty_report').show();
							$('#report_result').hide();							
						}else {
							
							$('#empty_report').hide();							
							$('#report_result').show();
						}
						
					}
				});

				return false;
			});

});