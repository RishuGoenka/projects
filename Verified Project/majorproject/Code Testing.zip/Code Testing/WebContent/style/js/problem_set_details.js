jQuery(function($) {

	var problemSetId = $('#test_shared_id').text();

	$.get("test/get/" ,{problemSetId : problemSetId}, function(response) {

		$('#test_name_h2').append( response.problemSet.problemSetName);	
		$('#test_shared_id_h3').append( response.problemSet.sharedId);	
		$('#test_duration_h3').append( response.problemSet.duration);	
		
		var problemTable = "";
		for (var i = 0; i < response.setOfProblems.length; i++) {

			var id = i+1;
			var qid = response.setOfProblems[i].problemId;
			var qName = response.setOfProblems[i].problemName;
			var qCategory = response.setOfProblems[i].problemCategory;
			var qDifficulty = response.setOfProblems[i].difficulty;

			problemTable += "<tr style='cursor:pointer' class='problem' data-id='"+qid+"'>" 
					+"<td> " + id + "</td>"
					+ "<td>"+ qName +"</td>"
					+ "<td>"+ qCategory +"</td>"
					+ "<td>"+ qDifficulty +"</td> </tr>"
		}

		$('#test_problem_table').html(problemTable);
		
		$(".problem").click(function(){
			  var questionId = $(this).data('id');
			  window.document.location = "view-problem?problemId="+questionId;
		}
		)
		
		$(".problem").hover(function(){
		    $(this).css("background-color", "#eee");
		    },
		    function(){
			    $(this).css("background-color", "white");
			    }
		);

	})

	
	
});