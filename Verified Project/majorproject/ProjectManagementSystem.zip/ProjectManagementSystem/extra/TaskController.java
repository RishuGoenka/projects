package com.zycus.pms.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.pms.entity.Priority;
import com.zycus.pms.entity.Task;
import com.zycus.pms.service.IPriorityService;
import com.zycus.pms.service.ITaskService;

@Controller
@SessionAttributes("cursor")
public class TaskController {
	
	@Autowired
	ITaskService taskService;
	
	@Autowired
	IPriorityService priorityService;
	
	@RequestMapping("/addNewTask.do")
	public String startAddTask(Map<String, Object> model){
		model.put("task", new Task());
		
		ArrayList<Priority> priorities = new ArrayList<Priority>(priorityService.getPriorities());
		
		model.put("priorities", priorities);
		return ("addTaskPage.jsp");
	}
	
	@RequestMapping("/modifyGivenTask.do")
	public String startModifyTask(Map<String, Object> model, HttpServletRequest request){
		
		Task origTask = taskService.getTask(Integer.parseInt(request.getParameter("origTask")));
		System.out.println("OT -> "+origTask);
		model.put("origTask", origTask);
		
		ArrayList<Priority> priorities = new ArrayList<Priority>(priorityService.getPriorities());
		
		model.put("priorities", priorities);
		return ("modifyTaskPage.jsp");
	}
	
	@RequestMapping(value="/addTask.do", method=RequestMethod.POST)
	public String addTask(@ModelAttribute("task") Task task, Map<String, Object> model, HttpServletRequest request){
		int priorityId=Integer.parseInt(request.getParameter("priorityId"));
		//System.out.println(priorityId);
		Priority priority = priorityService.getPriority(priorityId);
		task.setPriority(priority);
		taskService.addTask(task, 2, 1);
		return ("redirect:showTasks.do");
	}
	
	@RequestMapping(value="/modifyTask.do", method=RequestMethod.POST)
	public String modifyTask(
			@RequestParam(value="priorityId", required=false) int priorityId,
			HttpServletRequest request) throws ParseException{
		//int priorityId=Integer.parseInt(request.getParameter("priorityId"));
		int taskId = Integer.parseInt(request.getParameter("taskId"));
		Task toBeModifiedTask = taskService.getTask(taskId);
		
		System.out.println("BACK ON PAGE -> "+toBeModifiedTask);
		
		System.out.println(priorityId);
		Priority priority = priorityService.getPriority(priorityId);
		toBeModifiedTask.setPriority(priority);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
		
		String deadlineDate = request.getParameter("deadLine");
		Date deadline = sdf.parse(deadlineDate);
		toBeModifiedTask.setDeadLine(deadline);
		toBeModifiedTask.setDescription(request.getParameter("description"));
		
		int percComp = Integer.parseInt(request.getParameter("percentCompleted"));
		if(percComp==100){
			toBeModifiedTask.setEndDate(new Date());
		}
		toBeModifiedTask.setPercentCompleted(percComp);
		
		taskService.updateTask(toBeModifiedTask);
		return ("redirect:addNewTask.do");
	}
	
	@RequestMapping("/showTasks.do")
	public String showTasks(
			@RequestParam(value="view", required=false) String view,
			@RequestParam(value="ltd", required=false) String ltd,
			@RequestParam(value="cursor", required=false) Integer cursor,
			Map<String, Object> model){
		System.out.println(ltd);
		int userId = 2;
		if(cursor==null)
		cursor = (Integer) model.get("cursor");
		if(cursor == null)
			cursor = 0;
		if(view != null){
			if(view.equals("next"))
				cursor +=5;
			else if (view.equals("previous")){
				cursor -=5;
				if(cursor<0)
					cursor=0;
			}
		}
		List<Task> list = new ArrayList<Task>();
		if(ltd==null)
			ltd="";
		if(ltd.equals("completed")){
			list = taskService.getCompletedTasks(userId, cursor, 5);
			if(list.isEmpty()){
				cursor-=5;
				list = taskService.getCompletedTasks(userId, cursor, 5);
			}
		} else if(ltd.equals("incomplete")){
			list = taskService.getIncompleteTasks(userId, cursor, 5);
			if(list.isEmpty()){
				cursor-=5;
				list = taskService.getIncompleteTasks(userId, cursor, 5);
			}
		}else{
			list = taskService.getTasks(userId, cursor, 5);
			if(list.isEmpty()){
				cursor-=5;
				list = taskService.getTasks(userId, cursor, 5);
			}
		}
		model.put("ltd", ltd);
		model.put("cursor", cursor);
		model.put("listOfTasks", list);
		
		return ("viewTaskPage.jsp?ltd="+ltd);
	}

}
