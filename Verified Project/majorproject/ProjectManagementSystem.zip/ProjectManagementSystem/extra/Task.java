package com.zycus.pms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="PMS_TASK1")
public class Task {
	
	@Id@GenericGenerator(name="incr" , strategy="increment")
	@GeneratedValue(generator="incr")
	@Column(name="TASK_ID")
	private int taskId;
	
	@Column(name="DESCRIPTION")
	private String description;
	
	@ManyToOne
	@PrimaryKeyJoinColumn
	private Project project;
	
	@Column(name="START_DATE")
	private Date startDate;
	
	@Column(name="DEADLINE")
	private Date deadLine;
	
	@Column(name="END_DATE")
	private Date endDate;
	
	@Column(name="PERCENT_COMPLETED")
	private int percentCompleted;
	
	@ManyToOne
	private Priority priority;
	
	@ManyToOne
	@PrimaryKeyJoinColumn
	private User user;
	
	

	public Task() {
		super();
	}

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getDeadLine() {
		return deadLine;
	}

	public void setDeadLine(Date deadLine) {
		this.deadLine = deadLine;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getPercentCompleted() {
		return percentCompleted;
	}

	public void setPercentCompleted(int percentCompleted) {
		this.percentCompleted = percentCompleted;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Priority getPriority() {
		return priority;
	}

	public void setPriority(Priority priority) {
		this.priority = priority;
	}

	@Override
	public String toString() {
		return "Task [taskId=" + taskId + ", project=" + project
				+ ", startDate=" + startDate + ", deadLine=" + deadLine
				+ ", endDate=" + endDate + ", percentCompleted="
				+ percentCompleted + ", user=" + user + "]";
	}
	
	

}
