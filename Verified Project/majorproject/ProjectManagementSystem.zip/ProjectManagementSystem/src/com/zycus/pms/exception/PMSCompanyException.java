package com.zycus.pms.exception;

public class PMSCompanyException extends PMSException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PMSCompanyException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PMSCompanyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
