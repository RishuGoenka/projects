package com.zycus.pms.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.pms.entity.Priority;
import com.zycus.pms.entity.Task;
import com.zycus.pms.exception.PMSTaskException;
import com.zycus.pms.logger.LogMaster;
import com.zycus.pms.service.IPriorityService;
import com.zycus.pms.service.ITaskService;

@Controller
@SessionAttributes("cursor")
public class TaskController {

	@Autowired
	private LogMaster logger;

	@Autowired
	ITaskService taskService;

	@Autowired
	Validator validator;

	@Autowired
	IPriorityService priorityService;

	@InitBinder
	private void dateBinder(WebDataBinder binder) {
		//The date format to parse or output your dates
		SimpleDateFormat dateFormat = new SimpleDateFormat("yy-MM-dd");
		//Create a new CustomDateEditor
		CustomDateEditor editor = new CustomDateEditor(dateFormat, false);
		//Register it as custom editor for the Date type
		binder.registerCustomEditor(Date.class, editor);
	}

	@RequestMapping("/showTasks.do")
	public String showTasks(
			@RequestParam(value="view", required=false) String view,
			@RequestParam(value="ltd", required=false) String ltd,
			@RequestParam(value="cursor", required=false) Integer cursor,
			Map<String, Object> model,
			HttpServletRequest request){

		try {
			System.out.println(ltd);
			HttpSession session = request.getSession();
			int userId = (Integer) session.getAttribute("userId");
			int projId = (Integer) session.getAttribute("projectId");
			if(cursor==null)
				cursor = (Integer) model.get("cursor");
			if(cursor == null)
				cursor = 0;
			if(view != null){
				if(view.equals("next"))
					cursor +=5;
				else if (view.equals("previous")){
					cursor -=5;
					if(cursor<0)
						cursor=0;
				}
			}
			List<Task> list = new ArrayList<Task>();
			if(ltd==null)
				ltd="";
			if(ltd.equals("completed")){
				list = taskService.getCompletedTasks(userId, projId, cursor, 5);
				if(list.isEmpty()){
					cursor-=5;
					list = taskService.getCompletedTasks(userId, projId, cursor, 5);
				}
			} else if(ltd.equals("incomplete")){
				list = taskService.getIncompleteTasks(userId, projId, cursor, 5);
				if(list.isEmpty()){
					cursor-=5;
					list = taskService.getIncompleteTasks(userId, projId, cursor, 5);
				}
			}else{
				list = taskService.getTasks(userId, projId, cursor, 5);
				if(list.isEmpty()){
					cursor-=5;
					list = taskService.getTasks(userId, projId, cursor, 5);
				}
			}
			model.put("ltd", ltd);
			model.put("cursor", cursor);
			model.put("listOfTasks", list);

			return ("viewTaskPage.jsp?ltd="+ltd);
		} catch (PMSTaskException e) {
			LogMaster.getLogger(this.getClass()).error("Couldnt retreive tasks", e);
			request.setAttribute("errorMessage", "Something went wrong in retreiving task. Please contact your admin");
			return "errorPage.jsp";
		}
	}

	@RequestMapping("/showTasksOfProject.do")
	public String showTasksOfProject(
			@RequestParam(value="view", required=false) String view,
			@RequestParam(value="ltd", required=false) String ltd,
			@RequestParam(value="cursor", required=false) Integer cursor,
			Map<String, Object> model,
			HttpServletRequest request){
		try {
			HttpSession session = request.getSession();

			int projectId = (Integer) session.getAttribute("projectId");

			if(cursor==null)
				cursor = (Integer) model.get("cursor");
			if(cursor == null)
				cursor = 0;
			if(view != null){
				if(view.equals("next"))
					cursor +=5;
				else if (view.equals("previous")){
					cursor -=5;
					if(cursor<0)
						cursor=0;
				}
			}
			List<Task> list = new ArrayList<Task>();
			if(ltd==null)
				ltd="";
			if(ltd.equals("completed")){
				list = taskService.getCompletedTasksOfProject(projectId, cursor, 5);
				if(list.isEmpty()){
					cursor-=5;
					list = taskService.getCompletedTasksOfProject(projectId, cursor, 5);
				}
			} else if(ltd.equals("incomplete")){
				list = taskService.getIncompleteTasksOfProject(projectId, cursor, 5);
				if(list.isEmpty()){
					cursor-=5;
					list = taskService.getIncompleteTasksOfProject(projectId, cursor, 5);
				}
			}else{
				list = taskService.getTasksOfProject(projectId, cursor, 5);
				if(list.isEmpty()){
					cursor-=5;
					list = taskService.getTasksOfProject(projectId, cursor, 5);
				}
			}
			model.put("ltd", ltd);
			model.put("cursor", cursor);
			model.put("listOfTasks", list);

			return ("viewTaskPageManager.jsp?ltd="+ltd);
		} catch (PMSTaskException e) {
			LogMaster.getLogger(this.getClass()).error("Couldnt retreive tasks", e);
			request.setAttribute("errorMessage", "Something went wrong in retreiving task. Please contact your admin");
			return "errorPage.jsp";
		}
	}

	@RequestMapping("/addNewTask.do")
	public String startAddTask(Map<String, Object> model){
		model.put("task", new Task());

		ArrayList<Priority> priorities = new ArrayList<Priority>(priorityService.getPriorities());

		model.put("priorities", priorities);
		return ("addTaskPage.jsp");
	}

	@RequestMapping(value="/addTask.do", method=RequestMethod.POST)
	public String addTask(
			@Valid @ModelAttribute("task") Task task,
			BindingResult result,
			Map<String, Object> model,
			HttpServletRequest request) throws ParseException{
		HttpSession session = request.getSession();
		int userId;
		int projectId;
		int roleId;
		try {
			userId = (Integer) session.getAttribute("userId");
			projectId = (Integer) session.getAttribute("projectId");
			roleId = (Integer) session.getAttribute("roleId");
		} catch (Exception e) {
			e.printStackTrace();
			return("redirect:login.do");
		}

		/*SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
		String startDateString = request.getParameter("startDate");
		String deadlineDateString = request.getParameter("deadLine");

		try {
			Date startDate = sdf.parse(startDateString);
			task.setStartDate(startDate);
		} catch (Exception e) {
			e.printStackTrace();
		}

		try {
			Date deadline = sdf.parse(deadlineDateString);
			task.setDeadLine(deadline);
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		
		Calendar start = Calendar.getInstance();
		Calendar end = Calendar.getInstance();
		Date startDate = task.getStartDate();
		Date deadLine = task.getDeadLine();
		if(startDate!=null){
			start.setTimeInMillis(startDate.getTime());
			start.add(Calendar.DATE,1);
		}
		if(deadLine!=null){
			end.setTimeInMillis(deadLine.getTime());
		}
		
		
		validator.validate(task, result);
		
		if(deadLine==null){
			ObjectError deadLineError = new ObjectError("deadLine", "Please enter a deadline date");
			result.addError(deadLineError);
			result.rejectValue("deadLine", "deadLine", "Please enter a deadLine date");
		}
		
		if(startDate==null){
			ObjectError startDateError = new ObjectError("startDate", "Please enter a start date");
			result.addError(startDateError);
			result.rejectValue("startDate", "startDate", "Please enter a start date");
		} else if(start.before(Calendar.getInstance())){
			ObjectError startDateError = new ObjectError("startDate", "Start Date cannot be of the past");
			result.addError(startDateError);
			result.rejectValue("startDate", "startDate", "Start Date cannot be of the past");
		}
		
		if(deadLine!=null && startDate!=null){
			end.add(Calendar.DATE,1);
			if(start.after(end)){
				System.out.println("ENTERING");
				ObjectError deadLineError = new ObjectError("deadLine", "Deadline cannot be before start date");
				result.addError(deadLineError);
				result.rejectValue("deadLine", "deadLine", "Deadline cannot be before start date");
			}
		}
		
		if(result.hasErrors()){
			ArrayList<Priority> priorities = new ArrayList<Priority>(priorityService.getPriorities());
			model.put("priorities", priorities);
			return ("addTaskPage.jsp");
		}
		else{
			/*int priorityId=Integer.parseInt(request.getParameter("priorityId"));
			//System.out.println(priorityId);
			Priority priority = priorityService.getPriority(priorityId);
			task.setPriority(priority);*/
			try {
				taskService.addTask(task, userId, projectId);
			} catch (PMSTaskException e) {
				LogMaster.getLogger(this.getClass()).error(task, e);
				request.setAttribute("errorMessage", "Problem in adding task. Please contact your admin");
				return "errorPage.jsp";
			}
			if(roleId==2)
				return ("redirect:showTasks.do");
			else if (roleId==1)
				return ("redirect:showTasksOfProject.do");
			else
				return ("redirect:login.do");
		}

	}

	@RequestMapping("/modifyGivenTask.do")
	public String startModifyTask(Map<String, Object> model, HttpServletRequest request){

		Task origTask = null;
		try {
			origTask = taskService.getTask(Integer.parseInt(request.getParameter("origTask")));
			//System.out.println("OT -> "+origTask);
			model.put("origTask", origTask);

			ArrayList<Priority> priorities = new ArrayList<Priority>(priorityService.getPriorities());

			model.put("priorities", priorities);
			return ("modifyTaskPage.jsp");
		} catch (NumberFormatException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} catch (PMSTaskException e) {
			LogMaster.getLogger(this.getClass()).error(origTask, e);
			request.setAttribute("errorMessage", "Something went wrong in modifying task. Please contact your admin");
			return "errorPage.jsp";
		}
	}

	@RequestMapping(value="/modifyTask.do", method=RequestMethod.POST)
	public String modifyTask(
			HttpServletRequest request,
			@Valid @ModelAttribute("origTask") Task task,
			BindingResult result,
			Map<String, Object> model) throws ParseException{

		try {
			HttpSession session = request.getSession();
			int roleId;
			try {
				roleId = (Integer) session.getAttribute("roleId");
			} catch (Exception e) {
				e.printStackTrace();
				return("redirect:login.do");
			}

			//int priorityId=Integer.parseInt(request.getParameter("priorityId"));
			int taskId = Integer.parseInt(request.getParameter("taskId"));
			Task toBeModifiedTask = taskService.getTask(taskId);
			toBeModifiedTask.setPriority(task.getPriority());

			//System.out.println("BACK ON PAGE -> "+toBeModifiedTask);

			//System.out.println("PRIORITY -> "+priorityId);
			System.out.println("TASK BUILT BY JAVA -> "+task);
			//Priority priority = priorityService.getPriority(priorityId);
			//toBeModifiedTask.setPriority(priority);

			/*SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
	String deadlineDate = request.getParameter("deadLine");
	Date deadline = sdf.parse(deadlineDate);
	toBeModifiedTask.setDeadLine(deadline);*/

			toBeModifiedTask.setDeadLine(task.getDeadLine());

			toBeModifiedTask.setTaskName(request.getParameter("taskName"));
			toBeModifiedTask.setDescription(request.getParameter("description"));

			int percComp=0;
			try {
				percComp = Integer.parseInt(request.getParameter("percentCompleted"));
			} catch (NumberFormatException e) {
				percComp=0;
				e.printStackTrace();
			}
			if(percComp==100){
				toBeModifiedTask.setEndDate(new Date());
			}
			toBeModifiedTask.setPercentCompleted(percComp);

			task=toBeModifiedTask;

			Calendar start = Calendar.getInstance();
			Calendar end = Calendar.getInstance();
			Date startDate = task.getStartDate();
			Date deadLine = task.getDeadLine();
			if(startDate!=null){
				start.setTimeInMillis(startDate.getTime());
				start.add(Calendar.DATE,1);
			}
			if(deadLine!=null){
				end.setTimeInMillis(deadLine.getTime());
			}
			
			
			validator.validate(task, result);
			
			if(deadLine==null){
				ObjectError deadLineError = new ObjectError("deadLine", "Please enter a deadline date");
				result.addError(deadLineError);
				result.rejectValue("deadLine", "deadLine", "Please enter a deadLine date");
			} else {
				end.add(Calendar.DATE,1);
				if(start.after(end)){
					System.out.println("ENTERING");
					ObjectError deadLineError = new ObjectError("deadLine", "Deadline cannot be before start date");
					result.addError(deadLineError);
					result.rejectValue("deadLine", "deadLine", "Deadline cannot be before start date -> "+task.getStartDate());
				}
			}

			if(result.hasErrors()){
				//Task origTask = taskService.getTask(Integer.parseInt(request.getParameter("origTask")));
				//System.out.println("OT -> "+origTask);
				//model.put("origTask", task);
				ArrayList<Priority> priorities = new ArrayList<Priority>(priorityService.getPriorities());
				model.put("priorities", priorities);
				return ("modifyTaskPage.jsp");
			}
			else{
				taskService.updateTask(toBeModifiedTask);

				if(roleId==2)
					return ("redirect:showTasks.do");
				else if (roleId==1)
					return ("redirect:showTasksOfProject.do");
				else
					return ("redirect:login.do");
			}
		} catch (NumberFormatException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} catch (PMSTaskException e) {
			LogMaster.getLogger(this.getClass()).error(task, e);
			request.setAttribute("errorMessage", "Something went wrong in modifying task. Please contact your admin");
			return "errorPage.jsp";
		}
	}

	@RequestMapping("/deleteGivenTask.do")
	public String deleteTask(Map<String, Object> model, HttpServletRequest request){

		int taskId=0;
		try {
			taskId= Integer.parseInt(request.getParameter("origTask"));
			Task origTask = taskService.getTask(taskId);
			//System.out.println("OT -> "+origTask);
			model.put("origTask", origTask);
			return ("deleteTaskPage.jsp");
		} catch (NumberFormatException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} catch (PMSTaskException e) {
			LogMaster.getLogger(this.getClass()).error("while deleting task id "+taskId, e);
			request.setAttribute("errorMessage", "Something went wrong in modifying task. Please contact your admin");
			return "errorPage.jsp";
		}
	}

	@RequestMapping("/confirmDelete.do")
	public String confirmDeleteTask(Map<String, Object> model, HttpServletRequest request){
		//Task origTask = taskService.getTask(Integer.parseInt(request.getParameter("origTask")));

		int taskId=0;
		try {
			HttpSession session = request.getSession();
			int roleId;
			try {
				roleId = (Integer) session.getAttribute("roleId");
			} catch (Exception e) {
				e.printStackTrace();
				return("redirect:login.do");
			}

			taskId= Integer.parseInt(request.getParameter("origTask"));
			taskService.deleteTask(taskId);

			if(roleId==2)
				return ("redirect:showTasks.do");
			else if (roleId==1)
				return ("redirect:showTasksOfProject.do");
			else
				return ("redirect:login.do");
		} catch (NumberFormatException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} catch (PMSTaskException e) {
			LogMaster.getLogger(this.getClass()).error("while deleting task id "+taskId, e);
			request.setAttribute("errorMessage", "Something went wrong in deleting the task. Please contact your admin");
			return "errorPage.jsp";
		}
	}

	@RequestMapping("/searchTaskPage.do")
	public String searchTask(
			Map<String, Object> model,
			HttpServletRequest request){
		HttpSession session = request.getSession();
		int roleId;
		try {
			roleId = (Integer) session.getAttribute("roleId");
			if(roleId==2)
				return ("searchTaskForMember.jsp");
			else if (roleId==1)
				return ("searchTaskForManager.jsp");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return("redirect:login.do");
	}

	//searchTasksByDescr.do
	@RequestMapping("/searchTasksByDescr.do")
	public String searchTasksByDescr(
			@RequestParam(value="searchstring", required=false) String searchString,
			Map<String, Object> model,
			HttpServletRequest request){
		try {
			HttpSession session = request.getSession();
			int roleId = (Integer) session.getAttribute("roleId");
			int userId = (Integer) session.getAttribute("userId");
			System.out.println("IN CONTROLLER "+searchString);
			List<Task> list = new ArrayList<Task>();
			if(roleId==2)
				list = taskService.getTasksByDescr(userId, searchString);
			else if (roleId==1){
				int projectId = (Integer) session.getAttribute("projectId");
				list = taskService.getTasksByDescrManager(projectId, searchString);
			}
			model.put("byDescrTasks", list);
			return ("searchedTask.jsp");
		} catch (PMSTaskException e) {
			LogMaster.getLogger(this.getClass()).error(" while searching for '"+searchString+"'", e);
			request.setAttribute("errorMessage", "Something went wrong in searching for task. Please contact your admin");
			return "errorPage.jsp";
		}
	}

	@RequestMapping("/searchTasksByName.do")
	public String searchTasksByName(
			@RequestParam(value="searchstring", required=false) String searchString,
			Map<String, Object> model,
			HttpServletRequest request){
		try {
			HttpSession session = request.getSession();
			int roleId = (Integer) session.getAttribute("roleId");
			int userId = (Integer) session.getAttribute("userId");
			System.out.println("IN CONTROLLER "+searchString);
			List<Task> list = new ArrayList<Task>();
			if(roleId==2)
				list = taskService.getTasksByName(userId, searchString);
			else if (roleId==1){
				int projectId = (Integer) session.getAttribute("projectId");
				list = taskService.getTasksByNameManager(projectId, searchString);
			}
			model.put("byDescrTasks", list);
			return ("searchedTask.jsp");
		} catch (PMSTaskException e) {
			LogMaster.getLogger(this.getClass()).error(" while searching for '"+searchString+"'", e);
			request.setAttribute("errorMessage", "Something went wrong in searching for the tasks. Please contact your admin");
			return "errorPage.jsp";
		}
	}
}
