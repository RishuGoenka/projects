package com.zycus.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.pms.entity.Priority;
import com.zycus.pms.repository.IPriorityRepository;

@Service
public class PriorityService implements IPriorityService {

	@Autowired
	IPriorityRepository priorityRepository;
	
	@Override
	public List<Priority> getPriorities(){
		return priorityRepository.getPriorities();
	}

	@Override
	public Priority getPriority(int priorityId) {
		return priorityRepository.getPriority(priorityId);
	}
}
