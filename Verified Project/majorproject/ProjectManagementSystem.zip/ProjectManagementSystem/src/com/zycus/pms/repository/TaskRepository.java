package com.zycus.pms.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.pms.entity.Project;
import com.zycus.pms.entity.Task;
import com.zycus.pms.entity.User;
import com.zycus.pms.exception.PMSTaskException;

@Repository
@Transactional
@SuppressWarnings("unchecked")
public class TaskRepository implements ITaskRepository {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void addTask(Task task,int memId, int projectId ) throws PMSTaskException{
		try {
			Session session = sessionFactory.getCurrentSession();

			task.setPercentCompleted(0);
			task.setProject((Project) session.get(Project.class, projectId));
			task.setUser((User) session.get(User.class, memId));

			session.saveOrUpdate(task);
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in adding a task",e);
		}
	}

	@Override
	public List<Task> getTasks(int userId, Project project, int offset, int max) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria criteria = session.createCriteria(Task.class)
					.add(Restrictions.eq("user", session.get(User.class, userId)))
					.add(Restrictions.eq("project", project))
					.add(Restrictions.eq("isDeleted", false))
					.addOrder(Order.asc("taskId"))
					.setFirstResult(offset)
					.setMaxResults(max);

			return criteria.list();
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in getting tasks",e);
		}
	}

	@Override
	public List<Task> getTasksByDescr(int userId, String searchString) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria criteria = session.createCriteria(Task.class)
					.add(Restrictions.eq("user", session.get(User.class, userId)))
					.add(Restrictions.eq("isDeleted", false))
					.add(Restrictions.like("description", searchString, MatchMode.ANYWHERE))
					.addOrder(Order.asc("taskId"));

			return criteria.list();
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in getting tasks",e);
		}
	}

	@Override
	public List<Task> getCompletedTasks(int userId, Project project, Integer offset, int max) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria criteria = session.createCriteria(Task.class)
					.add(Restrictions.eq("user", session.get(User.class, userId)))
					.add(Restrictions.eq("project", project))
					.add(Restrictions.eq("isDeleted", false))
					.add(Restrictions.eq("percentCompleted", 100))
					.addOrder(Order.asc("taskId"))
					.setFirstResult(offset)
					.setMaxResults(max);

			return criteria.list();
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in getting tasks",e);
		}
	}

	@Override
	public List<Task> getIncompleteTasks(int userId, Project project, Integer offset, int max) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria criteria = session.createCriteria(Task.class)
					.add(Restrictions.eq("user", session.get(User.class, userId)))
					.add(Restrictions.eq("project", project))
					.add(Restrictions.eq("isDeleted", false))
					.add(Restrictions.ne("percentCompleted", 100))
					.addOrder(Order.asc("taskId"))
					.setFirstResult(offset)
					.setMaxResults(max);

			return criteria.list();
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in getting tasks",e);
		}
	}

	@Override
	public Task getTask(int taskId) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			return (Task) session.get(Task.class, taskId);
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in getting task",e);
		}
	}

	@Override
	public void update(Task task) {
		Session session = sessionFactory.getCurrentSession();
		session.update(task);
	}

	@Override
	public void delete(Task task) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();
			try {
				//session.delete(task);
				task.setDeleted(true);
				session.update(task);
			} catch (HibernateException e) {
				System.out.println("COULDN'T DELETE");
			}
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in deleting the task",e);
		}
	}

	@Override
	public List<Task> getCompletedTasksOfProject(Project project, Integer offset, int max) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria criteria = session.createCriteria(Task.class)
					.add(Restrictions.eq("isDeleted", false))
					.add(Restrictions.eq("project", project))
					.add(Restrictions.eq("percentCompleted", 100))
					.addOrder(Order.asc("taskId"))
					.setFirstResult(offset)
					.setMaxResults(max);

			return criteria.list();
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in deleting the task",e);
		}
	}

	@Override
	public List<Task> getIncompleteTasksOfProject(Project project, Integer offset, int max) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria criteria = session.createCriteria(Task.class)
					.add(Restrictions.eq("isDeleted", false))
					.add(Restrictions.eq("project", project))
					.add(Restrictions.ne("percentCompleted", 100))
					.addOrder(Order.asc("taskId"))
					.setFirstResult(offset)
					.setMaxResults(max);

			return criteria.list();
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in deleting the task",e);
		}
	}

	@Override
	public List<Task> getTasksOfProject(Project project, Integer offset, int max) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria criteria = session.createCriteria(Task.class)
					.add(Restrictions.eq("isDeleted", false))
					.add(Restrictions.eq("project", project))
					.addOrder(Order.asc("taskId"))
					.setFirstResult(offset)
					.setMaxResults(max);

			return criteria.list();
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in deleting the task",e);
		}
	}

	@Override
	public List<Task> getTasksByDescrManager(Project project, String searchString) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria criteria = session.createCriteria(Task.class)
					.add(Restrictions.eq("isDeleted", false))
					.add(Restrictions.eq("project", project))
					.add(Restrictions.like("description", searchString, MatchMode.ANYWHERE))
					.addOrder(Order.asc("taskId"));

			return criteria.list();
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in deleting the task",e);
		}
	}

	@Override
	public List<Task> getTasksByName(int userId, String searchString) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria criteria = session.createCriteria(Task.class)
					.add(Restrictions.eq("isDeleted", false))
					.add(Restrictions.eq("user", session.get(User.class, userId)))
					.add(Restrictions.like("taskName", searchString, MatchMode.ANYWHERE))
					.addOrder(Order.asc("taskId"));

			return criteria.list();
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in deleting the task",e);
		}
	}

	@Override
	public List<Task> getTasksByNameManager(Project project, String searchString) throws PMSTaskException {
		try {
			Session session = sessionFactory.getCurrentSession();

			Criteria criteria = session.createCriteria(Task.class)
					.add(Restrictions.eq("isDeleted", false))
					.add(Restrictions.eq("project", project))
					.add(Restrictions.like("taskName", searchString, MatchMode.ANYWHERE))
					.addOrder(Order.asc("taskId"));

			return criteria.list();
		} catch (HibernateException e) {
			//e.printStackTrace();
			throw new PMSTaskException("Problem in deleting the task",e);
		}
	}
}
