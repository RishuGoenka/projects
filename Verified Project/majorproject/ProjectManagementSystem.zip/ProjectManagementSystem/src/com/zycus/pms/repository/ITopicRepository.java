package com.zycus.pms.repository;

import java.util.List;

import com.zycus.pms.entity.Topic;
import com.zycus.pms.exception.PMSForumException;

public interface ITopicRepository {

	abstract public List<Topic> getAllTopics() throws PMSForumException;
	abstract public List<Topic> getTopicOfForum(int forumId, int first, int max) throws PMSForumException;
	abstract public void addTopic(Topic topic) throws PMSForumException;
	abstract public Topic getTopicById(int topicId) throws PMSForumException;
	
}
