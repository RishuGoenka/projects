package com.zycus.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.zycus.pms.entity.Company;
import com.zycus.pms.exception.PMSCompanyException;
import com.zycus.pms.repository.ICompanyRepository;

@Service("companyService")
public class CompanyService implements ICompanyService{

	@Autowired
	@Qualifier("companyRepository")
	private ICompanyRepository companyRepository;
	
	@Override
	public List<Company> getAllCompanies() throws PMSCompanyException {
		
		return companyRepository.getAllCompanies();
	}

	@Override
	public List<Company> getCompany(int companyId) {
		
		return companyRepository.getCompany(companyId);
	}

	@Override 
	public void addCompany(Company company){
		
		companyRepository.addCompany(company);
	}
}
