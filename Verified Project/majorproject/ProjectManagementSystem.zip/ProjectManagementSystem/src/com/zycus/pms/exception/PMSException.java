package com.zycus.pms.exception;

public class PMSException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PMSException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PMSException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
