package com.zycus.pms.exception;

public class PMSUserException extends PMSException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PMSUserException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PMSUserException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
