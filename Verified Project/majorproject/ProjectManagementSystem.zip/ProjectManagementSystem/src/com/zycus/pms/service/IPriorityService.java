package com.zycus.pms.service;

import java.util.List;

import com.zycus.pms.entity.Priority;

public interface IPriorityService {

	public List<Priority> getPriorities();

	public Priority getPriority(int priorityId);

}