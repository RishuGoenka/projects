package com.zycus.pms.service;

import java.text.ParseException;
import java.util.List;

import com.zycus.pms.entity.Task;

public interface IExcelService 
{
	public void importExcelService() throws ParseException;
	public List<Task> getAllCompletedTasks();
	public List<Task> getAllIncompleteTasks();
	public List<Task> getAllDeletedTasks();
	public boolean openExcelFile(String strExcelFile);

	public boolean openExcelFile(String strExcelFile, boolean blnFlag);

	/* @Method : resetSheetIndex
	 * @Param : no param
	 * @Description : Method will reset the global index variable with 0
	 */
	public void resetSheetIndex();

	/* @Method : setSheet
	 * @Param : no param
	 * @Description : Method will try to get the sheet at specified index. If the sheet is nulll
	 *      will try to create new sheet.
	 */
	public void setSheet();

	/* @Method : insertRow
	 * @Param : rowindex
	 * @Description : Method will insert new row if the row does not exists.
	 */
	public void insertRow(int row);

	/* @Method : insertRow
	 * @Param : rowindex
	 * @Description : Method will insert new row if the row does not exists.
	 */
	public void insertRow(short row);

	/* @Method : insertRow
	 * @Param : rowindex
	 * @Description : Method will insert new row if the row does not exists.
	 */
	public void insertRow(int row, boolean blnAppend);

	/* @Method : writeData
	 * @Param1 : col
	 * @Param2 : row
	 * @Param3 : data
	 * @Description : Method will write float data in specified row and column.
	 */
	public void writeData(int col, int row, Object data);

	/* @Method : fillColor
	 * @Param1 : sindex
	 * @Param2 : startcol
	 * @Param3 : endcol
	 * @Param4 : row
	 * @Description : Method will fill the color in specified row and column.
	 */
	public void fillColor(short sindex, int row, int startcol, int endcol);

	public void fillColor(short sindex, int row, int startcol, int endcol,
			int red, int green, int blue);

	public void setBorder(int row, int startCol, int endCol, boolean left,
			boolean top, boolean right, boolean bottom);

	public void setBorder(int row, int col, boolean left, boolean top,
			boolean right, boolean bottom);

	/* @Method : merge
	 * @Param : firstRow, lastRow, firstCol, lastCol
	 * @Description : Merges the selected rows/columns to one
	 */
	public void merge(int firstRow, int lastRow, int firstCol, int lastCol);

	/* @Method : setColumnWidth
	 * @Param : col, width
	 * @Description: Sets the column width
	 */
	public void setColumnWidth(int col, int width);

	/* @Method : closeExcel
	 * @Param : no param
	 * @Description : Method will write the contents to excel file and closes the stream.
	 */
	public void closeExcel();

}