package com.zycus.pms.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="PMS_EM4")
public class EMail {

	@Id@GenericGenerator(name="incr" , strategy="increment")
	@GeneratedValue(generator="incr")
	@Column(name="EMAIL_ID")
	private int emailId;
	
	@Column(name="EMAIL_SUBJECT")
	private String subject;
	
	@Column(name="EMAIL_BODY")
	private String body;
	
	@Column(name="SEND_DATE")
	private Date sendDate;
	
	
	@ManyToOne
	@PrimaryKeyJoinColumn
	private EMailAccount sender;
	
	@OneToMany
	@PrimaryKeyJoinColumn
	private List<EMailAccount> recipients = new ArrayList<EMailAccount>();

	public int getEmailId() {
		return emailId;
	}

	public void setEmailId(int emailId) {
		this.emailId = emailId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public Date getSendDate() {
		return sendDate;
	}

	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}

	public EMailAccount getSender() {
		return sender;
	}

	public void setSender(EMailAccount sender) {
		this.sender = sender;
	}

	public List<EMailAccount> getRecipients() {
		return recipients;
	}

	public void setRecipients(List<EMailAccount> recipients) {
		this.recipients = recipients;
	}

	@Override
	public String toString() {
		return "EMail [subject=" + subject + ", body=" + body + ", sendDate="
				+ sendDate + ", sender=" + sender  + "]";
	}
	
	
}
