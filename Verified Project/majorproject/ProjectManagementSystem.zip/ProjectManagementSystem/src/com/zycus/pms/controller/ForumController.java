package com.zycus.pms.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.pms.entity.Forum;
import com.zycus.pms.entity.Project;
import com.zycus.pms.exception.PMSException;
import com.zycus.pms.exception.PMSForumException;
import com.zycus.pms.exception.PMSProjectException;
import com.zycus.pms.logger.LogMaster;
import com.zycus.pms.service.IForumService;
import com.zycus.pms.service.IProjectService;


@Controller
@SessionAttributes("cursorForum")
public class ForumController {

	@Autowired
	private IForumService forumService;
	
	@Autowired
	private IProjectService projectService;
	
	@RequestMapping("/allForumOfProject.do")
	public String getAllForumOfProject(Map<String, Object> model,
			@RequestParam(value="view", required=false) String view, HttpServletRequest request){
		
		try {
			int projectId = (Integer) request.getSession().getAttribute("projectId");
			HttpSession session = request.getSession();
			int roleId = (Integer) session.getAttribute("roleId");
			
			Integer cursorForum = (Integer) model.get("cursorForum");
			if(cursorForum == null)
				cursorForum = 0;
			if(view != null){
				if(view.equals("next"))
					cursorForum += 5;
				else if(view.equals("previous"))
					cursorForum -= 5;
				if(cursorForum<0)
					cursorForum=0;
			}

			List<Forum> list = forumService.getForumsOfProject(projectId, cursorForum, 5);
			if(list.isEmpty()){
				cursorForum -= 5;
				list = forumService.getForumsOfProject(projectId, cursorForum, 5);
			}
			model.put("cursorForum", cursorForum);
			model.put("forumOfProject", list);
			if(roleId == 1)
				return "forumOfProject.jsp";
			else
				if(roleId == 2)
					return "forumsPageForMember.jsp";
				else
					return "errorPage.jsp";
			
		} catch (NumberFormatException e) {
			
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} catch (PMSForumException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
	}
	
	@RequestMapping("/addNewForum.do")
	public String addNewForum(Map<String, Object> model, HttpServletRequest request){
		
		List<Project> projects;
		try {
			projects = projectService.getAllProjects();
		} catch (PMSProjectException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in getting projects. Please log in again");
			return "errorPage.jsp";
		}
		
		model.put("projectList", projects);
		return "addNewForum.jsp";
	}
	
	@RequestMapping(value="/saveForum.do", method= RequestMethod.POST)
	public String saveNewForum( Map<String, Object> model,
			HttpServletRequest request){
		
		Project project = null;
		Forum forum = null;
		try {
			Integer projectId = Integer.parseInt(request.getParameter("project"));
			String forumHead = request.getParameter("forumHead");
			
			project = projectService.getProjectById(projectId);
			
			forum = new Forum();
			forum.setForumHead(forumHead);
			forum.setProject(project);
			
			forumService.addForum(forum);
			
			return "redirect:allForumOfProject.do";
		} catch (NumberFormatException e) {
			LogMaster.getLogger(this.getClass()).error(project, e);
			LogMaster.getLogger(this.getClass()).error(forum, e);
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} catch (PMSException e) {
			LogMaster.getLogger(this.getClass()).error(project, e);
			LogMaster.getLogger(this.getClass()).error(forum, e);
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
	}
	
}