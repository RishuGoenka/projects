package com.zycus.pms.repository;

import java.util.List;

import com.zycus.pms.entity.Company;
import com.zycus.pms.exception.PMSCompanyException;

public interface ICompanyRepository {

	abstract public List<Company> getAllCompanies() throws PMSCompanyException;
	abstract public List<Company> getCompany(int companyId);
	abstract public void addCompany(Company company);
}
