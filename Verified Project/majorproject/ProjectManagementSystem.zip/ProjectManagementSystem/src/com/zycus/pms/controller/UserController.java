package com.zycus.pms.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.validation.BindingResult;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


import com.zycus.pms.entity.User;
import com.zycus.pms.exception.PMSCompanyException;
import com.zycus.pms.exception.PMSUserException;
import com.zycus.pms.logger.LogMaster;
import com.zycus.pms.service.ICompanyService;
import com.zycus.pms.service.IRoleService;
import com.zycus.pms.service.IUserService;

@Controller
@SessionAttributes({"userId","roleId"})
public class UserController {
	
	@Autowired
	private LogMaster logger;
	
	@Autowired
	Validator validator;

	@Autowired
	private IUserService userService;

	@Autowired
	private ICompanyService companyService;

	@Autowired
	private IRoleService roleService;

/*	@RequestMapping("/addUser.do")
	public String redirect(Map<String, Object> model, HttpServletRequest request){
		try {
			model.put("user", new User());
			model.put("companyList", companyService.getAllCompanies());
			model.put("roles", roleService.getAllRoles());

			return "addNewUser.jsp";
		} catch (PMSCompanyException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
	}*/
	
	@RequestMapping("/addUser.do")//new
	public String addUserTest(Map<String, Object> model, HttpServletRequest request){
		try {
			model.put("user", new User());
			model.put("companyList", companyService.getAllCompanies());
			model.put("roles", roleService.getAllRoles());

			return "addUser.jsp";
		} catch (PMSCompanyException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
	}
	
	@RequestMapping("/saveUser.do")//new
	public String addTask(
			@Valid @ModelAttribute("user") User user,
			BindingResult result,
			Map<String, Object> model,
			HttpServletRequest request) throws PMSUserException{
		
		try {
			
			validator.validate(user, result);
			if(result.hasErrors()){
				model.put("companyList", companyService.getAllCompanies());
				model.put("roles", roleService.getAllRoles());
				return "addUser.jsp";
			}
			else{
				
				userService.addUser(user);
				return "addedUser.jsp";
			}
		} catch (PMSCompanyException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			LogMaster.getLogger(this.getClass()).error(user, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
		
		
	}
	
	
	/*@RequestMapping(value="/saveUser.do", method= RequestMethod.POST)
	public String save( Map<String, Object> model,
			HttpServletRequest request){
			User user = null;
		try {
			Integer roleId = Integer.parseInt(request.getParameter("role"));
			Integer companyId = Integer.parseInt(request.getParameter("company"));

			ArrayList<Role> roles = (ArrayList<Role>) roleService.getRole(roleId);
			ArrayList<Company> companies = (ArrayList<Company>) companyService.getCompany(companyId);

			user = new User();

			user.setUserName(request.getParameter("userName"));
			user.setPassword(request.getParameter("password"));
			user.setFullName(request.getParameter("fullName"));

			user.setRole(roles.get(0));
			user.setCompany(companies.get(0));


			userService.addUser(user);
			return "addedUser.jsp";
		} catch (NumberFormatException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} catch (PMSUserException e) {
			LogMaster.getLogger(this.getClass()).error(user, e);
			request.setAttribute("errorMessage", "Problem in adding user. Please try again");
			return "errorPage.jsp";
		}
	}*/

	@RequestMapping("/login.do")
	public String login(){
		return "login.jsp";
	}

	@RequestMapping(value="checkCredentials.do", method= RequestMethod.POST)
	public String checkCredentials(@RequestParam("userName")String userName, 
			@RequestParam("password")String password,  Map<String, Object> model,
			HttpServletRequest request){
		
		User user = null;

		try {
			if(userService.checkManagerCredentials(userName, password)){

				user = userService.getUser(userName);
				model.put("userId", user.getUserId());
				model.put("roleId", user.getRole().getRoleId());

				if(user.getRole().getRoleId()== 1)
					return "owner.jsp";
				else 
					if(user.getRole().getRoleId()==2)
						return "redirect:listProjectsByMember.do";
					else
						return "loginUnsucessfull.jsp";
			}else
				return "loginUnsucessfull.jsp";
		} catch (PMSUserException e) {
			LogMaster.getLogger(this.getClass()).error(user, e);
			request.setAttribute("errorMessage", "Problem in Login . Please try again");
			return "errorPage.jsp";
		}

	}
	
	@RequestMapping("/homePage.do")
	public String homePage(HttpServletRequest request){
		try {
			HttpSession session = request.getSession();
			int roleId = (Integer) session.getAttribute("roleId");
			if(roleId== 1)
				return "owner.jsp";
			else if(roleId==2)
					return "return:showTasks.do";
			else
				return "redirect:login.do";
		} catch (Exception e) {
			return "redirect:login.do";
		}
	}
}
