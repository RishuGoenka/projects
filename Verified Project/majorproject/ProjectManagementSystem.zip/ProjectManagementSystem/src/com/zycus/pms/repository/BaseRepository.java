package com.zycus.pms.repository;

import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import com.zycus.pms.util.HibernateUtil;


public class BaseRepository {
	
	public void jpaSave(Object obj){
		//1. We need an EntityManagerFactory object
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA");
		//2. EntityManager object
		EntityManager em = emf.createEntityManager();
		//3. Bind the em to the an active transportation
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		em.merge(obj);
		try{
			tx.commit();
		} catch(Exception e){
			e.printStackTrace();
			tx.rollback();
			//notify by throwing an exception
		} finally{
			em.close();
		}
	}

	public void saveOrUpdate(Object obj){
		//1.access the SessionFactory Object
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		//2.Get a session object
		Session session = sessionFactory.getCurrentSession();
		//3.Get an active connection
		Transaction tx = session.beginTransaction();
		//4.Code for insertion or updation
			//for transient -> Insert
			//for detached -> Update
		session.saveOrUpdate(obj);
		try{
			tx.commit();
		} catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			//notify by throwing an exception
		}
	}
	
	/*public void update(Object obj){
		//1.access the SessionFactory Object
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		//2.Get a session object
		Session session = sessionFactory.getCurrentSession();
		//3.Get an active connection
		Transaction tx = session.beginTransaction();
		//4.Code for updating
		session.update(obj);
		try{
			tx.commit();
		} catch(Exception e){
			tx.rollback();
			e.printStackTrace();
			//notify by throwing an exception
		}
	}*/
	
	@SuppressWarnings("unchecked")
	public <E>E get(Class<E> classname, Serializable pk){
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();
		E e = (E) session.get(classname, pk);
		tx.commit();
		return e;
	}
}
