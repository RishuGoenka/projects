package com.zycus.pms.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.pms.entity.Post;
import com.zycus.pms.entity.Topic;
import com.zycus.pms.entity.User;
import com.zycus.pms.exception.PMSForumException;
import com.zycus.pms.exception.PMSUserException;
import com.zycus.pms.logger.LogMaster;
import com.zycus.pms.service.IPostService;
import com.zycus.pms.service.ITopicService;
import com.zycus.pms.service.IUserService;

@Controller
@SessionAttributes("cursorPost")
public class PostController {
	
	
	@Autowired
	private IPostService postService;
	
	@Autowired
	private ITopicService topicService;
	
	@Autowired
	private IUserService userService;
	
	
	@RequestMapping("/postOfTopic.do")
	public String getAllTopicsOfForum(Map<String, Object> model,
			@RequestParam(value="view", required=false) String view, 
			@RequestParam(value="topicId", required=false) int topicId,HttpServletRequest request){
		
		try {
			Integer cursorPost = (Integer) model.get("cursorPost");
			if(cursorPost == null)
				cursorPost = 0;
			if(view != null){
				if(view.equals("next"))
					cursorPost += 5;
				else if(view.equals("previous"))
					cursorPost -= 5;
				if(cursorPost<0)
					cursorPost=0;
			}
			List<Post> list = postService.getPostOfTopic(topicId, cursorPost, 5);
			if(list.isEmpty()){
				cursorPost-= 5;
				list = postService.getPostOfTopic(topicId, cursorPost, 5);
			}
			model.put("cursorPost", cursorPost);
			model.put("postOfTopic", list);
			model.put("topicId", topicId);
			return "postOfTopic.jsp";
		} catch (PMSForumException e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
	}
	
	@RequestMapping("/addNewPost.do")
	public String addNewPost(@RequestParam("topicId") int topicId,  Map<String, Object> model){
		
		model.put("topicId", topicId);
		return "addNewPost.jsp";
	}
	
	@RequestMapping(value="/savePost.do", method= RequestMethod.POST)
	public String saveTopic(Map<String, Object> model,
			HttpServletRequest request){
		
		User user = null;
		Post post = null;
		try {
			int topicId = Integer.parseInt(request.getParameter("topicId"));
			Topic topic = topicService.getTopicById(topicId); 
			
			int userId = (Integer) request.getSession().getAttribute("userId");
			
			user = userService.getUserById(userId); 
			
			post = new Post();
			post.setDescription(request.getParameter("description"));
			post.setPostDate(new Date());
			post.setUser(user);
			post.setTopic(topic);
			
			postService.addPost(post);

			return "redirect:postOfTopic.do?topicId="+topicId;
		} catch (NumberFormatException e) {
			LogMaster.getLogger(this.getClass()).error(user, e);
			LogMaster.getLogger(this.getClass()).error(post, e);
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} catch (PMSForumException e) {
			LogMaster.getLogger(this.getClass()).error(user, e);
			LogMaster.getLogger(this.getClass()).error(post, e);
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} catch (PMSUserException e) {
			LogMaster.getLogger(this.getClass()).error(user, e);
			LogMaster.getLogger(this.getClass()).error(post, e);
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
	}
	
	
}
