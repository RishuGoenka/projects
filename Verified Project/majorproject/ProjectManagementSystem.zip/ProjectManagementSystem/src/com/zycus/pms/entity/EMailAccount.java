package com.zycus.pms.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="PMS_EM_A4")
public class EMailAccount {

	@Id@GenericGenerator(name="incr" , strategy="increment")
	@GeneratedValue(generator="incr")
	@Column(name="EMAIL_ACCOUNT_ID")
	private int emailAccountId;
	
	@OneToOne
	private User user;
	
	@OneToMany(mappedBy="sender")
	private List<EMail> sentMail = new ArrayList<EMail>();
	
	@ManyToMany
	@PrimaryKeyJoinColumn
	private List<EMail> inboxMail = new ArrayList<EMail>();;

	public int getEmailAccountId() {
		return emailAccountId;
	}

	public void setEmailAccountId(int emailAccountId) {
		this.emailAccountId = emailAccountId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<EMail> getSentMail() {
		return sentMail;
	}

	public void setSentMail(List<EMail> sentMail) {
		this.sentMail = sentMail;
	}

	public List<EMail> getInboxMail() {
		return inboxMail;
	}

	public void setInboxMail(List<EMail> inboxMail) {
		this.inboxMail = inboxMail;
	}
	
	
}
