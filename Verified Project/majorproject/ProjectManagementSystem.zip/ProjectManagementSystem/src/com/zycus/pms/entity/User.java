package com.zycus.pms.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="PMS_USER1")
public class User {

	@Id@GenericGenerator(name="incr" , strategy="increment")
	@GeneratedValue(generator="incr")
	@Column(name="USER_ID")
	private int userId;
	
	@Column(name="USER_NAME")
	@Size(min=3, max=18, message="UserName must be minimum 3 characters and maximum 18 characters long")
	private String userName;
	
	@Size(min=8,  message="Password must be minimum 8 characters long")
	@Column(name="PASSWORD")
	private String password;
	
	@Size(min=3, message="Full Name must be minimum 3 characters long")
	@Column(name="FULL_NAME")
	private String fullName;
	
	@Column(name="SECURITY_ANSWER")
	private String securityAnswer;
	
	@ManyToOne
	private Role role;
	
	@ManyToOne
	private Company company;
	
	@ManyToOne
	private SecurityQuestion securityQuestion;
	
	@ManyToMany(mappedBy="projectMembers")
	private List<Project> projects;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}
	
	public List<Project> getProjects() {
		return projects;
	}

	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName
				+ ", fullName=" + fullName + ", role=" + role + ", company="
				+ company + "]";
	}

	public void setSecurityQuestion(SecurityQuestion securityQuestion) {
		this.securityQuestion = securityQuestion;
	}

	public SecurityQuestion getSecurityQuestion() {
		return securityQuestion;
	}
	
	
}
