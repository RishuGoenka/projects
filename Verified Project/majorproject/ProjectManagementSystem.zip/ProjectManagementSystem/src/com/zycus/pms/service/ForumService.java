package com.zycus.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.zycus.pms.entity.Forum;
import com.zycus.pms.exception.PMSForumException;
import com.zycus.pms.repository.IForumRepository;

@Service("forumService")
public class ForumService implements IForumService {

	@Autowired
	@Qualifier("forumRepository")
	private IForumRepository forumRepository;

	@Override
	public List<Forum> getForumsOfProject(int projectId, int first, int max) throws PMSForumException {
	
		try {
			return forumRepository.getForumsOfProject(projectId, first,  max);
		} catch (PMSForumException e) {
			throw new PMSForumException("Error getForumsOfProject service", e);
		}
	}
	
	@Override
	public void addForum(Forum forum) throws PMSForumException{
		try {
			forumRepository.addForum(forum);
		} catch (PMSForumException e) {
			throw new PMSForumException("Error addForum service", e);
		}
	}
	
	@Override
	public Forum getForumById(int forumId) throws PMSForumException{
		try {
			return forumRepository.getForumById(forumId);
		} catch (PMSForumException e) {
			throw new PMSForumException("Error getForumById service", e);
		}
	}
}
 