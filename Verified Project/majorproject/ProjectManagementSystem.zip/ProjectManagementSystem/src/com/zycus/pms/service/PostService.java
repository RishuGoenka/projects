package com.zycus.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.zycus.pms.entity.Post;
import com.zycus.pms.exception.PMSForumException;
import com.zycus.pms.repository.IPostRepository;

@Service("postService")
public class PostService implements IPostService {

	@Autowired
	@Qualifier("postRepository")
	private IPostRepository postRepository;
	
	@Override
	public List<Post> getAllPosts() throws PMSForumException{
		try {
			return postRepository.getAllPosts();
		} catch (PMSForumException e) {
			throw new PMSForumException("Error getAllPosts service", e);
		}
	}
	
	@Override
	public List<Post> getPostOfTopic(int topicId, int first, int max) throws PMSForumException{
		try {
			return postRepository.getPostOfTopic(topicId, first, max);
		} catch (PMSForumException e) {
			throw new PMSForumException("Error getPostOfTopic service", e);
		}
	}
	
	@Override
	public void addPost(Post post) throws PMSForumException{
		try {
			postRepository.addPost(post);
		} catch (PMSForumException e) {
			throw new PMSForumException("Error addPost service", e);
		}
	}
}
