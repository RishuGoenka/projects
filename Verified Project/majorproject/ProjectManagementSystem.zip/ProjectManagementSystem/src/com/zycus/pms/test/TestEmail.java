package com.zycus.pms.test;

import java.util.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.junit.Test;

import com.zycus.pms.entity.EMail;
import com.zycus.pms.entity.EMailAccount;
import com.zycus.pms.entity.User;
import com.zycus.pms.repository.BaseRepository;
import com.zycus.pms.util.HibernateUtil;

public class TestEmail {

	@Test
	public void addMailAcc(){
		BaseRepository base = new BaseRepository();
		
		EMailAccount acc1 = new EMailAccount();
		acc1.setUser(base.get(User.class, 9));
		
		base.saveOrUpdate(acc1);
	}
	
	@Test
	public void SendMail(){
		BaseRepository base = new BaseRepository();
		
		EMailAccount sender = base.get(EMailAccount.class, 1);
		EMailAccount receiver = base.get(EMailAccount.class, 2);
		
		EMail mail = new EMail();
		mail.setBody("Aur bhiya kya haal h???");
		mail.setSubject("Mail 1");
		mail.setSendDate(new Date());
		mail.setSender(sender);
		mail.getRecipients().add(receiver);
		
		base.saveOrUpdate(mail);
	}
	@Test
	public void testInbox(){
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();
		try{
		EMailAccount acc =(EMailAccount) session.get(EMailAccount.class,2);
		
		List<EMail> mails = acc.getSentMail();
		
		for(EMail mail : mails){
			
			System.out.println(mail);
			
		}
		
		
			tx.commit();
		} catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
	}
}
