package com.zycus.pms.service;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.zycus.pms.entity.Project;
import com.zycus.pms.entity.User;
import com.zycus.pms.exception.PMSProjectException;
import com.zycus.pms.repository.BaseRepository;
import com.zycus.pms.repository.IProjectRepository;

@Service
public class ProjectServiceImpl implements IProjectService
{
	
	@Autowired
	private IProjectRepository projectRepository;
	
	@Override
	public String addNewProject(Project project) throws PMSProjectException
	{
		try 
		{
			//BaseRepository dao = new BaseRepository();
			//project.setProjectOwner(dao.get(User.class, 1));
			projectRepository.addNewProject(project);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to add New Project",e);
		}
		return("Project Successfully added.");
	}

	@Override
	public List<Project> getAllProjects() throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getAllProjects();
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get all projects",e);
		}
		return projList;
	}

	@Override
	public String delExistingProject(int projectId) throws PMSProjectException 
	{
		try 
		{
			projectRepository.delExistingProject(projectId);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to delete existing Project",e);
		}
		return("Project Successfully removed.");
	}

	@Override
	public List<Project> getProjectsByOwner(int ownerId, int offset, int rows) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getProjectsByOwner(ownerId, offset, rows);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Projects By Owner", e);
		}
		return projList;
	}
	
	@Override
	public List<Project> getPendingProjects(int ownerId, int offset, int rows) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getPendingProjects(ownerId, offset, rows);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Pending Project", e);
		}
		return projList;
	}

	@Override
	public List<Project> getCompletedProjects(int ownerId, int offset, int rows) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getCompletedProjects(ownerId, offset, rows);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Completed Projects", e);
		}
		return projList;
	}

	@Override
	public Project getProjectById(int projectId) throws PMSProjectException 
	{
		Project proj;
		try 
		{
			proj = projectRepository.getProjectById(projectId);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Project from ID", e);
		}
		return proj;
	}

	@Override
	public void modifyTheProject(String name, String desc,
			Date startDate, Date deadLine) throws PMSProjectException
	{
		
		try 
		{
			Project proj = new Project();
			proj.setDeadLine(deadLine);
			proj.setStartDate(startDate);
			proj.setDescription(desc);
			proj.setProjectTitle(name);
			
			projectRepository.modifyTheProject(proj);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to modify the project", e);
		}
	}

	@Override
	public void markProjectAsDone(Project project) throws PMSProjectException 
	{
		try 
		{
			projectRepository.markProjectAsDone(project);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to Mark Project As Done", e);
		}
	}

	@Override
	public List<Project> getProjectsByMember(int memberId) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getProjectsByMember(memberId);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Projects Of Member", e);
		}
		return projList;
	}

	@Override
	public List<Project> getIncompleteProjectsByDeadLine(Date deadDate) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getIncompleteProjectsByDeadLine(deadDate);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Incomplete Projects Approaching Deadline", e);
		}
		return projList;
	}

	@Override
	public List<Project> getProjectsByOwner(int ownerId) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getProjectsByOwner(ownerId);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Projects Of Owner", e);
		}
		return projList;
	}

	@Override
	public List<Project> getPendingProjects(int ownerId) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getPendingProjects(ownerId);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Pending Project", e);
		}
		return projList;
	}

	@Override
	public List<Project> getCompletedProjects(int ownerId) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getCompletedProjects(ownerId);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Completed Projects", e);
		}
		return projList;
	}

	@Override
	public List<Project> getActiveProjects(int ownerId, int offset, int rows) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getActiveProjects(ownerId, offset, rows);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Pending Project", e);
		}
		return projList;
	}

	@Override
	public List<Project> getActiveProjects(int ownerId) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getActiveProjects(ownerId);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get Pending Project", e);
		}
		return projList;
	}

	@Override
	public List<Project> getAllProjects(int offset, int rows) throws PMSProjectException 
	{
		List<Project> projList;
		try 
		{
			projList = projectRepository.getAllProjects(offset, rows);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to retrieve All Projects", e);
		}
		return projList;
	}

	@Override
	public void modifyTheProject(Project project) throws PMSProjectException 
	{
		try 
		{
			projectRepository.modifyTheProject(project);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to modify the project", e);
		}
	}

	@Override
	public int getIdFromProject(Project project) throws PMSProjectException 
	{
		int projectId;
		try 
		{
			projectId = projectRepository.getIdFromProject(project);
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Failed to get ID from Project", e);
		}
		return projectId;
	}
	
}
