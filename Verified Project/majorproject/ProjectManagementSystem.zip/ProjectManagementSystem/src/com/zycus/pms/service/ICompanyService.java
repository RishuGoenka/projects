package com.zycus.pms.service;

import java.util.List;

import com.zycus.pms.entity.Company;
import com.zycus.pms.exception.PMSCompanyException;

public interface ICompanyService {
	
	abstract public List<Company> getAllCompanies() throws PMSCompanyException;
	abstract public List<Company> getCompany(int companyId);
	abstract public void addCompany(Company company);
}
