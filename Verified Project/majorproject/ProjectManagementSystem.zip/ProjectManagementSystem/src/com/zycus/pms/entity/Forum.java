package com.zycus.pms.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="PMS_FORUM1")
public class Forum {

	@Id@GenericGenerator(name="incr" , strategy="increment")
	@GeneratedValue(generator="incr")
	@Column(name="FORUM_ID")
	private int forumId;
	
	@Column(name="FORUM_HEAD") 
	private String forumHead;
	
	@ManyToOne
	@PrimaryKeyJoinColumn
	private Project project;

	public String getForumHead() {
		return forumHead;
	}

	public void setForumHead(String forumHead) {
		this.forumHead = forumHead;
	}

	public int getForumId() {
		return forumId;
	}

	public void setForumId(int forumId) {
		this.forumId = forumId;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	@Override
	public String toString() {
		return "Forum [forumId=" + forumId + ", forumHead=" + forumHead
				+ ", project=" + project + "]";
	}

	
}
