package com.zycus.pms.service;

import java.util.List;

import org.hibernate.HibernateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


import com.zycus.pms.entity.User;
import com.zycus.pms.exception.PMSUserException;
import com.zycus.pms.repository.IUserRepository;


@Service("userService")
public class UserService  implements IUserService{

	@Autowired
	@Qualifier("userRepository")
	private IUserRepository userRepository;

	@Override
	public void addUser(User user) throws PMSUserException {
		try {
			userRepository.addUser(user);
		} catch (Exception e) {
			throw new PMSUserException("Couldn't add user in user srvice", e);
		}
	}

	@Override
	public boolean checkManagerCredentials(String userName, String password) throws PMSUserException {
		
		try {
			return userRepository.checkManagerCredentials(userName, password);
		} catch (Exception e) {
			throw new PMSUserException("Error in checkCredential service", e);
		}
	}

	@Override
	public User getUser(String userName) throws PMSUserException {
		
		try {
			return userRepository.getUser(userName);
		} catch (Exception e) {
			throw new PMSUserException("Error in getUser service", e);
		}
	}
	
	@Override
	public User getUserById(int userId) throws PMSUserException{
		try {
			return userRepository.getUserById(userId);
		} catch (Exception e) {
			throw new PMSUserException("Error in getUserById service", e);
		}
	}
	
	@Override
	public List<User> getUsersOfCompany(int companyId) throws PMSUserException{
		
		try {
			return userRepository.getUsersOfCompany(companyId);
		}catch (HibernateException e) {
			throw new PMSUserException("Error in retriving user list ", e);
		}
	}
}
