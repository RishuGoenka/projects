package com.zycus.pms.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.junit.Test;

import com.zycus.pms.entity.Company;
import com.zycus.pms.entity.Priority;
import com.zycus.pms.entity.Project;
import com.zycus.pms.entity.Role;
import com.zycus.pms.entity.Task;
import com.zycus.pms.entity.User;
import com.zycus.pms.repository.BaseRepository;
import com.zycus.pms.util.HibernateUtil;

public class ProjectTest {

	
	@Test
	public void addCompany(){
		BaseRepository dao = new BaseRepository();
		
		Company comp = new Company();
		comp.setCompanyName("Google");
		
		dao.saveOrUpdate(comp);
	}
	
	@Test
	public void addRoleOwner(){
		BaseRepository dao = new BaseRepository();
		
		Role role = new Role();
		
		role.setRoleType("Owner");
		
		dao.saveOrUpdate(role);
	}
	
	@Test
	public void addRoleMem(){
		BaseRepository dao = new BaseRepository();
		
		Role role = new Role();
		
		role.setRoleType("Project Member");
		
		dao.saveOrUpdate(role);
	}
	
	@Test
	public void addOwner(){
		BaseRepository dao = new BaseRepository();
		
		User user = new User();
		
		user.setCompany(dao.get(Company.class, 1));
		user.setFullName("New Pappu Singh");
		user.setPassword("pappukanayapassword"); 
		user.setRole(dao.get(Role.class, 1));
		user.setUserName("pappu");
		
		dao.saveOrUpdate(user);
	}
	
	@Test
	public void addUser1(){
		BaseRepository dao = new BaseRepository();
		
		User user = new User();
		
		user.setCompany(dao.get(Company.class, 1));
		user.setFullName("Ramesh Singh");
		user.setPassword("r");
		user.setRole(dao.get(Role.class, 2));
		user.setUserName("ramesh");
		
		dao.saveOrUpdate(user);
	}
	
	@Test
	public void addUser2(){
		BaseRepository dao = new BaseRepository();
		
		User user = new User();
		
		user.setCompany(dao.get(Company.class, 1));
		user.setFullName("Suresh Singh");
		user.setPassword("s");
		user.setRole(dao.get(Role.class, 2));
		user.setUserName("suresh");
		
		dao.saveOrUpdate(user);
	}
	
	@Test
	public void addTask1(){
		BaseRepository dao = new BaseRepository();
		
		Task task = new Task();
		task.setDeadLine(new Date());
		task.setEndDate(new Date());
		task.setStartDate(new Date());
		task.setDescription("TEST TASK");
		
		task.setPercentCompleted(50);
		task.setUser(dao.get(User.class, 2));
		
		dao.saveOrUpdate(task);
		
	}
	
	@Test
	public void addTask2(){
		BaseRepository dao = new BaseRepository();
		
		Task task = new Task();
		task.setDeadLine(new Date());
		task.setEndDate(new Date());
		task.setStartDate(new Date());
		
		task.setPercentCompleted(100);
		task.setUser(dao.get(User.class, 2));
		
		dao.saveOrUpdate(task);
		
	}
	
	@Test
	public void addPriorities(){
		BaseRepository dao = new BaseRepository();
		

		Priority p1 = new Priority();
		p1.setPriorityId(1);
		p1.setPriority("Low");
		
		Priority p3 = new Priority();
		p3.setPriorityId(3);
		p3.setPriority("High");
		
		Priority p2 = new Priority();
		p2.setPriorityId(2);
		p2.setPriority("Normal");
		
		dao.saveOrUpdate(p1);
		dao.saveOrUpdate(p2);
		dao.saveOrUpdate(p3);
		
	}
	
	@Test
	public void addTask3(){
		BaseRepository dao = new BaseRepository();
		
		Task task = new Task();
		task.setDeadLine(new Date());
		task.setEndDate(new Date());
		task.setStartDate(new Date());
		task.setPriority(dao.get(Priority.class, 2));
		task.setProject(dao.get(Project.class, 2));
		task.setDescription("TASK OF PROJ 2");
		task.setDeleted(true);
		task.setTaskName("DELETED TASK");
		
		task.setPercentCompleted(50);
		task.setUser(dao.get(User.class, 3));
		
		dao.saveOrUpdate(task);
		
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void getTaskFromUser(){
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Task.class)
				.add(Restrictions.eq("user", session.get(User.class, 2)));
		
		ArrayList<Task> tasks = new ArrayList<Task>(criteria.list());
		
		for(Task task : tasks){
			System.out.println(task);
		}
		
		try{
			tx.commit();
		} catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void getUserFromTask(){
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Task.class);
		
		ArrayList<Task> tasks = new ArrayList<Task>(criteria.list());
		
		for(Task task : tasks){
			System.out.println(task.getUser());
		}
		
		try{
			tx.commit();
		} catch(Exception e){
			tx.rollback();
			e.printStackTrace();
		}
	}
	
	@Test
	public void addProject1(){
		BaseRepository dao = new BaseRepository();
		
		Project project = new Project();
		project.setDeadLine(new Date());
		project.setDescription("Yehi hai Zindagi");
		project.setEndDate(new Date());
		project.setCompleted(false);
		project.setDeleted(false);
		
		ArrayList<User> list = new ArrayList<User>();
		list.add(dao.get(User.class, 2));
		list.add(dao.get(User.class, 3));
		project.setProjectMembers(list);
		
		ArrayList<Task> tasks = new ArrayList<Task>();
		tasks.add(dao.get(Task.class, 1));
		tasks.add(dao.get(Task.class, 2));
		project.setTasks(tasks);
		
		project.setProjectOwner(dao.get(User.class, 1));
		
		project.setProjectTitle("NewStuff");
		
		project.setStartDate(new Date());
		
		dao.saveOrUpdate(project);
	}
	
	@Test
	public void addBlankProject(){
		BaseRepository dao = new BaseRepository();
		
		Project project = new Project();
		project.setDeadLine(new Date());
		project.setDescription("Kya baat hai");
		project.setEndDate(new Date());

		project.setCompleted(false);
		
		project.setProjectOwner(dao.get(User.class, 1));
		
		project.setProjectTitle("BLANK");
		
		project.setStartDate(new Date());
		
		dao.saveOrUpdate(project);
	}
	
	@Test
	public void updateProject1(){
		BaseRepository dao = new BaseRepository();
		
		Project project = dao.get(Project.class, 1);
		
		project.setCompleted(false);
		
		dao.saveOrUpdate(project);
		
	}
	
	@Test
	public void getMembersByProject()
	{
		int projectId = 25;

		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();

		Project project = (Project) session.get(Project.class, projectId);
		List<User> listMembers = project.getProjectMembers();
		for(User user : listMembers)
		{
			System.out.println(user.getFullName());
		}
		tx.commit();
	} 
	
}
