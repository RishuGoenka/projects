package com.zycus.pms.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.pms.entity.Company;
import com.zycus.pms.entity.User;
import com.zycus.pms.exception.PMSUserException;

@Repository("userRepository")
@Transactional
@SuppressWarnings("unchecked")
public class UserRepository implements IUserRepository{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void addUser(User user) throws PMSUserException{
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(user);
		} catch (HibernateException e) {
			throw new PMSUserException("Couldn't add user", e);
		}
	}
	
	
	@Override
	public List<User> getUsersOfCompany(int companyId) throws PMSUserException{
		
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteriaCompany = session.createCriteria(Company.class);
			criteriaCompany.add(Restrictions.eq("companyId", companyId)); 
			
			Company company = (Company) criteriaCompany.list().get(0);
			
			Criteria criteriaUser = session.createCriteria(User.class);
			criteriaUser.add(Restrictions.eq("company", company));
			
			return criteriaUser.list();
		} catch (HibernateException e) {
			throw new PMSUserException("Error in retriving user list ", e);
		}
		
	}
	
	@Override
	public boolean checkManagerCredentials(String userName, String password) throws PMSUserException{
		
		Boolean flag=false;
		try {
			
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(User.class);
			criteria.add(Restrictions.eq("userName", userName));
			User user = (User) criteria.list().get(0);
			
			flag = false;
			if(user.getPassword().equals(password) ){
				flag = true;
			
			}
		}catch (HibernateException e) {
			throw new PMSUserException("Error in checking credentials ", e);
		}

		return flag;
	}


	@Override
	public User getUser(String userName) throws PMSUserException {
		
		User user;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(User.class);
			criteria.add(Restrictions.eq("userName", userName));
			user = (User) criteria.list().get(0);
			
			return user;
			
		} catch (HibernateException e) {
			throw new PMSUserException("Error in user checking ", e);
		}
		
		
		
	}
	
	@Override
	public User getUserById(int userId) throws PMSUserException{
		
		User user;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(User.class);
			criteria.add(Restrictions.eq("userId", userId));
			
			user = (User) criteria.list().get(0);
			return user;
			
		} catch (HibernateException e) {
			throw new PMSUserException("Error in user checking ", e);
		}
		
		
		
	}
	
	
}
