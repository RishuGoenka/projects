package com.zycus.pms.repository;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.pms.entity.Priority;

@Repository
@Transactional
public class PriorityRepository implements IPriorityRepository {

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	@SuppressWarnings("unchecked")
	public List<Priority> getPriorities(){
		try {
			Session session = sessionFactory.getCurrentSession();
			
			Criteria criteria = session.createCriteria(Priority.class);
			
			return criteria.list();
		} catch (HibernateException e) {
			e.printStackTrace();
			return new ArrayList<Priority>();
		}
		
	}

	@Override
	public Priority getPriority(int priorityId) {
		Session session = sessionFactory.getCurrentSession();
		
		Criteria criteria = session.createCriteria(Priority.class)
				.add(Restrictions.eq("priorityId", priorityId));
		
		return (Priority) criteria.uniqueResult();
	}
	
}
