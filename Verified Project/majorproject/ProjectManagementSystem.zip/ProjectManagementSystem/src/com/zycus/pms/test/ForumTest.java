package com.zycus.pms.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.junit.Test;

import com.zycus.pms.entity.Forum;
import com.zycus.pms.entity.Post;
import com.zycus.pms.entity.Project;
import com.zycus.pms.entity.Topic;
import com.zycus.pms.entity.User;
import com.zycus.pms.repository.BaseRepository;
import com.zycus.pms.util.HibernateUtil;

public class ForumTest {

	@Test
	public void createForum(){
		
		BaseRepository base = new BaseRepository();
		Forum forum = new Forum();
		forum.setProject(base.get(Project.class, 1));
		forum.setForumHead("Forum 2");
		
		base.saveOrUpdate(forum);
	}
	
	@Test
	public void createTopic(){
		
		BaseRepository base = new BaseRepository();
		Topic topic = new Topic();
		topic.setForum(base.get(Forum.class, 1));
		topic.setName("Topic 4");

		
		base.saveOrUpdate(topic);
	}
	
	@Test
	public void testTopic(){
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();
		
		Criteria criteria = session.createCriteria(Topic.class);
		List<Topic> topics = new ArrayList<Topic>(criteria.list());
		
		for(Topic topic : topics ){
			System.out.println(topic); 
		
		}
	
		try{	
			tx.commit();
		} catch(Exception e){
			e.printStackTrace();
			tx.rollback();
		}
	}
	
	@Test
	public void addPost1(){
		
		BaseRepository base = new BaseRepository();
		Post post = new Post();
		post.setTopic(base.get(Topic.class, 3));
		
		post.setPostDate(new Date());
		post.setUser(base.get(User.class, 2));
		post.setDescription("This is post 1 of topic 3");
		
		base.saveOrUpdate(post);
	}
	
	@Test
	public void getAllTopics(){
		
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();
		try{
			
		Criteria cri1 = session.createCriteria(Forum.class).add(Restrictions.like("forumId", 1));	
		Forum forum = (Forum) cri1.list().get(0);
		System.out.println(forum);
		
		/*Criteria criteria = session.createCriteria(Topic.class).add(Restrictions.eq("forum", forum.getForumId()));
			List<Topic> topics = new ArrayList<Topic>(criteria.list());*/
		Criteria criteria = session.createCriteria(Topic.class)
		.add(Restrictions.eq("forum",forum));
		
		List<Topic> topics = new ArrayList<Topic>(criteria.list());	
		
			System.out.println("asdhfuk"); 
			for(Topic topic : topics){ 
				System.out.println(topic);   
			}
			
		
				tx.commit();
			} catch(Exception e){
				e.printStackTrace();
				tx.rollback();
				
			}	
	}
	
	@Test
	public void getAllPosts(){
		
		
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Session session = sessionFactory.getCurrentSession();
		Transaction tx = session.beginTransaction();
		try{
			
		Criteria cri1 = session.createCriteria(Topic.class).add(Restrictions.like("topicId", 2));	
		Topic topic = (Topic) cri1.list().get(0);
		System.out.println(topic);
		
		/*Criteria criteria = session.createCriteria(Topic.class).add(Restrictions.eq("forum", forum.getForumId()));
			List<Topic> topics = new ArrayList<Topic>(criteria.list());*/
		Criteria criteria = session.createCriteria(Post.class)
		.add(Restrictions.eq("topic",topic));
		
		List<Post> posts = new ArrayList<Post>(criteria.list());	
		
			System.out.println("asdhfuk");
			
			for(Post post : posts){ 
				System.out.println(post);   
			}
			
		
				tx.commit();
			} catch(Exception e){
				e.printStackTrace();
				tx.rollback();
				
			}	
	}
}
