package com.zycus.pms.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.pms.entity.Project;
import com.zycus.pms.entity.Task;
import com.zycus.pms.entity.User;
import com.zycus.pms.exception.PMSProjectException;
import com.zycus.pms.exception.PMSUserException;
import com.zycus.pms.logger.LogMaster;
import com.zycus.pms.repository.BaseRepository;
import com.zycus.pms.service.IProjectService;
import com.zycus.pms.service.IUserService;

@Controller
@SessionAttributes({"cursor","projectId"})
public class ProjectController
{
	@Autowired
	private LogMaster logger;
	
	@InitBinder
	private void dateBinder(WebDataBinder binder) 
	{
	    //The date format to parse or output your dates
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yy-MM-dd");
	    
	    //Create a new CustomDateEditor
	    CustomDateEditor editor = new CustomDateEditor(dateFormat, false);
	    
	    //Register it as custom editor for the Date type
	    binder.registerCustomEditor(Date.class, editor);
	}
	
	@Autowired
	private Validator validator;
	
	@Autowired
	private IUserService userService;
	
	@Autowired
	private IProjectService projectService;
	
	@RequestMapping("/addNewProject.do")
	public String add(Map<String, Object> model)
	{
		try 
		{
			model.put("project", new Project());
			List<User> userList = new ArrayList<User>();
			userList.add(userService.getUserById(2));
			userList.add(userService.getUserById(3));
			model.put("userList", userList);
		} 
		catch (PMSUserException e) 
		{
			LogMaster.getLogger(this.getClass()).debug("Problem", e);
			//request.setAttribute("errorMessage", "Could not add the new project");
			return "errorPage.jsp";
		}
		return "addNewProject.jsp";
	}

	@RequestMapping(value="/saveNewProject.do", method=RequestMethod.POST)
	public String save(
			@Valid @ModelAttribute("project") Project project, 
			BindingResult result, 
			Map<String, Object> model,
			HttpServletRequest request)
	{
		try 
		{
			BaseRepository dao = new BaseRepository();
			HttpSession session = request.getSession();

			//System.out.println(project.getProjectMembers().size());
			List<User> users = new ArrayList<User>();
			String[] mems = request.getParameterValues("projectMembers");
			if(mems!=null)
			for(String memId : request.getParameterValues("projectMembers"))
			{
				User user = new User();
				user.setUserId(Integer.parseInt(memId));
				users.add(user);
			}
			project.setProjectMembers(users);
			System.out.println(project.getProjectMembers().size());

			int ownerId = (Integer) session.getAttribute("userId");
			project.setProjectOwner(dao.get(User.class, ownerId));
			project.setCompleted(false);

			Calendar start = Calendar.getInstance();
			Calendar end = Calendar.getInstance();
			Date deadLine = project.getDeadLine();
			Date startDate = project.getStartDate();
			
			if(startDate!=null)
			{
				start.setTimeInMillis(startDate.getTime());
				start.add(Calendar.DATE,1);
			}
			if(deadLine!=null)
			{
				end.setTimeInMillis(deadLine.getTime());
			}
			
			validator.validate(project, result);
			
			if(deadLine==null)
			{
				ObjectError deadLineError = new ObjectError("deadLine", "Please enter a deadline date");
				result.addError(deadLineError);
				result.rejectValue("deadLine", "deadLine", "Please enter a deadLine date");
			}
			if(startDate==null)
			{
				ObjectError startDateError = new ObjectError("startDate", "Please enter a start date");
				result.addError(startDateError);
				result.rejectValue("startDate", "startDate", "Please enter a start date");
			} 
			else if(start.before(Calendar.getInstance()))
			{
				ObjectError startDateError = new ObjectError("startDate", "Start Date cannot be of the past");
				result.addError(startDateError);
				result.rejectValue("startDate", "startDate", "Start Date cannot be of the past");
			}
			
			if(result.getErrorCount()>1){
				List<User> userList = new ArrayList<User>();
				userList.add(userService.getUserById(2));
				userList.add(userService.getUserById(3));
				model.put("userList", userList);
				return "addNewProject.jsp";
			}
			else
			{ 
				projectService.addNewProject(project);
				return "redirect:listProjectsByOwner.do";
			}
		} 
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(project, e);
			request.setAttribute("errorMessage", "Could not add the new project");
			return "errorPage.jsp";
		} catch (PMSUserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "errorPage.jsp";
		}
	}
	
	@RequestMapping(value="/listAllProjects.do")
	public String list(@RequestParam(value="view", required=false) String view,
			Map<String, Object> model, HttpServletRequest request)
	{
		List<Project> projList=null;
		try 
		{
			Integer cursor = (Integer)model.get("cursor");
			if(cursor==null)
				cursor=0;
			if(view!=null)
			{
				if(view.equals("next"))
					cursor+=5;
				else if(view.equals("previous"))
					cursor-=5;
				if(cursor<0)
					cursor=0;
			}
			projList = projectService.getAllProjects(cursor, 5);
			model.put("cursor", cursor);
			model.put("listOfProjects", projList);
			model.put("listSize", projectService.getAllProjects().size());
			return "listAllProjects.jsp";
		} 
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(projList, e);
			request.setAttribute("errorMessage", "Failed to list all Projects");
			return "errorPage.jsp";
		}
	}
	
	@RequestMapping(value="/listProjectsByOwner.do")
	public String listByOwner(@RequestParam(value="view", required=false) String view,
			Map<String, Object> model,
			HttpServletRequest request)
	{
		List<Project> projList=null;
		try 
		{
			HttpSession session = request.getSession();
			int ownerId = (Integer) session.getAttribute("userId");
			
			Integer cursor = (Integer)model.get("cursor");
			if(cursor==null)
				cursor=0;
			if(view!=null)
			{
				if(view.equals("next"))
					cursor+=5;
				else if(view.equals("previous"))
					cursor-=5;
				if(cursor<0)
					cursor=0;
			}
			
			projList = projectService.getProjectsByOwner(ownerId, cursor, 5);	
			model.put("cursor", cursor);
			model.put("listOfProjects", projList);
			model.put("listSize", projectService.getProjectsByOwner(ownerId).size());
			return "listProjectsByOwner.jsp";
		}
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(projList, e);
			request.setAttribute("errorMessage", "Falied to List Owner's Projects");
			return "errorPage.jsp";
		}
	}
	
	@RequestMapping(value="/deleteProject.do")
	public String delProject(Map<String, Object> model)
	{
		model.put("project", new Project());
		return "delProject.jsp";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/deleteExistingProject.do")
	public String delFunc(HttpServletRequest request)
	{
		int projectId=0;
		try 
		{
			Enumeration enum1 = request.getParameterNames();
			projectId = Integer.parseInt((String)enum1.nextElement());
			projectService.delExistingProject(projectId);
			return "redirect:listAllProjects.do";
		} 
		catch (NumberFormatException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} 
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(projectId, e);
			request.setAttribute("errorMessage", "Failed to Delete Existing Project");
			return "errorPage.jsp";
		}	
	}
	
	@RequestMapping(value="/listPendingProjects.do")
	public String listPendingProjects(
			@RequestParam(value="view", required=false) String view,
			Map<String, Object> model, HttpServletRequest request)
	{
		List<Project> projList=null;
		try 
		{
			HttpSession session = request.getSession();
			int ownerId = (Integer) session.getAttribute("userId");
			
			Integer cursor = (Integer)model.get("cursor");
			if(cursor==null)
				cursor=0;
			if(view!=null)
			{
				if(view.equals("next"))
					cursor+=5;
				else if(view.equals("previous"))
					cursor-=5;
				if(cursor<0)
					cursor=0;
			}
			
			projList = projectService.getPendingProjects(ownerId, cursor, 5);	//Alternative to above line.
			model.put("cursor", cursor);
			model.put("listOfProjects", projList);
			model.put("listSize", projectService.getPendingProjects(ownerId).size());
		} 
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(projList, e);
			request.setAttribute("errorMessage", "Failed to get list of pending projects");
			return "errorPage.jsp";
		}
		
		return "listPendingProjects.jsp";		
	}
	
	@RequestMapping(value="/listCompletedProjects.do")
	public String listCompletedProjects(
			@RequestParam(value="view", required=false) String view,
			Map<String, Object> model, HttpServletRequest request)
	{
		List<Project> projList=null;
		try 
		{
			HttpSession session = request.getSession();
			int ownerId = (Integer) session.getAttribute("userId");
			
			Integer cursor = (Integer)model.get("cursor");
			if(cursor==null)
				cursor=0;
			if(view!=null)
			{
				if(view.equals("next"))
					cursor+=5;
				else if(view.equals("previous"))
					cursor-=5;
				if(cursor<0)
					cursor=0;
			}
			
			projList = projectService.getCompletedProjects(ownerId, cursor, 5);	//Alternative to above line.
			model.put("cursor", cursor);
			model.put("listOfProjects", projList);
			model.put("listSize", projectService.getCompletedProjects(ownerId).size());
		} 
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(projList, e);
			request.setAttribute("errorMessage", "Failed to get list of completed projects");
			return "errorPage.jsp";
		}
		
		return "listCompletedProjects.jsp";		
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/modifyExistingProject.do")
	public String modifyProject(Map<String, Object> model, HttpServletRequest request)
	{
		Project project=null;
		try 
		{
			Enumeration enum1 = request.getParameterNames();
			int projectId = Integer.parseInt((String)enum1.nextElement());
			project = projectService.getProjectById(projectId);
			model.put("project", project);
		} 
		catch (NumberFormatException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(project, e);
			request.setAttribute("errorMessage", "Project Modification failed");
			return "errorPage.jsp";
		}
		//return "modifyProject.jsp";
		return "modifyProject2.jsp";
	}
	
	@RequestMapping(value="/modProject.do", method=RequestMethod.POST)
	public String modProject(@Valid @ModelAttribute("project") Project project, 
							BindingResult result, HttpServletRequest request) throws ParseException
	{
		HttpSession session = request.getSession();
		try 
		{
			Calendar start = Calendar.getInstance();
			Calendar end = Calendar.getInstance();
			Date deadLine = project.getDeadLine();
			Date startDate = project.getStartDate();
			
			if(startDate!=null)
			{
				start.setTimeInMillis(startDate.getTime());
				start.add(Calendar.DATE,1);
			}
			if(deadLine!=null)
			{
				end.setTimeInMillis(deadLine.getTime());
			}
			
			validator.validate(project, result);
			
			if(deadLine==null)
			{
				ObjectError deadLineError = new ObjectError("deadLine", "Please enter a deadline date");
				result.addError(deadLineError);
				result.rejectValue("deadLine", "deadLine", "Please enter a deadLine date");
			}
			if(startDate==null)
			{
				ObjectError startDateError = new ObjectError("startDate", "Please enter a start date");
				result.addError(startDateError);
				result.rejectValue("startDate", "startDate", "Please enter a start date");
			} 
			else if(start.before(Calendar.getInstance()))
			{
				ObjectError startDateError = new ObjectError("startDate", "Start Date cannot be of the past");
				result.addError(startDateError);
				result.rejectValue("startDate", "startDate", "Start Date cannot be of the past");
			}
			if(result.hasErrors())
				return "addNewProject.jsp";
			else
			{ 	
				validator.validate(project, result);
				projectService.modifyTheProject(project);
				return "redirect:listAllProjects.do";
			}
		} 
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(project, e);
			request.setAttribute("errorMessage", "Project Modification failed");
			return "errorPage.jsp";
		}
			
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/markProjectAsDone.do", method=RequestMethod.POST)
	public String markProject(HttpServletRequest request)
	{
		Project project = null;
		try 
		{
			Enumeration enum1 = request.getParameterNames();
			int projectId = Integer.parseInt((String)enum1.nextElement());
			project = projectService.getProjectById(projectId);
			projectService.markProjectAsDone(project);
		} 
		catch (NumberFormatException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} 
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(project, e);
			request.setAttribute("errorMessage", "Failed to mark Project as Done");
			return "errorPage.jsp";
		}
		return "redirect:listProjectsByOwner.do";
	}
	
	@RequestMapping(value="/listProjectsByMember.do")
	public String listByMember(Map<String, Object> model, HttpServletRequest request)
	{
		List<Project> projList = null;
		try 
		{
			HttpSession session = request.getSession();
			int memberId = (Integer) session.getAttribute("userId");
			projList = projectService.getProjectsByMember(memberId);	
			model.put("listOfProjects", projList);
			return "listProjectsByMember.jsp";
		} 
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(projList, e);
			request.setAttribute("errorMessage", "Listing project of member failed");
			return "errorPage.jsp";
		}
	}
	
	@RequestMapping(value="/searchIncompleteProjDate.do")
	public String listIncompleteProjByDate(Map<String, Object> model, HttpServletRequest request)
	{
		List<Project> projList = null;
		Date deadDate=null;
		try 
		{
			SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
			String deadLine = request.getParameter("deadLine");
			
			deadDate = sdf.parse(deadLine);
			
			projList = projectService.getIncompleteProjectsByDeadLine(deadDate);	
			for(Project proj : projList)
			{
				System.out.println(proj.toString());
			}
			model.put("listOfProjects", projList);
		} 
		catch (PMSProjectException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(projList, e);
			request.setAttribute("errorMessage", "Listing of incomplete projects approaching deadline failed");
			return "errorPage.jsp";
		} 
		catch (ParseException e) 
		{
			LogMaster.getLogger(this.getClass()).debug(deadDate, e);
			request.setAttribute("errorMessage", "Failed to parse the DeadLine date correctly");
			return "errorPage.jsp";
		}
		return "listIncompleteProjectsByDate.jsp";
	}

	@RequestMapping("/searchIncompleteProject.do")
	public String searchIncompleteProjByDate(Map<String, Object> model)
	{
		return "searchIncompleteProjectsByDate.jsp";
	}
	
	/*@RequestMapping(value="/listActiveProjects.do")
	public String listActiveProjects(
			@RequestParam(value="view", required=false) String view,
			Map<String, Object> model)
	{
		int ownerId = 1;	//Hard-Coded.
		
		Integer cursor = (Integer)model.get("cursor");
		if(cursor==null)
			cursor=0;
		if(view!=null)
		{
			if(view.equals("next"))
				cursor+=5;
			else if(view.equals("previous"))
				cursor-=5;
		}
		
		List<Project> projList = projectService.getActiveProjects(ownerId, cursor, 5);	//Alternative to above line.
		model.put("cursor", cursor);
		model.put("listOfProjects", projList);
		model.put("listSize", projectService.getActiveProjects(ownerId).size());
		
		return "listActiveProjects.jsp";		
	}*/
	
	@RequestMapping(value="/tasksOfProject.do")
	public String listTasksOfProject(@RequestParam(value="projectId", required=true) int projectId,
									 Map<String, Object> model)
	{
		
		model.put("projectId", projectId);
		
		return "redirect:showTasksOfProject.do";
	}
	
	@RequestMapping(value="/fileUpload.do")
	public String uploadFile()
	{
		return "fileUpload.jsp";
	}
	
}
