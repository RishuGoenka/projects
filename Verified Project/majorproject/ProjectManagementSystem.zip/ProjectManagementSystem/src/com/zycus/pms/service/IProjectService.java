package com.zycus.pms.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.validation.BindingResult;

import com.zycus.pms.entity.Project;
import com.zycus.pms.exception.PMSProjectException;

public interface IProjectService 
{
	public String addNewProject(Project project) throws PMSProjectException;

	public List<Project> getAllProjects() throws PMSProjectException;

	public String delExistingProject(int projectId) throws PMSProjectException;

	public List<Project> getProjectsByOwner(int ownerId, int offset, int rows) throws PMSProjectException;
	
	public List<Project> getPendingProjects(int ownerId, int offset, int rows) throws PMSProjectException;

	public List<Project> getCompletedProjects(int ownerId, int offset, int rows) throws PMSProjectException;

	public Project getProjectById(int projectId) throws PMSProjectException;

	public void modifyTheProject(String name, String desc,
			Date startDate, Date deadLine) throws PMSProjectException;

	public void markProjectAsDone(Project project) throws PMSProjectException;

	public List<Project> getProjectsByMember(int memberId) throws PMSProjectException;

	public List<Project> getIncompleteProjectsByDeadLine(Date deadDate) throws PMSProjectException;

	public List<Project> getProjectsByOwner(int ownerId) throws PMSProjectException;

	public List<Project> getPendingProjects(int ownerId) throws PMSProjectException;

	public List<Project> getCompletedProjects(int ownerId) throws PMSProjectException;

	public List<Project> getActiveProjects(int ownerId, int offset, int rows) throws PMSProjectException;

	public List<Project> getActiveProjects(int ownerId) throws PMSProjectException;

	public List<Project> getAllProjects(int offset, int rows) throws PMSProjectException;

	public void modifyTheProject(Project project) throws PMSProjectException;

	public int getIdFromProject(Project project) throws PMSProjectException;
	
	
}