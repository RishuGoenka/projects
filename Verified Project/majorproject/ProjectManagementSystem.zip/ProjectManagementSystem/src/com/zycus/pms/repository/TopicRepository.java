package com.zycus.pms.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.pms.entity.Forum;
import com.zycus.pms.entity.Topic;
import com.zycus.pms.exception.PMSForumException;

@Repository("topicRepository")
@Transactional
public class TopicRepository implements ITopicRepository{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public List<Topic> getAllTopics() throws PMSForumException{
		Criteria criteria;
		try {
			Session session = sessionFactory.getCurrentSession();
			criteria = session.createCriteria(Topic.class);
			return criteria.list();
		} catch (HibernateException e) {
			throw new PMSForumException("Error in getAllTopic Repository ", e);
		}
		
	}
	
	@Override
	public List<Topic> getTopicOfForum(int forumId, int first, int max) throws PMSForumException{
		
		Criteria criteriaTopic;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteriaForum = session.createCriteria(Forum.class);
			criteriaForum.add(Restrictions.eq("forumId", forumId));
			Forum forum = (Forum) criteriaForum.list().get(0);
			
			criteriaTopic = session.createCriteria(Topic.class);
			criteriaTopic.add(Restrictions.eq("forum", forum));
			criteriaTopic.setFirstResult(first);
			criteriaTopic.setMaxResults(max);
			return criteriaTopic.list();
		} catch (HibernateException e) {
			throw new PMSForumException("Error in getAllTopic Repository", e);
		}
		
		
	}
	
	@Override
	public void addTopic(Topic topic) throws PMSForumException{
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(topic);
		} catch (HibernateException e) {
			throw new PMSForumException("Error in addTopic Repository", e);
		}
	}
	
	@Override
	public Topic getTopicById(int topicId) throws PMSForumException{
		Topic topic = null;
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Topic.class);
			criteria.add(Restrictions.eq("topicId", topicId));
			
			topic = (Topic) criteria.list().get(0);
			return topic;
		} catch (HibernateException e) {
			throw new PMSForumException("Error in getTopicById Repository", e);
		}
		
		
	}
}
