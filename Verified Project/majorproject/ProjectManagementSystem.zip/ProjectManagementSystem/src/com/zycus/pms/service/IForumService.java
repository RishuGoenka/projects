package com.zycus.pms.service;

import java.util.List;

import com.zycus.pms.entity.Forum;
import com.zycus.pms.exception.PMSForumException;

public interface IForumService {

	abstract public void addForum(Forum forum) throws PMSForumException;
	abstract public List<Forum> getForumsOfProject(int projectId, int first, int max) throws PMSForumException;
	abstract public Forum getForumById(int forumId) throws PMSForumException;
}
