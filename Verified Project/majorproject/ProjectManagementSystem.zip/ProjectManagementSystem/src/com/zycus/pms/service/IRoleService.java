package com.zycus.pms.service;

import java.util.List;

import com.zycus.pms.entity.Role;

public interface IRoleService {

	abstract public List<Role> getAllRoles();
	abstract public List<Role> getRole(int roleId);
}
