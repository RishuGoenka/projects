package com.zycus.pms.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.pms.entity.Task;

@Repository("ExcelRepo")
@Transactional
public class ExcelRepository implements IExcelRepository
{
	@Autowired
	private SessionFactory sessionFactory;
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Task> getAllCompletedTasks() 
	{
		Session session = sessionFactory.getCurrentSession();
		
		Criteria criteria = session.createCriteria(Task.class)
				.add(Restrictions.eq("percentCompleted", 100))
				.addOrder(Order.asc("taskId"));
		
		return criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Task> getAllIncompleteTasks() 
	{
		Session session = sessionFactory.getCurrentSession();
		
		Criteria criteria = session.createCriteria(Task.class)
				.add(Restrictions.ne("percentCompleted", 100))
				.addOrder(Order.asc("taskId"));
		
		return criteria.list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Task> getAllDeletedTasks() 
	{
		Session session = sessionFactory.getCurrentSession();
		
		Criteria criteria = session.createCriteria(Task.class)
				.add(Restrictions.eq("isDeleted", true))
				.addOrder(Order.asc("taskId"));
		
		return criteria.list();
	}
}
