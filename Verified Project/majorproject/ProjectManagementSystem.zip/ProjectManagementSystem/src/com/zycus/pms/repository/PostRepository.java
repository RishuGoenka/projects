package com.zycus.pms.repository;

import java.util.List; 

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.pms.entity.Post;
import com.zycus.pms.entity.Topic;
import com.zycus.pms.exception.PMSForumException;

@Repository("postRepository")
@Transactional
@SuppressWarnings("unchecked")
public class PostRepository implements IPostRepository {

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public List<Post> getAllPosts() throws PMSForumException{
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Post.class);
			return criteria.list();
		} catch (HibernateException e) {
			throw new PMSForumException("Error in getAllPosts Repository ", e);
		}
	}
	
	@Override
	public List<Post> getPostOfTopic(int topicId, int first, int max) throws PMSForumException{
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteriaTopic = session.createCriteria(Topic.class);
			criteriaTopic.add(Restrictions.eq("topicId", topicId));
			Topic topic= (Topic) criteriaTopic.list().get(0);
			
			Criteria criteriaPost = session.createCriteria(Post.class);
			criteriaPost.add(Restrictions.eq("topic", topic));
			criteriaPost.addOrder(Order.desc("postDate"));
			criteriaPost.setFirstResult(first);
			criteriaPost.setMaxResults(max);
			
			return criteriaPost.list();
		} catch (HibernateException e) {
			throw new PMSForumException("Error in getPostOfTopic Repository ", e);
		}
	}
	
	@Override
	public void addPost(Post post) throws PMSForumException{
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(post);
		} catch (HibernateException e) {
			throw new PMSForumException("Error in addPost Repository ", e);
		}
	}
}
