package com.zycus.pms.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.pms.entity.Forum;
import com.zycus.pms.entity.Project;
import com.zycus.pms.exception.PMSForumException;

@Repository("forumRepository")
@Transactional
public class ForumRepository implements IForumRepository{

	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	public void addForum(Forum forum) throws PMSForumException{
		try {
			Session session = sessionFactory.getCurrentSession();
			session.save(forum);
		} catch (HibernateException e) {
			throw new PMSForumException("Error in addForum Repository ", e);
		}
	}
	
	
	@Override
	public List<Forum> getAllForums() throws PMSForumException{
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Forum.class);
			return criteria.list();
		} catch (HibernateException e) {
			throw new PMSForumException("Error in getAllForums Repository ", e);
		}
	}
	
	@Override
	public List<Forum> getForumsOfProject(int projectId, int first, int max) throws PMSForumException{
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteriaProject = session.createCriteria(Project.class);
			criteriaProject.add(Restrictions.eq("projectId", projectId));
			Project project = (Project) criteriaProject.list().get(0);
			
			Criteria criteriaForum = session.createCriteria(Forum.class);
			criteriaForum.add(Restrictions.eq("project", project));
			criteriaForum.setFirstResult(first);
			criteriaForum.setMaxResults(max);
			
			return criteriaForum.list();
		} catch (HibernateException e) {
			throw new PMSForumException("Error in getForumsOfProject Repository ", e);
		}
	}
	
	@Override
	public Forum getForumById(int forumId) throws PMSForumException{
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Forum.class);
			criteria.add(Restrictions.eq("forumId", forumId));
			
			Forum forum = (Forum) criteria.list().get(0);
			
			return forum;
		} catch (HibernateException e) {
			throw new PMSForumException("Error in getForumById Repository ", e);
		}
	}
}
