package com.zycus.pms.excelImport;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.zycus.pms.exception.PMSTaskException;

public class Configuration 
{
	private Properties properties;
	
	public Configuration(String filePathName) throws PMSTaskException
	{
		File configFile = new File(filePathName);
		
		if(!configFile.isFile())
		{
			// Throw exception
			PMSTaskException exception = new PMSTaskException("Config. file missing. Cannot continue.");
			throw exception;
		}
		else
		{
			// Open and read file.
			try 
			{
				InputStream is = new FileInputStream(configFile);
				properties = new Properties();
				properties.load(is);
				
			} 
			catch (IOException e) 
			{
				throw new PMSTaskException("Improper config file format. Cannot continue.");
			}
			
		}
	}
	
	public String getProperty(String propName) throws PMSTaskException
	{
		if(properties.containsKey(propName))
		{
			return properties.getProperty(propName);
		}
		else
		{
			throw new PMSTaskException("Wrong property name.");
		}
	}
	
	/*public static void main(String[] args) 
	{
		try 
		{
			Configuration config = new Configuration("C:\\Animesh Mehta\\CSVAPI\\src\\CsvContext.properties");
			System.out.println(config.getProperty("CSVFilePath"));
			System.out.println(config.getProperty("CSVFileName"));
			config.getProperty("asfdafds");
		} 
		catch (PMSTaskException e) 
		{
			e.printStackTrace();
		}
	}*/
}
