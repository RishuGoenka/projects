package com.zycus.pms.repository;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.pms.entity.Project;
import com.zycus.pms.entity.User;
import com.zycus.pms.exception.PMSProjectException;

@Repository("ProjectRepo")
@Transactional
public class ProjectRepository implements IProjectRepository
{

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void addNewProject(Project project) throws PMSProjectException 
	{
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			session.save(project);
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Adding new project has failed",e);
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public List<Project> getAllProjects() throws PMSProjectException 
	{
		Criteria criteria;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			criteria = session.createCriteria(Project.class);
			criteria.add(Restrictions.eq("deleted", false));
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Failed to Get All Projects",e);
		}
		return criteria.list();
	}

	@Override
	public void delExistingProject(int projectId) throws PMSProjectException 
	{
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Project proj = (Project)session.createCriteria(Project.class)
			.add(Restrictions.eq("projectId", projectId)).uniqueResult();
			
			proj.setDeleted(true);			// Performs Soft Delete		
			//session.delete(proj);			// Performs Hard Delete
			session.update(proj);
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Existing project could not be deleted", e);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getProjectsByOwner(int ownerId, int offset, int rows) throws PMSProjectException 
	{
		List<Project> list;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.createAlias("projectOwner", "ownerAlias");
			criteria.add(Restrictions.eq("ownerAlias.userId",ownerId));
			criteria.add(Restrictions.eq("deleted", false));
			criteria.addOrder(Order.asc("projectId"));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			criteria.setFirstResult(offset);
			criteria.setMaxResults(rows);
			
			list = criteria.list();
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Could not retrieve owner's Projects", e);
		}
		
		return list;
	}


	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getPendingProjects(int ownerId, int offset, int rows) throws PMSProjectException 
	{
		List<Project> list;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.createAlias("projectOwner", "ownerAlias");
			criteria.add(Restrictions.eq("ownerAlias.userId",ownerId));
			criteria.add(Restrictions.eq("deleted", false));
			criteria.add(Restrictions.eq("completed", false));
			criteria.addOrder(Order.asc("projectId"));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			criteria.setFirstResult(offset);
			criteria.setMaxResults(rows);
			
			list = criteria.list();
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Pending projects could not be retrieved", e);
		}
		
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getCompletedProjects(int ownerId, int offset, int rows) throws PMSProjectException 
	{
		List<Project> list;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.createAlias("projectOwner", "ownerAlias");
			criteria.add(Restrictions.eq("ownerAlias.userId",ownerId));
			criteria.add(Restrictions.eq("deleted", false));
			criteria.add(Restrictions.eq("completed", true));
			criteria.addOrder(Order.asc("projectId"));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			criteria.setFirstResult(offset);
			criteria.setMaxResults(rows);
			
			list = criteria.list();
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Completed projects could not be retrieved", e);
		}
		
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public Project getProjectById(int projectId) throws PMSProjectException 
	{
		Project project;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.add(Restrictions.eq("projectId",projectId));
			criteria.add(Restrictions.eq("deleted", false));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			
			List<Project> list = criteria.list();
			project = list.get(0);
		} 
		catch (HibernateException e)
		{
			throw new PMSProjectException("Project could not be retrieved from ID", e);
		}
		
		return project;
	}

	@Override
	public void modifyTheProject(Project proj) throws PMSProjectException 
	{
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			session.merge(proj);
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Project Modification Failed", e);
		}
	}

	@SuppressWarnings("unchecked")
	public int getIdFromProject(Project proj) throws PMSProjectException 
	{
		Project project;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.add(Restrictions.eq("projectTitle",proj.getProjectTitle()));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			
			List<Project> list = criteria.list();
			project = list.get(0);
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Project Modification Failed", e);
		}
		
		return project.getProjectId();
	}

	@Override
	public void markProjectAsDone(Project project) throws PMSProjectException 
	{
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			project.setCompleted(true);
			session.saveOrUpdate(project);
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Failed to Mark Project As Done", e);
		}
	}

	@Override
	public List<Project> getProjectsByMember(int memberId) throws PMSProjectException 
	{
		List<Project> memProjects = new ArrayList<Project>();
		List<Project> listProjects;
		try 
		{
			listProjects = getAllProjects();
			List<User> listMembers = new ArrayList<User>();
			/*for(Project project : listProjects)
			{
				listMembers = project.getProjectMembers();
				for(User member1 : listMembers)
				{
					if(member1.getUserId() == memberId)
					{
						listProjects.add(project);
						break;
					}
				}
			}*/
			Project project;
			User member;
			for(int i=0; i<listProjects.size(); i++)
			{
				project = listProjects.get(i);
				listMembers = project.getProjectMembers();
				for(int j=0; j<listMembers.size(); j++)
				{
					member = listMembers.get(j);
					if(member.getUserId() == memberId)
					{
						memProjects.add(project);
						break;
					}
				}
			}
		} 
		catch (Exception e) 
		{
			throw new PMSProjectException("Falied to Retrieve Member's Projects", e);
		}
		return memProjects;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getIncompleteProjectsByDeadLine(Date deadDate) throws PMSProjectException 
	{
		List<Project> list;
		try 
		{
			Calendar c = Calendar.getInstance();
			c.setTimeInMillis(0);
			Date initDate = c.getTime();
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.add(Restrictions.between("deadLine", initDate, deadDate));
			criteria.add(Restrictions.eq("completed", false));
			criteria.addOrder(Order.desc("deadLine"));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			
			list = criteria.list();
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Failed to Retrieve Incomplete Projects By Deadline", e);
		}
		
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getProjectsByOwner(int ownerId) throws PMSProjectException 
	{
		List<Project> list;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.createAlias("projectOwner", "ownerAlias");
			criteria.add(Restrictions.eq("ownerAlias.userId",ownerId));
			criteria.add(Restrictions.eq("deleted", false));
			criteria.addOrder(Order.asc("projectId"));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			
			list = criteria.list();
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Failed to Retrieve Projects By Owner", e);
		}
		
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getPendingProjects(int ownerId) throws PMSProjectException 
	{
		List<Project> list;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.createAlias("projectOwner", "ownerAlias");
			criteria.add(Restrictions.eq("ownerAlias.userId",ownerId));
			criteria.add(Restrictions.eq("completed", false));
			criteria.add(Restrictions.eq("deleted", false));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			
			list = criteria.list();
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Failed to get Pending Projects of Owner", e);
		}
		
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getCompletedProjects(int ownerId) throws PMSProjectException 
	{
		List<Project> list;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.createAlias("projectOwner", "ownerAlias");
			criteria.add(Restrictions.eq("ownerAlias.userId",ownerId));
			criteria.add(Restrictions.eq("completed", true));
			criteria.add(Restrictions.eq("deleted", false));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			
			list = criteria.list();
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Falied to Retrieve Owner's Completed Projects", e);
		}
		
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getActiveProjects(int ownerId, int offset, int rows) throws PMSProjectException 
	{
		List<Project> list;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.createAlias("projectOwner", "ownerAlias");
			criteria.add(Restrictions.eq("ownerAlias.userId",ownerId));
			criteria.add(Restrictions.eq("deleted", false));
			criteria.add(Restrictions.eq("active", true));
			criteria.addOrder(Order.asc("projectId"));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			criteria.setFirstResult(offset);
			criteria.setMaxResults(rows);
			
			list = criteria.list();
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Failed to get Active Projects", e);
		}
		
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getActiveProjects(int ownerId) throws PMSProjectException 
	{
		List<Project> list;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.createAlias("projectOwner", "ownerAlias");
			criteria.add(Restrictions.eq("ownerAlias.userId",ownerId));
			criteria.add(Restrictions.eq("active", true));
			criteria.add(Restrictions.eq("deleted", false));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			
			list = criteria.list();
		} 
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Failed to get Active Projects", e);
		}
		
		return list;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Project> getAllProjects(int offset, int rows) throws PMSProjectException 
	{
		List<Project> list;
		try 
		{
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Project.class);
			criteria.add(Restrictions.eq("deleted", false));
			criteria.addOrder(Order.asc("projectId"));
			criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
			criteria.setFirstResult(offset);
			criteria.setMaxResults(rows);
			
			list = criteria.list();
		}
		catch (HibernateException e) 
		{
			throw new PMSProjectException("Failed to get all Projects", e);
		}
		
		return list;
	}
	
}
