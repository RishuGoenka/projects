package com.zycus.pms.test;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;

import com.zycus.pms.entity.Project;
import com.zycus.pms.excelWriter.POIExcelWriter;
import com.zycus.pms.repository.BaseRepository;

public class ExcelImportTest 
{
	@Test
	public void createExcelFile()
	{
		POIExcelWriter obj = new POIExcelWriter();
		obj.openExcelFile("C:\\Animesh Mehta\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelExport\\newTaskExc.xls");
	}

	@Test
	public void openExcelFile()
	{
		POIExcelWriter obj = new POIExcelWriter();
		obj.openExcelFile("C:\\Animesh Mehta\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelExport\\firstExc.xls");
	}
	
	@Test
	public void closeExcel()
	{
		POIExcelWriter obj = new POIExcelWriter();
		obj.closeExcel();
	}
	
	@Test
	public void writeProjectRecord()
	{
		BaseRepository dao = new BaseRepository();
		POIExcelWriter obj = new POIExcelWriter();
		obj.openExcelFile("C:\\Animesh Mehta\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelFiles\\firstExc.xls");
		obj.resetSheetIndex();
		obj.setSheet();
		obj.insertRow(1);
		Project project = dao.get(Project.class, 3);
		
		String projectTitle = project.getProjectTitle();
		
		String desc = project.getDescription();
		
		Date sD = project.getStartDate();
		Format formatter = new SimpleDateFormat("yy-MM-dd");
		String startDate = formatter.format(sD);
		
		Date enD = project.getDeadLine();
		String deadLine = formatter.format(enD);
		
		obj.writeData(1, 1, projectTitle);
		obj.writeData(2, 1, desc);
		obj.writeData(3, 1, startDate);
		obj.writeData(4, 1, deadLine);
		
		obj.closeExcel();
	}
	
}
