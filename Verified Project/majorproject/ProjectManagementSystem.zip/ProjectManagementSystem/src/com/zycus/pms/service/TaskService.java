package com.zycus.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.pms.entity.Project;
import com.zycus.pms.entity.Task;
import com.zycus.pms.exception.PMSTaskException;
import com.zycus.pms.repository.ITaskRepository;

@Service
public class TaskService implements ITaskService {
	
	@Autowired
	ITaskRepository taskRepository;
	
	@Override
	public void addTask(Task task,int memId, int projectId ) throws PMSTaskException{
		taskRepository.addTask(task, memId, projectId);
	}

	@Override
	public List<Task> getTasks(int userId, int projId, int offset, int max) throws PMSTaskException {
		Project project = new Project();
		project.setProjectId(projId);
		return taskRepository.getTasks(userId, project, offset, max);
	}

	@Override
	public List<Task> getTasksByDescr(int userId, String searchString) throws PMSTaskException {
		return taskRepository.getTasksByDescr(userId, searchString);
	}

	@Override
	public List<Task> getCompletedTasks(int userId, int projId, Integer offset, int max) throws PMSTaskException {
		Project project = new Project();
		project.setProjectId(projId);
		return taskRepository.getCompletedTasks(userId, project, offset, max);
	}

	@Override
	public List<Task> getIncompleteTasks(int userId, int projId, Integer offset, int max) throws PMSTaskException {
		Project project = new Project();
		project.setProjectId(projId);
		return taskRepository.getIncompleteTasks(userId, project, offset, max);
	}

	@Override
	public Task getTask(int taskId) throws PMSTaskException {
		return taskRepository.getTask(taskId);
	}

	@Override
	public void updateTask(Task task) throws PMSTaskException {
		taskRepository.update(task);
		
	}

	@Override
	public void deleteTask(int taskId) throws PMSTaskException {
		Task task = taskRepository.getTask(taskId);
		taskRepository.delete(task);
		
	}

	@Override
	public List<Task> getCompletedTasksOfProject(int projectId, Integer offset, int max) throws PMSTaskException {
		Project project = new Project();
		project.setProjectId(projectId);
		return taskRepository.getCompletedTasksOfProject(project, offset, max);
	}

	@Override
	public List<Task> getIncompleteTasksOfProject(int projectId, Integer offset, int max) throws PMSTaskException {
		Project project = new Project();
		project.setProjectId(projectId);
		return taskRepository.getIncompleteTasksOfProject(project, offset, max);
	}

	@Override
	public List<Task> getTasksOfProject(int projectId, Integer offset, int max) throws PMSTaskException {
		Project project = new Project();
		project.setProjectId(projectId);
		return taskRepository.getTasksOfProject(project, offset, max);
	}

	@Override
	public List<Task> getTasksByDescrManager(int projectId, String searchString) throws PMSTaskException {
		Project project = new Project();
		project.setProjectId(projectId);
		return taskRepository.getTasksByDescrManager(project, searchString);
	}

	@Override
	public List<Task> getTasksByName(int userId, String searchString) throws PMSTaskException {
		return taskRepository.getTasksByName(userId, searchString);
	}

	@Override
	public List<Task> getTasksByNameManager(int projectId, String searchString) throws PMSTaskException {
		Project project = new Project();
		project.setProjectId(projectId);
		return taskRepository.getTasksByNameManager(project, searchString);
	}

}
