package com.zycus.pms.repository;

import java.util.List;

import com.zycus.pms.entity.Project;
import com.zycus.pms.entity.Task;
import com.zycus.pms.exception.PMSTaskException;

public interface ITaskRepository {

	public void addTask(Task task, int memId, int projectId) throws PMSTaskException;

	public List<Task> getTasks(int userId, Project project, int offset, int max) throws PMSTaskException;

	public List<Task> getCompletedTasks(int userId, Project project, Integer offset, int max) throws PMSTaskException;

	public List<Task> getIncompleteTasks(int userId, Project project, Integer offset, int max) throws PMSTaskException;

	public Task getTask(int taskId) throws PMSTaskException;

	public void update(Task task) throws PMSTaskException;

	public void delete(Task task) throws PMSTaskException;

	public List<Task> getTasksByDescr(int userId, String searchString) throws PMSTaskException;

	public List<Task> getCompletedTasksOfProject(Project project, Integer offset, int max) throws PMSTaskException;

	public List<Task> getIncompleteTasksOfProject(Project project, Integer offset, int max) throws PMSTaskException;

	public List<Task> getTasksOfProject(Project project, Integer offset, int max) throws PMSTaskException;

	public List<Task> getTasksByDescrManager(Project project, String searchString) throws PMSTaskException;

	public List<Task> getTasksByName(int userId, String searchString) throws PMSTaskException;

	public List<Task> getTasksByNameManager(Project project, String searchString) throws PMSTaskException;

}