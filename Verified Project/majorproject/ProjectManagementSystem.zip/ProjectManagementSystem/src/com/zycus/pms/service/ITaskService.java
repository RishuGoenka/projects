package com.zycus.pms.service;

import java.util.List;

import com.zycus.pms.entity.Task;
import com.zycus.pms.exception.PMSTaskException;

public interface ITaskService {

	public void addTask(Task task, int memId, int projectId) throws PMSTaskException;

	public List<Task> getTasks(int userId, int projId, int offset, int max) throws PMSTaskException;

	public List<Task> getCompletedTasks(int userId, int projId, Integer offset, int max) throws PMSTaskException;
	
	public List<Task> getIncompleteTasks(int userId, int projId, Integer offset, int max) throws PMSTaskException;

	public Task getTask(int taskId) throws PMSTaskException;

	public void updateTask(Task task) throws PMSTaskException;

	public void deleteTask(int taskId) throws PMSTaskException;

	public List<Task> getTasksByDescr(int userId, String searchString) throws PMSTaskException;

	public List<Task> getCompletedTasksOfProject(int projectId, Integer offset, int max) throws PMSTaskException;

	public List<Task> getIncompleteTasksOfProject(int projectId, Integer offset, int max) throws PMSTaskException;

	public List<Task> getTasksOfProject(int projectId, Integer offset, int max) throws PMSTaskException;

	public List<Task> getTasksByDescrManager(int projectId, String searchString) throws PMSTaskException;

	public List<Task> getTasksByName(int userId, String searchString) throws PMSTaskException;

	public List<Task> getTasksByNameManager(int projectId, String searchString) throws PMSTaskException;

}