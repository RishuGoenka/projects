package com.zycus.pms.exception;

public class PMSForumException extends PMSException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PMSForumException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PMSForumException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
