package com.zycus.pms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.Range;

@Entity
@Table(name="PMS_TASK1")
public class Task {
	
	@Id@GenericGenerator(name="incr" , strategy="increment")
	@GeneratedValue(generator="incr")
	@Column(name="TASK_ID")
	private int taskId;
	
	@Column(name="TASK_NAME")
	@Size(min=5, max=15, message="Name should be of 5 to 15 characters")
	private String taskName;
	
	@Column(name="DESCRIPTION")
	@Size(min=5, message="Description should be of minimum 5 characters")
	private String description;
	
	@Column(name="IS_DELETED")
	private boolean isDeleted=false;
	
	@ManyToOne
	@PrimaryKeyJoinColumn
	private Project project;
	
	@Column(name="START_DATE")
	private Date startDate;
	
	@Column(name="DEADLINE")
	private Date deadLine;
	
	@Column(name="END_DATE")
	private Date endDate;
	
	@Column(name="PERCENT_COMPLETED")
	@Range(min=0, max=100, message="Percentage must be between 0 and 100")
	private int percentCompleted;
	
	@ManyToOne
	private Priority priority;
	
	@ManyToOne
	@PrimaryKeyJoinColumn
	private User user;
	
	

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Task() {
		super();
	}

	public int getTaskId() {
		return taskId;
	}

	public void setTaskId(int taskId) {
		this.taskId = taskId;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getDeadLine() {
		return deadLine;
	}

	public void setDeadLine(Date deadLine) {
		this.deadLine = deadLine;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getPercentCompleted() {
		return percentCompleted;
	}

	public void setPercentCompleted(int percentCompleted) {
		this.percentCompleted = percentCompleted;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Priority getPriority() {
		return priority;
	}

	public void setPriority(Priority priority) {
		this.priority = priority;
	}

	@Override
	public String toString() {
		return "Task [taskId=" + taskId + ", project=" + project
				+ ", startDate=" + startDate + ", deadLine=" + deadLine
				+ ", endDate=" + endDate + ", percentCompleted="
				+ percentCompleted + ", user=" + user + "]";
	}
	
	

}
