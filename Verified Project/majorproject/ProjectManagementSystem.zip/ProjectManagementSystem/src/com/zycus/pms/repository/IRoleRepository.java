package com.zycus.pms.repository;

import java.util.List;

import com.zycus.pms.entity.Role;

public interface IRoleRepository {

	abstract public List<Role> getAllRoles();
	abstract public List<Role> getRole(int roleId);
}
