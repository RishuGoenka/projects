package com.zycus.pms.service;

import java.util.List;

import com.zycus.pms.entity.User;
import com.zycus.pms.exception.PMSUserException;

public interface IUserService {

	abstract public void addUser(User user) throws PMSUserException;
	abstract public boolean checkManagerCredentials(String userName, String password) throws PMSUserException;
	abstract public User getUser(String userName) throws PMSUserException;
	abstract public User getUserById(int userId) throws PMSUserException;
	abstract public List<User> getUsersOfCompany(int companyId) throws PMSUserException;
}
