package com.zycus.pms.logger;

import org.apache.log4j.Logger;

public class LogMaster {

	static Logger log ;
	
	public static <E>Logger getLogger(Class<E> className){
		return Logger.getLogger(className.getName());
	}
}
