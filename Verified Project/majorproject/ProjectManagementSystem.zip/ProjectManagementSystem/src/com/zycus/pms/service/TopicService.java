package com.zycus.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


import com.zycus.pms.entity.Topic;
import com.zycus.pms.exception.PMSForumException;

import com.zycus.pms.repository.ITopicRepository;

@Service("topicService")
public class TopicService implements ITopicService {

	@Autowired
	@Qualifier("topicRepository")
	private ITopicRepository topicRepository;
	
	@Override
	public List<Topic> getAllTopics() throws PMSForumException {
		try {
			return topicRepository.getAllTopics();
		} catch (Exception e) {
			throw new PMSForumException("Error getAllTopics service", e);
		}
	}
	
	@Override
	public List<Topic> getTopicOfForum(int forumId, int first, int max) throws PMSForumException{
		
		try {
			return topicRepository.getTopicOfForum(forumId, first, max);
		} catch (Exception e) {
			throw new PMSForumException("Error getTopicOfForum service", e);
		}
	}
	
	@Override
	public void addTopic(Topic topic) throws PMSForumException{
		try {
			topicRepository.addTopic(topic);
		} catch (PMSForumException e) {
			throw new PMSForumException("Error addTopic service", e);
		}
	}
	
	@Override
	public Topic getTopicById(int topicId) throws PMSForumException{
		
		try {
			return topicRepository.getTopicById(topicId);
		} catch (PMSForumException e) {
			throw new PMSForumException("Error addTopic service", e);
		} 
	}
}
