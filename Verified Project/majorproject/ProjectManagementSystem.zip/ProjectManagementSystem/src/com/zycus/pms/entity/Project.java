package com.zycus.pms.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="PMS_PROJECT1")
public class Project {

	@Id@GenericGenerator(name="incr" , strategy="increment")
	@GeneratedValue(generator="incr")
	@Column(name="PROJECT_ID")
	private int projectId;
	
	@Column(name="PROJECT_TITLE")
	@Size(min=3,message="Project Title should be atleast 3 characters long")
	private String projectTitle;
	
	@Column(name="DESCRIPTION")
	@Size(min=3,message="Project Description should be atleast 3 characters long")
	private String description;
	
	@Column(name="START_DATE")
	private Date startDate;
	
	@Column(name="DEADLINE")
	private Date deadLine;
	
	@Column(name="END_DATE")
	private Date endDate;
	
	@ManyToMany
	@JoinTable(name="PMS_PROJECT1_PMS_USER1",
	    joinColumns=
	        @JoinColumn(name="PMS_PROJECT1_PROJECT_ID", referencedColumnName="PROJECT_ID"),
	    inverseJoinColumns=
	        @JoinColumn(name="PROJECTMEMBERS_USER_ID", referencedColumnName="USER_ID")
	    )
	private List<User> projectMembers = new ArrayList<User>();
	
	@ManyToOne
	private User projectOwner;
	
	@OneToMany(mappedBy="project")
	private List<Task> tasks = new ArrayList<Task>();
	
	@Column(name="IS_COMPLETED")
	private boolean completed;

	@Column(name="IS_DELETED")
	private boolean deleted;
	
	/*@Column(name="IS_ACTIVE")
	private boolean active;
	
	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}*/

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectTitle() {
		return projectTitle;
	}

	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getStartDate() {
		return startDate;
	}

	public boolean isCompleted() {
		return completed;
	}

	public void setCompleted(boolean completed) {
		this.completed = completed;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getDeadLine() {
		return deadLine;
	}

	public void setDeadLine(Date deadLine) {
		this.deadLine = deadLine;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public List<User> getProjectMembers() {
		return projectMembers;
	}

	public void setProjectMembers(List<User> projectMembers) {
		this.projectMembers = projectMembers;
	}

	public User getProjectOwner() {
		return projectOwner;
	}

	public void setProjectOwner(User projectOwner) {
		this.projectOwner = projectOwner;
	}

	public List<Task> getTasks() {
		return tasks;
	}

	public void setTasks(List<Task> tasks) {
		this.tasks = tasks;
	}

	

	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectTitle="
				+ projectTitle + ", description=" + description
				+ ", startDate=" + startDate + ", deadLine=" + deadLine
				+ ", endDate=" + endDate + ", projectOwner=" + projectOwner
				+ ", isCompleted=" + completed + "]";
	}
	
}
