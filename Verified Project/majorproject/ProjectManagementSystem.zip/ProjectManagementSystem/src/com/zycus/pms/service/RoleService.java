package com.zycus.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;


import com.zycus.pms.entity.Role;
import com.zycus.pms.repository.IRoleRepository;

@Service("roleService")
public class RoleService implements IRoleService {

	@Autowired
	@Qualifier("roleRepository")
	private IRoleRepository roleRepository;

	@Override
	public List<Role> getAllRoles() {
		
		return roleRepository.getAllRoles();
	}
	
	@Override
	public List<Role> getRole(int roleId) {
		
		return roleRepository.getAllRoles();
	}
}
