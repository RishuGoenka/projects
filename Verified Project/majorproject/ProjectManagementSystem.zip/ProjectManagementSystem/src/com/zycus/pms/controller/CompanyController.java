package com.zycus.pms.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.zycus.pms.entity.Company;
import com.zycus.pms.logger.LogMaster;
import com.zycus.pms.service.ICompanyService;

@Controller
public class CompanyController {
	
	@Autowired
	private LogMaster logger;

	@Autowired
	private ICompanyService companyService;
	
	@RequestMapping("/addCompany.do")
	public String addCompany(Map<String, Object> model, HttpServletRequest request){
		try {
			model.put("company", new Company());
			return "addNewCompany.jsp";
		} catch (Exception e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
	}
	
	@RequestMapping("/saveCompany.do")
	public String saveCompany(@ModelAttribute("company") Company company, HttpServletRequest request){
		
		try {
			companyService.addCompany(company);
			System.out.println(company);
			return "addedUser.jsp";
		} catch (Exception e) {
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		} 
	}
}
