package com.zycus.pms.repository;

import java.util.List;

import com.zycus.pms.entity.Task;

public interface IExcelRepository {

	List<Task> getAllCompletedTasks();

	List<Task> getAllIncompleteTasks();

	List<Task> getAllDeletedTasks();

}