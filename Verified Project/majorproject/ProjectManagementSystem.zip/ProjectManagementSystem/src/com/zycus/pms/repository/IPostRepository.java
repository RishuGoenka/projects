package com.zycus.pms.repository;

import java.util.List;

import com.zycus.pms.entity.Forum;
import com.zycus.pms.entity.Post;
import com.zycus.pms.exception.PMSForumException;

public interface IPostRepository {

	abstract public List<Post> getAllPosts() throws PMSForumException;
	abstract public List<Post> getPostOfTopic(int topicId, int first, int max) throws PMSForumException;
	abstract public void addPost(Post post) throws PMSForumException;
}
