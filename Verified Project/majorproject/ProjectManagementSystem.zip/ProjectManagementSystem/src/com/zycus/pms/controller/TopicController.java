package com.zycus.pms.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;


import com.zycus.pms.entity.Forum;
import com.zycus.pms.entity.Topic;
import com.zycus.pms.exception.PMSForumException;
import com.zycus.pms.logger.LogMaster;
import com.zycus.pms.service.IForumService;
import com.zycus.pms.service.ITopicService;


@Controller
@SessionAttributes("cursorTopic")
public class TopicController {
	
	@Autowired
	private ITopicService topicService;
	
	@Autowired
	private IForumService forumService;
	
	@RequestMapping("/topicsOfForum.do")
	public String getAllTopicsOfForum(Map<String, Object> model,
			@RequestParam(value="view", required=false) String view, 
			@RequestParam(value="forumId",required=false) int forumId, HttpServletRequest request){
		
		try {
			Integer cursorTopic = (Integer) model.get("cursorTopic");
			if(cursorTopic == null)
				cursorTopic = 0;
			if(view != null){
				if(view.equals("next"))
					cursorTopic += 5;
				else if(view.equals("previous"))
					cursorTopic -= 5;
				if(cursorTopic<0)
					cursorTopic=0;
			}

			List<Topic> list = topicService.getTopicOfForum(forumId, cursorTopic, 5);
			if(list.isEmpty()){
				cursorTopic -= 5;
				list = topicService.getTopicOfForum(forumId, cursorTopic, 5);
			}
			model.put("cursorTopic", cursorTopic);
			model.put("topicOfForum", list);
			model.put("forumId", forumId);
			
			return "topiscOfForm.jsp";
		} catch (PMSForumException e) {
			
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
	}
	
	@RequestMapping("/addNewTopic.do")
	public String addNewForum(@RequestParam("forumId") int forumId,  Map<String, Object> model){
		
		model.put("forumId", forumId);
		return "addNewTopic.jsp";
	}
	
	@RequestMapping(value="/saveTopic.do", method= RequestMethod.POST)
	public String saveTopic(Map<String, Object> model,
			HttpServletRequest request){
		
		Topic topic = null;
		try {
			int forumId = Integer.parseInt(request.getParameter("forumId"));
			Forum forum = forumService.getForumById(forumId); 
			
			topic = new Topic();
			topic.setName(request.getParameter("name"));
			topic.setForum(forum);
			
			topicService.addTopic(topic);

			return "redirect:topicsOfForum.do?forumId="+forumId;
		} catch (NumberFormatException e) {
			LogMaster.getLogger(this.getClass()).error(topic, e);
			LogMaster.getLogger(this.getClass()).error(request, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
			
		} catch (PMSForumException e) {
			
			LogMaster.getLogger(this.getClass()).error(request, e);
			LogMaster.getLogger(this.getClass()).error(topic, e);
			request.setAttribute("errorMessage", "Problem in session. Please log in again");
			return "errorPage.jsp";
		}
	}

}
