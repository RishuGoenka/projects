package com.zycus.pms.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.zycus.pms.exception.PMSProjectException;
import com.zycus.pms.exception.PMSUserException;
import com.zycus.pms.service.IProjectService;
import com.zycus.pms.service.IUserService;

@Controller
public class UIController {
	
	@Autowired
	IUserService userService;
	
	@Autowired
	IProjectService projectService;

	@RequestMapping("/getNavigator.do")
	public String getNavigator(
			Map<String, Object> model,
			HttpServletRequest request) throws PMSUserException, PMSProjectException{

		HttpSession session = request.getSession();
		Object user = session.getAttribute("userId");
		Object proj = session.getAttribute("projectId");
		Object role = session.getAttribute("roleId");

		if(user==null || role==null){
			model.put("login", "please login <a href='login.do'>LOGIN</a>");
		}
		else{
			model.put("login", "Logged in as :"+userService.getUserById((Integer)user).getFullName());
			if(proj==null){
				if((Integer)role== 1)
					model.put("proj", "<a href='listProjectsByOwner.do'>Select a project</a>");
				else if((Integer)role==2)
					model.put("proj", "<a href='listProjectsByMember.do'>Select a project</a>");
				else
					model.put("login", "login.do");
			}
			else{
				if((Integer)role== 1){
					model.put("proj", "Project selected : "+projectService.getProjectById((Integer)proj).getProjectTitle()+"<br/>"+
										"Change Project : <a href='listProjectsByOwner.do'>Select a project</a>");
					model.put("tasks", "<a href='showTasks.do'>See your Tasks</a>");
				}
				else if((Integer)role==2){
					model.put("proj", "Project selected : "+projectService.getProjectById((Integer)proj).getProjectTitle()+"<br/>"+
							"Change Project : <a href='listProjectsByMember.do'>Select a project</a>");
					model.put("tasks", "<a href='showTasksOfProject.do'>See your Tasks</a>");
				}
				else
					model.put("login", "login.do");
			}
		}
		return "navigator.jsp";
	}
	
	@RequestMapping("/logout.do")
	public String logout(
			HttpServletRequest request){
		HttpSession session = request.getSession();
		session.invalidate();
		return "redirect:getNavigator.do";
	}
}
