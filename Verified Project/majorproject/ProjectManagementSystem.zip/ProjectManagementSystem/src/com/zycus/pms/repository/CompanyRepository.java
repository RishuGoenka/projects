package com.zycus.pms.repository;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.pms.entity.Company;
import com.zycus.pms.entity.Role;
import com.zycus.pms.entity.User;
import com.zycus.pms.exception.PMSCompanyException;
import com.zycus.pms.exception.PMSUserException;

@Repository("companyRepository")
@Transactional
public class CompanyRepository implements ICompanyRepository{

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public List<Company> getAllCompanies() throws PMSCompanyException {
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(Company.class);
			return criteria.list();
		} catch (HibernateException e) {
			throw new PMSCompanyException("Error Company getAllCompanies ", e);
		}
	}
	
	@Override
	public List<Company> getCompany(int companyId){
		
		Session session = sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Company.class);
		criteria.add(Restrictions.idEq(companyId));
		
		return criteria.list();
	}
	
	@Override 
	public void addCompany(Company company){

			Session session = sessionFactory.getCurrentSession();
			session.save(company);

	}
}
