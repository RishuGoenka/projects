package com.zycus.pms.service;

import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.*;
import org.apache.poi.poifs.filesystem.*;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.pms.controller.TaskController;
import com.zycus.pms.entity.Task;
import com.zycus.pms.repository.IExcelRepository;

import java.io.*;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

@Service
public class ExcelService implements IExcelService 
{
	@Autowired
	private IExcelRepository excelRepository;
	
	private POIFSFileSystem poiStream = null;
	private HSSFWorkbook document = null;
	private HSSFSheet sheet = null;
	private HSSFRow excelRow = null;
	private HSSFCell cell = null; 
	private HSSFCellStyle style = null;
	private HSSFFont font = null;

	String strExcelFile = "";
	int intSheetIndex = 0;
	 
	public ExcelService()
	{
		
	}

	public ExcelService(String strExcelFile)
	{
		openExcelFile(strExcelFile);
	}

	public boolean openExcelFile(String strExcelFile)
	{
		try
		{
			this.strExcelFile = strExcelFile;
			document = new HSSFWorkbook();
			java.io.FileOutputStream fileOut = new java.io.FileOutputStream(strExcelFile);
			document.write(fileOut);
			fileOut.close();

			poiStream = new POIFSFileSystem(new FileInputStream(strExcelFile));
			document = new HSSFWorkbook(poiStream);
			return(true);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return(false);
	 }

	 public boolean openExcelFile(String strExcelFile, boolean blnFlag)
	 {
		 try
		 {
			 this.strExcelFile = strExcelFile;
			 poiStream = new POIFSFileSystem(new FileInputStream(strExcelFile));
			 document = new HSSFWorkbook(poiStream);
			 return(true);
		 }
		 catch(Exception e)
		 {
			 System.out.println(e);
		 }
		 return(false);
	 }
	 
	 /* @Method : resetSheetIndex
	  * @Param : no param
	  * @Description : Method will reset the global index variable with 0
	  */
	  public void resetSheetIndex()
	  {
		  intSheetIndex = 0;
	  }
	  
	  /* @Method : setSheet
	   * @Param : no param
	   * @Description : Method will try to get the sheet at specified index. If the sheet is nulll
	   *      will try to create new sheet.
	   */
	  public void setSheet()
	  {
		  try
		  {
			  sheet = document.getSheetAt(intSheetIndex);
			  if(sheet == null)
			  {
				  sheet = document.createSheet();
			  }
		  }
		  catch(Exception e)
		  {
			  sheet = document.createSheet();
		  }
		  intSheetIndex++;
		  System.out.println("intSheetIndex >> " + intSheetIndex + " sheet >> " + sheet);
	  }
	  
	  /* @Method : insertRow
	   * @Param : rowindex
	   * @Description : Method will insert new row if the row does not exists.
	   */
	  public void insertRow(int row)
	  {
		  if(sheet != null)
		  {
			  if(sheet.getRow(row) != null) excelRow = sheet.getRow(row);
			  else excelRow = sheet.createRow(row);
		  }
	  }
	  
	  /* @Method : insertRow
	   * @Param : rowindex
	   * @Description : Method will insert new row if the row does not exists.
	   */
	  public void insertRow(short row)
	  {
		  if(sheet != null)
		  {
			  if(sheet.getRow(row) != null) excelRow = sheet.getRow(row);
			  else excelRow = sheet.createRow(row);
		  }
	  }
	  
	  /* @Method : insertRow
	   * @Param : rowindex
	   * @Description : Method will insert new row if the row does not exists.
	   */
	  public void insertRow(int row, boolean blnAppend)
	  {
		  if(sheet != null)
		  {
			  excelRow = sheet.createRow((short)row);
		  }
	  }
	  
	  /* @Method : writeData
	   * @Param1 : col
	   * @Param2 : row
	   * @Param3 : data
	   * @Description : Method will write float data in specified row and column.
	   */
	  public void writeData(int col, int row, Object data)
	  {
		  excelRow = sheet.getRow(row);
		  cell = excelRow.createCell(col);
		  if(data instanceof Boolean) 
		  {
			  cell.setCellType(HSSFCell.CELL_TYPE_BOOLEAN);
			  cell.setCellValue(Boolean.getBoolean(data.toString()));
		  } 
		  else if(data instanceof String) 
		  {
			  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			  cell.setCellValue(new HSSFRichTextString(data.toString()));
		  } 
		  else if(data instanceof Integer) 
		  {
			  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
			  cell.setCellValue(Double.parseDouble(data.toString()));
		  } 
		  else if(data instanceof Double) 
		  {
			  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
			  cell.setCellValue(Double.parseDouble(data.toString()));
		  } 
		  else if(data instanceof Float) 
		  {
			  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
			  cell.setCellValue(Float.parseFloat(data.toString()));
		  } 
		  else if(data instanceof Long) 
		  {
			  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
			  cell.setCellValue(Long.parseLong(data.toString()));
		  }
	  }
	  
	  /* @Method : fillColor
	   * @Param1 : sindex
	   * @Param2 : startcol
	   * @Param3 : endcol
	   * @Param4 : row
	   * @Description : Method will fill the color in specified row and column.
	   */ 
	  public void fillColor(short sindex, int row, int startcol, int endcol)
	  {
		  try
		  {
			  excelRow = sheet.getRow(row);
			  style = document.createCellStyle();
	     
			  style.setFillForegroundColor(sindex);
			  style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
			  for(int index=startcol; index <= endcol; index++)
			  {
				  cell = excelRow.getCell(index);
				  if(cell == null) 
					  cell = excelRow.createCell(index);
				  cell.setCellStyle(style);
			  }
		  }
		  catch(Exception e)
		  {
			  System.out.println("Error in fillColor () --- " + e);
		  }
	  }
	   
	  public void fillColor(short sindex, int row, int startcol, int endcol, int red, int green, int blue) 
	  {
		  //creating a custom palette for the workbook
		  HSSFPalette palette = document.getCustomPalette();

	      //replacing the standard red with freebsd.org red
	      palette.setColorAtIndex(sindex, (byte) red, (byte) green, (byte) blue);
	      excelRow = sheet.getRow(row);
	      style = document.createCellStyle();
	    
	      style.setFillForegroundColor(sindex);
	      style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
	      for(int index=startcol; index <= endcol; index++)
	      {
	    	  cell = excelRow.getCell(index);
	    	  if(cell == null) 
	    		  cell = excelRow.createCell(index);
	    	  cell.setCellStyle(style);
	      }
	  }
	   
	  public void setBorder(int row, int startCol, int endCol, boolean left, boolean top, boolean right, boolean bottom) 
	  {
		  excelRow = sheet.getRow(row);
		  for(int index = startCol; index <= endCol; index++) 
		  {
			  cell = excelRow.getCell(index);
			  if(cell == null) 
				  cell = excelRow.createCell(index);
	     
			  HSSFCellStyle cellStyle = cell.getCellStyle();
	     
			  if(left) 
				  cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			  if(top) 
				  cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
			  if(right) 
				  cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
			  if(bottom) 
				  cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	     
			  cell.setCellStyle(cellStyle);
		  }
	  }
	   
	  public void setBorder(int row, int col, boolean left, boolean top, boolean right, boolean bottom) 
	  {
		  excelRow = sheet.getRow(row);
		  cell = excelRow.getCell(col);
		  if(cell == null) 
			  cell = excelRow.createCell(col);
	    
		  HSSFCellStyle cellStyle = cell.getCellStyle();
	    
		  if(left) 
			  cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		  if(top) 
			  cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
		  if(right) 
			  cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
		  if(bottom) 
			  cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
	    
		  cell.setCellStyle(cellStyle);
	    
	  } 
	  
	  /* @Method : merge
	   * @Param : firstRow, lastRow, firstCol, lastCol
	   * @Description : Merges the selected rows/columns to one
	   */ 
	  @SuppressWarnings("deprecation")
	  public void merge(int firstRow, int lastRow, int firstCol, int lastCol) 
	  {
		  sheet.addMergedRegion(new CellRangeAddress(firstRow, lastRow, firstCol, lastCol));
	  }
	   
	  /* @Method : setColumnWidth
	   * @Param : col, width
	   * @Description: Sets the column width
	   */
	  public void setColumnWidth(int col, int width) 
	  {
		  sheet.setColumnWidth(col, width);
	  }
	  
	  /* @Method : closeExcel
	   * @Param : no param
	   * @Description : Method will write the contents to excel file and closes the stream.
	   */
	  public void closeExcel()
	  {
		  try
		  {
			  // Rewrite the spreadsheet to the File System 
			  FileOutputStream modSpreadsheet = new FileOutputStream(strExcelFile);
			  document.write(modSpreadsheet);
			  modSpreadsheet.close();
		  }
		  catch(Exception e)
		  {
			  
		  }
	  }

	  public void importExcelService() throws ParseException
	  {
		 /* int percentCompleted = -1;
		  String taskName = null;
		  String desc = null;
		  String startDate = null;
		  String deadLine = null;
		  
		  try 
		  {     
			  FileInputStream file = new FileInputStream(new File("C:\\Animesh Mehta\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelExport\\newTaskExc.xls"));
			     
			  //Get the workbook instance for XLS file
			  HSSFWorkbook workbook = new HSSFWorkbook(file);
			 
			  //Get first sheet from the workbook
			  HSSFSheet sheet = workbook.getSheetAt(0);
			     
			  //Iterate through each rows from first sheet
			  Iterator<Row> rowIterator = sheet.iterator();
			  while(rowIterator.hasNext()) 
			  {
				  Row row = rowIterator.next();
			         
			      //For each row, iterate through each columns
			      Iterator<Cell> cellIterator = row.cellIterator();
			      while(cellIterator.hasNext()) 
			      {       
			          Cell cell = cellIterator.next();
			             
			          switch(cell.getCellType()) 
			          {
			              case Cell.CELL_TYPE_BOOLEAN: break;
		                    						   
			              case Cell.CELL_TYPE_NUMERIC: break;
			                    
			              case Cell.CELL_TYPE_STRING: Row row1 = rowIterator.next();
			              							  Iterator<Cell> cellIterator1 = row1.cellIterator();
			              							  Cell cell1 = cellIterator.next();
			              							  taskName = cell1.getStringCellValue();
			              							  cell1 = cellIterator1.next();
			              							  desc = cell1.getStringCellValue();
			              							  cell1 = cellIterator1.next();
			              							  startDate = cell1.getStringCellValue();
			              							  cell1 = cellIterator1.next();
			              							  deadLine = cell1.getStringCellValue();
			              							  cell1 = cellIterator1.next();
			              							  //percentCompleted = (int) cell1.getNumericCellValue();
			              							  percentCompleted = 0;
		                    						  break;
			                    
			          }
			      }
			  }
			  file.close();
			  FileOutputStream out = new FileOutputStream(new File("C:\\Animesh Mehta\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelExport\\newTaskExc.xls"));
			  workbook.write(out);
			  out.close();
			  TaskController t1 = new TaskController();
			  HttpServletRequest request = null;
			//  t1.addTaskFromExcel(percentCompleted, taskName, desc, startDate, deadLine, request);
			     
		    } 
		  	catch (FileNotFoundException e) 
		  	{
			    e.printStackTrace();
			} 
		  	catch (IOException e) 
		  	{
			    e.printStackTrace();
			}*/
	  }
	  
	  @Override
	  public List<Task> getAllCompletedTasks() 
	  {
		  List<Task> completedTasks = excelRepository.getAllCompletedTasks();
		  return completedTasks;
	  }

	  @Override
	  public List<Task> getAllIncompleteTasks() 
	  {
		  List<Task> incompleteTasks = excelRepository.getAllIncompleteTasks();
		  return incompleteTasks;
	  }

	  @Override
	  public List<Task> getAllDeletedTasks() 
	  {
		  List<Task> deletedTasks = excelRepository.getAllDeletedTasks();
		  return deletedTasks;
	  }
}
