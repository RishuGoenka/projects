package com.zycus.pms.controller;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Validator;
import org.springframework.web.bind.annotation.RequestMapping;

import com.zycus.pms.entity.Task;
import com.zycus.pms.excelImport.Configuration;
import com.zycus.pms.exception.PMSTaskException;
import com.zycus.pms.logger.LogMaster;
import com.zycus.pms.service.IExcelService;
import com.zycus.pms.service.ITaskService;

@Controller
public class ExcelController 
{
	@Autowired
	ITaskService taskService;
	
	@Autowired
	IExcelService excelService;
	
	@Autowired
	Validator validator;
	
	private Integer taskId = 0;
	private String description = null;
	private String taskName = null;
	private Date sDate = null;
	private Date dLine = null;
	private Date eDate = null;
	private String startDate = null;
	private String endDate = null;
	private String deadLine = null;
	private Integer percentCompleted = -1;
	
	
	public void helperFunc1(String filePath)
	{
		excelService.openExcelFile(filePath);
		excelService.resetSheetIndex();
		excelService.setSheet();
		excelService.insertRow(1, true);
	}
	
	public void helperFunc2(String taskType)
	{
		excelService.writeData(1, 1, "TASK ID");
		excelService.writeData(2, 1, "TASK NAME");
		excelService.writeData(3, 1, "DESCRIPTION");
		excelService.writeData(4, 1, "START DATE");
		excelService.writeData(5, 1, "DEADLINE");
		
		if(taskType.equals("Completed"))
		{
			excelService.writeData(6, 1, "END DATE");
			excelService.writeData(7, 1, "PERCENT COMPLETED");
		}
		
		else if(taskType.equals("Incomplete") || taskType.equals("Deleted"))
		{
			excelService.writeData(6, 1, "PERCENT COMPLETED");
		}
	}

	public void helperFunc3(Task task, String taskType, int iteration)
	{
		Format formatter = new SimpleDateFormat("yy-MM-dd");
		excelService.insertRow(iteration, true);
		taskId = task.getTaskId();
		description = task.getDescription();
		taskName = task.getTaskName();
		sDate = task.getStartDate();
		dLine = task.getDeadLine();
		if(sDate!=null)
			startDate = formatter.format(sDate);
		if(dLine!=null)
			deadLine = formatter.format(dLine);
		
		percentCompleted = task.getPercentCompleted();
		
		excelService.writeData(1, iteration, taskId);
		excelService.writeData(2, iteration, taskName);
		excelService.writeData(3, iteration, description);
		excelService.writeData(4, iteration, startDate);
		excelService.writeData(5, iteration, deadLine);
		
		if(taskType.equals("Completed"))
		{
			eDate = task.getEndDate();
			if(eDate!=null)
				endDate = formatter.format(eDate);
			excelService.writeData(6, iteration, endDate);
			excelService.writeData(7, iteration, percentCompleted);
		}
		
		else if(taskType.equals("Incomplete") || taskType.equals("Deleted"))
		{
			excelService.writeData(6, iteration, percentCompleted);
		}
		
	}
	@RequestMapping("/exportCompletedTasksToExcel.do")
	public void exportCompletedTask(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
	{
		String filePath = "C:\\Animesh Mehta\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelExport\\CompleteTasksNow.xls";
		try {
			
			List<Task> completedList = excelService.getAllCompletedTasks();
			helperFunc1(filePath);
			
			String taskType="Completed";
			helperFunc2(taskType);

			int i=2;
			for(Task task : completedList)
			{
				helperFunc3(task, taskType, i);
				i++;
			}
			excelService.closeExcel();

			//return download(model, response, filePath);
			download(model, response, filePath);
		} 
		catch (IOException e) 
		{
			LogMaster.getLogger(this.getClass()).error(filePath, e);
			request.setAttribute("errorMessage", "Problem in downloading . Please try again");
			//return "errorPage.jsp";
		}
	}
	
	@RequestMapping("/exportIncompleteTasksToExcel.do")
	public void exportPendingTask(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
	{
		String filePath = "C:\\Animesh Mehta\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelExport\\incompTaskExc.xls";
		try {
			
			List<Task> completedList = excelService.getAllIncompleteTasks();
			helperFunc1(filePath);
			
			String taskType="Incomplete";
			helperFunc2(taskType);
			
			

			int i=2;
			for(Task task : completedList)
			{
				helperFunc3(task, taskType, i);
				i++;
			}
			excelService.closeExcel();

			//return download(model, response, filePath);
			download(model, response, filePath);
		} 
		catch (IOException e)
		{
			LogMaster.getLogger(this.getClass()).error(filePath, e);
			request.setAttribute("errorMessage", "Problem in downloading . Please try again");
			//return "errorPage.jsp";
		}
	}
	
	@RequestMapping("/exportDeletedTasksToExcel.do")
	public void exportDeletedTask(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
	{
		String filePath = "C:\\Animesh Mehta\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelExport\\DeleteTasks.xls";
		try {
			List<Task> deletedList = excelService.getAllDeletedTasks();
			helperFunc1(filePath);
			
			String taskType="Deleted";
			helperFunc2(taskType);
			
			int i=2;
			for(Task task : deletedList)
			{
				helperFunc3(task, taskType, i);	
				i++;
			}
			excelService.closeExcel();
			
			//return download(model, response, filePath);
			download(model, response, filePath);
		} 
		catch (IOException e) 
		{
			LogMaster.getLogger(this.getClass()).error(filePath, e);
			request.setAttribute("errorMessage", "Problem in downloading . Please try again");
			//return "errorPage.jsp";
		}
	}
	
	@RequestMapping("/download.do")
	public void download(Map<String, Object> model, HttpServletResponse response, String filepath) throws IOException {
		
		//String filename = "C:\\Mayur\\Eclipse\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelExport\\delTaskExc.xls";

		
        ServletOutputStream out = response.getOutputStream();
        FileInputStream in = new FileInputStream(filepath);

        response.setContentType("application/vnd.ms-excel");
        response.addHeader("content-disposition", "attachment; filename=" + filepath);

        int iteration;
        while((iteration = in.read()) != -1)
            out.write(iteration);

        in.close();
        out.close();
        
        model.put("uploadedExcel", out);
        response.sendRedirect("exportCompleted.jsp");
		//return "exportCompleted.jsp";
	}
	
	@RequestMapping("/convExcelToCSV.do")
	public String convertExcelToCSV(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response)
	{
		try
		{
			//File to store data in form of CSV
			File f = new File("C:\\Animesh Mehta\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelExport\\inputTasks.txt");

			OutputStream os = (OutputStream)new FileOutputStream(f);
			String encoding = "UTF8";
			OutputStreamWriter osw = new OutputStreamWriter(os, encoding);
			BufferedWriter bw = new BufferedWriter(osw);

			//Excel document to be imported
			String filename = "C:\\Animesh Mehta\\ProjectManagementSystem\\src\\com\\zycus\\pms\\excelExport\\newTaskExc.xls";
			WorkbookSettings ws = new WorkbookSettings();
			ws.setLocale(new Locale("en", "EN"));
			Workbook w = Workbook.getWorkbook(new File(filename),ws);

			// Gets the sheets from workbook
			for (int sheet = 0; sheet < w.getNumberOfSheets(); sheet++)
			{
				Sheet s = w.getSheet(sheet);

				/*bw.write(s.getName());
				bw.newLine();*/

				Cell[] row = null;
        
				// Gets the cells from sheet
				for (int i = 0 ; i < s.getRows() ; i++)
				{
					row = s.getRow(i);

					if (row.length > 0)
					{
						bw.write(row[0].getContents());
						for (int j = 1; j < row.length; j++)
						{
							bw.write(',');
							bw.write(row[j].getContents());
						}
					}
					bw.newLine();
				}	
			}
			bw.flush();
			bw.close();
		}
		catch (UnsupportedEncodingException e)
		{
			System.err.println(e.toString());
		}
		catch (IOException e)
		{
			System.err.println(e.toString());
		}
		catch (Exception e)
		{
			System.err.println(e.toString());
		}
		
		//return("Import Completed");
		return("redirect: importCSVToDB.do");
	}
	
	@RequestMapping("/importCSVToDB.do")
	public String importCSVToDB(Map<String, Object> model, HttpServletRequest request, HttpServletResponse response) throws PMSTaskException, ParseException
	{
		Configuration configuration = new Configuration("C:\\Animesh Mehta\\ProjectManagementSystem\\src\\ExcelImport.properties");
		
		String filePath = configuration.getProperty("CSVFilePath");
		String fileName = configuration.getProperty("CSVFileName");
		BufferedReader reader = null;
		FileInputStream fileStream = null;
		ArrayList<String> records = new ArrayList<String>();
		
		int projectId = 0;
		int userId = 0;
		String taskName = null;
		String description = null;
		String startDate = null;
		Date sDate = null;
		String deadLine = null;
		Date dLine = null;
		int percentCompleted = -1;
		
		// Open a file
		File file = new File(filePath + File.separator + fileName);
		System.out.println(file.getAbsolutePath());
			
		if( ! file.isFile())
		{
			throw new PMSTaskException("Data file missing: "+fileName);
		}
		else
		{
			try 
			{
				fileStream = new FileInputStream(file);
				reader = new BufferedReader(new InputStreamReader(fileStream));
				reader.readLine();	
				reader.readLine();
				// Traverse a file and read data.
				String record = reader.readLine();
				while(record != null)
				{
					StringTokenizer tokens = new StringTokenizer(record, ",");
					try 
					{
						projectId = Integer.parseInt(tokens.nextToken());
					} 
					catch (NumberFormatException e)
					{
							e.printStackTrace();
					}
					try 
					{
						userId = Integer.parseInt(tokens.nextToken());
					} 
					catch (NumberFormatException e)
					{
							e.printStackTrace();
					}
					taskName = tokens.nextToken();
					description = tokens.nextToken();
					
					SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd");
					startDate = tokens.nextToken();
					sDate = sdf.parse(startDate);
					
					deadLine = tokens.nextToken();
					dLine = sdf.parse(deadLine);
					
					try 
					{
						percentCompleted = Integer.parseInt(tokens.nextToken());
					} 
					catch (NumberFormatException e)
					{
						e.printStackTrace();
					} 
					
					record = reader.readLine();			//To prevent infinite loop.
				}
				
				Task task = new Task();
				task.setDeadLine(dLine);
				task.setDescription(description);
				task.setPercentCompleted(percentCompleted);
				task.setStartDate(sDate);
				task.setTaskName(taskName);
				
				taskService.addTask(task, userId, projectId);
				// Return arrayList
				//return records;
				} 
				catch (IOException e) 
				{
					throw new PMSTaskException("Data file corrupt");
				}
				finally
				{
					// Close resources
					try 
					{
						if(reader != null)
						{
							reader.close();
						}
						if(fileStream != null)
						{
							fileStream.close();
						}
					} 
					catch (IOException e) 
					{
						throw new PMSTaskException("File closing unsuccessful");
					}
				}
			}
		
		return "importSuccess.jsp";
	}
}
