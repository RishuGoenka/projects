package com.zycus.bugzilla.bugmgmt.interfaces;

import java.util.Date;
import java.util.List;

import com.zycus.bugzilla.bugmgmt.entities.Bug;
import com.zycus.bugzilla.bugmgmt.entities.BugSeverity;
import com.zycus.bugzilla.bugmgmt.entities.BugStatus;
import com.zycus.bugzilla.bugmgmt.entities.BugType;
import com.zycus.bugzilla.bugmgmt.entities.QualityAspect;
import com.zycus.bugzilla.bugmgmt.exceptions.BugException;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.usermgmt.entities.User;


public interface IBugDao 
{
	public void addBug(Bug bug) throws BugException;
	public List<BugSeverity> getSeverityList() throws BugException;
	public List<QualityAspect> getQualityAspectList() throws BugException;
	public List<BugType> getBugTypes() throws BugException;
	public void changeStatus(Bug bug, BugStatus status) throws BugException;
	public List<Bug> getAllBugs() throws BugException;
	public List<Bug> getAllBugs(int offset, int rows) throws BugException;
	public Bug getBug(int bugId) throws BugException;
	public List<BugStatus> getStatusList() throws BugException;
	
	
	public List<Bug> listoutBugsByAssignee(User user) throws BugException;
	public List<Bug> listoutBugsByAssignee(User user, int offset, int rows) throws BugException;
	
	public List<Bug> listoutBugsByReportee(User user) throws BugException;
	public List<Bug> listoutBugsByReportee(User user, int offset, int rows) throws BugException;
	
	public List<Bug> listoutBugsBySeverity(BugSeverity bugSeverity) throws BugException;
	public List<Bug> listoutBugsBySeverity(BugSeverity bugSeverity, int offset, int rows) throws BugException;
	
	public List<Bug> listoutBugsByQualityAspect(QualityAspect qualityAspect) throws BugException;
	public List<Bug> listoutBugsByQualityAspect(QualityAspect qualityAspect, int offset, int rows) throws BugException;
	
	public List<Bug> listoutBugsByStatus(BugStatus bugStatus) throws BugException;
	public List<Bug> listoutBugsByStatus(BugStatus bugStatus, int offset, int rows) throws BugException;
	
	public List<Bug> listoutBugsByDate(Date bugDate, String spec) throws BugException;
	public List<Bug> listoutBugsByDate(Date bugDate, String spec, Product product) throws BugException;
	public List<Bug> listoutBugsByDate(Date bugDate, String spec, int offset, int rows) throws BugException;
	
	public List<Bug> listoutBugsByProducts(Product product) throws BugException;
	public List<Bug> listoutBugsByProducts(Product product, int offset, int rows) throws BugException;
}
