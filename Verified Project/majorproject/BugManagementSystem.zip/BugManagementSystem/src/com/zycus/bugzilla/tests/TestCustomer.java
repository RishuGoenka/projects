package com.zycus.bugzilla.tests;

import org.junit.Test;

import com.zycus.bugzilla.common.daos.BaseDao;
import com.zycus.bugzilla.customermgmt.entities.Customer;

public class TestCustomer {

		@Test
		public void addCustomer()
		{
			BaseDao dao = new BaseDao();
			
			Customer customer = new Customer();
			customer.setCustName("Houzefa");
			customer.setEmailId("houzefa@gmail.com");
			
			dao.saveOrUpdate(customer);
		}
}
