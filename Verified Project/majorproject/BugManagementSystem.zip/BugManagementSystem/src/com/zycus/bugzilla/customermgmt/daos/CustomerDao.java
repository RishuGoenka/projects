package com.zycus.bugzilla.customermgmt.daos;

import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.bugzilla.common.daos.BaseDao;
import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.customermgmt.exceptions.CustomerException;
import com.zycus.bugzilla.customermgmt.interfaces.ICustomerDao;
import com.zycus.bugzilla.productmgmt.entities.Product;

/**
 * 
 * @author sankhadeep.basak
 *
 */
@Repository("customerDao")
public class CustomerDao extends BaseDao implements ICustomerDao{
	
	@Override
	public void addNewCustomer(Customer customer) throws CustomerException {
		
			super.save(customer);
	}
	
	@Override
	public void updateCustomer(Customer customer) throws CustomerException {
		
			super.update(customer);
	}
	
	@Override
	public void deleteCustomer(Customer customer) throws CustomerException{
		
			super.delete(customer);
	}
	
	
	@Override
	public void addProductsToCustomer(Customer customer, Set<Product> products) throws CustomerException{
		
			customer.getProducts().addAll(products);
	}	
	
	@Override
	public List<Customer> getAllCustomers() throws CustomerException{
		Session session = null;
		Criteria criteria = null;
		session = super.sessionFactory.getCurrentSession();
		criteria = session.createCriteria(Customer.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.addOrder(Order.asc("custName"));
			
		return criteria.list();
	}
	
	@Override
	public List<Customer> getAllCustomersByProduct(Product product) throws CustomerException{
		Session session = null;
		Criteria criteria = null;
		
		session = super.sessionFactory.getCurrentSession();
		criteria = session.createCriteria(Customer.class);
		criteria.setFetchMode("products", FetchMode.JOIN);
		criteria.createAlias("products", "productAlias");
		criteria.add(Restrictions.eq("productAlias.productId", product.getProductId()));
		criteria.addOrder(Order.asc("custId"));
			
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		List<Customer> custList = criteria.list();
		for(Customer c:custList)
		{
			c.getCustName();
		}
		return criteria.list();
	}
	
	@Override
	public String isUserValidated(String custName) throws CustomerException{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class);
		criteria.add(Restrictions.eq("custName", custName));
		
		if(criteria.list().isEmpty()){
			return "user Validated";
		}else{
			return "User Exist";
		}
	}

	@Override
	public String isEmailValidated(String email) throws CustomerException{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Customer.class);
		criteria.add(Restrictions.eq("emailId",email));
		
		if(criteria.list().isEmpty()){
			return "Email Validated";
		}else{
			return "Email exist";
		}
	}
}
