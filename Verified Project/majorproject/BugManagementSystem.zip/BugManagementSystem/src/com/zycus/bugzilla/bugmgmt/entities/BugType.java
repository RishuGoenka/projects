package com.zycus.bugzilla.bugmgmt.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="tbl_bug_type")
@GenericGenerator(name="typeIncr", strategy="increment")
public class BugType {
	
	@Id
	@GeneratedValue(generator="typeIncr")
	@Column(name="type_id")
	private int typeId;
	
	@Column(name="type_name")
	private String type;
	
	@OneToMany
	private Set<Bug> bugs=new HashSet<Bug>();

	public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Set<Bug> getBugs() {
		return bugs;
	}

	public void setBugs(Set<Bug> bugs) {
		this.bugs = bugs;
	}
	
	
	
}
