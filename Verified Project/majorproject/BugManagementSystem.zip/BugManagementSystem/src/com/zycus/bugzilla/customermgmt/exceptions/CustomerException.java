package com.zycus.bugzilla.customermgmt.exceptions;

public class CustomerException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public CustomerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	
	public CustomerException(String arg0) {
		super(arg0);
		
	}

}
