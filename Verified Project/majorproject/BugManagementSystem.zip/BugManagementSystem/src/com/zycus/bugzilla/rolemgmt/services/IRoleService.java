package com.zycus.bugzilla.rolemgmt.services;

import java.util.List;
import java.util.Map;

import com.zycus.bugzilla.rolemgmt.entities.Role;
import com.zycus.bugzilla.rolemgmt.exceptions.RoleException;

public interface IRoleService {

	public List<Role> getAllRoles() throws RoleException;
	public String addNewRole(String roleName) throws RoleException;
}
