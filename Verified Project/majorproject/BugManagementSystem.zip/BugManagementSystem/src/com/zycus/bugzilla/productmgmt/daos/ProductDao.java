package com.zycus.bugzilla.productmgmt.daos;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import com.zycus.bugzilla.common.daos.BaseDao;
import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.productmgmt.exceptions.ProductException;
import com.zycus.bugzilla.productmgmt.interfaces.IProductDao;
/**
 * 
 * @author sankhadeep.basak
 *
 */
@Repository("productDao")
public class ProductDao extends BaseDao implements IProductDao{
	
	@Override
	public void addNewProduct(Product product) throws ProductException{
		
			super.save(product);
	}
	
	@Override
	public void updateProduct(Product product) throws ProductException{
		
			super.update(product);
	}
	
	@Override
	public void deleteProduct(Product product) throws ProductException{
		
			super.delete(product);
	}
	
	@Override
	public void addCustomersToProduct(Product product, Customer customer) throws ProductException{
		
			product.getCustomers().add(customer);
	}
	
	@Override
	public List<Product> getAllProducts() throws ProductException{
		Session session = null;
		Criteria criteria = null;
		session = super.sessionFactory.getCurrentSession();
		criteria = session.createCriteria(Product.class);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.addOrder(Order.asc("productId"));
			
		return criteria.list();
	}
	
	@Override
	public List<Product> getAllProductsByCustomer(Customer customer) throws ProductException{
		Session session = null;
		Criteria criteria = null;
	
		session = super.sessionFactory.getCurrentSession();
		criteria = session.createCriteria(Product.class);
		criteria.setFetchMode("customers", FetchMode.JOIN);
		criteria.createAlias("customers", "customerAlias");
		criteria.add(Restrictions.eq("customerAlias.custId", customer.getCustId()));
		criteria.addOrder(Order.asc("productId"));
			
		return criteria.list();
	}
	
	@Override
	public String isProductValidated(String productName) throws ProductException{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Product.class);
		criteria.add(Restrictions.eq("productName", productName));
		
		if(criteria.list().isEmpty()){
			return "Product Validated";
		}else{
			return "Product Exist";
		}
	}
}
