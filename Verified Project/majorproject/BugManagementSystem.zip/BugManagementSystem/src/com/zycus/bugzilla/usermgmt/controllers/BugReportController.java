package com.zycus.bugzilla.usermgmt.controllers;



import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
	import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.zycus.bugzilla.bugmgmt.entities.Bug;
import com.zycus.bugzilla.bugmgmt.interfaces.IBugService;

/**
 * 
 * @author saurabh.dharod
 *
 */
@Controller
	public class BugReportController extends AbstractController{

	
		@Autowired
		IBugService bugService;

		@Override
		@RequestMapping(value="excelReport.do")
		protected ModelAndView handleRequestInternal(HttpServletRequest request,
				HttpServletResponse response) throws Exception {
			
			String output =
				ServletRequestUtils.getStringParameter(request, "output");
			
			//dummy data
			List<Bug> bugData=bugService.getAllBugs();
			
			if(output ==null || "".equals(output)){
				//return normal view
								
				return new ModelAndView("BugSummary","bugData",bugData);
				
			}else if("EXCEL".equals(output.toUpperCase())){
				//return excel view
				return new ModelAndView("ExcelBugSummary","bugData",bugData);
				
			}else{
				//return normal view
				return new ModelAndView("BugSummary","bugData",bugData);
				
			}
			
		}

	
}
