package com.zycus.bugzilla.bugmgmt.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.usermgmt.entities.User;

@Entity
@Table(name="tbl_bug2")
@GenericGenerator(name = "bugIncr", strategy = "increment")
public class Bug {

	@Id
	@GeneratedValue(generator="bugIncr")
	@Column(name="bug_id")
	private int bugId;
	
	@Column(name="rca")
	private String RCA;
	
	@Column(name="impact_area")
	private String impactArea;
	
	@Column(name="summary")
	private String summary;
	
	@Temporal(TemporalType.DATE)
	@Column(name="created_date")
	private Date createdDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name="modified_date")
	private Date modifiedDate;
	
	
	/*------------------------- MAPPED TO PRODUCT-------------------------------------------------*/
	@ManyToOne
	@JoinColumn(name="product_id")
	private Product product;
	
	
	/*------------------------- BUG QUALITIES-------------------------------------------------*/
	@ManyToMany
	@JoinTable(name="tbl_aspect_bug2",
			joinColumns=@JoinColumn (name="bug_id",nullable=false),
			inverseJoinColumns = @JoinColumn(name = "quality_aspect_id",nullable=false)
			)
	private Set<QualityAspect> qualityAspects=new HashSet<QualityAspect>();

	@ManyToOne
	@JoinColumn(name="status_id")
	private BugStatus bugStatus;
	
	@ManyToOne
	@JoinColumn(name="severity_id")
	private BugSeverity bugSeverity;
	
	@ManyToOne
	@JoinColumn(name="type_id")
	private BugType type;
	
	
	/*------------------------- MAPPED TO USERS AND CUSTOMERS-------------------------------------------------*/
	@ManyToOne
	@JoinColumn(name="reportee")
	private User reportee;
	
	@ManyToOne
	@JoinColumn(name="injected_by")
	private User injectedBy;
	
	@ManyToOne
	@JoinColumn(name="missed_by")
	private User missedBy;
	
	@ManyToOne
	@JoinColumn(name="customer")
	private Customer customer;
	
	
	/*------------------------- GETTERS & SETTERS-------------------------------------------------*/
	public int getBugId() {
		return bugId;
	}


	public void setBugId(int bugId) {
		this.bugId = bugId;
	}


	public String getRCA() {
		return RCA;
	}


	public void setRCA(String rca) {
		RCA = rca;
	}


	public String getImpactArea() {
		return impactArea;
	}


	public void setImpactArea(String impactArea) {
		this.impactArea = impactArea;
	}


	public String getSummary() {
		return summary;
	}


	public void setSummary(String summary) {
		this.summary = summary;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public Date getModifiedDate() {
		return modifiedDate;
	}


	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}


	public Set<QualityAspect> getQualityAspects() {
		return qualityAspects;
	}


	public void setQualityAspects(Set<QualityAspect> qualityAspects) {
		this.qualityAspects = qualityAspects;
	}


	public void setBugStatus(BugStatus bugStatus) {
		this.bugStatus = bugStatus;
	}


	public BugStatus getBugStatus() {
		return bugStatus;
	}


	public BugSeverity getBugSeverity() {
		return bugSeverity;
	}


	public void setBugSeverity(BugSeverity bugSeverity) {
		this.bugSeverity = bugSeverity;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}


	public BugType getType() {
		return type;
	}


	public void setType(BugType type) {
		this.type = type;
	}


	public User getInjectedBy() {
		return injectedBy;
	}


	public void setInjectedBy(User injectedBy) {
		this.injectedBy = injectedBy;
	}


	public User getMissedBy() {
		return missedBy;
	}


	public void setMissedBy(User missedBy) {
		this.missedBy = missedBy;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	public User getReportee() {
		return reportee;
	}


	public void setReportee(User reportee) {
		this.reportee = reportee;
	}

	
}
