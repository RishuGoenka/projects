package com.zycus.bugzilla.rolemgmt.daos;

import java.util.List;

import com.zycus.bugzilla.rolemgmt.entities.Role;
import com.zycus.bugzilla.rolemgmt.exceptions.RoleException;
import com.zycus.bugzilla.usermgmt.entities.User;

public interface IRoleDao {


	public List<Role> getAllRoles()throws  RoleException;
	public String addNewRole(Role role)throws  RoleException;
	Role getRoleByName(Role role) throws RoleException;
}
