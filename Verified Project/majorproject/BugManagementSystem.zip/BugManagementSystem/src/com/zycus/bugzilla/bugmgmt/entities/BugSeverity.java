package com.zycus.bugzilla.bugmgmt.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="tbl_bug_severity")
@GenericGenerator(name="severityIncr", strategy="increment")
public class BugSeverity {
	
	
		
		@Id
		@GeneratedValue(generator="severityIncr")
		@Column(name="severity_id")
		private int severityId;
		
		@Column(name="severity_message")
		private String severityMessage;
		
		@OneToMany
		private Set<Bug> bugs=new HashSet<Bug>();

		public int getSeverityId() {
			return severityId;
		}

		public void setSeverityId(int severityId) {
			this.severityId = severityId;
		}

		public String getSeverityMessage() {
			return severityMessage;
		}

		public void setSeverityMessage(String severityMessage) {
			this.severityMessage = severityMessage;
		}

		public Set<Bug> getBugs() {
			return bugs;
		}

		public void setBugs(Set<Bug> bugs) {
			this.bugs = bugs;
		}
}
