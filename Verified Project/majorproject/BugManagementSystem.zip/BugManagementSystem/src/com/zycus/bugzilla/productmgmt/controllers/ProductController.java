package com.zycus.bugzilla.productmgmt.controllers;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

//import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.customermgmt.exceptions.CustomerException;
import com.zycus.bugzilla.customermgmt.interfaces.ICustomerService;
//import com.zycus.bugzilla.productmgmt.daos.ProductDao;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.productmgmt.exceptions.ProductException;
import com.zycus.bugzilla.productmgmt.interfaces.IProductService;

/**
 * 
 * @author sankhadeep.basak
 *
 */
@Controller
public class ProductController {
	
	@Autowired
	private IProductService productService;
	
	@Autowired
	private ICustomerService customerService;
	
	@RequestMapping(value="/productHome.do")
	public String showProductHomepage(Map<String, Object> model){
		List<Product> products = null;
		
		try {
			products = productService.getAllProducts();
			model.put("listOfProducts", products);
			
			return "viewProducts";
		} catch (ProductException e) {
			return "exceptionPage";
		}
		
	}
	
	@RequestMapping(value="addProduct.do")
	public String addProduct(Map<String,Object> model){
		model.put("product", new Product());
		return "addProduct";
	}
	
	@RequestMapping(value="/saveProduct.do",method=RequestMethod.POST)
	public String saveProduct(@Valid @ModelAttribute("product") Product product, BindingResult result){
		if(result.hasErrors()){
			return "addProduct";
		}else{
			try {
				productService.addNewProduct(product);
				return "redirect:productListing.do";
			} catch (ProductException e) {
				return "exceptionPage";
			}
		}
	}
	
	@RequestMapping(value="/productListing.do")
	public String listOfProducts(
			@RequestParam(value="view", required=false) String view,
			@RequestParam(value="viewType", required=false) String viewType,
			Map<String,Object> model){
		List<Product> products = null;
		
		try {
			products = productService.getAllProducts();
			model.put("listOfProducts", products);
			return "viewProducts";
		} catch (ProductException e) {
			return "exceptionPage";
		}
	}
	
	@RequestMapping(value="/listAllCustomers.do")
	public String returnCustomerList(Map<String, Object> model){
		List<Customer> custList = null;
		try {
			custList = customerService.getAllCustomers();
			model.put("custList", custList);
			return "populateCustomerList";
		} catch (CustomerException e) {
			return "exceptionPage";
		}
	}
	
	@RequestMapping("listAllProducts.do")
	public String getAllProducts(Map<String, Object> model)
	{
		List<Product> prodList = null;
		
		try {
			prodList = productService.getAllProducts();
			model.put("prodList", prodList);
			return "populateProductList";
		} catch (ProductException e) {
			return "exceptionPage";
		}
	}
	
	@RequestMapping(value = "/editproduct.do")
	public String editProduct(Map<String,Object> model){
		List<Product> prodList = null;
		
		try {
			prodList = productService.getAllProducts();
			model.put("prodList", prodList);
			return "editProduct";
		} catch (ProductException e) {
			return "exceptionPage";
		}
	}
	
	@RequestMapping(value = "/editProductSuccessfully.do")
	public String editProductSuccessfully(
			@RequestParam(value = "product") int productId,
			@RequestParam(value = "changedName") String productName,
			Map<String,Object> model){
		
		try {
			productService.updateExistingProduct(productId,productName);
			return "redirect:productListing.do";
		} catch (ProductException e) {
			return "exceptionPage";
		}
	}
	
	@RequestMapping(value="/assignCustomerToProduct.do")
	public String assignCustomerToProduct(Map<String,Object> model){
		
		List<Product> products = null;
		
		try {
			products = productService.getAllProducts();
			
			model.put("products",products);
			return "addCustomersToProduct";
		} catch (ProductException e) {
			return "exceptionPage";
		}
	}
		
	@RequestMapping(value = "/listOfCustomersNotInProduct.do")
	public String listOfCustomerNotInProduct(
			@RequestParam(value = "productId" , required = true) int productId, 
			Map<String,Object> model){
		System.out.println(productId);
		List<Customer> unassignedCustList = null;
		
		try {
			
			unassignedCustList = productService.getAllCustomersNotAssignedToProduct(productId);
			
			model.put("custList", unassignedCustList);
			System.out.println(unassignedCustList.size());
			return "populateCustomerList";
		} catch (Exception e) {
			return "exceptionPage";
		}
	}
	
	@RequestMapping(value = "/addCustomerToProduct.do")
	public String addCustomerToProduct(
		@RequestParam(value = "productId", required = true) int productId,
		@RequestParam(value = "customerId", required = true) int customerId,
		Map<String, Object> model){
		
		
		try {
			System.out.println("CustomerId: "+customerId);
			productService.assignCustomesToProduct(productId, customerId);        
			return "redirect:productListing.do";
		} catch (ProductException e) {
			return "exceptionPage";
		}
	}
	
	@RequestMapping(value = "/deleteProduct.do")
	public String deleteProduct(Map<String,Object> model){
		List<Product> products = null;
		
		try {
			products = productService.getAllProducts();
			model.put("listOfProducts",products);
			return "deleteProduct";
		} catch (ProductException e) {
			return "exceptionPage"; 
		}
	}
	
	@RequestMapping(value = "/deleteProductSuccessfully.do")
	public String deleteProductSuccessfully(
			@RequestParam(value = "product", required = true) int productId,
			Map<String,Object> model){
			System.out.println(productId);
		try {
			productService.deleteProduct(productId);
			return "redirect:productListing.do";
		} catch (ProductException e) {
			return "exceptionPage";
		}
	}
	
	@RequestMapping(value = "/validateProductName.do")
	public @ResponseBody String validateProductName(@RequestParam(value = "name") String productName){
		try {
			if(productService.isProductValidated(productName)){
				return "Product Validated";
			}else{
				return "Product already exist";
			}
		} catch (ProductException e) {
			return "exceptionPage";
		}
	}
}
