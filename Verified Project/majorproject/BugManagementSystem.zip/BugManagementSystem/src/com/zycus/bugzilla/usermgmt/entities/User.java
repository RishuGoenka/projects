package com.zycus.bugzilla.usermgmt.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.ScriptAssert;

import com.zycus.bugzilla.rolemgmt.entities.Role;


@Entity
@Table(name="tbl_user_master")
@GenericGenerator(name="userIncr", strategy="increment")

public class User {
		
	@Id
	@GeneratedValue(generator="userIncr")
	@Column(name="user_id")
	private int userId;
	
	
	@Column(name="user_name")
	
	@Size(min=3,max=25,message="User name should be between 3 and 12 characters")
	private String userName;

	@Email
	@Column(name="email_id")
	private String emailId;
	
	@Size(min=5,max=10,message="passord should be between 6 and 10 characters")
	@Column(name="password")
	private String password;

	@ManyToMany
	@JoinTable( name="tbl_user_role", 
			joinColumns={ @JoinColumn(name="user_id",nullable=false)} , 
			inverseJoinColumns={@JoinColumn(name="role_id",nullable=false)})
	private Set<Role> roles = new HashSet<Role>();

	public Set<Role> getRoles() {
		return roles;
	}
	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}

	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String toString(){
		return "userId: "+userId+"  userName:  "+userName+" emailId "+emailId;
	}
}
