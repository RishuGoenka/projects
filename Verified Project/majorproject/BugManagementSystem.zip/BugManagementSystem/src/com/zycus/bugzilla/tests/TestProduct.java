package com.zycus.bugzilla.tests;

import org.junit.Test;

import com.zycus.bugzilla.common.daos.BaseDao;
import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.productmgmt.entities.Product;


public class TestProduct {
	
	@Test
	public void addProductWithCustomers(){
		
		BaseDao dao = new BaseDao();
		
		Customer customer = dao.get(Customer.class, 1);
		
		
		Product product = dao.get(Product.class, 1);
		System.out.println(product);
		System.out.println(product.getCustomers());
		
		//product.getCustomers().add(customer);
		
		
		
		//dao.saveOrUpdate(product);
		
	}
}
