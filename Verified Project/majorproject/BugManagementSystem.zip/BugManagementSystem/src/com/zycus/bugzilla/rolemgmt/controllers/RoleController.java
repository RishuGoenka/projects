package com.zycus.bugzilla.rolemgmt.controllers;


import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.bugzilla.common.constants.RoleConstant;
import com.zycus.bugzilla.rolemgmt.entities.Role;
import com.zycus.bugzilla.rolemgmt.exceptions.RoleException;
import com.zycus.bugzilla.rolemgmt.services.IRoleService;
import com.zycus.bugzilla.usermgmt.exceptions.UserException;
import com.zycus.bugzilla.usermgmt.services.IUserService;
/**
 * 
 * @author saurabh.dharod
 *
 */
@Controller
@SessionAttributes({"role", "loggedInUserId"})
public class RoleController {

	@Autowired
	private IRoleService roleService;

	@Autowired
	private IUserService userService;

	@RequestMapping(value="/employeeLogin.do")
	public String login(Map<String, Object> model){

		return "/rolemgmt/login";
	}
	@RequestMapping(value="/invalidLogin.do")
	public String invalidLogin(Map<String, Object> model){

		String invalid="invalid";
		model.put("invalid",invalid);
		return "/rolemgmt/login";
	}
	@RequestMapping(value="/checkCredentials.do")
	public String checkCredentials(String userName,
			String password,Map<String, Object> model) throws  UserException
	{
		try {
			Map<String, Object> objects = userService.isUserAuthenticated(userName,password);
			if(objects!=null)
			{
				String role = (String) objects.get("role");
				Integer userId = (Integer) objects.get("id");

				model.put("role",role);
				model.put("loggedInUserId", userId);

				if(RoleConstant.ADMIN.equalsIgnoreCase(role) || RoleConstant.QA.equalsIgnoreCase(role) || RoleConstant.DEVELOPER.equalsIgnoreCase(role))
					return "/rolemgmt/admin";

			}
			return "redirect:invalidLogin.do";
		} catch (Exception e) {
			return "exceptionpage";
		}

	}
	@RequestMapping(value="listAllRoles.do")
	public String  getAllRoles(Map<String ,Object> model) throws RoleException
	{

		try {
			List<Role> roleList=roleService.getAllRoles();
			model.put("roleList", roleList);
			return "/rolemgmt/roleList";
		} catch (Exception e) {
			return "exceptionpage";
		}
	}

	@RequestMapping("roleHome.do")
	public String addRole(Map<String ,Object> model)
	{

		try {
			return "/rolemgmt/addRole";
		} catch (Exception e) {
			return "exceptionpage";
		}
	}

	@RequestMapping(value="saveRole.do",method=RequestMethod.POST)
	public String save( Map<String ,Object> model,String roleName) throws RoleException
	{
		try {
			String existsrole=roleService.addNewRole(roleName);
			if(existsrole.equals("failure"))
			{
				model.put("existsrole",existsrole);
				return "/rolemgmt/addRole";
			}
			return "/rolemgmt/addRole";
		} catch (Exception e) {
			return "exceptionpage";
		}

	}



}
