package com.zycus.bugzilla.customermgmt.services;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.customermgmt.exceptions.CustomerException;
import com.zycus.bugzilla.customermgmt.interfaces.ICustomerDao;
import com.zycus.bugzilla.customermgmt.interfaces.ICustomerService;
import com.zycus.bugzilla.productmgmt.entities.Product;

/**
 * 
 * @author sankhadeep.basak
 *
 */
@Service("customerService")
@Transactional
public class CustomerService implements ICustomerService {
	private static Logger logger=Logger.getLogger(CustomerService.class.getName());

	@Autowired
	private ICustomerDao customerDao;

	@Override
	public void  addNewCustomer(Customer customer) throws CustomerException {
		try {
			customerDao.addNewCustomer(customer);
		} catch (CustomerException e) {
			logger.error("Problem in addNewCustomer method in customerService", e);
			logger.debug("Customer "+customer);
			throw new CustomerException("Problem encountered while adding a new product",e);
		}
	}

	@Override
	public void updateExistingCustomer(int custId, String custName, String emailId) throws CustomerException {
		Customer customer = new Customer();
		try{
			customer.setCustId(custId);
			customer.setCustName(custName);
			customer.setEmailId(emailId);

			customerDao.updateCustomer(customer);
		}
		catch(CustomerException e){
			logger.error("Exception encountered in updateExistingProduct method of CustomerService",e);
			logger.debug("CustomerId: "+custId);
			logger.debug("CustomerName: "+custName);
			logger.debug("EmailId: "+emailId);
			throw new CustomerException("Problem encountered while updating customer",e);
		}
	}

	@Override
	public List<Customer> getAllCustomers() throws CustomerException {
		List<Customer> customers = null;
		try {
			customers = customerDao.getAllCustomers();
			return customers;
		} catch (CustomerException e) {
			logger.error("Exception encountered in updateExistingProduct method of CustomerService",e);
			logger.debug("Customers: "+customers);
			throw new CustomerException("Problem encountered while fetching customer list from db",e);
		}
	}

	@Override
	public void assignProductsToCustomer(int customerId, List<Integer> productIds) throws CustomerException{
		Customer customer = new Customer();
		Set<Product> products = new HashSet<Product>();

		try {
			customer.setCustId(customerId);

			for(Integer productId:productIds){
				Product product = new Product();
				product.setProductId(productId);
				products.add(product);
			}

			customerDao.addProductsToCustomer(customer, products);
		} catch (CustomerException e) {
			logger.error("Exception encountered in assignProductsToCustomer method of CustomerService",e);
			logger.debug("CustomerId: "+customerId);
			logger.debug("Customer: "+customer);
			logger.debug("ProductIds: "+productIds);
			logger.debug("Product: "+products);
			throw new CustomerException("Problem encountered while assigning products to customer",e);
		}
	}

	@Override
	public void deleteCustomer(int customerId) throws CustomerException{
		Customer customer = null;
		try {
			customer = new Customer();
			customer.setCustId(customerId);
			customerDao.deleteCustomer(customer);
		} catch (CustomerException e) {
			logger.error("Exception encountered in deleteCustomer method of CustomerService",e);
			logger.debug("CustomerId: "+customerId);
			logger.debug("Customer: "+customer);
			throw new CustomerException("Problem encountered while deleting customer",e);
		}
	}

	@Override
	public List<Customer> getAllCustomersByProduct(int productId) throws CustomerException
	{
		try {
			Product product = new Product();
			product.setProductId(productId);

			return customerDao.getAllCustomersByProduct(product);
		} catch (Exception e) {
			throw new CustomerException("Problem encountered while deleting customer of CustomerService",e);
		}
	}

	@Override
	public boolean isUserValidated(String custName) throws CustomerException{

		try {
			String result = customerDao.isUserValidated(custName);
			if(result.equalsIgnoreCase("User Exist")){
				return false;
			}	
			return true;
		} catch (CustomerException e) {
			logger.error("Exception encountered in isUserValidated method of CustomerService",e);
			logger.debug("CustomerName: "+custName);
			throw new CustomerException("Problem encountered while getting user validated",e);
		}
	}

	@Override
	public boolean isUserEmailValidated(String email) throws CustomerException {
		try{
			System.out.println("In Service: "+email);
			String result = customerDao.isEmailValidated(email);
			System.out.println(result);
			if(result.equalsIgnoreCase("Email exist")){
				return false;
			}
			return true;
		}catch (CustomerException e) {
			logger.error("Exception encountered in isUserEmailValidated method of CustomerService",e);
			logger.debug("Customer Email: "+email);
			throw new CustomerException("Problem encountered while getting email validated",e);
		}
	}
}
