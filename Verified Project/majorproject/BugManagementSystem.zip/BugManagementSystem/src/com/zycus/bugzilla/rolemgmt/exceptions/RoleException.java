package com.zycus.bugzilla.rolemgmt.exceptions;

public class RoleException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -6854074943251637526L;

	

	public RoleException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public RoleException(String message) {
		super(message);
		
	}
	

}
