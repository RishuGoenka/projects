package com.zycus.bugzilla.bugmgmt.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="tbl_bug_status2")
@GenericGenerator(name="statusIncr", strategy="increment")
public class BugStatus {
	
	@Id
	@GeneratedValue(generator="statusIncr")
	@Column(name="status_id")
	private int statusId;
	
	@Column(name="status")
	private String status;
	
	@OneToMany
	private Set<Bug> bugs=new HashSet<Bug>();


	public int getStatusId() {
		return statusId;
	}
	public void setStatusId(int statusId) {
		this.statusId = statusId;
	}

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public Set<Bug> getBugs() {
		return bugs;
	}
	public void setBugs(Set<Bug> bugs) {
		this.bugs = bugs;
	}
}
