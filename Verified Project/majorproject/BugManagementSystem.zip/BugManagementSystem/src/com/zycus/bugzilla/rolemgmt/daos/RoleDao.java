package com.zycus.bugzilla.rolemgmt.daos;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.zycus.bugzilla.common.daos.BaseDao;
import com.zycus.bugzilla.rolemgmt.entities.Role;
import com.zycus.bugzilla.rolemgmt.exceptions.RoleException;
import com.zycus.bugzilla.usermgmt.entities.User;

/**
 * 
 * @author saurabh.dharod
 *
 */
@Repository

public class RoleDao  extends BaseDao implements IRoleDao {

	@Override
	public String addNewRole(Role role) throws  RoleException{
		
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Role.class);
		criteria.add(Restrictions.eq("roleName",role.getRoleName()));
		Role role1=(Role) criteria.uniqueResult();
		
		if(role1==null)		
			{
			super.save(role);
			return "success";
			}
		return "failure";
		
	}
	
	@Override
	public List<Role> getAllRoles()throws  RoleException{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Role.class);
		return criteria.list();
	}
	 
	@Override
	public Role getRoleByName(Role role) throws  RoleException{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Role.class);
		return (Role) criteria.uniqueResult();
	}
	
}


