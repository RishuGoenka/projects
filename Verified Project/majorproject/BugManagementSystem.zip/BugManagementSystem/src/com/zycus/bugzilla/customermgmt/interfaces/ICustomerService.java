package com.zycus.bugzilla.customermgmt.interfaces;

import java.util.List;

import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.customermgmt.exceptions.CustomerException;

/**
 * 
 * @author sankhadeep.basak
 *
 */
public interface ICustomerService {

	public abstract void addNewCustomer(Customer customer) throws CustomerException;

	public abstract List<Customer> getAllCustomers() throws CustomerException;

	void assignProductsToCustomer(int customerId, List<Integer> productIds) throws CustomerException;

	void deleteCustomer(int customerId) throws CustomerException;

	public abstract void updateExistingCustomer(int custId, String custName,
			String email) throws CustomerException;

	public abstract List<Customer> getAllCustomersByProduct(int prodId) throws CustomerException;

	boolean isUserValidated(String custName) throws CustomerException;

	public boolean isUserEmailValidated(String email) throws CustomerException;

}