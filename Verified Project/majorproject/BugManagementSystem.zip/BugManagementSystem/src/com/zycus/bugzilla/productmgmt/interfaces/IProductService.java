package com.zycus.bugzilla.productmgmt.interfaces;

import java.util.List;

import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.productmgmt.exceptions.ProductException;
/**
 * 
 * @author sankhadeep.basak
 *
 */
public interface IProductService {
	
	public void addNewProduct(Product product) throws ProductException;

	void updateExistingProduct(int productId, String productName) throws ProductException;
	
	List<Product> getAllProducts() throws ProductException;

	void deleteProduct(int productId) throws ProductException;

	List<Customer> getAllCustomersNotAssignedToProduct(int productId) throws ProductException;

	void assignCustomesToProduct(int productId, int customerIds)
			throws ProductException;

	boolean isProductValidated(String productName) throws ProductException;

	
}
