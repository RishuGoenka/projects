package com.zycus.bugzilla.productmgmt.services;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.customermgmt.exceptions.CustomerException;
import com.zycus.bugzilla.customermgmt.interfaces.ICustomerDao;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.productmgmt.exceptions.ProductException;
import com.zycus.bugzilla.productmgmt.interfaces.IProductDao;
import com.zycus.bugzilla.productmgmt.interfaces.IProductService;

/**
 * 
 * @author sankhadeep.basak
 *
 */
@Service("productService")
@Transactional
public class ProductService implements IProductService {

	private static Logger logger=Logger.getLogger(ProductService.class.getName());
	
	@Autowired
	private IProductDao  productDao;
	
	@Autowired
	private ICustomerDao customerDao;
	
	@Override
	public void addNewProduct(Product product) throws ProductException {
		 try {
			productDao.addNewProduct(product);
		} catch (ProductException e) {
			logger.error("Exception encountered in addnewProduct method of ProductService ",e);
			logger.debug("Product "+product);
			throw new ProductException("Problem encountered while adding a new product",e);
		}
	}

	@Override
	public void updateExistingProduct(int productId, String productName) throws ProductException {
		Product product = null;
		try{
			product = new Product();
			product.setProductId(productId);
			product.setProductName(productName);
			productDao.updateProduct(product);
		}
		catch (ProductException e) {
			logger.error("Exception encountered in updateExistingProduct method of ProductService ",e);
			logger.debug("ProductId: "+productId);
			logger.debug("ProductName: "+productName);
			logger.debug("Product "+product);
			throw new ProductException("Problem encountered while updating a new product",e);
		}
		
	}

	@Override
	public List<Product> getAllProducts() throws ProductException {
		List<Product> products = null;
		try {
			products = productDao.getAllProducts();
			return products;
		} catch (ProductException e) {
			logger.error("Exception encountered in getAllProducts method of ProductService ",e);
			logger.debug("Products: "+products);
			throw new ProductException("Problem encountered while fetching all products from db",e);
		}
	}

	@Override
	public void assignCustomesToProduct(int productId, int customerId) throws ProductException {
		Product product = null;
		Customer customer = null;
		try{
			product = new Product();
			product.setProductId(productId);
			System.out.println("Customer Id: "+customerId);
			customer = new Customer();
			customer.setCustId(customerId);
			productDao.addCustomersToProduct(product, customer);
		}
		catch(ProductException e){
			logger.error("Exception encountered in assignCustomesToProduct method of ProductService ",e);
			logger.debug("ProductId: "+productId);
			logger.debug("customerId: "+customerId);
			logger.debug("Product: "+product);
			logger.debug("Customers: "+customer);
			throw new ProductException("Problem encountered while adding customers to product",e);
			
		}
	}

	@Override
	public void deleteProduct(int productId) throws ProductException {
		Product product = null;
		
		try {
			product = new Product();
			product.setProductId(productId);
			productDao.deleteProduct(product);
		} catch (ProductException e) {
			logger.error("Exception encountered in deleteProduct method of ProductService ",e);
			logger.debug("ProductId: "+productId);
			throw new ProductException("Problem encountered while deleting product",e);
		}
	}

	@Override
	public List<Customer> getAllCustomersNotAssignedToProduct(int productId) throws ProductException{
		Product product = new Product();
		List<Customer> assignedCustomers = null;
		List<Customer> allCustomers = null;
		List<Customer> unassignedCustomers = null;

		try {
			System.out.println(productId);
			product.setProductId(productId);
			assignedCustomers = customerDao.getAllCustomersByProduct(product);
			allCustomers = customerDao.getAllCustomers();
			unassignedCustomers = new ArrayList<Customer>();
			
			
			for(Customer all:allCustomers){
				boolean flag = false;
				for(Customer assigned:assignedCustomers){
					if(all.getCustId() == assigned.getCustId()){
						flag = true;
					}
				}
				if(!flag)
					unassignedCustomers.add(all);
			}
			
			return unassignedCustomers;
		} catch (CustomerException e) {
			logger.error("Exception encountered in deleteProduct method of ProductService ",e);
			logger.debug("ProductId: "+productId);
			logger.debug("Product: "+product);
			logger.debug("All Customer: "+allCustomers);
			logger.debug("Assigned: "+assignedCustomers);
			logger.debug("Unassigned: "+unassignedCustomers);
			throw new ProductException("Problem encountered while getting all unassigned customers",e);
		}
	}
	
	@Override
	public boolean isProductValidated(String productName) throws ProductException{

		try {
			String result = productDao.isProductValidated(productName);
			if(result.equalsIgnoreCase("Product Exist")){
				return false;
			}	
			return true;
		} catch (ProductException e) {
			logger.error("Exception encountered in isProductValidated method of ProductService",e);
			logger.debug("Product Name: "+productName);
			throw new ProductException("Problem encountered while getting product validated",e);
		}
	}
}
