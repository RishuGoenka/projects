package com.zycus.bugzilla.bugmgmt.views;




	import java.util.Date;
import java.util.List;
	import java.util.Map;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	import org.apache.poi.hssf.usermodel.HSSFRow;
	import org.apache.poi.hssf.usermodel.HSSFSheet;
	import org.apache.poi.hssf.usermodel.HSSFWorkbook;
	import org.springframework.web.servlet.view.document.AbstractExcelView;
import com.zycus.bugzilla.bugmgmt.entities.Bug;

	public class BugReportView extends AbstractExcelView{
		
		@Override
		protected void buildExcelDocument(Map<String,Object> model, HSSFWorkbook workbook,
				HttpServletRequest request, HttpServletResponse response)
				throws Exception {
			
			
			List<Bug> bugData =  (List<Bug>) model.get("bugData");
			//create a wordsheet
			HSSFSheet sheet = workbook.createSheet("Revenue Report");
			
			HSSFRow header = sheet.createRow(0);
			header.createCell(0).setCellValue("BugId");
			header.createCell(1).setCellValue("Summary");
			header.createCell(2).setCellValue("RCA");
			header.createCell(3).setCellValue("Status");
			header.createCell(4).setCellValue("Severity");
			header.createCell(5).setCellValue("BugType");
			header.createCell(6).setCellValue("injectedBy");
			header.createCell(7).setCellValue("impactArea");
			header.createCell(8).setCellValue("missedBy");
			header.createCell(9).setCellValue("Customer");
			header.createCell(10).setCellValue("createdDate");
			header.createCell(11).setCellValue("modifiedDate");
			
			
			
			int rowNum = 1;
			if(bugData!=null)
			for (Bug entry : bugData) {
				//create the row data
				HSSFRow row = sheet.createRow(rowNum++);
				row.createCell(0).setCellValue(entry.getBugId());
				row.createCell(1).setCellValue(entry.getSummary());
				row.createCell(2).setCellValue(entry.getRCA());
				
				if(entry.getBugStatus()!=null)
				row.createCell(3).setCellValue(entry.getBugStatus().getStatus());
				
				if(entry.getBugSeverity()!=null)
				row.createCell(4).setCellValue(entry.getBugSeverity().getSeverityMessage());
				
				if(entry.getType()!=null)
				row.createCell(5).setCellValue(entry.getType().getType());
				
				if(entry.getInjectedBy()!=null)
				row.createCell(6).setCellValue(entry.getInjectedBy().getUserName());
				
				row.createCell(7).setCellValue(entry.getImpactArea());
				
				if(entry.getMissedBy()!=null)
				row.createCell(8).setCellValue(entry.getMissedBy().getUserName());
				
				if(entry.getCustomer()!=null)
				row.createCell(9).setCellValue(entry.getCustomer().getCustName());				
				
				if(entry.getCreatedDate().toString()!=null)
				row.createCell(10).setCellValue(entry.getCreatedDate().toString());
				
				if(entry.getModifiedDate()!=null)
				row.createCell(11).setCellValue(entry.getModifiedDate().toString());
	
				response.setContentType("application/vnd.ms-excel");
				
	        }
		}	
}
