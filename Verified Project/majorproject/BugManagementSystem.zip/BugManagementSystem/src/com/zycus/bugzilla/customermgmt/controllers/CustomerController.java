package com.zycus.bugzilla.customermgmt.controllers;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.customermgmt.exceptions.CustomerException;
import com.zycus.bugzilla.customermgmt.interfaces.ICustomerService;

/**
 * 
 * @author sankhadeep.basak
 *
 */
@Controller
public class CustomerController {
	
	@Autowired
	private ICustomerService customerService;
	
	@RequestMapping(value="/customerHome.do")
	public String showCustomerHomepage(Map<String, Object> model){
		List<Customer> customers = null;
		
		try {
			customers = customerService.getAllCustomers();
			model.put("listOfCustomers", customers);//it is retained in request
		
			return "viewCustomers";
		} catch (CustomerException e) {
			return "exceptionPage"; 
		}
	}
	
	@RequestMapping(value="addCustomer.do")
	public String addCustomer(Map<String,Object> model){
		model.put("customer", new Customer());
		return "addCustomer";
	}
	
	@RequestMapping(value="/saveCustomer.do",method=RequestMethod.POST)
	public String saveCustomer(@Valid @ModelAttribute("customer") Customer customer, BindingResult result){
		if(result.hasErrors()){
			return "addCustomer";
		}else{
			try {
				customerService.addNewCustomer(customer);
				return "redirect:customerListing.do";
			} catch (CustomerException e) {
				return "exceptionPage"; 
			}
		}
	}
	
	@RequestMapping(value="/customerListing.do")
	public String listOfCustomers(
			@RequestParam(value="view", required=false) String view,
			@RequestParam(value="viewType", required=false) String viewType,
			Map<String,Object> model){
		List<Customer> customers = null;
		
		try {
			customers = customerService.getAllCustomers();
			model.put("listOfCustomers", customers);
			return "viewCustomers";
		} catch (CustomerException e) {
			return "exceptionPage"; 
		}
	}
	
	@RequestMapping(value = "/editCustomer.do")
	public String editCustomer(Map<String,Object> model){
		List<Customer> custList = null;
		
		try {
			custList = customerService.getAllCustomers();
			model.put("custList", custList);
			return "editCustomer";
		} catch (CustomerException e) {
			return "exceptionPage"; 
		}
	}
	
	@RequestMapping(value = "/editCustomerSuccessfully.do")
	public String ediCustomerSuccessfully(
			@RequestParam(value = "customer") int custId,
			@RequestParam(value = "changedName") String custName,
			@RequestParam(value = "changedEmail") String email,
			Map<String,Object> model){
		
		try {
			customerService.updateExistingCustomer(custId,custName,email);
			return "redirect:customerListing.do";
		} catch (CustomerException e) {
			return "exceptionPage"; 
		}
	}
	
	@RequestMapping("listAllCustomersOfProduct.do")
	public String getAllProducts(int prodId, Map<String, Object> model) throws CustomerException
	{
		List<Customer> custList =  customerService.getAllCustomersByProduct(prodId);
		model.put("custList", custList);
		return "populateCustomerList";
	}
	
	@RequestMapping(value = "/deleteCustomer.do")
	public String deleteCustomer(Map<String,Object> model){
		List<Customer> customers = null;
		
		try {
			customers = customerService.getAllCustomers();
			model.put("listOfCustomers",customers);
			return "deleteCustomer";
		} catch (CustomerException e) {
			return "exceptionPage"; 
		}
	}
	
	@RequestMapping(value = "/deleteCustomerSuccessfully.do")
	public String deleteCustomerSuccessfully(
			@RequestParam(value = "customer", required = true) int customerId,
			Map<String,Object> model){
		try {
			customerService.deleteCustomer(customerId);
			return "redirect:customerListing.do";
		} catch (CustomerException e) {
			return "exceptionPage";
		}
	}
	
	@RequestMapping(value = "/validateCustomerName.do")
	public @ResponseBody String validateCustomerName(@RequestParam(value = "name") String name){
		try {
			if(customerService.isUserValidated(name)){
				return "User Validated";
			}
			else{
				return "User Already Exist";
			}
		} catch (CustomerException e) {
			return "exceptionPage";
		}
	}
	
	@RequestMapping(value = "/validateCustomerEmail.do")
	public @ResponseBody String validateCustomerEmail(@RequestParam(value = "email") String email){
		try {
			if(customerService.isUserEmailValidated(email)){
				return "Email Validated";
			}
			else{
				return "Email already exist";
			}
		} catch (CustomerException e) {
			return "exceptionPage";
		}
	}
	
}
