package com.zycus.bugzilla.rolemgmt.services;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.bugzilla.rolemgmt.daos.IRoleDao;
import com.zycus.bugzilla.rolemgmt.entities.Role;
import com.zycus.bugzilla.rolemgmt.exceptions.RoleException;
import com.zycus.bugzilla.usermgmt.entities.User;

@Service
@Transactional
public class RoleService implements IRoleService{

	private static Logger logger=Logger.getLogger(RoleService.class.getName());
	
	@Autowired
	private IRoleDao roleDao;
		
	@Override
	public List<Role> getAllRoles() throws RoleException{
		
		try {
			return roleDao.getAllRoles();
		} catch (RoleException e) {
			
			logger.debug(" roles "+roleDao.getAllRoles().get(0));
			logger.error("Problem encountered getting all roles", e);
			throw new RoleException("Problem occured in getting all roles",e);
		}
		
		
	}

	@Override
	public String addNewRole(String  roleName) throws RoleException {
		try {
			Role role=new Role();
			role.setRoleName(roleName);
			return roleDao.addNewRole(role);
		} catch (RoleException e) {
			
			logger.debug(" roleName "+roleName);
			logger.error("Problem encountered adding new role", e);
			throw new RoleException("Problem occured in adding new role",e);
		}		
	}
	
	
	
	
}
