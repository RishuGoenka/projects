package com.zycus.bugzilla.bugmgmt.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


/**
 * 
 * @author owais.iqbal
 *
 */
@Entity
@Table(name="tbl_bug_comment")
@GenericGenerator(name="commentIncr", strategy="increment")
public class Comment {
	
	@Id
	@GeneratedValue(generator="commentIncr")
	@Column(name="comment_id")
	private int commentId;
	
	@Column(name="message")
	private String message;
	
	@ManyToOne
	@JoinColumn(name="bug_id")
	private Bug bug;

	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Bug getBug() {
		return bug;
	}

	public void setBug(Bug bug) {
		this.bug = bug;
	}
	
}
