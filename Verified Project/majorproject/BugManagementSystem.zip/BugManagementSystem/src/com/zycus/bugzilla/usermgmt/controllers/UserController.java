package com.zycus.bugzilla.usermgmt.controllers;


import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import com.zycus.bugzilla.usermgmt.entities.User;
import com.zycus.bugzilla.usermgmt.exceptions.UserException;
import com.zycus.bugzilla.usermgmt.services.IUserService;

/**
 * 
 * @author saurabh.dharod
 *
 */
@Controller
@SessionAttributes({"role", "loggedInUserId"})
public class UserController {

	@Autowired
	private IUserService userService;


	@RequestMapping(value="welcome.do")
	public String getWelcomePage(Map<String ,Object> model) throws UserException{

		try
		{
			return "/rolemgmt/admin";
		}
		catch(Exception e){
			return "excetionpage";
		}
	}

	@RequestMapping(value="userHome.do")
	public String viewUserHome(Map<String ,Object> model) throws UserException{
		
		try {
			model.put("user",new User());

			List<User> userList=userService.getAllUsers();
			model.put("userList", userList);
			return "/usermgmt/user";
		} catch (Exception e) {
			return "exceptionPage";
		}
		
	}


	@RequestMapping(value="addUser.do",method=RequestMethod.POST)
	public String addUser(Map<String ,Object> model,@ModelAttribute("user")User user){
		try {

			return "/usermgmt/addUser";
		} catch (Exception e) {
			return "exceptionPage";
		}
	}

	@RequestMapping(value="saveUser.do",method=RequestMethod.POST)
	public String save(Map<String ,Object> model,@RequestParam(value="role") int roleId,
			@Valid @ModelAttribute("user")User user,
			BindingResult result) throws UserException{
		try {
			if(result.hasErrors())
				return "/usermgmt/addUser";
			else
			{
				String exists=userService.addUser(user,roleId);
					if(exists.equals("failure"))
					{
						model.put("exists",exists);
						return "/usermgmt/addUser";
					}
				return "/usermgmt/user";

			}
		} catch (Exception e) {
			return "exceptionPage";
		}		
	}

	

	@RequestMapping(value="editUser.do")
	public String editUser(int userId,Map<String ,Object> model) throws UserException{
		try {
			User user=userService.getUserById(userId);
			model.put("userdata", user); 
			return "/usermgmt/editUser";
		} catch (Exception e) {
			return "exceptionPage";
		}
	}

	@RequestMapping(value="updateUser.do")
	public String updateUserDetails(@Valid @ModelAttribute("userdata")User user,BindingResult result) throws UserException{
		try {
			if(result.hasErrors())
				return "/usermgmt/editUser";
			else
			{
				System.out.println(user.getRoles());
				userService.editUser(user);
				return "redirect:userHome.do";
			}
		} catch (Exception e) {
			return "exceptionPage";
		}		
	}

	@RequestMapping(value="deleteUser.do")
	public String add(int userId,Map<String ,Object> model) throws Exception{
		try {
			userService.deleteUser(userId);
			return "redirect:userHome.do";
		} catch (Exception e) {
			throw  new Exception(e);
		}
	}


	@RequestMapping(value="listAllUsers.do")
	public  String getAllUsers(
			Map<String ,Object> model) throws UserException{

		try {
			List<User> userList=userService.getAllUsers();
			model.put("userList", userList);
			return "/usermgmt/userList";
		} catch (Exception e) {
			return "exceptionPage";
		}
	}
	@RequestMapping(value="listAllDevelopers.do")
	public String getDevelopers(Map<String ,Object> model) throws UserException
	{
		try {
			List<User> devList = userService.getDevelopers();
			model.put("devList", devList);
			return "/common/populateDeveloperList";
		} catch (Exception e) {
			return "exceptionPage";
		}
	}

	@RequestMapping(value="listAllQAs.do")
	public String getQAs(Map<String ,Object> model) throws UserException
	{
		try {
			List<User> qaList = userService.getQAs();
			model.put("qaList", qaList);
			return "/common/populateQAList";
		} catch (Exception e) {
			return "exceptionPage";
		}
	}

	@RequestMapping(value="logout.do")
	public String logout(HttpServletRequest request,Map<String ,Object> model)
	{
		HttpSession session=null;
		try {
			model.put("loggedInUserId",0);			
			session=request.getSession(false);
			session.invalidate();
			session.removeAttribute("role");
			session.removeAttribute("loggedInUserId");
			return "/rolemgmt/login";
		} catch (Exception e) {
			return "/rolemgmt/login";
		}
	}

}
