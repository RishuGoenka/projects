package com.zycus.bugzilla.bugmgmt.services;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zycus.bugzilla.bugmgmt.entities.Bug;
import com.zycus.bugzilla.bugmgmt.entities.BugSeverity;
import com.zycus.bugzilla.bugmgmt.entities.BugStatus;
import com.zycus.bugzilla.bugmgmt.entities.BugType;
import com.zycus.bugzilla.bugmgmt.entities.QualityAspect;
import com.zycus.bugzilla.bugmgmt.exceptions.BugException;
import com.zycus.bugzilla.bugmgmt.interfaces.IBugDao;
import com.zycus.bugzilla.bugmgmt.interfaces.IBugService;
import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.productmgmt.exceptions.ProductException;
import com.zycus.bugzilla.productmgmt.interfaces.IProductService;
import com.zycus.bugzilla.usermgmt.entities.User;

@Service
public class BugService implements IBugService
{
	@Autowired
	private IBugDao bugDao;
	
	@Autowired
	private IProductService productService;
	
	private Logger logger = Logger.getLogger(this.getClass().getName());
	
	@Override
	public void addBug(String summary, String RCA, String impactArea,
			Integer[] aspectIds, int severityId, int typeId,
			int productId, 
			int assigneeId, int reporteeId) throws BugException 
	{
		Bug bug = new Bug();
		
		bug.setSummary(summary);
		bug.setRCA(RCA);
		bug.setImpactArea(impactArea);
		
		BugStatus bugStatus = new BugStatus();
		bugStatus.setStatusId(1);
		bug.setBugStatus(bugStatus);
		
		System.out.println("before problem");
		Set<QualityAspect> aspectSet = new HashSet<QualityAspect>();
		for(int i=0; i<aspectIds.length; i++)
		{
			QualityAspect aspect = new QualityAspect();
			aspect.setQualityAspectId(aspectIds[i]);
			aspectSet.add(aspect);
		}
		bug.setQualityAspects(aspectSet);
		System.out.println("after problem");
		
		BugSeverity severity = new BugSeverity();
		severity.setSeverityId(severityId);
		bug.setBugSeverity(severity);
		
		BugType type = new BugType();
		type.setTypeId(typeId);
		bug.setType(type);
		
		Product product = new Product();
		product.setProductId(productId);
		bug.setProduct(product);
		
		User assignee = new User();
		assignee.setUserId(assigneeId);
		bug.setInjectedBy(assignee);
		
		User reportee = new User();
		reportee.setUserId(reporteeId);
		bug.setReportee(reportee);
		
		Calendar cal = Calendar.getInstance();
		bug.setCreatedDate(cal.getTime());
		
		
		try {
			bugDao.addBug(bug);
		} catch (BugException e) {
			logger.debug("Bug "+bug);
			logger.error("Problem with adding a bug", e);
			throw new BugException("Problem encountered while adding bug",e);
		}
	}
	
	@Override
	public void addBug(String summary, String RCA, String impactArea,
			Integer[] aspectIds, int severityId, int typeId,
			int productId, 
			int assigneeId, int reporteeId, 
			int missedById, int customerId) throws BugException 
	{
		Bug bug = new Bug();
		
		bug.setSummary(summary);
		bug.setRCA(RCA);
		bug.setImpactArea(impactArea);
		
		BugStatus bugStatus = new BugStatus();
		bugStatus.setStatusId(1);
		bug.setBugStatus(bugStatus);
		
		System.out.println("before problem");
		Set<QualityAspect> aspectSet = new HashSet<QualityAspect>();
		for(int i=0; i<aspectIds.length; i++)
		{
			QualityAspect aspect = new QualityAspect();
			aspect.setQualityAspectId(aspectIds[i]);
			aspectSet.add(aspect);
		}
		bug.setQualityAspects(aspectSet);
		System.out.println("after problem");
		
		BugSeverity severity = new BugSeverity();
		severity.setSeverityId(severityId);
		bug.setBugSeverity(severity);
		
		BugType type = new BugType();
		type.setTypeId(typeId);
		bug.setType(type);
		
		Product product = new Product();
		product.setProductId(productId);
		bug.setProduct(product);
		
		User assignee = new User();
		assignee.setUserId(assigneeId);
		bug.setInjectedBy(assignee);
		
		User reportee = new User();
		reportee.setUserId(reporteeId);
		bug.setReportee(reportee);
		
		Calendar cal = Calendar.getInstance();
		bug.setCreatedDate(cal.getTime());
		
		if(typeId==2)
		{
			User missedBy = new User();
			missedBy.setUserId(missedById);
			bug.setMissedBy(missedBy);
			
			Customer customer = new Customer();
			customer.setCustId(customerId);
			bug.setCustomer(customer);
		}
		
		try {
			bugDao.addBug(bug);
		} catch (BugException e) {
			logger.debug("Bug "+bug);
			logger.error("Problem with adding a bug", e);
			throw new BugException("Problem encountered while adding bug",e);		
			}
	}

	@Override
	public List<BugSeverity> getSeverityList() throws BugException 
	{
		try {
			return bugDao.getSeverityList();
		} catch (BugException e) {
			logger.error("Problem encountered while getting severity list", e);
			throw new BugException("Problem encountered while getting severity list",e);
		}
	}
	
	@Override
	public List<QualityAspect> getQualityAspectList() throws BugException
	{
		try {
			return bugDao.getQualityAspectList();
		} catch (BugException e) {
			logger.error("Problem encountered while getting quality aspect list", e);
			throw new BugException("Problem encountered while getting quality aspect list",e);
		}
	}

	@Override
	public List<BugType> getBugTypes() throws BugException 
	{
		try {
			return bugDao.getBugTypes();
		} catch (BugException e) {
			logger.error("Problem encountered while getting bug types", e);
			throw new BugException("Problem encountered while getting bug types",e);		
		}
	}
	
	@Override
	public void changeStatus(int bugId, int bugStatusId) throws BugException
	{
		Bug bug = null;
		try {
			bug = bugDao.getBug(bugId);
			Calendar cal = Calendar.getInstance();
			Date modDate = cal.getTime();
			bug.setModifiedDate(modDate);
			
			BugStatus status = new BugStatus();
			status.setStatusId(bugStatusId);
			
			bugDao.changeStatus(bug, status);
		} catch (BugException e) {
			logger.debug("Bug "+bug);
			logger.debug("bugStatusId: "+bugStatusId);
			logger.error("Problem encountered while changing status", e);
			throw new BugException("Problem encountered while changing status",e);
		}
	}
	
	@Override
	public Bug getBug(int bugId) throws BugException
	{
		try {
			return bugDao.getBug(bugId);
		} catch (BugException e) {
			logger.debug("bugId "+bugId);
			logger.error("Problem encountered while getting a bug", e);
			throw new BugException("Problem encountered while getting a bug",e);
		}
	}

	@Override
	public List<Bug> getAllBugs() throws BugException 
	{
		try {
			return bugDao.getAllBugs();
		} catch (BugException e) {
			logger.error("Problem encountered while getting all bugs", e);
			throw new BugException("Problem encountered while getting all bugs",e);
		}
	}
	
	
	
	@Override
	public List<Bug> getAllBugs(int offset, int rows) throws BugException 
	{
		try {
			return bugDao.getAllBugs(offset, rows);
		} catch (BugException e) {
			logger.error("Problem encountered while getting all bugs", e);
			throw new BugException("Problem encountered while getting all bugs",e);
		}
	}
	
	@Override
	public List<BugStatus> getStatusList() throws BugException
	{
		try {
			return bugDao.getStatusList();
		} catch (BugException e) {
			logger.error("Problem encountered while getting status list", e);
			throw new BugException("Problem encountered while getting status list",e);
		}
	}
	
	@Override
	public List<BugStatus> getStatusByRole(String role) throws BugException
	{
		List<BugStatus> statusList;
		try {
			statusList = bugDao.getStatusList();
		} catch (BugException e) {
			logger.error("Problem encountered while getting status list", e);
			throw new BugException("Problem encountered while getting status list",e);
		}
		
		List<BugStatus> respectiveStatusList = new ArrayList<BugStatus>();
		
		if(role.equalsIgnoreCase("QA") || role.equalsIgnoreCase("Admin"))
			for(BugStatus status:statusList)
			{
				if(status.getStatus().equalsIgnoreCase("Reopened") || status.getStatus().equalsIgnoreCase("Closed"))
					respectiveStatusList.add(status);
			}
		else if(role.equalsIgnoreCase("Developer"))
			for(BugStatus status:statusList)
			{
				if(status.getStatus().equalsIgnoreCase("Resolved"))
					respectiveStatusList.add(status);
			}
		
		return respectiveStatusList;
	}
	
	@Override
	public List<Bug> listoutBugsByProducts(int productId) throws BugException{
		
		Product product = new Product();
		//product.setProductId(productId);
		product.setProductId(productId);
		
		List<Bug> bugList;
		try {
			bugList = bugDao.listoutBugsByProducts(product);
		} catch (BugException e) {
			logger.debug("ProductID "+productId);
			logger.error("Problem with listing bugs by product", e);
			throw new BugException("Problem with listing bugs by product",e);
		}
		
		return bugList;
	}
	
	@Override
	public List<Bug> listoutBugsByProducts(int productId, int offset, int rows) throws BugException{
		
		System.out.println("offset "+offset+"rows "+rows);
		Product product = new Product();
		//product.setProductId(productId);
		product.setProductId(productId);
		
		List<Bug> bugList = null;
		try {
			bugList = bugDao.listoutBugsByProducts(product, offset, rows);
		} catch (BugException e) {
			logger.debug("ProductID "+productId);
			logger.error("Problem with listing bugs by product", e);
			throw new BugException("Problem with listing bugs by product",e);
		}
		
		return bugList;
	}
	
	@Override
	public List<Bug> listoutBugsBySeverity(int severityId) throws BugException{
		
		BugSeverity bugSeverity = new BugSeverity();
		bugSeverity.setSeverityId(severityId);
		
		List<Bug> bugList;
		try {
			bugList = bugDao.listoutBugsBySeverity(bugSeverity);
		} catch (BugException e) {
			logger.debug("SeverityID "+severityId);
			logger.error("Problem with listing bugs by severity", e);
			throw new BugException("Problem with listing bugs by severity",e);		
			}
		
		return bugList;
	}
	
	
	@Override
	public List<Bug> listoutBugsBySeverity(int severityId, int offset, int rows) throws BugException{
		
		BugSeverity bugSeverity = new BugSeverity();
		bugSeverity.setSeverityId(severityId);
		
		List<Bug> bugList;
		try {
			bugList = bugDao.listoutBugsBySeverity(bugSeverity, offset, rows);
		} catch (BugException e) {
			logger.debug("SeverityID "+severityId);
			logger.error("Problem with listing bugs by severity", e);
			throw new BugException("Problem with listing bugs by severity",e);
		}
		
		return bugList;
	}
	
	@Override
	public List<Bug> listoutBugsByQualityAspects(int qualityAspectId) throws BugException{
		
		QualityAspect qualityAspect = new QualityAspect();
		qualityAspect.setQualityAspectId(qualityAspectId);
		
		List<Bug> bugList;
		try {
			bugList = bugDao.listoutBugsByQualityAspect(qualityAspect);
		} catch (BugException e) {
			logger.debug("QualityAspectID"+qualityAspectId);
			logger.error("Problem with listing bugs by aspect", e);
			throw new BugException("Problem with listing bugs by aspect",e);
		}
		
		return bugList;
	}
	
	
	@Override
	public List<Bug> listoutBugsByQualityAspects(int qualityAspectId, int offset, int rows) throws BugException{
		
		QualityAspect qualityAspect = new QualityAspect();
		qualityAspect.setQualityAspectId(qualityAspectId);
		
		List<Bug> bugList;
		try {
			bugList = bugDao.listoutBugsByQualityAspect(qualityAspect, offset, rows);
		} catch (BugException e) {
			logger.debug("QualityAspectID"+qualityAspectId);
			logger.error("Problem with listing bugs by aspect", e);
			throw new BugException("Problem with listing bugs by aspect",e);
		}
		
		return bugList;
	}
	
	@Override
	public List<Bug> listoutBugsByStatus(int bugStatusId) throws BugException{
		
		BugStatus bugStatus = new BugStatus();
		bugStatus.setStatusId(bugStatusId);
		
		List<Bug> bugList;
		try {
			bugList = bugDao.listoutBugsByStatus(bugStatus);
		} catch (BugException e) {
			logger.debug("StatusID"+bugStatusId);
			logger.error("Problem with listing bugs by status", e);
			throw new BugException("Problem with listing bugs by status",e);
		}
		
		return bugList;
	}
	
	@Override
	public List<Bug> listoutBugsByStatus(int bugStatusId, int offset, int rows) throws BugException{
		
		BugStatus bugStatus = new BugStatus();
		bugStatus.setStatusId(bugStatusId);
		
		List<Bug> bugList;
		try {
			bugList = bugDao.listoutBugsByStatus(bugStatus, offset, rows);
		} catch (BugException e) {
			logger.debug("StatusID"+bugStatusId);
			logger.error("Problem with listing bugs by status", e);
			throw new BugException("Problem with listing bugs by status",e);
		}
		
		return bugList;
	}
	
	@Override
	public List<Bug> listoutBugsByDate(Date bugDate, String spec) throws BugException{
		
		List<Bug> bugList;
		try {
			bugList = bugDao.listoutBugsByDate(bugDate, spec);
		} catch (BugException e) {
			logger.debug("bugDate "+bugDate);
			logger.debug("spec "+spec);
			logger.error("Problem with listing bugs by date", e);
			throw new BugException("Problem with listing bugs by date",e);
		}
		
		return bugList;
	}
	
	@Override
	public List<Bug> listoutBugsByDate(Date bugDate, String spec, Product product) throws BugException{
		
		List<Bug> bugList;
		try {
			bugList = bugDao.listoutBugsByDate(bugDate, spec, product);
		} catch (BugException e) {
			logger.debug("bugDate "+bugDate);
			logger.debug("spec "+spec);
			logger.debug("product "+product);
			logger.error("Problem with listing bugs by date", e);
			throw new BugException("Problem with listing bugs by date",e);
		}
		
		return bugList;
	}
	
	@Override
	public List<Bug> listoutBugsByDate(Date bugDate, String spec, int offset, int rows) throws BugException{
		
		List<Bug> bugList;
		try {
			bugList = bugDao.listoutBugsByDate(bugDate, spec, offset, rows);
		} catch (BugException e) {
			logger.debug("bugDate "+bugDate);
			logger.debug("spec "+spec);
			logger.error("Problem with listing bugs by date", e);
			throw new BugException("Problem with listing bugs by date",e);
		}
		
		return bugList;
	}
	
	@Override
	public List<Bug> listoutBugsByAssignee(int userId) throws BugException{
		User user=new User();
		user.setUserId(userId);
		try {
			return bugDao.listoutBugsByAssignee(user);
		} catch (BugException e) {
			logger.debug("userId "+userId);
			logger.error("Problem with listing bugs by assignee", e);
			throw new BugException("Problem with listing bugs by assignee",e);
		}
	}
	
	@Override
	public List<Bug> listoutBugsByAssignee(int userId, int offset, int rows) throws BugException{
		User user=new User();
		user.setUserId(userId);
		try {
			return bugDao.listoutBugsByAssignee(user, offset, rows);
		} catch (BugException e) {
			logger.debug("userId "+userId);
			logger.error("Problem with listing bugs by assignee", e);
			throw new BugException("Problem with listing bugs by assignee",e);
		}
	}
	
	@Override
	public List<Bug> listoutBugsByReportee(int userId) throws BugException{
		User user=new User();
		user.setUserId(userId);
		try {
			return bugDao.listoutBugsByReportee(user);
		} catch (BugException e) {
			logger.debug("userId "+userId);
			logger.error("Problem with listing bugs by reportee", e);
			throw new BugException("Problem with listing bugs by reportee",e);
		}
	}
	
	@Override
	public List<Bug> listoutBugsByReportee(int userId, int offset, int rows) throws BugException{
		User user=new User();
		user.setUserId(userId);
		try {
			return bugDao.listoutBugsByReportee(user, offset, rows);
		} catch (Exception e) {
			logger.debug("userId "+userId);
			logger.error("Problem with listing bugs by reportee", e);
			throw new BugException("Problem with listing bugs by reportee",e);
		}
	}

	@Override
	public List<Product> viewProductBugStatus() throws BugException 
	{
		List<Product> prodList;
		try {
			prodList = productService.getAllProducts();
		} catch (ProductException e1) {
			logger.error("Problem with viewing product bug status", e1);
			throw new BugException("Problem with viewing product bug status",e1);
		}
		
		try {
			for(Product product:prodList)
			{	
				//---BUG INDEX---
				int noOfBlockers=0, noOfCriticals=0, noOfMajors=0, noOfMinors=0;
				List<Bug> bugList = listoutBugsByProducts(product.getProductId());
				for(Bug bug:bugList)
				{
					if(bug.getBugSeverity().getSeverityMessage().equalsIgnoreCase("Blocker"))
						noOfBlockers++;
					if(bug.getBugSeverity().getSeverityMessage().equalsIgnoreCase("Critical"))
						noOfCriticals++;
					if(bug.getBugSeverity().getSeverityMessage().equalsIgnoreCase("Major"))
						noOfMajors++;
					if(bug.getBugSeverity().getSeverityMessage().equalsIgnoreCase("Minor"))
						noOfMinors++;
				}
				double bugIndex = (noOfBlockers*8)+(noOfCriticals*4)+(noOfMajors*2)+(noOfMinors*1); 
				product.setBugIndex(bugIndex);
				
				
				//---KILL RATE---
				Calendar cal = Calendar.getInstance();
				Date bugDate = cal.getTime();
				int noOfOpen=0, noOfClosed=0;
				
				List<Bug> createdBugList = listoutBugsByDate(bugDate, "created", product);
				for(Bug bug:createdBugList)
				{
					
					if(bug.getBugStatus().getStatus().equalsIgnoreCase("Open") || bug.getBugStatus().getStatus().equalsIgnoreCase("Reopened"))
						noOfOpen++;
				}
				
				List<Bug> modifiedBugList = listoutBugsByDate(bugDate, "modified", product);
				for(Bug bug:modifiedBugList)
				{
					if(bug.getBugStatus().getStatus().equalsIgnoreCase("Closed"))
						noOfClosed++;
				}
				
				double killRate=0;
				if(noOfOpen!=0)
					killRate = noOfClosed / noOfOpen;
				else if(noOfOpen==0)
					killRate = noOfClosed;
				
				product.setKillRate(killRate);
			}
		} catch (Exception e) {
			logger.debug("prodList "+prodList);
			logger.error("Problem with viewing product bug status", e);
			throw new BugException("Problem with viewing product bug status",e);
		}
		
		return prodList;
	}	
}
