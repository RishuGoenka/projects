package com.zycus.bugzilla.bugmgmt.controllers;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.zycus.bugzilla.bugmgmt.entities.Bug;
import com.zycus.bugzilla.bugmgmt.entities.BugSeverity;
import com.zycus.bugzilla.bugmgmt.entities.BugStatus;
import com.zycus.bugzilla.bugmgmt.entities.BugType;
import com.zycus.bugzilla.bugmgmt.entities.QualityAspect;
import com.zycus.bugzilla.bugmgmt.exceptions.BugException;
import com.zycus.bugzilla.bugmgmt.interfaces.IBugService;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.productmgmt.interfaces.IProductService;

@Controller
@SessionAttributes(value={"storeDate", "role", "loggedInUserId"})
public class BugController 
{
	@Autowired
	private IBugService bugService;
	
	
	@RequestMapping("enterBug.do")
	public String enterBug(Map<String, Object> model)
	{
		try {
			List<BugSeverity> severityList = bugService.getSeverityList();
			model.put("severityList", severityList);
			
			List<QualityAspect> qualityAspectList = bugService.getQualityAspectList();
			model.put("qualityAspectList", qualityAspectList);
			
			List<BugType> bugTypes = bugService.getBugTypes();
			model.put("bugTypeList", bugTypes);
			
			return "enterBug";
		} catch (BugException e) {
			return "exceptionPage";
		}
	}
	
	
	@RequestMapping("addBug.do")
	public String addBug(String summary, String RCA, String impactArea, Integer customers, Integer[] aspects,
							Integer severities, Integer developers, Integer bugTypes,
							Integer products, Integer qas,
							Map<String, Object> model)
	{
		Integer userId = (Integer) model.get("loggedInUserId");
		
		
		try {
			if(bugTypes==1)
				bugService.addBug(summary, RCA, impactArea, aspects, severities, bugTypes, products, developers, userId);
			else
				bugService.addBug(summary, RCA, impactArea, aspects, severities, bugTypes, products, developers, userId, qas, customers);
			return "successfullyAddedBug";
		} catch (BugException e) {
			return "exceptionPage";
		}
	}
	
	/*---------------------- GET BUG ATTRIBUTES -------------------------------------------------*/
	@RequestMapping("listAllSeverities.do")
	public String listOfSeverities(Map<String,Object> model)
	{
		try {
			List<BugSeverity> severityList = bugService.getSeverityList();
			model.put("severityList", severityList);
		} catch (BugException e) {
			return "exceptionPage";
		}
		
		return "populateSeverityList";
	}
	
	@RequestMapping("listAllStatus.do")
	public String listOfStatus(Map<String,Object> model)
	{
		List<BugStatus> statusList;
		try {
			statusList = bugService.getStatusList();
		} catch (BugException e) {
			return "exceptionPage";
		}
		model.put("statusList", statusList);
		
		return "populateStatusList";
	}
	
	@RequestMapping("listAllAspects.do")
	public String listOfAspects(Map<String,Object> model)
	{
		List<QualityAspect> aspectList;
		try {
			aspectList = bugService.getQualityAspectList();
		} catch (BugException e) {
			return "exceptionPage";
		}
		model.put("aspectList", aspectList);
		
		return "populateAspectList";
	}
	
	
	/*-------------------------- LIST BUG REQUESTS -------------------------------*/
	@RequestMapping("listAllBugs.do")
	public String listAllBugs(@RequestParam(value="view", required=false) String view,
								Map<String, Object> model)
	{
		Integer currentPage = (Integer) model.get("currentPage");
		if(currentPage==null)
			currentPage = 1;
		if(view!=null)
		{
			if(view.equals("next"))
				currentPage++;
			else if(view.equals("previous"))
				if(currentPage!=1)
					currentPage--;
		}
		model.put("currentPage", currentPage);
		
		List<Bug> bugList;
		try {
			bugList = bugService.getAllBugs((currentPage-1)*5, 5);
		} catch (BugException e) {
			return "exceptionPage";
		}
		model.put("bugList", bugList);
		
		return "viewBug";
	}
	
	@RequestMapping("listBugsByProduct.do")
	public String listBugsByProduct(@RequestParam(value="view", required=false) String view,
									@RequestParam(value="currentPage", required=false) Integer currentPage,
									@RequestParam(value="totalPages", required=false) Integer totalPages,
									int prodId, Map<String, Object> model)
	{
		if(currentPage==null)
			currentPage = 1;
		
		if(view!=null)
		{
			if(view.equals("next"))
				currentPage++;
			else if(view.equals("previous"))
				if(currentPage!=1)
					currentPage--;
		}
		model.put("currentPage", currentPage);
		if(totalPages==null)
		{
			try {
				totalPages = (int) Math.ceil(bugService.listoutBugsByProducts(prodId).size()/5);
			} catch (BugException e) {
				return "exceptionPage";
			}
			//totalPages++;
			model.put("totalPages", totalPages);
		}
		
		//set role in session later instead of this
		//model.put("role", "QA");
		
		
		
		model.put("catString", "prod");
		model.put("prodId", prodId);
		List<Bug> bugList;
		try {
			bugList = bugService.listoutBugsByProducts(prodId, (currentPage-1)*5, 5);
			System.out.println(bugList.size());
		} catch (BugException e) {
			return "exceptionPage";
		}
		if(bugList.isEmpty())
			model.put("catString", "empty");
		
		model.put("bugList", bugList);
		return "populateBugList";
	}
	
	@RequestMapping("listBugsBySeverity.do")
	public String listBugsBySeverity(@RequestParam(value="view", required=false) String view,
									@RequestParam(value="currentPage", required=false) Integer currentPage,
									@RequestParam(value="totalPages", required=false) Integer totalPages,
									int severityId, Map<String, Object> model)
	{
		if(currentPage==null)
			currentPage = 1;
		if(view!=null)
		{
			if(view.equals("next"))
				currentPage++;
			else if(view.equals("previous"))
				if(currentPage!=1)
					currentPage--;
		}
		model.put("currentPage", currentPage); 
		if(totalPages==null)
		{
			try {
				totalPages = (int) Math.ceil(bugService.listoutBugsBySeverity(severityId).size()/5);
			} catch (BugException e) {
				return "exceptionPage";
			}
			//totalPages++;
			model.put("totalPages", totalPages);
		}
		
		//set role in session later instead of this
		//model.put("role", "QA");
		
		
		model.put("catString", "severity");
		model.put("severityId", severityId);
		List<Bug> bugList;
		try {
			bugList = bugService.listoutBugsBySeverity(severityId, (currentPage-1)*5, 5);
		} catch (BugException e) {
			return "exceptionPage";
		}
		if(bugList.isEmpty())
			model.put("catString", "empty");
		
		model.put("bugList", bugList);
		return "populateBugList";
	}
	
	@RequestMapping("listBugsByStatus.do")
	public String listBugsByStatus(@RequestParam(value="view", required=false) String view,
									@RequestParam(value="currentPage", required=false) Integer currentPage,
									@RequestParam(value="totalPages", required=false) Integer totalPages,
									int statusId, Map<String, Object> model)
	{
		if(currentPage==null)
			currentPage = 1;
		if(view!=null)
		{
			if(view.equals("next"))
				currentPage++;
			else if(view.equals("previous"))
				if(currentPage!=1)
					currentPage--;
		}
		model.put("currentPage", currentPage);
		if(totalPages==null)
		{
			int listBugSize;
			try {
				listBugSize = bugService.listoutBugsByStatus(statusId).size();
			} catch (BugException e) {
				return "exceptionPage";
			}
			totalPages = (int) Math.ceil(listBugSize/5);
			//totalPages++;
			model.put("totalPages", totalPages);
		}
		//set role in session later instead of this
		//model.put("role", "QA");
		
		
		model.put("catString", "status");
		model.put("statusId", statusId);
		List<Bug> bugList;
		try {
			bugList = bugService.listoutBugsByStatus(statusId, (currentPage-1)*5, 5);
		} catch (BugException e) {
			return "exceptionPage";
		}
		if(bugList.isEmpty())
			model.put("catString", "empty");
		
		model.put("bugList", bugList);
		return "populateBugList";
	}
	
	@RequestMapping("listBugsByAspect.do")
	public String listBugsByAspect(@RequestParam(value="view", required=false) String view,
									@RequestParam(value="currentPage", required=false) Integer currentPage,
									@RequestParam(value="totalPages", required=false) Integer totalPages,
									int aspectId, Map<String, Object> model)
	{
		if(currentPage==null)
			currentPage = 1;
		if(view!=null)
		{
			if(view.equals("next"))
				currentPage++;
			else if(view.equals("previous"))
				if(currentPage!=1)
					currentPage--;
		}
		model.put("currentPage", currentPage); 
		if(totalPages==null)
		{
			try {
				totalPages = (int) Math.ceil(bugService.listoutBugsByQualityAspects(aspectId).size()/5);
			} catch (BugException e) {
				return "exceptionPage";
			}
			//totalPages++;
			model.put("totalPages", totalPages);
		}
		
		//set role in session later instead of this
		//model.put("role", "QA");
		
		
		model.put("catString", "aspect");
		model.put("aspectId", aspectId);
		List<Bug> bugList;
		try {
			bugList = bugService.listoutBugsByQualityAspects(aspectId, (currentPage-1)*5, 5);
		} catch (BugException e) {
			return "exceptionPage";
		}
		if(bugList.isEmpty())
			model.put("catString", "empty");
		
		model.put("bugList", bugList);
		return "populateBugList";
	}
	
	@RequestMapping("listBugsByReportee.do")
	public String listBugsByReportee(@RequestParam(value="view", required=false) String view,
									@RequestParam(value="currentPage", required=false) Integer currentPage,
									@RequestParam(value="totalPages", required=false) Integer totalPages,
									int userId, Map<String, Object> model)
	{
		if(currentPage==null)
			currentPage = 1;
		if(view!=null)
		{
			if(view.equals("next"))
				currentPage++;
			else if(view.equals("previous"))
				if(currentPage!=1)
					currentPage--;
		}
		model.put("currentPage", currentPage); 
		if(totalPages==null)
		{
			try {
				totalPages = (int) Math.ceil(bugService.listoutBugsByReportee(userId).size()/5);
			} catch (BugException e) {
				return "exceptionPage";
			}
			//totalPages++;
			model.put("totalPages", totalPages);
		}
		
		//set role in session later instead of this
		//model.put("role", "QA");
		
		
		model.put("catString", "reportee");
		model.put("userId", userId);
		List<Bug> bugList;
		try {
			bugList = bugService.listoutBugsByReportee(userId, (currentPage-1)*5, 5);
		} catch (BugException e) {
			return "exceptionPage";
		}
		if(bugList.isEmpty())
			model.put("catString", "empty");
		
		model.put("bugList", bugList);
		return "populateBugList";
	}
	
	@RequestMapping("listBugsByAssignee.do")
	public String listBugsByAssignee(@RequestParam(value="view", required=false) String view,
									@RequestParam(value="currentPage", required=false) Integer currentPage,
									@RequestParam(value="totalPages", required=false) Integer totalPages,
									int userId, Map<String, Object> model)
	{
		if(currentPage==null)
			currentPage = 1;
		if(view!=null)
		{
			if(view.equals("next"))
				currentPage++;
			else if(view.equals("previous"))
				if(currentPage!=1)
					currentPage--;
		}
		model.put("currentPage", currentPage); 
		if(totalPages==null)
		{
			try {
				totalPages = (int) Math.ceil(bugService.listoutBugsByAssignee(userId).size()/5);
			} catch (BugException e) {
				return "exceptionPage";
			}
			//totalPages++;
			model.put("totalPages", totalPages);
		}
		
		//set role in session later instead of this
		//model.put("role", "QA");
		
		
		model.put("catString", "assignee");
		model.put("userId", userId);
		List<Bug> bugList;
		try {
			bugList = bugService.listoutBugsByAssignee(userId, (currentPage-1)*5, 5);
		} catch (BugException e) {
			return "exceptionPage";
		}
		if(bugList.isEmpty())
			model.put("catString", "empty");
		
		model.put("bugList", bugList);
		return "populateBugList";
	}
	
	@RequestMapping("listBugsByDate.do")
	public String listBugsByDate(@RequestParam(value="view", required=false) String view,
									@RequestParam(value="currentPage", required=false) Integer currentPage,
									@RequestParam(value="totalPages", required=false) Integer totalPages,
									@RequestParam(value="bugDate", required=false) Date bugDate,
									Map<String, Object> model)
	{
		if(bugDate!=null)
		{
			model.put("storeDate", bugDate);
		}
		else if(bugDate==null)
		{
			bugDate = (Date) model.get("storeDate");
		}
		
		if(currentPage==null)
			currentPage = 1;
		if(view!=null)
		{
			if(view.equals("next"))
				currentPage++;
			else if(view.equals("previous"))
				if(currentPage!=1)
					currentPage--;
		}
		model.put("currentPage", currentPage); 
		if(totalPages==null)
		{
			try {
				totalPages = (int) Math.ceil(bugService.listoutBugsByDate(bugDate, "created").size()/5);
			} catch (BugException e) {
				return "exceptionPage";
			}
			//totalPages++;
			model.put("totalPages", totalPages);
		}
		
		//set role in session later instead of this
		//model.put("role", "QA");
		
		
		model.put("catString", "bugDate");
		model.put("bugDate", bugDate);
		List<Bug> bugList;
		try {
			bugList = bugService.listoutBugsByDate(bugDate, "created", (currentPage-1)*5, 5);
		} catch (BugException e) {
			return "exceptionPage";
		}
		if(bugList.isEmpty())
			model.put("catString", "empty");
		
		model.put("bugList", bugList);
		return "populateBugList";
	}
	
	
	/*--------------------------- VIEW PRODUCT BUG STATUS -------------------------------------------*/
	@RequestMapping("viewProductBugStatus.do")
	public String viewProductBugStatus(Map<String, Object> model)
	{
		List<Product> prodList;
		try {
			prodList = bugService.viewProductBugStatus();
		} catch (BugException e) {
			return "exceptionPage";
		}
		
		model.put("prodList", prodList);
		return "productBugStatus";
	}
	
	/*------------------------- STATUS REQUESTS-------------------------------------------------*/
	@RequestMapping("gotoChangeStatus.do")
	public String gotoChangeStatus(int bugId, int statusId, Map<String, Object> model)
	{
		Bug bug;
		try {
			bug = bugService.getBug(bugId);
		} catch (BugException e) {
			return "exceptionPage";
		}
		model.put("bug", bug);
		
		
		String role = (String) model.get("role");
		//System.out.println("ROLE -- "+role);
		
		List<BugStatus> statusList;
		try {
			statusList = bugService.getStatusByRole(role);
		} catch (BugException e) {
			return "exceptionPage";
		}
		model.put("statusList", statusList);
		
		/*System.out.println("Quality aspect length-"+bug.getQualityAspects().size());
		for(QualityAspect qa:bug.getQualityAspects())
		{
			System.out.println(qa.getQualityAspectMessage());
		}*/
		
		return "changeStatus";
	}
	
	@RequestMapping("changeStatus.do")
	public String changeStatus(int bugId, int newStatus)
	{
		try {
			bugService.changeStatus(bugId, newStatus);
		} catch (BugException e) {
			return "exceptionPage";
		}
		return "redirect:listAllBugs.do";
	}
}
