package com.zycus.bugzilla.productmgmt.interfaces;

import java.util.List;

import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.productmgmt.exceptions.ProductException;
/**
 * 
 * @author sankhadeep.basak
 *
 */
public interface IProductDao {

	void addNewProduct(Product product) throws ProductException;

	void updateProduct(Product product) throws ProductException;

	void deleteProduct(Product product) throws ProductException;

	List<Product> getAllProducts() throws ProductException;

	List<Product> getAllProductsByCustomer(Customer customer) throws ProductException;

	void addCustomersToProduct(Product product, Customer customer)
			throws ProductException;

	String isProductValidated(String productName) throws ProductException;

}
