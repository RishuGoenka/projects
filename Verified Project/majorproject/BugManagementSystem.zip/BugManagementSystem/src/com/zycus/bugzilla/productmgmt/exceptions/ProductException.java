package com.zycus.bugzilla.productmgmt.exceptions;

public class ProductException extends Exception {
	
	private static final long serialVersionUID = 1L;

	public ProductException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}

	
	public ProductException(String arg0) {
		super(arg0);
		
	}

}
