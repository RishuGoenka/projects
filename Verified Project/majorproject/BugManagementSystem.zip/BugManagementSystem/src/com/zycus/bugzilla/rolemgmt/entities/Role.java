package com.zycus.bugzilla.rolemgmt.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

import com.zycus.bugzilla.usermgmt.entities.User;



@Entity
@Table(name="tbl_role_master")
@GenericGenerator(name="roleIncr", strategy="increment")
public class Role {
	@Id
	@GeneratedValue(generator="roleIncr")
	@Column(name="role_id")
	private int roleId;
	
	@Size(min=2,message="min characters are 2")
	@Column(name="role_name")
	private String roleName;
	
	@ManyToMany( mappedBy="roles")
	private Set<User> users = new HashSet<User>();

	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public Set<User> getUsers() {
		return users;
	}
	public void setUsers(Set<User> users) {
		this.users = users;
	}	
	
	@Override
	public String toString(){
		
		return " roleid "+roleId+" roleName "+roleName; 
	}
}
