package com.zycus.bugzilla.usermgmt.daos;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;


import com.zycus.bugzilla.common.daos.BaseDao;
import com.zycus.bugzilla.rolemgmt.entities.Role;
import com.zycus.bugzilla.rolemgmt.exceptions.RoleException;
import com.zycus.bugzilla.usermgmt.entities.User;
import com.zycus.bugzilla.usermgmt.exceptions.UserException;

/**
 * 
 * @author saurabh.dharod
 *
 */
@Repository


public class UserDao extends BaseDao implements IUserDao{
	
	@Override
	public User isUserAuthenticated(String name,String password)throws  UserException{
		
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.eq("emailId",name));
		criteria.add(Restrictions.eq("password",password));
		criteria.setFetchMode("roles", FetchMode.JOIN);
		return (User) criteria.uniqueResult();
	}
	
	public String addUser(User user) throws UserException{
		
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria =session.createCriteria(User.class);
		criteria.add(Restrictions.eq("emailId",user.getEmailId()));
		User user1=(User) criteria.uniqueResult();
		if(user1==null)
			{
			session.save(user);
			return "success";
			}
		return "failure";
	}
	
	public void editUser(User user)throws UserException
	{
		Session session = super.sessionFactory.getCurrentSession();
		session.update(user);
	}
	
	public void deleteUser(User user)throws UserException{
		Session session = super.sessionFactory.getCurrentSession();
		session.delete(user);
	}
	public List<User> getAllUsers()throws UserException{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria =session.createCriteria(User.class);
		criteria.setFetchMode("roles", FetchMode.JOIN);
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.addOrder(Order.asc("userId"));
	
		return criteria.list();
	}
	
	public List<User> getUsersByName(User user)throws UserException{
		Session session=sessionFactory.getCurrentSession();
		Criteria criteria =session.createCriteria(User.class);
		criteria.add(Restrictions.eq("userName",user.getUserName()));
		return criteria.list();
	}

	@Override
	public List<User> getUserById(User user) throws UserException {
		Session session=sessionFactory.getCurrentSession();
		Criteria criteria =session.createCriteria(User.class);
		criteria.add(Restrictions.eq("userId",user.getUserId()));
		criteria.setFetchMode("roles", FetchMode.JOIN );
		return criteria.list();
	}
	
	@Override
	public User getUserByEmailId(User user) throws UserException {
		Session session=sessionFactory.getCurrentSession();
		Criteria criteria =session.createCriteria(User.class);
		criteria.add(Restrictions.eq("emailId",user.getEmailId()));
		criteria.setFetchMode("roles", FetchMode.JOIN );
		return (User) criteria.uniqueResult();
	}
	
	@Override
	public List<User> getUsersByRole(Role role)throws UserException
	{
		Session session=sessionFactory.getCurrentSession();
		Criteria criteria =session.createCriteria(User.class);
		criteria.setFetchMode("roles", FetchMode.JOIN );
		criteria.createAlias("roles", "rolesAlias");
		criteria.add(Restrictions.eq("rolesAlias.roleId",role.getRoleId()));
				
		return criteria.list();
		
	}
	
}
