package com.zycus.bugzilla.customermgmt.interfaces;

import java.util.List;
import java.util.Set;

import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.customermgmt.exceptions.CustomerException;
import com.zycus.bugzilla.productmgmt.entities.Product;

/**
 * 
 * @author sankhadeep.basak
 *
 */
public interface ICustomerDao {

	public abstract void addNewCustomer(Customer customer) throws CustomerException;

	public abstract void deleteCustomer(Customer customer) throws CustomerException;

	public abstract void addProductsToCustomer(Customer customer,
			Set<Product> products) throws CustomerException;

	public abstract List<Customer> getAllCustomers() throws CustomerException;

	public abstract List<Customer> getAllCustomersByProduct(Product product) throws CustomerException;

	public abstract void updateCustomer(Customer customer) throws CustomerException;

	public abstract String isUserValidated(String custName) throws CustomerException;

	public String isEmailValidated(String email) throws CustomerException;

}