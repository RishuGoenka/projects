package com.zycus.bugzilla.bugmgmt.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="tbl_quality_aspect2")
@GenericGenerator(name = "aspectIncr", strategy = "increment")
public class QualityAspect {

	@Id
	@GeneratedValue(generator="aspectIncr")
	@Column(name="quality_aspect_id")
	private int qualityAspectId;
	
	@Column(name="qua_aspect_msg")
	private String qualityAspectMessage;
	
	@ManyToMany(mappedBy="qualityAspects")
	private Set<Bug> bugs=new HashSet<Bug>();;

	public int getQualityAspectId() {
		return qualityAspectId;
	}
	public void setQualityAspectId(int qualityAspectId) {
		this.qualityAspectId = qualityAspectId;
	}

	public String getQualityAspectMessage() {
		return qualityAspectMessage;
	}
	public void setQualityAspectMessage(String qualityAspectMessage) {
		this.qualityAspectMessage = qualityAspectMessage;
	}

	public Set<Bug> getBugs() {
		return bugs;
	}
	public void setBugs(Set<Bug> bugs) {
		this.bugs = bugs;
	}
}
