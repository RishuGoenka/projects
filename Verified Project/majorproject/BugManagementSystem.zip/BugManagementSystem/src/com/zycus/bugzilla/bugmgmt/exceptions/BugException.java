package com.zycus.bugzilla.bugmgmt.exceptions;

public class BugException extends Exception {

	public BugException() {
	}

	public BugException(String arg0) {
		super(arg0);
	}

	public BugException(Throwable arg0) {
		super(arg0);
	}

	public BugException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
