package com.zycus.bugzilla.usermgmt.services;

import java.util.List;
import java.util.Map;

import com.zycus.bugzilla.rolemgmt.exceptions.RoleException;
import com.zycus.bugzilla.usermgmt.entities.User;
import com.zycus.bugzilla.usermgmt.exceptions.UserException;
/**
 * 
 * @author saurabh.dharod
 *
 */
public interface IUserService {

	public String  addUser(User user,int roleId) throws UserException;
	public List<User> getAllUsers() throws UserException;
	public void editUser(User user) throws UserException;
	public void deleteUser(int userId) throws UserException;
	public User getUserById(int userId) throws UserException;
	
	public List<User> getDevelopers() throws UserException;
	public List<User> getQAs() throws UserException;
	Map<String, Object> isUserAuthenticated(String name, String password)
			throws UserException;
}
