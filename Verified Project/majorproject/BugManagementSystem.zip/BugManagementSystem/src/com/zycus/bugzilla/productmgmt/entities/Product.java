package com.zycus.bugzilla.productmgmt.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.bugmgmt.entities.Bug;

@Entity
@Table(name="tbl_product_master")
@GenericGenerator(name="productIncr", strategy="increment")
public class Product {

	/*----------------- CALCULATABLE FIELDS------------------------------*/
	@Transient
	private double bugIndex;
	@Transient
	private double killRate;
	
	@Id
	@GeneratedValue(generator="productIncr")
	@Column(name="product_id")
	private int productId;
	
	@Size(min=1,message="must not be empty")
	@Column(name="product_name")
	private String productName;
	
	@ManyToMany(mappedBy="products", fetch=FetchType.EAGER)
	private Set<Customer> customers=new HashSet<Customer>();
	
	@OneToMany
	private Set<Bug> bugs=new HashSet<Bug>();
	
	
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Set<Customer> getCustomers() {
		return customers;
	}
	public void setCustomers(Set<Customer> customers) {
		this.customers = customers;
	}
	public Set<Bug> getBugs() {
		return bugs;
	}
	public void setBugs(Set<Bug> bugs) {
		this.bugs = bugs;
	}
	public double getBugIndex() {
		return bugIndex;
	}
	public void setBugIndex(double bugIndex) {
		this.bugIndex = bugIndex;
	}
	public double getKillRate() {
		return killRate;
	}
	public void setKillRate(double killRate) {
		this.killRate = killRate;
	}
	
	@Override
	public String toString() {
		return "Product [Id: "+productId+"\tName: "+productName+"]";
	}
	
	
}
