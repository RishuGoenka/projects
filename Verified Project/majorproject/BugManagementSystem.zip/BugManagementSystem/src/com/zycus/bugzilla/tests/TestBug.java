package com.zycus.bugzilla.tests;


import org.junit.Test;

import com.zycus.bugzilla.bugmgmt.entities.Bug;
import com.zycus.bugzilla.bugmgmt.entities.BugSeverity;
import com.zycus.bugzilla.bugmgmt.entities.BugStatus;
import com.zycus.bugzilla.bugmgmt.entities.BugType;
import com.zycus.bugzilla.bugmgmt.entities.QualityAspect;
import com.zycus.bugzilla.common.daos.BaseDao;
import com.zycus.bugzilla.customermgmt.entities.Customer;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.usermgmt.entities.User;


public class TestBug {

	@Test
	public void addBug(){
		BaseDao dao=new BaseDao();
		
		Bug bug=new Bug();
		bug.setSummary("on click on login, processing failed");
		
		
		QualityAspect qualityAspect=new QualityAspect();
		qualityAspect.setQualityAspectMessage("UserInterface");
	//	dao.saveOrUpdate(qualityAspect);
		bug.getQualityAspects().add(qualityAspect);
		
		dao.saveOrUpdate(qualityAspect);
		dao.saveOrUpdate(bug);
		
	}
	
	@Test
	public void setStatusToBug()
	{
		BaseDao dao = new BaseDao();
		
		Bug bug = dao.get(Bug.class, 1);
		
		BugStatus status = dao.get(BugStatus.class, 1);
		
		bug.setBugStatus(status);
		
		dao.saveOrUpdate(bug);
	}
	
	@Test
	public void setSeverityToBug(){
		BaseDao dao = new BaseDao();
		
		Bug bug = dao.get(Bug.class, 1);
		
		BugSeverity severity = dao.get(BugSeverity.class, 1);
		
		bug.setBugSeverity(severity);
		
		dao.saveOrUpdate(bug);
	}
	
	@Test
	public void setProductToBug()
	{
		BaseDao dao = new BaseDao();
		
		Product product = dao.get(Product.class, 1);
		
		Bug bug = dao.get(Bug.class, 1);
		
		bug.setProduct(product);
		
		dao.saveOrUpdate(bug);
	}
	
	@Test
	public void setTypeToBug()
	{
		BaseDao dao = new BaseDao();
		
		BugType type = new BugType();
		type.setType("CFT");
		
		Bug bug = dao.get(Bug.class, 1);
		
		bug.setType(type);
		
		dao.saveOrUpdate(type);
		dao.saveOrUpdate(bug);
	}
	
	@Test
	public void setUsersToBug()
	{
		BaseDao dao = new BaseDao();
		
		Bug bug = dao.get(Bug.class, 1);
		
		User user = dao.get(User.class, 1);
		Customer cust = dao.get(Customer.class, 1);
		
		bug.setInjectedBy(user);
		bug.setCustomer(cust);
		
		dao.saveOrUpdate(bug);
	}
}
