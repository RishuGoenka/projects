package com.zycus.bugzilla.usermgmt.services;


import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.type.descriptor.java.UUIDTypeDescriptor.ToBytesTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.bugzilla.rolemgmt.entities.Role;
import com.zycus.bugzilla.rolemgmt.exceptions.RoleException;
import com.zycus.bugzilla.usermgmt.daos.IUserDao;
import com.zycus.bugzilla.usermgmt.entities.User;
import com.zycus.bugzilla.usermgmt.exceptions.UserException;

/**
 * 
 * @author saurabh.dharod
 *
 */
@Service
@Transactional
public class UserService implements IUserService{

	private static Logger logger=Logger.getLogger(UserService.class.getName());
	
	@Autowired
	private IUserDao userDao;
	
	@Override
	public Map<String, Object> isUserAuthenticated(String name,String password) throws UserException{
		
		User user=null;
		Map<String, Object> map = null; 
		
		try {
			user=userDao.isUserAuthenticated(name,password);
			Set<Role> set = new HashSet<Role>();
			if(user!=null)
			{
				set=user.getRoles();
				map = new HashMap<String, Object>();
				map.put("id", user.getUserId());
				System.out.println(user.getUserId());
			}
			
			if(!set.isEmpty())
			{
				Iterator<Role> iterator = set.iterator();
				while(iterator.hasNext())
				{
					Role role = iterator.next();
					if(role.getRoleName().equalsIgnoreCase(("Admin")))
					{
						map.put("role", role.getRoleName());
						return map;
					}
					System.out.println(role.getRoleName());
					map.put("role", role.getRoleName());
				}
				return map;
			}
			
			return map;
		} catch (UserException e) {
			logger.debug(" user "+user);
			logger.error("Problem encountered in is user authenticated", e);
			throw new UserException("Problem occured in is user authenticated",e);
		}
	}
	
	@Override
	public String addUser(User user,int roleId) throws UserException{
		try {
			
			Role role=new Role();
			role.setRoleId(roleId);
			user.getRoles().add(role);
			return userDao.addUser(user);
		} catch (UserException e) {
			
			logger.debug(" user: "+user);
			logger.debug("roleId: " +roleId);
			logger.error("Problem encountered in getting all users", e);
			throw new UserException("Problem encountered in adding user",e);
		}		
	}
	
	@Override
	public List<User> getAllUsers() throws UserException{
		try{
		return userDao.getAllUsers();		
		}
		catch(UserException e){
			logger.debug(" Users: "+userDao.getAllUsers().get(0));
			logger.error("Problem encountered in getting all users", e);
			throw new UserException("Problem encountered in getting all users ",e);
		}
	}
	@Override
	public void editUser(User user) throws UserException{
		
		User toBeEditedUser=null;
		try
		{
		toBeEditedUser = getUserById(user.getUserId());
		toBeEditedUser.setUserName(user.getUserName());
		toBeEditedUser.setEmailId(user.getEmailId());
		System.out.println("editUser"+toBeEditedUser.getRoles());
		userDao.editUser(toBeEditedUser);
		}catch(UserException e){
			logger.debug(" userId "+toBeEditedUser);
			logger.error("Problem encountered in editing user", e);
			throw new UserException("Problem encountered in editing user ",e);
		}
		
	}
	@Override
	public void deleteUser(int userId) throws UserException
	{
		try{
		User user=new User();
		user.setUserId(userId);
		userDao.deleteUser(user);
		}
		catch(UserException e){
			logger.debug(" userId "+userId);
			logger.error("Problem encountered in deleting user by id", e);
			throw new UserException("Problem encountered in deleting  user by id ",e);
		}
		
	}
	@Override
	public User getUserById(int userId) throws UserException {
		try{
		User user =new User();
		user.setUserId(userId);
		List<User> list=userDao.getUserById(user);
		return list.get(0);
		}
		catch(UserException e){
			
			logger.debug(" userId "+userId);
			logger.error("Problem encountered in getting users by id", e);
			throw new UserException("Problem encountered in getting users by id ",e);
		}
	}

	
	@Override
	public List<User> getDevelopers() throws UserException 
	{
		Role role = new Role();
		role.setRoleId(3);
		return userDao.getUsersByRole(role);
	}
	
	@Override
	public List<User> getQAs() throws UserException 
	{
		Role role = new Role();
		role.setRoleId(2);
		return userDao.getUsersByRole(role);
	}
}
