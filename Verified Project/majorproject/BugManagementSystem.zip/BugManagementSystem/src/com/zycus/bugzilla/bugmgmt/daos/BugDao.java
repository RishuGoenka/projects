package com.zycus.bugzilla.bugmgmt.daos;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.bugzilla.bugmgmt.entities.Bug;
import com.zycus.bugzilla.bugmgmt.entities.BugSeverity;
import com.zycus.bugzilla.bugmgmt.entities.BugStatus;
import com.zycus.bugzilla.bugmgmt.entities.BugType;
import com.zycus.bugzilla.bugmgmt.entities.QualityAspect;
import com.zycus.bugzilla.bugmgmt.exceptions.BugException;
import com.zycus.bugzilla.bugmgmt.interfaces.IBugDao;
import com.zycus.bugzilla.common.daos.BaseDao;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.usermgmt.entities.User;

@Repository
@Transactional
public class BugDao extends BaseDao implements IBugDao
{

	@Override
	public void addBug(Bug bug) throws BugException
	{
		super.save(bug);
	}
	
	@Override
	public List<Bug> getAllBugs() throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.setFetchMode("bugStatus", FetchMode.JOIN);
		criteria.setFetchMode("bugSeverity", FetchMode.JOIN);
		criteria.setFetchMode("type", FetchMode.JOIN);
		criteria.setFetchMode("product", FetchMode.JOIN);
		criteria.addOrder(Order.asc("bugId"));
		
		return criteria.list();
	}
	
	@Override
	public List<Bug> getAllBugs(int offset, int rows) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.setFetchMode("bugStatus", FetchMode.JOIN);
		criteria.setFetchMode("bugSeverity", FetchMode.JOIN);
		criteria.setFetchMode("type", FetchMode.JOIN);
		criteria.setFetchMode("product", FetchMode.JOIN);
		criteria.addOrder(Order.asc("bugId"));
		
		criteria.setFirstResult(offset);
		criteria.setMaxResults(rows);
		
		return criteria.list();
	}
	
	@Override
	public List<Bug> listoutBugsByProducts(Product product) throws BugException
	{
		
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.add(Restrictions.eq("product", product));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		return criteria.list();
	}
	
	@Override
	public List<Bug> listoutBugsByProducts(Product product, int offset, int rows) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.add(Restrictions.eq("product", product));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		criteria.addOrder(Order.asc("bugId"));
		
		List<Bug> bugList = criteria.list();
		
		List<Bug> newBugList = new ArrayList<Bug>();
		int count=0;
		for(Bug bug:bugList)
		{
			if(count>=offset && count<(offset + rows))
			{
				newBugList.add(bug);
			}
			count++;
		}

		return newBugList;
	}
	
	@Override
	public List<BugStatus> getStatusList() throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(BugStatus.class);
		
		return criteria.list();
	}
	
	@Override
	public List<BugSeverity> getSeverityList()  throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(BugSeverity.class);
		
		return criteria.list();
	}
	
	@Override
	public List<QualityAspect> getQualityAspectList() throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(QualityAspect.class);
		
		return criteria.list();
	}

	@Override
	public List<BugType> getBugTypes()  throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(BugType.class);
		
		return criteria.list();
	}
	
	@Override
	public List<Bug> listoutBugsByAssignee(User user) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.setFetchMode("injectedBy", FetchMode.JOIN );
		criteria.createAlias("injectedBy","injectedAlias");	
		criteria.add(Restrictions.eq("injectedAlias.userId",user.getUserId()));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		
		criteria.addOrder(Order.asc("bugId"));
		
		return criteria.list();
	}
	
	@Override
	public List<Bug> listoutBugsByAssignee(User user, int offset, int rows) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.setFetchMode("injectedBy", FetchMode.JOIN );
		criteria.createAlias("injectedBy","injectedAlias");	
		criteria.add(Restrictions.eq("injectedAlias.userId",user.getUserId()));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		
		criteria.addOrder(Order.asc("bugId"));
		
		List<Bug> bugList = criteria.list();
		
		List<Bug> newBugList = new ArrayList<Bug>();
		int count=0;
		for(Bug bug:bugList)
		{
			if(count>=offset && count<(offset + rows))
			{
				newBugList.add(bug);
			}
			count++;
		}

		return newBugList;
	}
	
	
	@Override
	public void changeStatus(Bug bug, BugStatus status) throws BugException
	{
		bug.setBugStatus(status);
		super.update(bug);
	}
	
	@Override
	public List<Bug> listoutBugsByReportee(User user) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.setFetchMode("reportee", FetchMode.JOIN );
		criteria.createAlias("reportee","reporteeAlias");	
		criteria.add(Restrictions.eq("reporteeAlias.userId",user.getUserId()));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		
		
		criteria.addOrder(Order.asc("bugId"));
		
		return criteria.list();
	}
	
	@Override
	public List<Bug> listoutBugsByReportee(User user, int offset, int rows) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.setFetchMode("reportee", FetchMode.JOIN );
		criteria.createAlias("reportee","reporteeAlias");	
		criteria.add(Restrictions.eq("reporteeAlias.userId",user.getUserId()));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);

		
		criteria.addOrder(Order.asc("bugId"));

		List<Bug> bugList = criteria.list();
		
		List<Bug> newBugList = new ArrayList<Bug>();
		int count=0;
		for(Bug bug:bugList)
		{
			if(count>=offset && count<(offset + rows))
			{
				newBugList.add(bug);
			}
			count++;
		}

		return newBugList;
	}
	
	@Override 
	public Bug getBug(int bugId) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.add(Restrictions.eq("bugId", bugId));
		criteria.setFetchMode("bugStatus", FetchMode.JOIN);
		criteria.setFetchMode("bugSeverity", FetchMode.JOIN);
		criteria.setFetchMode("qualityAspects", FetchMode.JOIN);
		criteria.setFetchMode("type", FetchMode.JOIN);
		criteria.setFetchMode("product", FetchMode.JOIN);
		
		return (Bug) criteria.list().get(0);
	}
	
	@Override
	public List<Bug> listoutBugsBySeverity(BugSeverity bugSeverity) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.add(Restrictions.eq("bugSeverity",bugSeverity));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		criteria.addOrder(Order.asc("bugId"));
		
		return criteria.list();
	}
	
	@Override
	public List<Bug> listoutBugsBySeverity(BugSeverity bugSeverity, int offset, int rows) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.add(Restrictions.eq("bugSeverity",bugSeverity));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		criteria.addOrder(Order.asc("bugId"));

		List<Bug> bugList = criteria.list();
		
		List<Bug> newBugList = new ArrayList<Bug>();
		int count=0;
		for(Bug bug:bugList)
		{
			if(count>=offset && count<(offset + rows))
			{
				newBugList.add(bug);
			}
			count++;
		}

		return newBugList;
	}
	
	
	@Override
	public List<Bug> listoutBugsByQualityAspect(QualityAspect qualityAspect) throws BugException
	{
		
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.setFetchMode("qualityAspects", FetchMode.JOIN);
		criteria.createAlias("qualityAspects", "qualityAspectsAlias");
		criteria.add(Restrictions.eq("qualityAspectsAlias.qualityAspectId",qualityAspect.getQualityAspectId()));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		criteria.addOrder(Order.asc("bugId"));
		
		return criteria.list();
	}
	
	@Override
	public List<Bug> listoutBugsByQualityAspect(QualityAspect qualityAspect, int offset, int rows) throws BugException
	{
		
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.setFetchMode("qualityAspects", FetchMode.JOIN);
		criteria.createAlias("qualityAspects", "qualityAspectsAlias");
		criteria.add(Restrictions.eq("qualityAspectsAlias.qualityAspectId",qualityAspect.getQualityAspectId()));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		criteria.addOrder(Order.asc("bugId"));

		List<Bug> bugList = criteria.list();
		
		List<Bug> newBugList = new ArrayList<Bug>();
		int count=0;
		for(Bug bug:bugList)
		{
			if(count>=offset && count<(offset + rows))
			{
				newBugList.add(bug);
			}
			count++;
		}

		return newBugList;
	}
	
	
	@Override
	public List<Bug> listoutBugsByStatus(BugStatus bugStatus) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.add(Restrictions.eq("bugStatus",bugStatus));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		criteria.addOrder(Order.asc("bugId"));

		return criteria.list();
	}
	
	
	@Override
	public List<Bug> listoutBugsByStatus(BugStatus bugStatus, int offset, int rows) throws BugException
	{
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		criteria.add(Restrictions.eq("bugStatus",bugStatus));
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		criteria.addOrder(Order.asc("bugId"));

		List<Bug> bugList = criteria.list();
		
		List<Bug> newBugList = new ArrayList<Bug>();
		int count=0;
		for(Bug bug:bugList)
		{
			if(count>=offset && count<(offset + rows))
			{
				newBugList.add(bug);
			}
			count++;
		}

		return newBugList;
	}
	
	
	
	@Override
	public List<Bug> listoutBugsByDate(Date bugDate, String spec, Product product) throws BugException
	{
		
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		
		if(spec.equalsIgnoreCase("created"))
			criteria.add(Restrictions.eq("createdDate", bugDate));
		else if(spec.equalsIgnoreCase("modified"))
			criteria.add(Restrictions.eq("modifiedDate", bugDate));
		
		criteria.add(Restrictions.eq("product", product));
		
		criteria.setFetchMode("bugStatus", FetchMode.JOIN);
		
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		return criteria.list();
	}
	
	@Override
	public List<Bug> listoutBugsByDate(Date bugDate, String spec) throws BugException
	{
		
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		
		if(spec.equalsIgnoreCase("created"))
			criteria.add(Restrictions.eq("createdDate", bugDate));
		else if(spec.equalsIgnoreCase("modified"))
			criteria.add(Restrictions.eq("modifiedDate", bugDate));
		
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		return criteria.list();
	}
	
	@Override
	public List<Bug> listoutBugsByDate(Date bugDate, String spec, int offset, int rows) throws BugException
	{
		
		Session session = super.sessionFactory.getCurrentSession();
		Criteria criteria = session.createCriteria(Bug.class);
		
		if(spec.equalsIgnoreCase("created"))
			criteria.add(Restrictions.eq("createdDate", bugDate));
		else if(spec.equalsIgnoreCase("modified"))
			criteria.add(Restrictions.eq("modifiedDate", bugDate));
		
		criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
		
		criteria.addOrder(Order.asc("bugId"));

		List<Bug> bugList = criteria.list();
		
		List<Bug> newBugList = new ArrayList<Bug>();
		int count=0;
		for(Bug bug:bugList)
		{
			if(count>=offset && count<(offset + rows))
			{
				newBugList.add(bug);
			}
			count++;
		}

		return newBugList;
	}
}
