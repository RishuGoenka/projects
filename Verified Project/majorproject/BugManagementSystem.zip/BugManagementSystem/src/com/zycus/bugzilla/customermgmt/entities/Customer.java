package com.zycus.bugzilla.customermgmt.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.validator.constraints.Email;

import com.zycus.bugzilla.productmgmt.entities.Product;

@Entity
@Table(name = "tbl_customer_master")
@GenericGenerator(name = "customerIncr", strategy = "increment")
public class Customer {
	
	@Id
	@GeneratedValue(generator = "customerIncr")
	@Column(name="cust_id")
	private int custId;
	
	@Column(name = "cust_name")
	private String custName;
	
	@Email
	@Column(name = "cust_email_id")
	private String emailId;
	
	@ManyToMany(fetch=FetchType.EAGER)
	@JoinTable(name = "tbl_product_customer", 
			joinColumns = { @JoinColumn(name = "cust_id",nullable = false)} , 
			inverseJoinColumns = {@JoinColumn(name = "product_id",nullable = false)})
	private Set<Product> products = new HashSet<Product>();

	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Set<Product> getProducts() {
		return products;
	}
	public void setProducts(Set<Product> products) {
		this.products = products;
	}
	@Override
	public String toString() {
		return "Customer [Id: "+custId+"\tName: "+custName+"\tEmailId: "+emailId+"]";
	}
	
	
}
