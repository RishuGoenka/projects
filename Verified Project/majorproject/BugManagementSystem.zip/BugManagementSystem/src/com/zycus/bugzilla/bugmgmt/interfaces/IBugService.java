package com.zycus.bugzilla.bugmgmt.interfaces;

import java.util.Date;
import java.util.List;

import com.zycus.bugzilla.bugmgmt.entities.Bug;
import com.zycus.bugzilla.bugmgmt.entities.BugSeverity;
import com.zycus.bugzilla.bugmgmt.entities.BugStatus;
import com.zycus.bugzilla.bugmgmt.entities.BugType;
import com.zycus.bugzilla.bugmgmt.entities.QualityAspect;
import com.zycus.bugzilla.bugmgmt.exceptions.BugException;
import com.zycus.bugzilla.productmgmt.entities.Product;

public interface IBugService 
{
	public void addBug(String summary, String RCA, String impactArea,
			Integer[] aspectIds, int severityId, int typeId,
			int productId, 
			int assigneeId, int reporteeId) throws BugException;
	
	public void addBug(String summary, String RCA, String impactArea,
			Integer[] aspectIds, int severityId, int typeId,
			int productId, 
			int assigneeId, int reporteeId, 
			int missedById, int customerId) throws BugException;
	
	public List<BugSeverity> getSeverityList() throws BugException;
	public List<QualityAspect> getQualityAspectList() throws BugException;
	public List<BugType> getBugTypes() throws BugException;
	public void changeStatus(int bugId, int bugStatusId) throws BugException;
	
	public List<Bug> getAllBugs() throws BugException;
	public List<Bug> getAllBugs(int offset, int rows) throws BugException;
	
	public Bug getBug(int bugId) throws BugException;
	
	public List<BugStatus> getStatusList() throws BugException;
	public List<BugStatus> getStatusByRole(String role) throws BugException;
	
	public List<Bug> listoutBugsByProducts(int productId) throws BugException;
	public List<Bug> listoutBugsByProducts(int productId, int offset, int rows) throws BugException;
	
	public List<Bug> listoutBugsBySeverity(int severityId) throws BugException;
	public List<Bug> listoutBugsBySeverity(int severityId, int offset, int rows) throws BugException;

	public List<Bug> listoutBugsByQualityAspects(int qualityAspectId) throws BugException;
	public List<Bug> listoutBugsByQualityAspects(int qualityAspectId, int offset, int rows) throws BugException;

	public List<Bug> listoutBugsByStatus(int bugStatusId) throws BugException;
	public List<Bug> listoutBugsByStatus(int bugStatusId, int offset, int rows) throws BugException;
	
	public List<Bug> listoutBugsByDate(Date bugDate, String spec) throws BugException;
	public List<Bug> listoutBugsByDate(Date bugDate, String spec, Product product) throws BugException;
	public List<Bug> listoutBugsByDate(Date bugDate, String spec, int offset, int rows) throws BugException;
	
	public List<Bug> listoutBugsByAssignee(int userId) throws BugException;
	public List<Bug> listoutBugsByAssignee(int userId, int offset, int rows) throws BugException;
	
	public List<Bug> listoutBugsByReportee(int userId) throws BugException;
	public List<Bug> listoutBugsByReportee(int userId, int offset, int rows) throws BugException;
	
	public List<Product> viewProductBugStatus() throws BugException;
}
