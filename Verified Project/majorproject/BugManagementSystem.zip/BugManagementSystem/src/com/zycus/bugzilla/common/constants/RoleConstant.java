package com.zycus.bugzilla.common.constants;

public class RoleConstant {

		public static final String ADMIN="admin";
		public static final String QA="QA";
		public static final String DEVELOPER="Developer";
}
