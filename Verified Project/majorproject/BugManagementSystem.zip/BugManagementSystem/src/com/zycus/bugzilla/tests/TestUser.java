 package com.zycus.bugzilla.tests;


import org.junit.Test;

import com.zycus.bugzilla.common.daos.BaseDao;
import com.zycus.bugzilla.rolemgmt.entities.Role;
import com.zycus.bugzilla.usermgmt.entities.User;


public class TestUser {

	@Test
	public void addUserAndRole()
	{
		BaseDao dao = new BaseDao();
		
		User user = dao.get(User.class, 1);
		
		Role role = dao.get(Role.class, 2);
		
		user.getRoles().add(role);
		dao.saveOrUpdate(user);
	}
}
