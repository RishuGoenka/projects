package com.zycus.bugzilla.bugmgmt.controllers;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.zycus.bugzilla.bugmgmt.entities.Bug;
import com.zycus.bugzilla.bugmgmt.interfaces.IBugService;
import com.zycus.bugzilla.productmgmt.entities.Product;
import com.zycus.bugzilla.productmgmt.interfaces.IProductService;

@Controller
public class ExcelController {


	@Autowired
	IProductService productService;

	@Autowired
	IBugService bugService ;

	@RequestMapping(value="excelReport.do")
	protected String excelReport(Map<String ,Object> model) throws Exception {
		List<Product> products=productService.getAllProducts();
		model.put("products",products);
		return "listAllBugsExcel";

	}
	@RequestMapping(value="excelProductReport.do")
	protected String generateProductReport(@RequestParam(value = "productId") String productId ,
			Map<String ,Object> model
			) throws Exception {
		String output="excel";
		if(!productId.equalsIgnoreCase("select"))
		{
			Integer prodId=Integer.parseInt(productId);
			List<Bug> bugData=bugService.listoutBugsByProducts(prodId);
			model.put("bugData",bugData);

			if("EXCEL".equals(output.toUpperCase())){
				//return excel view
				return "ExcelBugSummary";
			}
			else 				
				return "BugSummary";
		}
		else
			return "redirect:excelReport.do";
	}
	@RequestMapping(value="excelSeverityReport.do")
	protected String generateSeverityReport(String severityId,Map<String ,Object> model) throws Exception {

		String output="excel";
		if(!severityId.equalsIgnoreCase("select"))
		{
			Integer severId=Integer.parseInt(severityId);
			List<Bug> bugData=bugService.listoutBugsBySeverity(severId);

			model.put("bugData",bugData);

			if("EXCEL".equals(output.toUpperCase())){
				//return excel view
				return "ExcelBugSummary";
			}
			else 				
				return "BugSummary";
		}
		else 
			return "redirect:excelReport.do";
	}

	@RequestMapping(value="excelAssigneeReport.do")
	protected String generateAssigneeReport(String assigneeId,Map<String ,Object> model) throws Exception {

		String output="excel";

		if(!assigneeId.equalsIgnoreCase("select"))
		{
			Integer assignId=Integer.parseInt(assigneeId);
			List<Bug> bugData=bugService.listoutBugsByAssignee(assignId);
			model.put("bugData",bugData);

			if("EXCEL".equals(output.toUpperCase())){
				//return excel view
				return "ExcelBugSummary";
			}
			else 				
				return "BugSummary";
		}
		else 
			return "redirect:excelReport.do";
	}
	@RequestMapping(value="excelReporteeReport.do")
	protected String generateReporteeReport(String reporteeId,Map<String ,Object> model) throws Exception {

		String output="excel";

		if(!reporteeId.equalsIgnoreCase("select")){

			Integer reportId=Integer.parseInt(reporteeId);
			List<Bug> bugData=bugService.listoutBugsByReportee(reportId);
			model.put("bugData",bugData);

			if("EXCEL".equals(output.toUpperCase())){
				//return excel view
				return "ExcelBugSummary";
			}
			else 				
				return "BugSummary";
		}
			else 
				return "redirect:excelReport.do";
		
	}
	@RequestMapping(value="excelStatusReport.do")
	protected String generateStatusReport(String statusId ,Map<String ,Object> model) throws Exception {

		String output="excel";
		
		if(!statusId.equalsIgnoreCase("select"))
		{
			
		Integer statuId=Integer.parseInt(statusId);
		List<Bug> bugData=bugService.listoutBugsByStatus(statuId);
		model.put("bugData",bugData);

		if("EXCEL".equals(output.toUpperCase())){
			//return excel view
			return "ExcelBugSummary";
		}
		else 				
			return "BugSummary";
		}
		else 
			return "redirect:excelReport.do";
	}
	@RequestMapping(value="excelQualityAspectReport.do")
	protected String generateAspectsReport(String qualityAspectId,
			Map<String ,Object> model
			) throws Exception {

		String output="excel";
		if(!qualityAspectId.equalsIgnoreCase("select"))
		{
			Integer quaId=Integer.parseInt(qualityAspectId);
		List<Bug> bugData=bugService.listoutBugsByQualityAspects(quaId);
		model.put("bugData",bugData);

		if("EXCEL".equals(output.toUpperCase())){
			//return excel view
			return "ExcelBugSummary";
		}
		else 				
			return "BugSummary";}
		else 
			return "redirect:excelReport.do";
	}

}
