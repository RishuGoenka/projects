package com.zycus.bugzilla.common.daos;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class BaseDao 
{
	@Autowired
	protected SessionFactory sessionFactory;

	public void save(Object obj)
	{
		Session session = sessionFactory.getCurrentSession();
		session.save(obj);//insert or update
	}
	
	public void update(Object obj)
	{
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(obj);//insert or update
	}

	public void delete(Object obj){
		Session session = sessionFactory.getCurrentSession();
		session.delete(obj);
	}
	
	@SuppressWarnings("unchecked")
	public <E>E get(Class<E> classname,Serializable pk)
	{
		Session session=sessionFactory.getCurrentSession();
		E e=(E)session.get(classname, pk);//select based on pk
		return e;
	}
}
