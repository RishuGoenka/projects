package com.zycus.bugzilla.usermgmt.daos;

import java.util.List;

import com.zycus.bugzilla.rolemgmt.entities.Role;
import com.zycus.bugzilla.rolemgmt.exceptions.RoleException;
import com.zycus.bugzilla.usermgmt.entities.User;
import com.zycus.bugzilla.usermgmt.exceptions.UserException;
/**
 * 
 * @author saurabh.dharod
 *
 */
public interface IUserDao {

	public String addUser(User user) throws UserException;
	public void editUser(User user) throws UserException;
	public void deleteUser(User user) throws UserException;
	public List<User> getAllUsers() throws UserException;
	public List<User> getUsersByName(User user) throws UserException;
	public List<User> getUserById(User user) throws UserException;
	
	public List<User> getUsersByRole(Role role)throws UserException;
	User isUserAuthenticated(String name, String password) throws  UserException;
	User getUserByEmailId(User user) throws UserException;
}
