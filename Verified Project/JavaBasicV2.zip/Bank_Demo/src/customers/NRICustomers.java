package customers;

public class NRICustomers {
	public static void main(String args[]) {
		/*
		 * SavingsAccount sav = new SavingsAccount(); 
		 * CurrentAccount cav = new CurrentAccount(); 
		 * InterestCalculator ic = new InterestCalculator();
		 * BankCharges bc = new BankCharges(); 
		 * FineCalculator fc = new FineCalculator();
		 */
	}
}
