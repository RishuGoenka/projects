package accounts;

public class CurrentAccount {

}
