package accounts;

public class FineCalculator {

}
