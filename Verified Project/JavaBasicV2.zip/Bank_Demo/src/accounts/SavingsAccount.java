package accounts;

public class SavingsAccount {

}
