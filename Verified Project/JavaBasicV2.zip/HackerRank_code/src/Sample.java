import java.util.Scanner;

public class Sample {

	public static void main(String[] args) {
		try {
			Scanner scn = new Scanner(System.in);
			int q = scn.nextInt();
			if (q >= 1 && q <= 100000) {
				int[] n = new int[q];
				String[] s = new String[q];
				for (int i = 0; i < q; i++) {

					n[i] = scn.nextInt();
					if (n[i] >= 3 && n[i] <= 10000) {
						if (n[i] % 2 == 0)
							s[i] = "yes";
						else
							s[i] = "no";
					} else
						i--;
				}
				for (int i = 0; i < q; i++)
					System.out.println(s[i]);
				scn.close();

			}

		} catch (Exception e) {
		}
	}
}