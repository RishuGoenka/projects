package com.rish.app;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.rish.models.Planet;
import com.rish.models.PlanetID;

public class MainApp {

	public static void main(String[] args) {
SessionFactory factory = new Configuration().configure().buildSessionFactory();
		
		Session session = factory.openSession();
		Transaction t = session.getTransaction();
		
		Planet planet = new Planet();
		PlanetID id = new PlanetID();
		id.setPlanetId(11);
		id.setStarId(103145);
		planet.setId(id);
		planet.setPlanetClass("Terra");
		
		try {
			t.begin();
			session.save(planet);
			t.commit();
			System.out.println("record have been saved!");
		} catch (HibernateException ex) {
			ex.printStackTrace();
			if(t!=null){
				t.rollback();
			}
			
			session.close();
		}
		
	}

}
