package com.rish.models;

import java.io.Serializable;

public class Planet implements Serializable {
	
	private PlanetID id;
	private String planetClass;
	public PlanetID getId() {
		return id;
	}
	public void setId(PlanetID id) {
		this.id = id;
	}
	public String getPlanetClass() {
		return planetClass;
	}
	public void setPlanetClass(String planetClass) {
		this.planetClass = planetClass;
	}
	
	

}
