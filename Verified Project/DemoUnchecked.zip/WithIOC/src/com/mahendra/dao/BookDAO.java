package com.mahendra.dao;

import java.util.logging.Logger;

public class BookDAO {
	
	private static Logger log = Logger.getLogger(BookDAO.class.getCanonicalName());
	
	
	
	
	public BookDAO() {
		super();
		log.info("An Instance of BookDAO created");
	}

	public void someMethod(){
		log.info("someMethod is being called!");
	}
}
