package com.mahendra.dao;

import java.util.logging.Logger;

import javax.sql.DataSource;

public class BookDAO {

	private static Logger log = Logger.getLogger(BookDAO.class
			.getCanonicalName());

	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public BookDAO() {
		super();
		log.info("An Instance of BookDAO created");
	}

	public void someMethod() {
		log.info("someMethod is being called!");
	}

	public void getready() {
		log.info("Preparing book dao to perform data operations");
	}

	public void prepareToDie() {
		log.info("W'll meet in Hell !!");

	}
}
