package com.rish.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.rish.app.HibernateUtil;
import com.rish.models.Book;

public class BookDAO {
	private SessionFactory factory = HibernateUtil.getFactory();
	
	public Integer save(Book b){
		Session session = factory.openSession();
		Integer n = null;
		Transaction tn = session.getTransaction();
		System.out.println("Befor Try Block" + tn.isActive());
		try {
			tn.begin();
			System.out.println("after begin" +tn.isActive());
			n =(Integer) session.save(b);
			tn.commit();
			System.out.println("after commit" +tn.isActive());
		} catch(HibernateException ex) {
			if(tn!=null){
				tn.rollback();
				System.out.println("after rollback" + tn.isActive());
			}
			ex.printStackTrace();
		}
		session.close();
		return n;
	}
	
	public void update(Book b){
		Session session = factory.openSession();
		Transaction tn = session.getTransaction();
		try {
			tn.begin();
			session.update(b);
			tn.commit();
		} catch (HibernateException ex) {
			if(tn!=null){
				tn.rollback();
				System.out.println("after rollback" + tn.isActive());
			}
			ex.printStackTrace();
		}
		session.close();
	}
	
	public Book getById(Integer id){
		Session session = factory.openSession();
		Book b = null;
		b = (Book) session.createCriteria(Book.class).add(Restrictions.eq("bookId", id)).list().get(0);
		return b;
	}

}
