package com.rish.app;

import com.rish.dao.BookDAO;
import com.rish.models.Book;

public class TransactionDemo {
	public static void main(String[] args) {
		
		BookDAO dao = new BookDAO();
		
		//Commented for version test
		/*Book book =  new Book();
		book.setAuthor("Stephen Hawkings");
		book.setStatus("A");
		book.setTitle("The Universe is Nutshell");
		
		Integer id = dao.save(book);*/
		
		Book b = dao.getById(1);
		b.setTitle("Brief history of Time");
		dao.update(b);
		
		//System.out.println("Book saved with id : " +id);
	}
}
