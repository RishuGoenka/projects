package com.rish.dao;

import java.util.List;

import org.hibernate.*;

import com.rish.app.HibernateUtil;
import com.rish.models.Contact;

public class ContactDAO {

	private SessionFactory factory = null;

	public ContactDAO() {
		factory = HibernateUtil.getFactory();
	}

	public void save(Contact c) {
		Session session = factory.openSession();
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			session.save(c);
			tn.commit();
			System.out.println("Record Saved!");
		} catch (HibernateException ex) {
			if (tn != null)
				tn.rollback();

			ex.printStackTrace();
		}
		session.close();
	}

	public void modify(Contact c) {
		Session session = factory.openSession();
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			session.update(c);
			tn.commit();
			System.out.println("record Updated!");
		} catch (HibernateException ex) {
			if (tn != null)
				tn.rollback();

			ex.printStackTrace();
		}
		session.close();
	}

	public void remove(short contactId) {
		Session session = factory.openSession();
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			Object c = session.get(Contact.class, contactId);
			if (c != null) {
				session.delete(c);
				System.out.println("Record deleted.!");
			} else
				System.out.println("Record doesn't exists!!");
			tn.commit();
		} catch (HibernateException ex) {
			if (tn != null)
				tn.rollback();

			ex.printStackTrace();
		}
		session.close();
	}

	public List<Contact> findByName(String name) {
		Session session = factory.openSession();
		List<Contact> contacts = null;

		contacts = session
				.createQuery(
						"from Contact c where c.firstName = :nm or c.lastname = :nm")
				.setString("nm", name).list(); // name of class
												// not table name

		session.close();
		return contacts;
	}

}
