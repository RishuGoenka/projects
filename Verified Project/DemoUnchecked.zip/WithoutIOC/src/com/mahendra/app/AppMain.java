package com.mahendra.app;

import com.mahendra.services.LibraryService;

public class AppMain {

	public static void main(String[] args) {
		
		LibraryService service = new LibraryService();
		service.doSomething();
		//Again after few seconds....
		service.doSomething();
		

	}

}
