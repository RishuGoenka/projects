package com.rish.demo;
import java.util.Date;
import java.util.logging.Logger;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class DemoController {

	private static Logger log = Logger.getLogger(DemoController.class.getName());
	
	@RequestMapping(value= "/index.htm", method = RequestMethod.GET)
	public String doSomething(Model map){
		Date today = new Date();
		String msg = "Welcome to Spring!";
		log.info("Demo controller is processing your request!");
		map.addAttribute("msg", msg);
		map.addAttribute("date", today);
		//return "/WEB-INF/views/result.jsp";
		return "result";
	}
}
