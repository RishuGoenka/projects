package com.mahendra.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mahendra.models.Employee;

public class AppMain {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getFactory();
		Session session = factory.openSession();
		Employee e = (Employee) session.get(Employee.class, 7369);
		System.out.println(e.getName()+" working in "+e.getDepartment().getName());
		System.out.println(e.getHiredate());
		session.close();
	}
}
