package com.mahendra.demo1.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractFormController;

import com.mahendra.demo1.data.UserDAO;
import com.mahendra.demo1.model.User;

public class RegisterUserController extends AbstractFormController{
	
	private UserDAO dao;
		
	public void setDao(UserDAO dao) {
		this.dao = dao;
	}

	@Override
	protected ModelAndView processFormSubmission(HttpServletRequest arg0,
			HttpServletResponse arg1, Object arg2, BindException arg3)
			throws Exception {
		ModelAndView mv = null;
		if(arg2 instanceof User){
			User user = (User) arg2;			
			getValidator().validate(user, arg3);//Call validator
			try {
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			dao.add(user);
			mv = new ModelAndView("success");
			mv.addObject("msg", "User "+user.getUserName()+" now registered");			
		}
		return mv;
	}

	@Override
	protected ModelAndView showForm(HttpServletRequest arg0,
			HttpServletResponse arg1, BindException arg2) throws Exception {
		User user = new User();
		ModelAndView mv = new ModelAndView("form");
		//must MATCH with modelAttribute in form page
		mv.addObject("user", user); 
		return mv;
	}
}
