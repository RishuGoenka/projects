package com.rish.models;

public class SavingsAccount extends Account{

	private Double minBalance;

	public Double getMinBalance() {
		return minBalance;
	}

	public void setMinBalance(Double minBalance) {
		this.minBalance = minBalance;
	}
	
	
}
