package com.rish.app;

import java.util.Date;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.rish.models.LoanAccount;
import com.rish.models.SavingsAccount;

public class MainApp {
	public static void main(String[] args) {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		
		Session session = factory.openSession();
		Transaction t = session.getTransaction();
		
		SavingsAccount acc1 = new SavingsAccount();
		acc1.setAccountNo(101);
		acc1.setAccountHolder("Devdas");
		acc1.setDateOfOpening(new Date());
		acc1.setMinBalance(1000D);  //Double constants have 'D' suffix
		
		LoanAccount acc2 = new LoanAccount();
		acc2.setAccountHolder("Paro");
		acc2.setAccountNo(1048);
		acc2.setDateOfOpening(new Date());
		acc2.setInstallment(14063D);
		
		try {
			t.begin();
			session.save(acc1);
			session.save(acc2);
			t.commit();
			System.out.println("Both record have been saved!");
		} catch (HibernateException ex) {
			ex.printStackTrace();
			if(t!=null){
				t.rollback();
			}
		}
		
	}

}
