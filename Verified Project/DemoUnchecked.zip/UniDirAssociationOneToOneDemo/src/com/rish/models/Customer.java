package com.rish.models;

public class Customer {

	private Integer customerId;
	private Person personalInfo; // Reference to person object
	private String custType;
	private double dues;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(Integer customerId, Person personalInfo, String custType,
			double dues) {
		super();
		this.customerId = customerId;
		this.personalInfo = personalInfo;
		this.custType = custType;
		this.dues = dues;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public Person getPersonalInfo() {
		return personalInfo;
	}

	public void setPersonalInfo(Person personalInfo) {
		this.personalInfo = personalInfo;
	}

	public String getCustType() {
		return custType;
	}

	public void setCustType(String custType) {
		this.custType = custType;
	}

	public double getDues() {
		return dues;
	}

	public void setDues(double dues) {
		this.dues = dues;
	}

}
