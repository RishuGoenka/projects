package com.mahendra.services;

import java.util.logging.Logger;

import com.mahendra.dao.BookDAO;
import com.mahendra.dao.MemberDAO;

public class LibraryService {
	private static Logger log = Logger.getLogger(LibraryService.class
			.getCanonicalName());

	private BookDAO bookDao;
	private MemberDAO memberDao;

	// An example of Dependency injection by constructor
	// Also called as CONSTRUCTOR INJECTION
	public LibraryService() {

	}

	public LibraryService(BookDAO bookDao,MemberDAO memberDao) {
		this.bookDao = bookDao;
		this.memberDao = memberDao;
	}

	// An example of Dependency injection by setter
	// Also called as SETTER INJECTION
	public void setBookDao(BookDAO dao) {
		this.bookDao = dao;
	}

	public void setMemberDao(MemberDAO memberDao) {
		this.memberDao = memberDao;
	}

	public void doSomething() {
		log.info("Calling required methods ");
		bookDao.someMethod();
		memberDao.someMethod();
	}
}
