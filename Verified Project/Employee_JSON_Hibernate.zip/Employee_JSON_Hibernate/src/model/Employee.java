package model;

public class Employee {

	private long employeeID;
	private String employeeName;
	private int age;
	private String department;
	private double salary;

	public Employee(long employeeID, String employeeName, int age, String department, double salary) {
		this.employeeID = employeeID;
		this.employeeName = employeeName;
		this.age = age;
		this.department = department;
		this.salary = salary;
	}

	public long getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(long employeeID) {
		this.employeeID = employeeID;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [employeeID=" + employeeID + ", employeeName=" + employeeName + ", age=" + age
				+ ", department=" + department + ", salary=" + salary + "]";
	}

}
