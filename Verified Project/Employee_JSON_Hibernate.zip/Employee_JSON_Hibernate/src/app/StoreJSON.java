package app;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Employee;

import com.google.gson.Gson;

public class StoreJSON {

	public static void main(String[] args) throws IOException {
		SessionFactory factory = new Configuration().configure().buildSessionFactory();

		Session session = factory.openSession();
		Transaction transaction = session.getTransaction();

		// Valid File Path Declaration needed.
		BufferedReader reader = new BufferedReader(new FileReader("./employee.json"));
		Gson gson = new Gson();
		Employee[] employee = gson.fromJson(reader, Employee[].class);
		reader.close();

		try {
			transaction.begin();
			for (int i = 1; i < employee.length; i++)
				session.save(employee[i]);
			transaction.commit();
			System.out.println("record have been saved!");
			System.out.println(((Employee) session.get(Employee.class, 3L)));
		} catch (HibernateException ex) {
			ex.printStackTrace();
			if (transaction != null) {
				transaction.rollback();
			}

			session.close();
		}

	}

}
