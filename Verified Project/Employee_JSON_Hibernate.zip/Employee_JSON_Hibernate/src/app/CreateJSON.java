package app;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import model.Employee;

import com.google.gson.Gson;

public class CreateJSON {

	public static void main(String[] args) throws IOException {
		List<Employee> employees = new ArrayList<Employee>();

		Random arbitrary = new Random();
		for (int i = 1; i < 101; i++) {
			long employeeID = i;
			String employeeName = "Employee" + i;
			int age = arbitrary.nextInt(60) + 20;
			String department = "Department" + i;
			double salary = arbitrary.nextInt(i + 1);
			Employee employee = new Employee(employeeID, employeeName, age, department, salary);
			employees.add(employee);
		}
		// Valid File Path Declaration needed.
		Writer writer = new FileWriter("./employee.json");
		Gson gson = new Gson();
		gson.toJson(employees, writer);
		System.out.println("File Created");
		writer.close();

	}
}
