package app;

import model.Employee;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdateDataBase {

	public static void main(String[] args) {
		SessionFactory factory = new Configuration().configure()
				.buildSessionFactory();

		Session session = factory.openSession();
		Transaction transaction = session.getTransaction();

		Employee employee = new Employee(1227, "gfdg", 11212, "fgf", 523);

		try {
			transaction.begin();
			session.save(employee);
			transaction.commit();
			System.out.println("record have been saved!");
		} catch (HibernateException ex) {
			ex.printStackTrace();
			if (transaction != null) {
				transaction.rollback();
			}

			session.close();
		}

	}
}