package com.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbApp {

public static void main(String[] args) {
		
		//Step 0 : Load Properties
		
		Properties ps = new Properties();
		try {
			ps.load(DbApp.class.getResourceAsStream("/db.properties"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		//Step 1 : Load JDBC Driver
		
		try {
			Class.forName(ps.getProperty("driver"));
		} catch (ClassNotFoundException e2) {
			e2.printStackTrace();
		}
		
		//Step 2 : Connect to DB Server
		Connection con = null;
		
		try {
			con = DriverManager.getConnection(ps.getProperty("url"),ps.getProperty("user"),ps.getProperty("password"));
			System.out.println("Connect to "+ con.getMetaData().getDatabaseProductName());
		} catch (SQLException e3) {
			e3.printStackTrace();
		}
		
		finally 	{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		System.out.println("END");
		
		

	}
	
}
