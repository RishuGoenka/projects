package com.db;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbUtil {

	private static Properties loadProperties(String propFile)	{
		Properties ps = new Properties();
		try {
			ps.load(DbApp.class.getResourceAsStream(propFile));
		} catch (IOException e) {
			throw new RuntimeException("Unable to load db.properties",e);
		}
		return ps;
	}
	
	public static Connection openConnection()	{
		Properties ps = loadProperties("/db.properties");
		Connection con = null;
		
		//Step 1 : Load JDBC Driver
		try {
			Class.forName(ps.getProperty("driver"));
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Unable to load JDBC Driver",e);
		}
		
		//Step 2 : Connect to DB server
		
		try {
			con = DriverManager.getConnection(ps.getProperty("url"),ps.getProperty("user"),ps.getProperty("password"));
			System.out.println("Connect to " +con.getMetaData().getDatabaseProductName());
		} catch (SQLException ex) {
			throw new RuntimeException("Unable to connect",ex);
		}
		return con;
	}
	
	public static void closeConnection(Connection con)	{
		
		try 	{
			if(con!=null)
				con.close();
		} catch (SQLException e)	{
			throw new RuntimeException("Unable to close connection",e);
		}
	}
	
}
