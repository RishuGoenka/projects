package com.mart.bean;

import java.io.Serializable;

public class OrderList implements Serializable {

	private int orderId;
	private int prodno;
	private int prodId;
	private int quantity;
	
	public OrderList(int orderId, int prodno, int prodId, int quantity) {
		super();
		this.orderId = orderId;
		this.prodno = prodno;
		this.prodId = prodId;
		this.quantity = quantity;
	}

	public OrderList() {
		super();
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getProdno() {
		return prodno;
	}

	public void setProdno(int prodno) {
		this.prodno = prodno;
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
		
}
