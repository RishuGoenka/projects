package com.mart.bean;

import java.io.Serializable;

public class Product implements Serializable {

	private int prodId;
	private String prodName;
	private int price;
	private String description;
	private String category;
	
	public Product(int prodId, String prodName, int price, String description,
			String category) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.price = price;
		this.description = description;
		this.category = category;
	}

	public Product() {
		super();
	}

	public int getProdId() {
		return prodId;
	}

	public void setProdId(int prodId) {
		this.prodId = prodId;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
		
}
