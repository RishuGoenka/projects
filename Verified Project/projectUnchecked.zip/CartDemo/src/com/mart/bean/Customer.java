package com.mart.bean;

import java.io.Serializable;

public class Customer implements Serializable {

	private int custId;
	private String custName;
	private String custPhone;
	private String custAdd;
	
	public Customer(int custId, String custName, String custPhone,
			String custAdd) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custPhone = custPhone;
		this.custAdd = custAdd;
	}

	public Customer() {
		super();
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustPhone() {
		return custPhone;
	}

	public void setCustPhone(String custPhone) {
		this.custPhone = custPhone;
	}

	public String getCustAdd() {
		return custAdd;
	}

	public void setCustAdd(String custAdd) {
		this.custAdd = custAdd;
	}
	
}
