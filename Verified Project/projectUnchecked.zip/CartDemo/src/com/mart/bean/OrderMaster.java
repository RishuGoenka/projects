package com.mart.bean;

import java.io.Serializable;
import java.sql.Date;

public class OrderMaster implements Serializable {

	private int orderId;
	private int custId;
	private java.sql.Date orderDate;
	private String shipAdd;
	private int payAmt;
	
	public OrderMaster(int orderId, int custId, Date orderDate, String shipAdd,
			int payAmt) {
		super();
		this.orderId = orderId;
		this.custId = custId;
		this.orderDate = orderDate;
		this.shipAdd = shipAdd;
		this.payAmt = payAmt;
	}

	public OrderMaster() {
		super();
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public java.sql.Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(java.sql.Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getShipAdd() {
		return shipAdd;
	}

	public void setShipAdd(String shipAdd) {
		this.shipAdd = shipAdd;
	}

	public int getPayAmt() {
		return payAmt;
	}

	public void setPayAmt(int payAmt) {
		this.payAmt = payAmt;
	}
	
}
