package com.mart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mart.bean.Customer;
import com.db.DbUtil;

public class CustomerDAO {

	private static final String INSERT_QUERY = "insert into customer values (?,?,?,?)";
	private static final String RETRIEVE_QUERY = "select * from customer";
	
	public void insert(Customer cust)	{
		int n = 0;
		Connection con = null;
		
		con = DbUtil.openConnection();
		
		try {
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);
			ps.setInt(1, cust.getCustId());
			ps.setString(2, cust.getCustName());
			ps.setString(3, cust.getCustPhone());
			ps.setString(4, cust.getCustAdd());
			
			n = ps.executeUpdate();
			
			System.out.println(n + " Record Inserted . . .");
		} catch (SQLException e) {
			System.out.println("Unable to add new Customer ..");
			e.printStackTrace();
		}
		DbUtil.closeConnection(con);
	}
	
	public List<Customer> retrieve()	{
		Customer cust = null;
		Connection con = DbUtil.openConnection();
		
		List<Customer> cl=new ArrayList<Customer>();
		
		PreparedStatement ps;
		
		try {
			ps = con.prepareStatement(RETRIEVE_QUERY);
			
			ResultSet rs = ps.executeQuery();
			
			while (rs.next())	{
				cust= new Customer();
				cust.setCustId(rs.getInt(1));
				cust.setCustName(rs.getString(2));
				cust.setCustPhone(rs.getString(3));
				cust.setCustAdd(rs.getString(4));
				cl.add(cust);
				
			}
			
		
		} catch (SQLException e) {
			System.out.println("Unable to find Customer . . .");
			e.printStackTrace();
		}
		DbUtil.closeConnection(con);
		return cl;		
	}
	
}
