package com.mahendra.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mahendra.models.Article;
import com.mahendra.models.ArticleDAO;
import com.mahendra.models.CommentDAO;

/**
 * Servlet implementation class HomeServlet
 */
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HomeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Get Both DAO's from Application scope
		ArticleDAO adao = (ArticleDAO) getServletContext().getAttribute("articleDao");
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><head><title>My Blog </title></head>");
		out.println("<body>");
		out.println("<h2>The Articles </h2>");
		List<Article> articles = adao.getAll();
		for(Article a : articles){
			out.println("<div class='para'>");
			out.println("Author: "+ a.getAuthor()+", ID <b>"+a.getArticleId()+"</b><br/>");
			out.println("<p>"+a.getText()+"</p>");
			out.println("Date of Post: "+ a.getDateOfPost()+"<br/>");
			out.println("<a href='show-comment.htm?article="+a.getArticleId()+"'>Show Comments</a>");
			out.println("</div>");
		}
		
		out.println("</body></html>");
		out.close();
	}

}
