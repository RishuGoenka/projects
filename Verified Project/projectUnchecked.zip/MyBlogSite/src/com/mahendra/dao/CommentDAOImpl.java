package com.mahendra.dao;

import java.util.LinkedList;
import java.util.List;

import com.mahendra.models.Comment;
import com.mahendra.models.CommentDAO;

public class CommentDAOImpl implements CommentDAO {
List<Comment> comments = null;

	public CommentDAOImpl(List<Comment> comments) {
	this.comments = comments;
}

	@Override
	public int add(Comment comment) {
		int id = 1;
		if(comments == null)
			comments = new LinkedList<Comment>();
		if(!comments.isEmpty())
			id = comments.size()+1;	
		comments.add(comment);
		return id;
	}

	@Override
	public List<Comment> getCommentForArticleId(int id) {
		List<Comment> temp = new LinkedList<Comment>();
		for(Comment c : comments){
			if(c.getArticleId() == id){
				temp.add(c);
			}
		}
		return temp;
	}

	@Override
	public Comment findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
