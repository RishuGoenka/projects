package com.mahendra.models;

import java.util.List;

public interface CommentDAO {

	int add(Comment comment);
	List<Comment> getCommentForArticleId(int id);
	Comment findById(int id);
}
