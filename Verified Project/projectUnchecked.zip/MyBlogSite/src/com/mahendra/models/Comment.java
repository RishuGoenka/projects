package com.mahendra.models;

import java.io.Serializable;
import java.util.Date;

public class Comment implements Serializable {
	private int commentId;
	private String text;
	private String user;
	private Date dateOfPost;
	private String clientIp;
	private int articleId;
	
	public int getCommentId() {
		return commentId;
	}
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public Date getDateOfPost() {
		return dateOfPost;
	}
	public void setDateOfPost(Date dateOfPost) {
		this.dateOfPost = dateOfPost;
	}
	public String getClientIp() {
		return clientIp;
	}
	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}
	public int getArticleId() {
		return articleId;
	}
	public void setArticleId(int articleId) {
		this.articleId = articleId;
	}
}
