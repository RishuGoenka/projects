package com.movierental.model;

import java.io.Serializable;

public class MovieGenre implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Movie movie;
	private Genre genre;

	public MovieGenre() {
		super();
	}

	public MovieGenre(Movie movie, Genre genre) {
		super();
		this.movie = movie;
		this.genre = genre;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public Genre getgenre() {
		return genre;
	}

	public void setgenre(Genre genre) {
		this.genre = genre;
	}

	@Override
	public String toString() {
		return "Moviegenre [movie=" + movie + ", genre=" + genre + "]";
	}
}
