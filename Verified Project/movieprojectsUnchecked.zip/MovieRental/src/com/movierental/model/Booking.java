package com.movierental.model;

import java.io.Serializable;

public class Booking implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int bookingId;
	private User user;
	private Movie movie;
	private String startTime;
	private String endTime;

	public Booking() {
		super();
	}

	public Booking(User user, Movie movie, String startTime, String endTime) {
		super();
		this.user = user;
		this.movie = movie;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", user=" + user
				+ ", movie=" + movie + ", startTime=" + startTime
				+ ", endTime=" + endTime + "]";
	}

}
