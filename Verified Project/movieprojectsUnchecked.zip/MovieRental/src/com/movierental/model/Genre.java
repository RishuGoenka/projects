package com.movierental.model;

import java.io.Serializable;

public class Genre implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int genreId;
	private String genre;

	public Genre() {
		super();
	}

	public Genre(String genre) {
		super();
		this.genre = genre;
	}

	public int getgenreId() {
		return genreId;
	}

	public void setgenreId(int genreId) {
		this.genreId = genreId;
	}

	public String getgenre() {
		return genre;
	}

	public void setgenre(String genre) {
		this.genre = genre;
	}

	@Override
	public String toString() {
		return "genre [genreId=" + genreId + ", genre=" + genre + "]";
	}

}
