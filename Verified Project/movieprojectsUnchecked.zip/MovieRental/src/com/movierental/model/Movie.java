package com.movierental.model;

import java.io.Serializable;

public class Movie implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int movieId;
	private String movieTitle;
	private double movieCost;

	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Movie(String movieTitle, double movieCost) {
		super();
		this.movieTitle = movieTitle;
		this.movieCost = movieCost;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public double getMovieCost() {
		return movieCost;
	}

	public void setMovieCost(double movieCost) {
		this.movieCost = movieCost;
	}

	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieTitle=" + movieTitle
				+ ", movieCost=" + movieCost + "]";
	}

}
