package com.movierental.utility;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	private static SessionFactory factory = build();

	private static SessionFactory build() {
		Configuration config = new Configuration().configure();
		SessionFactory factory = config.buildSessionFactory();
		return factory;
	}

	public static SessionFactory getFactory() {
		return factory;
	}
}
