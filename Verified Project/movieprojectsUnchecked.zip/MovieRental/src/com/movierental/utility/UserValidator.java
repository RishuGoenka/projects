package com.movierental.utility;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.movierental.model.User;

public class UserValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {
		// If Instance of arg0 can be assigned to variable of Type User
		// Then this validator can validate it
		// SIMPLE WORDS: Any class inherited from User
		return arg0.isAssignableFrom(User.class);

		// VALIDATE ONLY User class and not derived one's
		// return User.class.equals(arg0);
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		User user = (User) arg0; // TypeCast target instance into User type

		// Using Util methods to generated 'FieldErrors'
		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "userName",
				"empty.username", "Please enter username");
		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "password",
				"empty.password", "Please enter password");

		// Manually generated errors
		if (user.getPassword().trim().length() < 8) {
			arg1.rejectValue("password", "invalid.password",
					"At least 8 characters in password");
		}

	}

}
