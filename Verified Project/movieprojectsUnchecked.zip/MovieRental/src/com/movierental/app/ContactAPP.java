package com.movierental.app;

public class ContactAPP {

	public static void main(String[] args) {
		
	}

}
