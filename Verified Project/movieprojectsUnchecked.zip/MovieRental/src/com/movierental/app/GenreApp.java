package com.movierental.app;

public class GenreApp {
	public static void main(String[] args) {

	}
}
