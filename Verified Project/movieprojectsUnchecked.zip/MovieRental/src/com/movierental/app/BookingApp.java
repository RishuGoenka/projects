package com.movierental.app;

public class BookingApp {

	public static void main(String[] args) {

	}

}
