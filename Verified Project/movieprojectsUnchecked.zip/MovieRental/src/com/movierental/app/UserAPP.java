package com.movierental.app;

public class UserAPP {
	public static void main(String[] args) {

	}
}
