package com.movierental.app;

public class MovieAPP {
	public static void main(String[] args) {

	}
}
