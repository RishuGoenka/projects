package com.movierental.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.movierental.model.MovieGenre;
import com.movierental.model.User;
@Transactional
@Repository
public class MovieGenreDAOImpl implements MovieGenreDAO{
	
	@PersistenceContext
	private EntityManager manager;
	
	private static List<MovieGenre> moviegenreList;

	
	@Override
	public boolean saveMoveGenre(MovieGenre movegenreObj) {
		try {
			manager.persist(movegenreObj);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} 
	}
	@Override
	public void updateMovieGenre(MovieGenre movegenreObj) {
		public void updateEmployee(Integer EmployeeID, int salary ){
		      Session session = factory.openSession();
		      Transaction tx = null;
		      try{
		         tx = session.beginTransaction();
		         Employee employee = 
		                    (Employee)session.get(Employee.class, EmployeeID); 
		         employee.setSalary( salary );
				 session.update(employee); 
		         tx.commit();
		      }catch (HibernateException e) {
		         if (tx!=null) tx.rollback();
		         e.printStackTrace(); 
		      }finally {
		         session.close(); 
		      }
	}

	@Override
	public void deleteByMovieId(Integer movieId) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.delete(session.get(MovieGenre.class, movieId));
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public void deleteByGenreId(Integer genreId) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.delete(session.get(MovieGenre.class, genreId));
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}
	@Override
	public void deleteById(Integer movieId, Integer genreId) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.delete(session.createQuery("FROM MovieGenre moviegenre where moviegenre.movieId =:movieId & moviegenre.genreId =:genreId")
					.setParameter("movieId", movieId).setParameter("genreId", genreId).uniqueResult());
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}
	@Override
	public List<MovieGenre> getAllMappingByMovieId(Integer movieId) {
		try {
			session = factory.openSession();
			moviegenreList = session.createQuery("FROM MovieGenre moviegenre where moviegenre.movieId =:movieId")
					.setParameter("movieId", movieId).list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return moviegenreList;
	}

	@Override
	public List<MovieGenre> getAllmappingByGenreId(Integer genreId) {
		try {
			session = factory.openSession();
			moviegenreList = session.createQuery("FROM MovieGenre moviegenre where moviegenre.genreId =:genreId")
					.setParameter("genreId", genreId).list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return moviegenreList;
	}

}
