package com.movierental.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.movierental.model.Booking;
import com.movierental.model.User;

public class BookingDAOImpl implements BookingDAO{
	private static SessionFactory factory = null;
	private static Session session = null;
	private static Transaction tx = null;
	private static Booking bookingObj;
	private static List<Booking> bookingList;

	public BookingDAOImpl() {
		factory = new Configuration().configure().buildSessionFactory();
	}

	@Override
	public void saveBooking(Booking bookingObj) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.save(bookingObj);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public void deleteBooking(Integer bookingId) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.delete(session.get(Booking.class, bookingId));
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public Booking getBookingByID(Integer bookingId) {
		try {
			session = factory.openSession();
			bookingObj = (Booking) session.get(Booking.class, bookingId);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return bookingObj;
	}

	@Override
	public List<Booking> getAllBookings() {
		try {
			session = factory.openSession();
			bookingList = session.createQuery("FROM Booking").list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return bookingList;
	}

	@Override
	public List<Booking> getAllBookingsByUserID(Integer userId) {
		try {
			session = factory.openSession();
			bookingList= session.createQuery(
					"Select booking from Booking booking where booking.userId =:userId").setParameter("userId", userId).list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return bookingList;
	}

	@Override
	public List<Booking> getAllBookingsByMovieID(Integer movieId) {
		try {
			session = factory.openSession();
			bookingList = session.createQuery(
					"Select booking from Booking booking where booking.movieId =:movieId").setParameter("movieId", movieId).list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return bookingList;
	}

	@Override
	public long getNoOfBookings() {
		long bookingCount = 0;
		try {
			session = factory.openSession();
			bookingCount = (long) session.createQuery(
					"Select COUNT(booking) from Booking booking")
					.uniqueResult();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return bookingCount;
	}

	@Override
	public long getNoOfBookingsByUserID(Integer userId) {
		long userbookingCount = 0;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			userbookingCount = (long) session.createQuery(
					"Select COUNT(booking) from Booking booking where booking.userId =:userId").setParameter("userId", userId)
					.uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return userbookingCount;
	}

	@Override
	public long getNoOfBookingsByMovieID(Integer movieId) {
		long moviebookingCount = 0;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			moviebookingCount = (long) session.createQuery(
					"Select COUNT(booking) from Booking booking where booking.movieId =:movieId").setParameter("movieId", movieId)
					.uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return moviebookingCount;
	}

}
