package com.movierental.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class BookingDAOImplTest {
	BookingDAOImpl bookingDao = new BookingDAOImpl();
	@Test
	public void testGetAllBookings() {
		while(true){
			bookingDao.getAllBookings();
		}
	}

}
