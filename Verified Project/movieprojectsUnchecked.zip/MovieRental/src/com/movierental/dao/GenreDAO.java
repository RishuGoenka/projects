package com.movierental.dao;

import java.util.List;

import com.movierental.model.Genre;

public interface GenreDAO {
	/**
	 * Method to Saves Genre object passed to it.
	 * 
	 * @param genreObj
	 */
	public void saveGenre(Genre genreObj);

	/**
	 * Method to Update Genre object whose genreId and new genre passed to it.
	 * 
	 * @param genreId
	 * @param genre
	 */
	public void updateGenre(Integer genreId, String genre);

	/**
	 * Method to Delete Genre GenreID passed to it.
	 * 
	 * @param genreId
	 */
	public abstract void deleteGenre(Integer genreId);
	
	/**
	 * Return a list of all the Genre if empty it return an empty list
	 * 
	 * @return genreList
	 */
	public abstract List<Genre> getAllGenres();

	/**
	 * Returns true if Genre already exist in the database or else returns
	 * false
	 * 
	 * @param genre
	 * @return true/false
	 */
	public abstract boolean isGenreAvailable(String genre);

	/**
	 * get total number of Genre
	 * 
	 * @return genresCount
	 */
	public int getNoOfGenres();
}
