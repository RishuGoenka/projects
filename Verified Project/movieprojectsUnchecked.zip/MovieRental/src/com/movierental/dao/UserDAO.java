package com.movierental.dao;

import java.util.List;

import com.movierental.model.User;

public interface UserDAO {
	/**
	 * Method to Saves User object passed to it.
	 * 
	 * @param userObj
	 */
	public void saveUser(User userObj);

	/**
	 * Method to Delete User by UserID passed to it.
	 * 
	 * @param userId
	 */
	public abstract void deleteUser(Integer userId);

	/**
	 * Returns user Object of the User whose userId is passed to it else return
	 * null
	 * 
	 * @param userId
	 * @return user
	 */
	public abstract User getUserByID(Integer userId);

	/**
	 * Return a list of all the Users if empty it return an empty list
	 * 
	 * @return userList
	 */
	public abstract List<User> getAllUsers();

	/**
	 * Returns Object of User whose emailId is passed or else returns null
	 * 
	 * @param email
	 * @return userObj
	 */
	public abstract User getUserByEmail(String email);

	/**
	 * Returns true if the email already exist or matches in the database or else returns
	 * false
	 * 
	 * @param email
	 * @return true/false
	 */
	public abstract boolean isEmailAvailable(String email);
	
	/**
	 * get total number of Users
	 * 
	 * @return usersCount
	 */
	public long getNoOfUsers();
}
