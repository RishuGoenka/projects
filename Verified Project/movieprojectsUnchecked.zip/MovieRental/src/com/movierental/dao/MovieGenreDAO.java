package com.movierental.dao;

import java.util.List;

import com.movierental.model.MovieGenre;

public interface MovieGenreDAO {
	/**
	 * Method to Saves MoveGenre object passed to it.
	 * 
	 * @param MoveGenreObject
	 * @return 
	 */
	public boolean saveMoveGenre(MovieGenre movegenreObj);

	/**
	 * Method to Update MoveGener object passed to it.
	 * 
	 * @param MoveGenerObject
	 */
	public void updateMovieGenre(MovieGenre movegenreObj);

	/**
	 * Method to Delete MovieGenre movieId passed to it.
	 * 
	 * @param movieId
	 */
	public abstract void deleteByMovieId(Integer movieId);

	/**
	 * Method to Delete MovieGenre genreId passed to it.
	 * 
	 * @param genreId
	 */
	public abstract void deleteByGenreId(Integer genreId);

	/**
	 * Method to Delete MovieGenre genreId and movieId passed to it.
	 * 
	 * @param movieId
	 * @param genreId
	 */
	public abstract void deleteById(Integer movieId, Integer genreId);

	/**
	 * Return a list of all the MovieId and GenreId whose MovieId is passed if
	 * empty it return an empty list
	 * 
	 * @return movieIdMap
	 */
	public abstract List<MovieGenre> getAllMappingByMovieId(Integer movieId);

	/**
	 * Return a list of all the MovieId and GenreId whose GenreId is passed if
	 * empty it return an empty list
	 * 
	 * @return genreIdMap
	 */
	public abstract List<MovieGenre> getAllmappingByGenreId(Integer genreId);
}
