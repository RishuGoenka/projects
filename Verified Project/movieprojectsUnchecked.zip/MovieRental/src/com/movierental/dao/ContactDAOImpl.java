package com.movierental.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.movierental.model.Contact;

public class ContactDAOImpl implements ContactDAO{
	private static SessionFactory factory = null;
	private static Session session = null;
	private static Transaction tx = null;
	
	public ContactDAOImpl() {
		factory = new Configuration().configure().buildSessionFactory();
	}


	@Override
	public void saveUser(Contact contact) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.save(contact);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public void deleteContact(Integer contactId) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.delete(session.get(Contact.class, contactId));
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public Contact getContactByID(Integer contactId) {
		Contact contactObj = null;
		try {
			session = factory.openSession();
			contactObj = (Contact) session.get(Contact.class, contactId);
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return contactObj;
	}

	@Override
	public List<Contact> getAllContacts() {
		List<Contact> contactList = null;
		try {
			session = factory.openSession();
			contactList = session.createQuery("FROM Contact").list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return contactList;
	}

}
