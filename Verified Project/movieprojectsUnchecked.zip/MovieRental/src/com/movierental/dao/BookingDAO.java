package com.movierental.dao;

import java.util.List;

import com.movierental.model.Booking;

public interface BookingDAO {
	/**
	 * Method to Saves Booking object passed to it.
	 * 
	 * @param bookingObj
	 */
	public void saveBooking(Booking bookingObj);

	/**
	 * Method to Delete Booking whose BookingID passed to it.
	 * 
	 * @param bookingId
	 */
	public abstract void deleteBooking(Integer bookingId);

	/**
	 * returns Booking Object whose bookingId is passed to it else return null
	 * 
	 * @param bookingId
	 * @return bookingObj
	 */
	public abstract Booking getBookingByID(Integer bookingId);

	/**
	 * Return a list of all the Booking if empty it return an empty list
	 * 
	 * @return bookingList
	 */
	public abstract List<Booking> getAllBookings();

	/**
	 * Return a list of all the Booking whose userID is passed to it if empty it
	 * return an empty list
	 * 
	 * @return bookingUserList
	 */
	public abstract List<Booking> getAllBookingsByUserID(Integer userId);

	/**
	 * Return a list of all the Booking whose MovieID is passed to it if empty
	 * it return an empty list
	 * 
	 * @return bookingMovieList
	 */
	public abstract List<Booking> getAllBookingsByMovieID(Integer movieId);

	/**
	 * get total number of Bookings
	 * 
	 * @return bookingCount
	 */
	public long getNoOfBookings();

	/**
	 * get total number of Bookings whose userId is passed
	 * 
	 * @return userBookingCount
	 */
	public long getNoOfBookingsByUserID(Integer userId);

	/**
	 * get total number of Bookings whose movieId is passed
	 * 
	 * @return movieBookingCount
	 */
	public long getNoOfBookingsByMovieID(Integer movieId);
}
