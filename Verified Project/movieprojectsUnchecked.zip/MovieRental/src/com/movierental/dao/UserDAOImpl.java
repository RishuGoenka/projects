package com.movierental.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.movierental.model.User;

public class UserDAOImpl implements UserDAO {
	private static SessionFactory factory = null;
	private static Session session = null;
	private static Transaction tx = null;
	private static User userObj;
	private static List<User> userList;

	public UserDAOImpl() {
		factory = new Configuration().configure().buildSessionFactory();
	}

	@Override
	public void saveUser(User userObj) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.save(userObj);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public void deleteUser(Integer userId) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.delete(session.get(User.class, userId));
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public User getUserByID(Integer userId) {
		try {
			session = factory.openSession();
			userObj = (User) session.get(User.class, userId);
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return userObj;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<User> getAllUsers() {
		try {
			session = factory.openSession();
			userList = session.createQuery("FROM User").list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return userList;
	}

	@Override
	public User getUserByEmail(String email) {
		try {
			session = factory.openSession();
			userObj = (User) session
					.createQuery(
							"Select user from User user where user.email =:email")
					.setParameter("email", email).list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		if (userList.size() >= 1) {
			return userObj;
		} else {
			return null;
		}
	}

	@Override
	public boolean isEmailAvailable(String email) {
		int total = 0;
		try {
			session = factory.openSession();
			total = (int) session
					.createQuery(
							"Select COUNT(user) from User user where user.email =:email")
					.setParameter("email", email).uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		if (total == 1)
			return true;
		else
			return false;
	}

	@Override
	public long getNoOfUsers() {
		long usersCount = 0;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			usersCount = (long) session.createQuery(
					"Select COUNT(u) from User u where u.role='ROLE_USER'")
					.uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return usersCount;
	}
}
