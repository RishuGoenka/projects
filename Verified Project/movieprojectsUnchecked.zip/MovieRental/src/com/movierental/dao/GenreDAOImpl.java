package com.movierental.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.movierental.model.Genre;

public class GenreDAOImpl implements GenreDAO {
	private static SessionFactory factory = null;
	private static Session session = null;
	private static Transaction tx = null;
	private static Genre genreObj;
	private static List<Genre> genreList;

	public GenreDAOImpl() {
		factory = new Configuration().configure().buildSessionFactory();
	}

	@Override
	public void saveGenre(Genre genreObj) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.save(genreObj);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public void updateGenre(Integer genreId, String genre) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			genreObj = (Genre) session.get(Genre.class, genreId);
			genreObj.setgenre(genre);
			session.update(genreObj);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@Override
	public void deleteGenre(Integer genreId) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.delete(session.get(Genre.class, genreId));
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public List<Genre> getAllGenres() {
		try {
			session = factory.openSession();
			genreList = session.createQuery("FROM Genre").list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return genreList;
	}

	@Override
	public boolean isGenreAvailable(String genre) {
		int total = 0;
		try {
			session = factory.openSession();
			total = (int) session
					.createQuery(
							"Select COUNT(genre) from Genre genre where genre.genre =:genre")
					.setParameter("genre", genre).uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		if (total == 1)
			return true;
		else
			return false;
	}

	@Override
	public int getNoOfGenres() {
		int genresCount = 0;
		try {
			session = factory.openSession();
			genresCount = session.createQuery("from Genre").list()
					.size();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return genresCount;
	}

}
