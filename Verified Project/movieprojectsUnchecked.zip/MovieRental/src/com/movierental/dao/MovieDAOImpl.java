package com.movierental.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.movierental.model.Movie;
import com.movierental.model.User;

public class MovieDAOImpl implements MovieDAO {
	private static SessionFactory factory = null;
	private static Session session = null;
	private static Transaction tx = null;
	private static Movie movieObj;
	private static List<Movie> movieList;

	public MovieDAOImpl() {
		factory = new Configuration().configure().buildSessionFactory();
	}

	@Override
	public void saveMovie(Movie movieObj) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.save(movieObj);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public void updateMovie(Integer movieId, double cost) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			movieObj = (Movie) session.get(Movie.class, movieId);
			movieObj.setMovieCost(cost);
			session.update(movieObj);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}
	}

	@Override
	public void deleteMovie(Integer movieId) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.delete(session.get(Movie.class, movieId));
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	@Override
	public Movie getMovieByID(Integer movieId) {
		try {
			session = factory.openSession();
			movieObj = (Movie) session.get(Movie.class, movieId);
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return movieObj;
	}

	@Override
	public List<Movie> getAllMovies() {
		try {
			session = factory.openSession();
			movieList = session.createQuery("FROM Movie").list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return movieList;
	}

	@Override
	public Movie getMovieByTitle(String movieTitle) {
		try {
			session = factory.openSession();
			movieObj = (Movie) session.get(Movie.class, movieTitle);
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return movieObj;
	}

	@Override
	public List<Movie> getMovieByCost(String movieCost) {
		try {
			session = factory.openSession();
			movieList = session
					.createQuery(
							"Select movie from Movie movie where movie.movieCost =:movieCost")
					.setParameter("movieCost", movieCost).list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		if (movieList.size() >= 1) {
			return movieList;
		} else {
			return null;
		}
	}

	@Override
	public long getNoOfMovies() {
		long moveCount = 0;
		try {
			session = factory.openSession();
			moveCount = (long) session.createQuery(
					"Select COUNT(movie) from Movie movie").uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return moveCount;
	}

}
