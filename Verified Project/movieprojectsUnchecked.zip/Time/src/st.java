import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class st {

	public static void main(String[] args) throws ParseException {

		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = new Date();
		System.out.println(dateFormat.format(date));
		
		String dt = dateFormat.format(date);
		Calendar c = Calendar.getInstance();
		c.setTime(dateFormat.parse(dt));
		c.add(Calendar.DATE, 30);  // number of days to add
		dt = dateFormat.format(c.getTime());  // dt is now the new date
		
		System.out.println(dt);
	}
}