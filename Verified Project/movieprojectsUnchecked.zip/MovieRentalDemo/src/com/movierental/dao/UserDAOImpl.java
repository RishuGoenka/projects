package com.movierental.dao;

import java.util.List;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.movierental.model.User;

public abstract class UserDAOImpl implements UserDAO {
	private static SessionFactory factory = null;
	private static Session session = null;
	private static Transaction tx = null;
	private static User user = null;
	private static List<User> userList = null;

	public UserDAOImpl() {
		factory = new Configuration().configure().buildSessionFactory();
	}

	public void saveUser(User userObj) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			session.save(userObj);
			tx.commit();
			System.out.println(" Record created ");
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}
		session.close();
	}

	public void deleteUser(Integer userId) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			User user = (User) session.get(User.class, userId);
			session.delete(user);
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
	}

	public User getUserById(Integer userId) {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			user = (User) session.load(User.class, userId);
			Hibernate.initialize(user);
			tx.commit();
		} catch (Exception e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen()) {
				session.close();
			}
		}
		return user;
	}

	public List<User> getAllUsers() {
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			userList = session.createQuery("FROM Employee").list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return userList;
	}

	public User getUserByEmail(String email) {
		try {
			session = factory.openSession();
			userList = session
					.createQuery(
							"Select user from User user where user.email =:email")
					.setString("email", email).list();
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		if (userList.size() >= 1) {
			return userList.get(0);
		} else {
			return null;
		}
	}

	public boolean isEmailAvailable(String email) {
		int total = 0;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			total = (int) session
					.createQuery(
							"Select COUNT(user) from User user where user.email =:email")
					.setParameter("email", email).uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		if (total == 1) {
			return true;
		} else {
			return false;
		}
	}

	public long getNoOfUsers() {
		long noOfUsers = 0;
		try {
			session = factory.openSession();
			tx = session.beginTransaction();
			noOfUsers = (long) session.createQuery(
					"Select COUNT(u) from User u where u.role='ROLE_USER'")
					.uniqueResult();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		} finally {
			if (session != null && session.isOpen())
				session.close();
		}
		return noOfUsers;
	}

}