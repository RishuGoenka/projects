package com.movierental.dao;

import java.util.List;

import com.movierental.model.BookingHistory;
import com.movierental.model.User;

public interface BookingHistoryDAO {
	/**
	 * Method to Saves Booking object passed to it.
	 * 
	 * @param BookingHistoryObject
	 */
	public abstract void saveBooking(BookingHistory bookinghistoryObj);

	/**
	 * Method to Delete Booking BookingID passed to it.
	 * 
	 * @param BookingId
	 */
	public abstract void deleteBooking(Integer bookingId);
	
	/**
	 * Method to Update Booking Time by BookingID passed to it.
	 * 
	 * @param BookingId
	 */
	public abstract void UpdateBooking(Integer bookingId,String startTime,String endTime);

	/**
	 * returns Booking Object of the user whose user-id is passed to it else return null
	 * 
	 * @param userId
	 * @return BookingHistoryList
	 */
	public abstract BookingHistory getBookingByUserID(Integer userId);
	
	/**
	 * returns Booking Object of the Movie whose movie-id is passed to it else return null
	 * 
	 * @param movieId
	 * @return BookingHistoryList
	 */
	public abstract BookingHistory getBookingByMovieID(Integer movieId);

	/**
	 * Return a list of all the BookingHistory if empty it return an empty list
	 * 
	 * @return BookingHistoryList
	 */
	public abstract List<BookingHistory> getAllBookings();

	/**
	 * Returns List of Movies Booked at the Current Time
	 * 
	 * @param currentTime
	 * @return User
	 */
	public abstract User getBookedMovieByCurrentTime(String currentTime);

	/**
	 * Returns List of Movies Not Booked at the Current Time
	 * 
	 * @param currentTime
	 * @return User
	 */
	public abstract User getNotBookedByCurrentTime(String currentTime);
}
