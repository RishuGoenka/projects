package com.movierental.dao;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.movierental.model.BookingHistory;
import com.movierental.model.Movie;

public class MovieDAOImpl {
	private static SessionFactory factory;

	public MovieDAOImpl() {
		factory = new Configuration().configure().buildSessionFactory();
	}

	public Serializable save(Movie movie) {
		Session session = factory.openSession();
		Transaction tx = null;
		Integer id = null;
		try {
			tx = session.beginTransaction();
			id = (Integer) session.save(movie);
			tx.commit();
			System.out.println(" Record created ");
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}
		session.close();
		return id;
	}
}
