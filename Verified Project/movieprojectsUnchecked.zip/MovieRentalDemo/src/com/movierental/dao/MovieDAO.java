package com.movierental.dao;

import java.util.List;

import com.movierental.model.BookingHistory;
import com.movierental.model.Movie;
import com.movierental.model.User;

public interface MovieDAO {
	/**
	 * Method to Saves Movie object passed to it.
	 * 
	 * @param BookingHistoryObject
	 */
	public abstract void saveMovie(Movie movieObj);

	/**
	 * Method to Delete Movie BookingID passed to it.
	 * 
	 * @param BookingId
	 */
	public abstract void deleteBooking(Integer bookingId);

	/**
	 * returns Movie Object of the movie whose movie-id is passed to it else return null
	 * 
	 * @param movieId
	 * @return MovieList
	 */
	public abstract Movie getMovieByMovieID(Integer movieId);
	
	/**
	 * Return a list of all the Movie if empty it return an empty list
	 * 
	 * @return MovieList
	 */
	public abstract List<Movie> getAllMovies();
	
	/**
	 * Method to Update Movie Title by MovieID passed to it.
	 * 
	 * @param movieId
	 */
	public abstract void UpdateMovieTitle(Integer movieId,String movieTitle);

	/**
	 * Method to Update Movie Cost by MovieID passed to it.
	 * 
	 * @param movieId
	 */
	public abstract void UpdateMovieCost(Integer movieId,double Cost);

}
