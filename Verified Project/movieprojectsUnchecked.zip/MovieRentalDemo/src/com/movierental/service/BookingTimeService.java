package com.movierental.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class BookingTimeService {
	static DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	static Date date = new Date();
	private static String time;

	public String startDate() {
		time = dateFormat.format(date);
		return time;
	}

	public String endDate(int bookDays) throws ParseException {
		Calendar c = Calendar.getInstance();
		c.setTime(dateFormat.parse(time));
		c.add(Calendar.DATE, bookDays); // number of days to add
		time = dateFormat.format(c.getTime()); // dt is now the new date
		return time;
	}
}
