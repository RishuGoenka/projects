package com.movierental.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Catagory implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int catagoryId;
	private String catagory;
	private Set<Movie> movie = new HashSet<>();
	public Catagory() {
		super();
	}

	public Catagory(String catagory) {
		super();
		this.catagory = catagory;
	}

	public int getCatagoryId() {
		return catagoryId;
	}

	public void setCatagoryId(int catagoryId) {
		this.catagoryId = catagoryId;
	}

	public String getCatagory() {
		return catagory;
	}

	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}
	
	public Set<Movie> getMovie() {
		return movie;
	}

	public void setMovie(Set<Movie> movie) {
		this.movie = movie;
	}

	public void addMovie(Movie movie) {
		this.movie.add(movie);
	}
	@Override
	public String toString() {
		return "Catagory [catagoryId=" + catagoryId + ", catagory=" + catagory
				+ "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((catagory == null) ? 0 : catagory.hashCode());
		result = prime * result + catagoryId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Catagory other = (Catagory) obj;
		if (catagory == null) {
			if (other.catagory != null)
				return false;
		} else if (!catagory.equals(other.catagory))
			return false;
		if (catagoryId != other.catagoryId)
			return false;
		return true;
	}

}
