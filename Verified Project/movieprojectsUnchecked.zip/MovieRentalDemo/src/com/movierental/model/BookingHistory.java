package com.movierental.model;

import java.io.Serializable;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

public class BookingHistory implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int bookingId;
	private User user;
	private Movie movie;
	private String startTime;
	private String endTime;

	public BookingHistory() {
		super();
	}

	public BookingHistory(User user, Movie movie, String startTime,
			String endTime) {
		super();
		this.user = user;
		this.movie = movie;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Movie getMovie() {
		return movie;
	}

	public void setMovie(Movie movie) {
		this.movie = movie;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}
