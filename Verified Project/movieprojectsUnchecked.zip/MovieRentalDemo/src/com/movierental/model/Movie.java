package com.movierental.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

public class Movie implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int movieId;
	private String movieTitle;
	private double moviecost;
	private Set<Catagory> catagory = new HashSet<>();

	public Movie() {
		super();
	}

	public Movie(String movieTitle, double moviecost) {
		super();
		this.movieTitle = movieTitle;
		this.moviecost = moviecost;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieTitle() {
		return movieTitle;
	}

	public void setMovieTitle(String movieTitle) {
		this.movieTitle = movieTitle;
	}

	public double getMoviecost() {
		return moviecost;
	}

	public void setMoviecost(double moviecost) {
		this.moviecost = moviecost;
	}

	public Set<Catagory> getCatagory() {
		return catagory;
	}

	public void setCatagory(Set<Catagory> catagory) {
		this.catagory = catagory;
	}

	public void addCatagory(Catagory catagory) {
		this.catagory.add(catagory);
	}

	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieTitle=" + movieTitle
				+ ", moviecost=" + moviecost + ", Catagory=" + catagory + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + movieId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Movie other = (Movie) obj;
		if (movieId != other.movieId)
			return false;
		return true;
	}

}
