package com.movierental.controllers;

import java.util.List;

import com.movierental.model.Movie;

public interface MovieDAO {
	/**
	 * Method to Saves Movie object passed to it.
	 * 
	 * @param movieObj
	 */
	public void saveMovie(Movie movieObj);
	
	/**
	 * Method to Update Movie object  movieId, cost passed to it.
	 * 
	 * @param movieId, cost
	 */
	public void updateMovie(Integer movieId, double cost);

	/**
	 * Method to Delete Movie MovieID passed to it.
	 * 
	 * @param userId
	 */
	public abstract void deleteMovie(Integer userId);

	/**
	 * returns user Object of the Movie whose movieId is passed to it else
	 * return null
	 * 
	 * @param movieId
	 * @return movieObj
	 */
	public abstract Movie getMovieByID(Integer movieId);

	/**
	 * Return a list of all the Movie if empty it return an empty list
	 * 
	 * @return movieList
	 */
	public abstract List<Movie> getAllMovies();

	/**
	 * Returns Object of Movie having movieTitle or else returns null
	 * 
	 * @param movieTitle
	 * @return movieObj
	 */
	public abstract Movie getMovieByTitle(String movieTitle);

	/**
	 * Returns Object of Movie having movieCost or else returns null
	 * 
	 * @param movieCost
	 * @return movieObj
	 */
	public abstract List<Movie> getMovieByCost(String movieCost);

	/**
	 * get total number of Movies
	 * 
	 * @return movieCount
	 */
	public long getNoOfMovies();

}
