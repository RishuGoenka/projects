package com.movierental.controllers;

import java.util.List;

import com.movierental.model.Contact;

public interface ContactDAO {
	/**
	 * Method to Saves Contact object passed to it.
	 * 
	 * @param contactObj
	 */
	public void saveUser(Contact contact);

	/**
	 * Method to Delete Contact ContactID passed to it.
	 * 
	 * @param contactId
	 */
	public abstract void deleteContact(Integer contactId);

	/**
	 * returns Contact Object whose contactId is passed to it else return null
	 * 
	 * @param contactId
	 * @return contactObj
	 */
	public abstract Contact getContactByID(Integer contactId);

	/**
	 * Return a list of all the Contact if empty it return an empty list
	 * 
	 * @return contactList
	 */
	public abstract List<Contact> getAllContacts();

}
