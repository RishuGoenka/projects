package com.movierental.app;

import java.text.ParseException;

import com.movierental.dao.BookingHistoryDAOImpl;
import com.movierental.model.BookingHistory;
import com.movierental.model.User;
import com.movierental.service.BookingTimeService;

public class BookingHistoryAPP {

	public static void main(String[] args) throws ParseException {
		
		BookingHistoryDAOImpl bookingbistorydao = new BookingHistoryDAOImpl();
		BookingHistory bookinghistory = new BookingHistory();
		BookingTimeService bookingTimeService = new BookingTimeService();
		
		bookinghistory.setStartTime(bookingTimeService.startDate());
		bookinghistory.setEndTime(bookingTimeService.endDate(5));
		bookingbistorydao.save(bookinghistory);
	}

}
