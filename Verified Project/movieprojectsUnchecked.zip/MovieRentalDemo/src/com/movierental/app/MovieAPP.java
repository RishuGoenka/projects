package com.movierental.app;

import com.movierental.dao.MovieDAOImpl;
import com.movierental.model.Catagory;
import com.movierental.model.Movie;

public class MovieAPP {

    public static void main(String[] args) {
 
        Catagory catagory1 = new Catagory("Sci");
        Catagory catagory2 = new Catagory("Fi");
         
        Movie movie1 = new Movie("Mac", 5);
        Movie movie2 = new Movie("Jac", 7);
         
        catagory1.addMovie(movie1);
        catagory1.addMovie(movie2);
         
        catagory2.addMovie(movie1);
         
        movie1.addCatagory(catagory1);
        movie2.addCatagory(catagory1);
        movie1.addCatagory(catagory2);
        
        MovieDAOImpl moviedao = new MovieDAOImpl();
        moviedao.save(movie1);
        moviedao.save(movie2);
    }
}
