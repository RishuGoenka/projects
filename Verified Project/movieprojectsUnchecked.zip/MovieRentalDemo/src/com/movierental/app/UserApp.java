package com.movierental.app;

import com.movierental.dao.UserDAO;
import com.movierental.model.User;

public class UserApp {

	public static void main(String[] args) {
		User user = new User();
		UserDAO userdao = new UserDAO();
		user.setFirstName("firstname");
		user.setLastName("lastName");
		user.setEmail("email");
		user.setPassword("password");
		user.setUserRole("roll");
		userdao.saveUser(user);

	}

}
