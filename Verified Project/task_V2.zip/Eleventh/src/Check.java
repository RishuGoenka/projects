public class Check {

	public static void implement(int test) {
		int[] arr = new int[Integer.toString(test).length()];
		int arrLength = arr.length;
		int val = test;
		for (int i = 0; i < arrLength; i++) {
			arr[i] = test % 10;
			test = test / 10;
		}
		if (repit(arr) == 1) {
			for (int i = 1; i <= 5 + 1; i++) {
				switch (i % 2) {
				case 1:
					arr[0] = arr[0] ^ arr[1];
					arr[1] = arr[0] ^ arr[1];
					arr[0] = arr[0] ^ arr[1];
					disp(arr, val);
					break;
				case 0:
					arr[1] = arr[1] ^ arr[2];
					arr[2] = arr[1] ^ arr[2];
					arr[1] = arr[1] ^ arr[2];
					disp(arr, val);
					break;
				}
			}
		} else
			System.out.println("Invalid");
	}

	private static int repit(int[] arr) {
		int arrLength = arr.length;
		boolean match = true;
		for (int i = 0; i < arrLength; i++) {
			for (int j = i + 1; j < arrLength; j++) {
				if (arr[i] == arr[j]) {
					System.out.println("No Repetion allowed");
					match = false;
					break;
				}
			}
			if (match == false)
				return 0;
		}
		return 1;
	}

	private static void disp(int[] arr, int val) {
		System.out.println(val / 1000 + "" + arr[2] + "" + arr[1] + "" + arr[0]);
		if (arr.length == 4)
			System.out.println(arr[3] + arr[2] - arr[1] / arr[0]);
		if (arr.length == 5)
			System.out.println(arr[4] + arr[3] - arr[2] / arr[1] * arr[0]);
		if (arr.length == 6)
			System.out.println(arr[5] + arr[4] - arr[3] / arr[2] * arr[1]+ arr[0]);
		if (arr.length == 7)
			System.out.println(arr[6] + arr[5] - arr[4] / arr[3] * arr[2]+ arr[1] - arr[0]);
		if (arr.length == 8)
			System.out.println(arr[7] + arr[6] - arr[5] / arr[4] * arr[3]+ arr[2] - arr[1] / arr[0]);
		if (arr.length == 9)
			System.out.println(arr[8] + arr[7] - arr[6] / arr[5] * arr[4]+ arr[3] - arr[2] / arr[1] * arr[0]);
	}
}