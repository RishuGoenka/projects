import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {
		try {
			BufferedReader read = new BufferedReader(new InputStreamReader(
					System.in));
			int test = 0;
			do {
				System.out.println("Enter minimum 4 digit number");
				test = Integer.parseInt(read.readLine());
			} while (Integer.toString(test).length() < 4);
			if (Pattern.matches("[1-9]+", Integer.toString(test)))
				Check.implement(test);
			else
				System.out.println("Invalid input");
		} catch (Exception e) {
			System.out.println("Invalid Input");
		}
	}
}