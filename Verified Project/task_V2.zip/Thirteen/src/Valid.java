import java.util.regex.Pattern;

public class Valid {

	public static void productInput(StringBuffer sb) {
		String[] separate = sb.toString().trim().split("d1i2v3s4b");
		String[] quantitys = new String[separate.length];
		String[] costs = new String[separate.length];
		String[] productDescription = new String[separate.length];
		int totalProduct = separate.length;
		try {
			for (int i = 0; i < totalProduct; i++) {
				int quantity = 0, cost = 0;
				quantity = separate[i].trim().indexOf(' ');
				cost = separate[i].trim().lastIndexOf(' ');
				quantitys[i] = separate[i].substring(0, quantity).trim();
				if (quantity == cost)
					System.out
							.println("Data Insufficient: Kindly Input Product Details");
				else
					productDescription[i] = separate[i]
							.substring(quantity + 1, cost).toLowerCase().trim();
				costs[i] = separate[i]
						.substring(cost + 1, separate[i].length()).trim();
			}
		} catch (IllegalArgumentException | StringIndexOutOfBoundsException e) {
			System.out.println("Invalid Input");
		}
		productValid(totalProduct, quantitys, productDescription, costs);
	}

	private static void productValid(int totalProduct, String[] quantitys,
			String[] productDescription, String[] costs) {
		int count = 0;
		try {
			for (int i = 0; i < totalProduct; i++) {
				if (Pattern.matches("\\d+", quantitys[i])
						&& Pattern.matches("[a-z\\s]+", productDescription[i])
						&& Pattern.matches("\\d+(\\.\\d{1,2})?", costs[i])) {
					count++;
				} else
					System.out.println("Invalid Details");

			}
		} catch (NullPointerException e) {
			System.out.println("Invalid Input");
		}
		if (count == totalProduct)
			Calculate.tax(totalProduct, quantitys, productDescription, costs);

	}

}
