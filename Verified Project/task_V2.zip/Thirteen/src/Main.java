import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		StringBuffer sb = new StringBuffer();
		String moreProduct = "", product;
		do {
			System.out.println("Enter Product write inported and exempted");
			product = read.readLine();
			sb.append(product).append("d1i2v3s4b");
			System.out.println("Press Enter for more product");
			moreProduct = read.readLine();
		} while (moreProduct.equalsIgnoreCase(""));
		Valid.productInput(sb);
	}

}
