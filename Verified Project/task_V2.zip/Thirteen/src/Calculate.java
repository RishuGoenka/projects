public class Calculate {

	public static void tax(int totalProduct, String[] quantitys,
			String[] productDescription, String[] costs) {
		float[] saltax = new float[totalProduct];
		float[] newcost = new float[totalProduct];
		float tax = 0, total = 0;
		for (int i = 0; i < totalProduct; i++) {
			if (productDescription[i].contains("exempted")
					&& productDescription[i].contains("imported")) {
				saltax[i] = (Float.valueOf(costs[i]) * 5) / 100;
				saltax[i] = (float) (Math.ceil(saltax[i] / 0.05f) * 0.05);
				newcost[i] = Float.valueOf(costs[i]) + saltax[i];
			}
			if (productDescription[i].equals("exempted")
					&& !(productDescription[i].contains("imported"))) {
				saltax[i] = 0;
				newcost[i] = Float.valueOf(costs[i]) + saltax[i];
			}
			if (!(productDescription[i].contains("exempted"))
					&& productDescription[i].contains("imported")) {
				saltax[i] = (Float.valueOf(costs[i]) * 15) / 100;
				saltax[i] = (float) (Math.ceil(saltax[i] / 0.05f) * 0.05);
				newcost[i] = Float.valueOf(costs[i]) + saltax[i];
			}
			if (!(productDescription[i].contains("exempted"))
					&& !(productDescription[i].contains("imported"))) {
				saltax[i] = (Float.valueOf(costs[i]) * 10) / 100;
				saltax[i] = (float) (Math.ceil(saltax[i] / 0.05f) * 0.05);
				newcost[i] = Float.valueOf(costs[i]) + saltax[i];
			}
			tax = saltax[i] + tax;
			total = total + newcost[i];
			System.out.println(quantitys[i] + " " + productDescription[i] + " "
					+ newcost[i]);
		}
		System.out.println("Sales tax : " + tax);
		System.out.println("Total : " + total);

	}
}
