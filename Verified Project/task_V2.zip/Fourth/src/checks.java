import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class checks {
	public static int calcPower(String str, int k){
		int count=0;
		int end,iteration=1;
		for(int i=str.length();i>0;i--){
			end=i;
			for(int j=0;j<iteration;j++){
				count = PatternChecker(str, str.substring(j, end++));
				if(count>=k){
					return str.substring(j, end++-1).length();
				}
			}
			iteration++;
		}
		return 0;
	}

	public static int PatternChecker(String testString, String testPattern) {
		int count = 0;
		Pattern pattern = Pattern.compile(testPattern);
		Matcher matcher;
		for(int i=0; i<=(testString.length()-testPattern.length()); i++){
			matcher = pattern.matcher(testString.substring(i, i+testPattern.length()));
			if(matcher.matches()){
				count++;
			}
		}
		return count;
	}
}
