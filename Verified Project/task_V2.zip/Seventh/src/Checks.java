import java.util.regex.Pattern;


public class Checks {
	public static boolean IOValid(String emailString) {
		if(Pattern.matches("^([a-zA-Z0-9_\\-\\.]+)@([a-zA-Z0-9_\\-\\.]+)\\.([a-zA-Z]{2,5})$", emailString))
			return true;
		return false;
		
	}
}
