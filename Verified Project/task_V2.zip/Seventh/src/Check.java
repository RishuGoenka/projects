import java.util.regex.Pattern;

public class Check {

	public static boolean IOValid(String emailString) {
		String[] separate = emailString.trim().split("@");
		if (separate.length == 2) {
			String[] domseprate = separate[1].trim().split("\\.");
			if (domseprate.length == 2) {
				if (domseprate[1].length() == 2 || domseprate[1].length() == 3) {
					if (Pattern.matches("[A-Za-z]+", domseprate[1])
							&& !(separate[1].contains(" "))
							&& !(separate[0].contains(" ")))
						return true;
					else
						return false;
				} else
					return false;
			}
			if (domseprate.length == 3) {
				if ((domseprate[1].length() == 2 || domseprate[1].length() == 3)
						&& (domseprate[2].length() == 2 || domseprate[2]
								.length() == 3)) {
					if (Pattern.matches("[A-Za-z]+", domseprate[1])
							&& Pattern.matches("[A-Za-z]+", domseprate[2])
							&& !(separate[1].contains(" "))
							&& !(separate[0].contains(" ")))
						return true;
					else
						return false;
				} else
					return false;
			} else
				return false;
		} else
			return false;
	}
}
