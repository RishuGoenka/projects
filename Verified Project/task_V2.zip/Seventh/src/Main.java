import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) {
		BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Email ID");
			try {
				String emailString = read.readLine();
					//System.out.println(Check.IOValid(emailString));
				System.out.println(Checks.IOValid(emailString));
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
}
