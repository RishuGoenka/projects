import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
	static int TEST_LIMIT = 100;
	static int NUMBER_LIMIT = 2000;
	public static void main(String[] args){
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		int test = 0;
		try{
			do {
		System.out.println("Enter No of test case");
			test = Integer.parseInt(read.readLine());
		} while (test < 1 && test > TEST_LIMIT);
		int[] caseN = new int[test];
		for (int i = 0; i < test;) {
			System.out.println("Enter " + i + " case");
			caseN[i] = Integer.parseInt(read.readLine());
			if (caseN[i] >= 2 && caseN[i] <= NUMBER_LIMIT)
				i++;
		}
		check.implement(caseN, test);
		}catch(Exception e){
			System.out.println("Invalid Input");
		}
	}

}
