public class RoversMove {

	public static void mars(String[] coordinate, String[] location, String moves) {
		String[][] cord = new String[Integer.parseInt(coordinate[0]) + 1][Integer
				.parseInt(coordinate[1]) + 1];
		if (Integer.parseInt(location[0]) <= Integer.parseInt(coordinate[0]) && Integer.parseInt(location[1]) <= Integer.parseInt(coordinate[1])) {
			cord[Integer.parseInt(location[0])][Integer.parseInt(location[1])] = location[2];
			char[] movs = new char[moves.length()];
			for (int i = 0; i < moves.length(); i++) {
				movs[i] = moves.charAt(i);
			}
			int first = Integer.parseInt(location[0]);
			int second = Integer.parseInt(location[1]);
			for (int i = 0; i < moves.length(); i++) {
				try {
					switch (movs[i]) {
					case 'L':
						if (cord[first][second].equals("N")) {
							cord[first][second] = "W";
							break;
						}
						if (cord[first][second].equals("W")) {
							cord[first][second] = "S";
							break;
						}
						if (cord[first][second].equals("S")) {
							cord[first][second] = "E";
							break;
						}
						if (cord[first][second].equals("E")) {
							cord[first][second] = "N";
							break;
						}
					case 'R':
						if (cord[first][second].equals("N")) {
							cord[first][second] = "E";
							break;
						}
						if (cord[first][second].equals("E")) {
							cord[first][second] = "S";
							break;
						}
						if (cord[first][second].equals("S")) {
							cord[first][second] = "W";
							break;
						}
						if (cord[first][second].equals("W")) {
							cord[first][second] = "N";
							break;
						}
					case 'M':
						if (cord[first][second].equals("N")) {
							second++;
							cord[first][second] = "N";
							break;
						}
						if (cord[first][second].equals("E")) {
							first++;
							cord[first][second] = "E";
							break;
						}
						if (cord[first][second].equals("S")) {
							second--;
							cord[first][second] = "S";
							break;
						}
						if (cord[first][second].equals("W")) {
							first--;
							cord[first][second] = "W";
							break;
						}
					}
				} catch (ArrayIndexOutOfBoundsException e) {
					break;
				}
			}
			try {
				System.out.println(first + " " + second + " "
						+ cord[first][second]);
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out
						.println("Rover Stop at this location no further valid move" + first +" " + second);
			}
		} else
			System.out.println("Invalid Rover Location");
	}
}
