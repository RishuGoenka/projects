import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		System.out.println("Enter Coordinate X and Y with space separated");
		String[] coordinate = read.readLine().trim().split("\\s");
		System.out.println("Enter rovers location X, Y coordiante and Direction with space separated");
		String[] location = read.readLine().trim().split("\\s");
		System.out.println("Enter total Movement");
		String moves = read.readLine();
		if(Pattern.matches("\\d+", coordinate[0]) && Pattern.matches("\\d+", coordinate[1])  && Pattern.matches("\\d+", location[0])
				 && Pattern.matches("\\d+", location[1]) && Pattern.matches("[NSEW]", location[2]) && Pattern.matches("[LRM]+", moves)){
			RoversMove.mars(coordinate, location, moves);
		}else
			System.out.println("Invalid Input");

	}
}
