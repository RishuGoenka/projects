import java.util.Stack;


public class BackTest {

	public static void main(String[] args) {
		Stack<Integer> numberStack = new Stack<Integer>();
		Stack<Integer> printStack = new Stack<Integer>();
		int testArray[] = {1,2,3,4,5};
		for(int i=0;i<5;i++){
			numberStack.add(testArray[i]);
		}
		for(int i=0;i<numberStack.size();i++){
			printStack.add(numberStack.peek());
			calculate(numberStack.pop(), numberStack, printStack);
			printStack.pop();
		}

	}
	
	public static void calculate(int sum,Stack<Integer> numberStack,Stack<Integer> printStack){
		Stack<Integer> numStack = (Stack<Integer>) numberStack.clone();
		while(!numStack.isEmpty()){
			int n =12;
			printStack.add(numStack.peek());
			int x = numStack.pop();
			if(sum+x==n){
				for(int i : printStack){
					System.out.print(i+" ");
				}
				System.out.println("");
				printStack.pop();
			}
			else if(sum+x>n){
				printStack.pop();
			}
			else{
				calculate(sum+x,numStack,printStack);
				printStack.pop();
			}
			
		}
	}

}
