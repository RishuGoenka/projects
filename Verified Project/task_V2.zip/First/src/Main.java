import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Pattern;


public class Main {

	public static void main(String[] args) {
		try{
		BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter space-separated integers N its Array Size and K its No. of Blocks.");
		String stringNK = read.readLine();
		System.out.println("Enter Array with element space-separated");
		String stringArr = read.readLine();
		if(Pattern.matches("[0-9\\s]+", stringNK) && Pattern.matches("[0-9\\s]+", stringArr)){
			Check.inputValid(stringNK, stringArr);
		}
		else
			System.out.println("Invalid  Input");
		}catch(Exception e){
			System.out.println("Invalid Input");
		}
	}

}
