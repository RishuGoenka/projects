public class Check {
	final static int NLimit = 500;
	final static int KLimit = 300;
	
	/**
	 * validate Input
	 * 
	 * @param stringNK  array and group length
	 * @param stringArr  Entered array
	 */
	public static void inputValid(String stringNK, String stringArr) {
 		String[] separateNK = stringNK.trim().split(" ");
		String[] separateARR = stringArr.trim().split(" ");
		int arrayN = Integer.parseInt(separateNK[0]);
		int blockK = Integer.parseInt(separateNK[1]);

		if (arrayN <= NLimit && blockK <= KLimit && blockK <= arrayN && separateNK.length == 2) {
			if (separateARR.length == arrayN) {
				if (arrayvalidate(separateARR, arrayN)) {
					Blocks.ioOperation(arrayN,blockK,separateARR);
				}
				else
					System.out.println("Invalid Array Element");
			}else
				System.out.println("Invalid Array");
		}else
			System.out.println("Invalid Data N/K");
	}

	/**
	 * return true if the enter array Validate the input.
	 * 
	 * @param separateARR  Entered Array
	 * @param arrayN  Array Length
	 * @return
	 */
	private static boolean arrayvalidate(String[] separateARR, int arrayN) {
		for (int i = 0; i < arrayN; i++) {
			if (!(Integer.parseInt(separateARR[i]) >= 0 && Integer.parseInt(separateARR[i]) <= 105))
				return false;
		}
		return true;
	}
	
}
