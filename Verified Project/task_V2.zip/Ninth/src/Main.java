import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	static int TEST_LIMIT = 600;
	static BufferedReader read = new BufferedReader(new InputStreamReader(
			System.in));
	static int test;

	public static void main(String[] args) throws IOException {
		try {
			do {
				System.out.println("Enter test Case");
				test = Integer.parseInt(read.readLine());
			} while (test > TEST_LIMIT && test < 1);
			Check.input(test);
		} catch (Exception e) {
			System.out.println("Invalid Input");
		}
	}

}
