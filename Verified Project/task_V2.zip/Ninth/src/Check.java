import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Check {
	
	static int ARRAY_LENGTH = 200;
	static BufferedReader read = new BufferedReader(new InputStreamReader(
			System.in));

	/**
	 * Bin_Search is performed.
	 * 
	 * @param arrayCount
	 *            total no of Array
	 * @param testArray
	 *            the given array
	 * @param keyValue
	 *            the value to search
	 * @return
	 */

	private static int binSearch(String[] arrayCount, String[] testArray,
			String[] keyValue) {
		try {
			for (int i = 0; i < Integer.parseInt(arrayCount[0]); i++) {
				if (keyValue[0].equals(testArray[i]))
					return i + 1;
			}
		} catch (Exception e) {
			System.out.println("invalid input");
		}
		return 0;
	}

	/**
	 * Take array input and the Key to search
	 * 
	 * @param test
	 *            number of test cases
	 * @return
	 */

	static String[][] input(int test) {
		try {
			String[][] testContain = new String[test][3];
			for (int i = 0; i < test; i++) {
				System.out.println("Enter Details For test Case " + i);
				System.out.println("Enter Size of Array");
				testContain[i][0] = read.readLine();
				if (!(Pattern.matches("\\d+", testContain[i][0])
						&& Integer.parseInt(testContain[i][0]) <= ARRAY_LENGTH && Integer
						.parseInt(testContain[i][0]) >= 1)) {
					System.out.println("Invalid Array size");
					break;
				}
				System.out.println("Enter Array with space separation");
				testContain[i][1] = read.readLine();
				if (!(Pattern.matches("[\\d\\s]+", testContain[i][1]))) {
					System.out.println("Invalid Array");
					break;
				}
				System.out.println("Enter Key");
				testContain[i][2] = read.readLine();
				if (!(Pattern.matches("\\d+", testContain[i][2]))) {
					System.out.println("Invalid key");
					break;
				}
			}
			ioValid(testContain,test);
		} catch (Exception e) {
			System.out.println("Invalid");
		}
		return null;
	}

	/**
	 * Input Split and Validation
	 * 
	 * @param testContain
	 * @param test
	 */
	public static void ioValid(String[][] testContain, int test) {
		try {
			for (int i = 0; i < test; i++) {
				String[] arrayCount = testContain[i][0].trim().split("\\s");
				String[] testArray = testContain[i][1].trim().split("\\s");
				String[] keyValue = testContain[i][2].trim().split("\\s");
				if (Integer.parseInt(arrayCount[0]) == testArray.length)
					System.out.println((binSearch(arrayCount, testArray,
							keyValue)) - 1);
				else
					System.out.println("Invalid");
			}
		} catch (Exception e) {
			System.out.println("Invalid");
		}

	}

}
