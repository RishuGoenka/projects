import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class check {

	static BufferedReader read = new BufferedReader(new InputStreamReader(
			System.in));

	public static void inputOp(String num) throws IOException {
		try{
			if (Integer.parseInt(num) >= 1 && Integer.parseInt(num) <= 104) {
			callInput(num);
		} else
			System.out.println("Invalid Test");
		}catch(NumberFormatException e){
			System.out.println("Invalid Input");
		}
	}

	private static void callInput(String num) throws IOException {
		String[][] allList = new String[Integer.parseInt(num)][2];
		for (int i = 0; i < Integer.parseInt(num); i++) {
			System.out.println("Enter case");
			String mn = read.readLine();
			if (Pattern.matches("[0-9\\s]+", mn)) {
				String[] separate = mn.trim().split(" ");
				if (Integer.parseInt(separate[0]) >= 1
						&& Integer.parseInt(separate[0]) <= 1016) {
					if (Integer.parseInt(separate[1]) >= 1
							&& Integer.parseInt(separate[1]) <= 1016) {
						allList[i][0] = separate[0];
						allList[i][1] = separate[1];
					} else
						System.out.println("Invalid Input");
				} else
					System.out.println("Invalid Input");
			} else
				System.out.println("Invalid Input");
		}
		bitval(allList, num);
	}

	private static void bitval(String[][] allList, String num) {
		for(int i=0;i<Integer.parseInt(num);i++){
			int count = Integer.bitCount(Integer.parseInt(allList[i][0])^Integer.parseInt(allList[i][1]));
			if(count>0){
				System.out.print(Integer.parseInt(allList[i][0]) + " (");
				System.out.print(Integer.toBinaryString(Integer.parseInt(allList[i][0])));
				System.out.print(") and " + Integer.parseInt(allList[i][1]) + " (");
				System.out.print(Integer.toBinaryString(Integer.parseInt(allList[i][1])));
				System.out.println(") differ in " + count+ " bits.");
			}
			if(count == 0)
				System.out.println("The two numbers are identical.");
		}
		
	}
}
