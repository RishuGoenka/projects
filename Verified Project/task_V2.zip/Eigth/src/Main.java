import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {
		try {
			BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter The Text");
			String textString = read.readLine();
			if (Pattern.matches("[A-za-z\\s]+", textString))
				System.out.println(Check.spacetrim(textString));
			else
				System.out.println("Invalid Input");
		} catch (Exception e) {
			System.out.println("Input not valid");
			e.printStackTrace();
		}
	}
}