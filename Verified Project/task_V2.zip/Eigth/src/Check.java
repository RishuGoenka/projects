public class Check {
	
	static char SPACE = '\u0020';
	/**
	 * Remove the Space from front and end.
	 * 
	 * @param textString its inputed string
	 * @param stringLength total length of string
	 * @param stringStart starting index of string
	 * @return  returns the substring length
	 */
	
	static int spacetrim(String textString) {
		char[] value = textString.toCharArray();
		int stringLength = value.length;
        int stringStart = 0;
        char[] val = value;    
        while ((stringStart < stringLength) && (val[stringStart] == SPACE))
            stringStart++;
        while ((stringStart < stringLength) && (val[stringLength - 1] <= SPACE))
            stringLength--;
		return textString.substring(stringStart, stringLength).length();
	}

}
