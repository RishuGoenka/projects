public class Check {

	static int[] count = new int[10];
	static String[] remain = new String[] { "", "", "", "", "", "", "", "", "",
			"" };

	public static void inputOp(String num) {
		try {
			String[] separate = num.trim().split(",");
			int setLength = separate.length;
			for (int i = 0; i < setLength; i++) {
				int j = separate[i].charAt(0) % 48;
				count[j]++;
				if (separate[i].length() > 1)
					remain[j] = remain[j]
							+ separate[i].substring(1, separate[i].length());
			}
			for (int i = 0; i < 10; i++) {
				if (count[i] != 0) {
					System.out.println("Frequency :" + count[i]);
					System.out.println("First Common Digit :" + i);
					System.out.println("Remaining Digits :" + remain[i]);
					System.out.println("\n");
				}
			}
		} catch (Exception e) {
			System.out.println("Invalid Data");
		}

	}
}
