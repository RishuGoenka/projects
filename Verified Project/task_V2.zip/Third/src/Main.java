import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;
import java.util.regex.Pattern;


public class Main {

	public static void main(String[] args) {
		BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter No of Iteration");
		int iteration = 0;
		try {
			iteration = Integer.parseInt(read.readLine());
		} catch (NumberFormatException | IOException | InputMismatchException e) {
						System.out.println("Invalid input Enter Integer");
		} 
		if(Pattern.matches("[0-4]",Integer.toString(iteration))){
			if(iteration == 0 )
				check.iterate();
			else
				checkRest.match(iteration);
		}
		else
			System.out.println("Invalid Iteration No.");
	}

}
