public class check {

	public static void iterate() {
		int x = 1, y = 0;
		for (int i = 0; i < 32; i++) {
			for (int j = 0; j <= 31 - x; j++) {
				System.out.print("_");
			}
			for (int l = 0; l <= y; l++) {
				System.out.print("1");
			}
			for (int k = 32 + x; k <= 63; k++) {
				System.out.print("_");
			}
			System.out.println();
			x++;
			y += 2;
		}

	}

}
