public class checkRest {

	public static void match(int iteration) {
		int nRow = 32;
		String[][] array = new String[nRow + 1][(2 * nRow)];
		for (int i = 1; i <= nRow; i++) {
			for (int j = 1; j < (2 * nRow); j++) {
				if (j > (nRow + (i - 1)) || j < (nRow - (i - 1))) {
					array[i][j] = "_";
				} else {
					array[i][j] = "1";
				}
			}
		}
		array = reverse(array, (nRow / 2) + 1, nRow, iteration);
		for (int i = 1; i <= nRow; i++) {
			for (int j = 1; j < (2 * nRow); j++) {
				System.out.print(array[i][j]);
			}
			System.out.println();
		}
	}

	public static String[][] reverse(String array[][], int startRow,int endRow, int iteration) {
		int rowStart = startRow;
		int rowEnd = endRow;
		if (rowStart > rowEnd)
			return array;
		for (int i = rowStart; i <= rowEnd; i++) {
			for (int j = 0; j <= 63; j++) {
				if ("1".equals(array[(2 * rowStart) - i - 1][j])) {
					array[i][j] = "_";
				}
			}
		}
		iteration--;
		if (iteration > 0) {
			array = reverse(array, rowStart - ((rowEnd - rowStart) / 2) - 1,
					rowStart - 1, iteration);
			array = reverse(array, rowStart + ((rowEnd - rowStart) / 2) + 1,
					rowEnd, iteration);
		}
		return array;
	}

}
