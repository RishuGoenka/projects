package com.editor.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.editor.model.User;
import com.editor.web.HibernateUtil;

public class UserDAO {
	private SessionFactory factory = null;

	public UserDAO() {
		super();
		factory = HibernateUtil.getFactory();
	}

	public void save(User user) {
		Session session = factory.openSession();
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			session.save(user);
			tn.commit();
			System.out.println(" Record created ");
		} catch (HibernateException e) {
			if (tn != null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}

}
