package com.editor.service;

import com.editor.model.User;

public class UserService {

	public UserService() {
		super();
	}

	public boolean validate(User user) {
		return false;

		// String codeText = user.getCodeText();

		// if(codeText == null || codeText.trim().length()<1){
		// System.out.println("text cannot be blank");
		// return false;
		// }

		// UserDAO javaeditordao = new UserDAO();
		// JavaEditor javaeditorobj = new JavaEditor();
		// System.out.println("before find->"+codeText);
		// javaeditorobj = javaeditordao.findByText(codeText);

		// if(codeText.equals(javaeditorobj.getCodeText())){
		// System.out.println(" Already Exist ");
		// return true;
		// }
		// return false;
	}
}
