package com.editor.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.editor.dao.UserDAO;
import com.editor.model.User;
import com.editor.service.UserService;

/**
 * Servlet implementation class RegisterServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		User user = new User();
		UserDAO userdao = new UserDAO();
		UserService userservice = new UserService();
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		user.setFirstname(firstname);
		user.setLastname(lastname);
		if(userservice.validate(user)){
			userdao.save(user);
		}else
			System.out.println("User Exit or not Valid");
	}

}
