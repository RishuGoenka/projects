package com.daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.BussObj.UserCredentials;
import com.exception.DuplicateUserException;
import com.factory.ConnectionFactoryService;

public class UserMasterDao
{
	//private DataSource					dataSource;
	private ConnectionFactoryService	connectionSource;

	/*public UserMasterDao(DataSource dataSource)
	{
		this.dataSource = dataSource;
	}
	*/
	public UserMasterDao(ConnectionFactoryService service)
	{
		this.connectionSource = service;
	}

	public UserCredentials getUserCredentials(String userName)
	{
		Connection connect = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		UserCredentials cred = null;
		try
		{
			//connect = dataSource.getConnection();
			connect = connectionSource.getConnection();
			pstmt = connect.prepareStatement("select username,fullname,password from Login_2227 where username=?");
			pstmt.setString(1, userName);
			rs = pstmt.executeQuery();
			if (rs.next())
			{
				String fullname = rs.getString("fullname");
				String password = rs.getString("password");
				cred = new UserCredentials(userName, password, fullname);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (pstmt != null)
				{
					pstmt.close();
					pstmt = null;
				}
				if (connect != null)
				{
					connect.close();//does not close connection but return to data source
					connect = null;
				}
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
		return cred;

	}

	public void addNewUser(String userName, String fullName, String password) throws DuplicateUserException
	{
		Connection connect = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try
		{
			//connect = dataSource.getConnection();
			connect = connectionSource.getConnection();
			pstmt = connect.prepareStatement("insert into Login values(?,?,?,?)");
			pstmt.setString(1, userName);
			pstmt.setString(2, fullName);
			pstmt.setString(3, password);
			pstmt.setString(4, "user");
			rs = pstmt.executeQuery();

		}
		catch (SQLException e)
		{
			throw new DuplicateUserException("login.DuplicateUser");
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (pstmt != null)
				{
					pstmt.close();
					pstmt = null;
				}
				if (connect != null)
				{
					connect.close();//does not close connection but return to data source
					connect = null;
				}
			}
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
	}
}
