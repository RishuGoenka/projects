package com.daos;

import java.util.ArrayList;

import com.BussObj.BugStatus;
import com.BussObj.BugType;
import com.BussObj.Bugs;
import com.exception.BugNotFoundException;
import com.exception.InvalidStatusName;
import com.exception.InvalidTypeName;
import com.exception.RecordNotInserted;

public interface IBugDao {
	public ArrayList<Bugs> getAllBug();

	public Bugs getBugById(int bugId) throws BugNotFoundException;

	public ArrayList<Bugs> getBugByAssignee(String assignee) throws BugNotFoundException;

	public ArrayList<Bugs> getBugByType(String bugTypeName) throws InvalidTypeName, BugNotFoundException;

	public ArrayList<Bugs> getBugByStatus(String bugStatusName) throws InvalidStatusName, BugNotFoundException;

	public void fileBug(String bugDesc, String bugType, String bugStatus, String assignee, String reportee)
			throws RecordNotInserted;

	public ArrayList<BugType> getAllBugType();

	public ArrayList<BugStatus> getAllBugStatus();

}
