package com.BussObj;

public class BugStatus {
	private int bugStatusId;
	private String bugStatusName;

	public BugStatus(int bugStatusId, String bugStatusName) {
		super();
		this.bugStatusId = bugStatusId;
		this.bugStatusName = bugStatusName;
	}

	public int getBugStatusId() {
		return bugStatusId;
	}

	public void setBugStatusId(int bugStatusId) {
		this.bugStatusId = bugStatusId;
	}

	public String getBugStatusName() {
		return bugStatusName;
	}

	public void setBugStatusName(String bugStatusName) {
		this.bugStatusName = bugStatusName;
	}

	@Override
	public String toString() {
		return "BugStatus [bugStatusId=" + bugStatusId + ", bugStatusName=" + bugStatusName + "]";
	}

}
