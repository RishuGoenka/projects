package com.BussObj;

public class UserCredentials {
	private String status;
	private String username;
	private String password;
	private String userFullName;

	public UserCredentials(String username, String password, String userFullName) {
		super();
		this.username = username;
		this.password = password;
		this.userFullName = userFullName;
	}

	public UserCredentials() {
		super();
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "UserCredentials [username=" + username + ", password=" + password + ", userFullName=" + userFullName
				+ "]";
	}

}
