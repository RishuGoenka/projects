package com.BussObj;

public class Bugs {
	private int bugId;
	private String bugDesc;
	private BugType bugType;
	private BugStatus bugStatus;
	private String assignee;
	private String reporte;

	public Bugs(int bugId, String bugDesc, BugType bugType, BugStatus bugStatus, String assignee, String reporte) {
		super();
		this.bugId = bugId;
		this.bugDesc = bugDesc;
		this.bugType = bugType;
		this.bugStatus = bugStatus;
		this.assignee = assignee;
		this.reporte = reporte;
	}

	public int getBugId() {
		return bugId;
	}

	public void setBugId(int bugId) {
		this.bugId = bugId;
	}

	public String getBugDesc() {
		return bugDesc;
	}

	public void setBugDesc(String bugDesc) {
		this.bugDesc = bugDesc;
	}

	public BugType getBugType() {
		return bugType;
	}

	public void setBugType(BugType bugType) {
		this.bugType = bugType;
	}

	public BugStatus getBugStatus() {
		return bugStatus;
	}

	public void setBugStatus(BugStatus bugStatus) {
		this.bugStatus = bugStatus;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public String getReporte() {
		return reporte;
	}

	public void setReporte(String reporte) {
		this.reporte = reporte;
	}

	@Override
	public String toString() {
		return "Bugs [bugId=" + bugId + ", bugDesc=" + bugDesc + ", bugType=" + bugType + ", bugStatus=" + bugStatus
				+ ", assignee=" + assignee + ", reporte=" + reporte + "]";
	}

}
