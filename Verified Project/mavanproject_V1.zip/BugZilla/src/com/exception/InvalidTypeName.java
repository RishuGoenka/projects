package com.exception;

public class InvalidTypeName extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidTypeName() {
	}

	public InvalidTypeName(String message) {
		super(message);
	}

	public InvalidTypeName(Throwable cause) {
		super(cause);
	}

	public InvalidTypeName(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidTypeName(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
