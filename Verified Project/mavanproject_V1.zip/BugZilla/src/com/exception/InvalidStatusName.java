package com.exception;

public class InvalidStatusName extends Exception {

	private static final long serialVersionUID = 1L;

	public InvalidStatusName() {
	}

	public InvalidStatusName(String message) {
		super(message);
	}

	public InvalidStatusName(Throwable cause) {
		super(cause);
	}

	public InvalidStatusName(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidStatusName(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

}
