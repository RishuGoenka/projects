package com.service;

import java.util.ArrayList;

import com.BussLogic.BugBLogic;
import com.BussObj.BugStatus;
import com.BussObj.BugType;
import com.BussObj.Bugs;
import com.exception.BugNotFoundException;
import com.exception.InvalidStatusName;
import com.exception.InvalidTypeName;
import com.exception.RecordNotInserted;

public class BugServices {
	private BugBLogic bugLogic;

	public void setBugLogic(BugBLogic bugLogic) {
		this.bugLogic = bugLogic;
	}

	public ArrayList<Bugs> getAllBug() {
		return bugLogic.getAllBug();
	}

	public Bugs getBugById(int bugId) throws BugNotFoundException {
		return bugLogic.getBugById(bugId);
	}

	public ArrayList<Bugs> getBugByAssignee(String assignee) throws BugNotFoundException {
		return bugLogic.getBugByAssignee(assignee);
	}

	public ArrayList<Bugs> getBugByType(String bugTypeName) throws InvalidTypeName, BugNotFoundException {
		return bugLogic.getBugByType(bugTypeName);
	}

	public ArrayList<Bugs> getBugByStatus(String bugStatusName) throws InvalidStatusName, BugNotFoundException {
		return bugLogic.getBugByStatus(bugStatusName);
	}

	public void fileBug(String bugDesc, String bugType, String bugStatus, String assignee, String reportee)
			throws RecordNotInserted {
		bugLogic.fileBug(bugDesc, bugType, bugStatus, assignee, reportee);
	}

	public ArrayList<BugType> getAllBugType() {
		return bugLogic.getAllBugType();
	}

	public ArrayList<BugStatus> getAllBugStatus() {
		return bugLogic.getAllBugStatus();
	}
}
