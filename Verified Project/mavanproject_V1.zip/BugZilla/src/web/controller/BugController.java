package web.controller;

import java.util.ArrayList;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.BussObj.BugStatus;
import com.BussObj.BugType;
import com.BussObj.Bugs;
import com.BussObj.UserCredentials;
import com.exception.BugNotFoundException;
import com.exception.DuplicateUserException;
import com.exception.InvalidStatusName;
import com.exception.InvalidTypeName;
import com.exception.RecordNotInserted;
import com.google.gson.Gson;
import com.service.BugServices;
import com.service.UserServices;

@Controller
@RequestMapping("*.do")
public class BugController {
	@Resource
	private BugServices bugService;
	@Resource
	private UserServices userService;

	@RequestMapping("/login.do")
	protected ModelAndView getLoginPage() {

		// System.out.println("in login");
		ModelAndView mav = new ModelAndView("/outerJsps/Login.jsp");
		return mav;

	}

	@RequestMapping("/authenticate.do")
	protected ModelAndView authenticate(HttpServletRequest request, HttpServletResponse response) {
		String userName = request.getParameter("user");
		String password = request.getParameter("pass");
		UserCredentials cred = userService.getAuthenticationStatus(userName, password);
		ModelAndView mav = null;
		System.out.println(cred.getStatus());
		switch (cred.getStatus()) {
		case "login.UserMissing": {
			request.setAttribute("model", cred);
			mav = new ModelAndView("/outerJsps/Login.jsp");
			break;
		}
		case "login.wrongPassword": {
			request.setAttribute("model", cred);
			mav = new ModelAndView("/outerJsps/Login.jsp");
			break;
		}
		case "login.authenticate": {
			HttpSession session = request.getSession(true);
			session.setAttribute("credentials", cred);

			request.setAttribute("model", cred);
			mav = new ModelAndView("/outerJsps/MainMenu.jsp");

			break;
		}
		}
		return mav;
	}

	@RequestMapping("/getAllBug.do")
	@ResponseBody
	protected String GetAllBug() {
		ArrayList<Bugs> bugList = bugService.getAllBug();
		String jsonString = new Gson().toJson(bugList);
		// System.out.println(jsonString);
		return jsonString;
	}

	@RequestMapping("/getBugById.do")
	@ResponseBody
	protected String getBugById(HttpServletRequest req, HttpServletResponse res) {
		String strBugId = req.getParameter("item");
		int bugId = Integer.parseInt(strBugId);
		Bugs bug = null;
		try {
			bug = bugService.getBugById(bugId);
		} catch (BugNotFoundException e) {
			e.printStackTrace();
		}
		String jsonString = new Gson().toJson(bug);
		// System.out.println(jsonString);
		return jsonString;
	}

	@RequestMapping("/getBugByType.do")
	@ResponseBody
	protected String getBugByType(HttpServletRequest req, HttpServletResponse res) {
		String strBugType = req.getParameter("item");
		// System.out.println(strBugType);
		ArrayList<Bugs> bugListByType = null;
		try {
			bugListByType = bugService.getBugByType(strBugType);
		} catch (InvalidTypeName | BugNotFoundException e) {
			e.printStackTrace();
		}
		String jsonString = new Gson().toJson(bugListByType);
		// System.out.println(jsonString);
		return jsonString;
	}

	@RequestMapping("/getBugByStatus.do")
	@ResponseBody
	protected String getBugByStatus(HttpServletRequest req, HttpServletResponse res) {
		String strBugStatus = req.getParameter("item");
		// System.out.println(strBugStatus);
		ArrayList<Bugs> bugListByStatus = null;

		try {
			bugListByStatus = bugService.getBugByStatus(strBugStatus);
		} catch (InvalidStatusName | BugNotFoundException e) {
			e.printStackTrace();
		}

		String jsonString = new Gson().toJson(bugListByStatus);
		// System.out.println(jsonString);
		return jsonString;
	}

	@RequestMapping("/getBugByAssignee.do")
	@ResponseBody
	protected String getBugByAssignee(HttpServletRequest req, HttpServletResponse res) {
		String strBugAssignee = req.getParameter("item");
		// System.out.println(strBugAssignee);
		ArrayList<Bugs> bugListByStatus = null;
		try {
			bugListByStatus = bugService.getBugByAssignee(strBugAssignee);
		} catch (BugNotFoundException e) {

			e.printStackTrace();
		}
		String jsonString = new Gson().toJson(bugListByStatus);
		// System.out.println(jsonString);
		return jsonString;
	}

	@RequestMapping("/filePage.do")
	protected ModelAndView getBugForm() {

		ModelAndView mav = new ModelAndView("/outerJsps/InsertBug.jsp");
		ArrayList<BugType> bugType = bugService.getAllBugType();
		ArrayList<BugStatus> bugStatus = bugService.getAllBugStatus();
		mav.addObject("bugType", bugType);
		mav.addObject("bugStatus", bugStatus);
		return mav;

	}

	@RequestMapping("/fileBug.do")
	protected ModelAndView fileBug(HttpServletRequest request, HttpServletResponse response) {
		String reportee = request.getParameter("reportee");
		String assignee = request.getParameter("assignee");
		String bugDesc = request.getParameter("bugDesc");
		String bugType = request.getParameter("bugType");
		String bugStatus = request.getParameter("bugStatus");
		ModelAndView mav = null;
		// System.out.println(reportee + " " + assignee + " " + bugDesc + " " +
		// bugType + " " + bugStatus);
		try {
			bugService.fileBug(bugDesc, bugType, bugStatus, assignee, reportee);
			request.setAttribute("msg1", "Record inserted Sussefully");
			mav = new ModelAndView("filePage.do");
		} catch (RecordNotInserted e) {
			request.setAttribute("msg", "Record not inserted Sussefully");
			mav = new ModelAndView("filePage.do");
		}

		return mav;
	}

	@RequestMapping("/logout.do")
	protected ModelAndView logout(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession(false);
		session.invalidate();
		ModelAndView mav = new ModelAndView("/outerJsps/Thanks.jsp");
		return mav;
	}

	@RequestMapping("/NewUser.do")
	protected ModelAndView getSignUpPage() {
		ModelAndView mav = new ModelAndView("/outerJsps/SignUp.jsp");
		return mav;
	}

	protected ModelAndView addNewUser(HttpServletRequest request, HttpServletResponse response) {

		String userName = request.getParameter("user");
		String fullName = request.getParameter("fullName");
		String pass = request.getParameter("pass");
		System.out.println(userName + " " + fullName + " " + pass);
		ModelAndView mav = null;
		try {
			userService.addNewUser(userName, fullName, pass);
			request.setAttribute("msg1", "User added Sussefully");
			mav = new ModelAndView("NewUser.do");

		} catch (DuplicateUserException e)

		{
			request.setAttribute("msg", "User not inserted");
			mav = new ModelAndView("NewUser.do");
		}
		return mav;
	}
}
