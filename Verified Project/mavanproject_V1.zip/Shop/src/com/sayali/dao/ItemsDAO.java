package com.sayali.dao;

import org.hibernate.*;
import com.sayali.model.ItemDetails;
import com.sayali.web.HibernateUtil;

public class ItemsDAO {
	private SessionFactory factory = null;
	public ItemsDAO() {
		super();
		factory = HibernateUtil.getFactory();
	}
		
	//Adding items to shop
	public void save(ItemDetails item){
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			session.save(item);
			tn.commit();
			System.out.println(" Record created");
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}
		 
	//Finding an Item in shop
	public ItemDetails findbyid(int iid){
		ItemDetails item = null;
		
		//item = (ItemDetails) session.createQuery("from ItemDetails i where i.iid = :nm").setInteger("nm", iid).uniqueResult();
		Session session =factory.openSession();
		Transaction tn= null;
		System.out.println("findbyid");

		try{
			tn=session.beginTransaction();
			item=(ItemDetails) session.createQuery("from ItemDetails i where i.iid = ?").setInteger(0, iid).uniqueResult();
			tn.commit();
			
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
		return item;
	}
		 
	//Deleting item from shop
	public void delete (int iid){
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			Object item= session.get(ItemDetails.class, iid);
			if(item!=null){
				session.delete(item);
				System.out.println("Record deleted..!!");
			}else
				System.out.println("Record doesnt exists!!");
			tn.commit();
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}
		 
	//Updating item details in shop
	public void modify(ItemDetails item) {
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			session.update(item);
			tn.commit();
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}		 
}
/*public ItemsDetails readorder(int cartId){
	Session session =factory.openSession();
	OrderedItems cart =new OrderedItems();
	Transaction tn= null;
	try{
		tn=session.beginTransaction();
	//	cart =  session.createQuery("select o.iid,i.name,o.quantity,o.price from ItemDetails i, OrderedItems o where o.iid=i.iid AND o.cid=?" ).setInteger(0,cid).list();			
		//Query q = session.get("select new com.sayali.model.Cart (o.iid,o.quantity,o.price,i.name) from ItemDetails i, OrderedItems o where o.iid=i.iid AND o.cid=?").setInteger(0,cid);
		
		cart =(OrderedItems) session.get(OrderedItems.class, cartId);
		
		tn.commit();
		return cart;
	}catch(HibernateException e){
		if(tn!=null)
			tn.rollback();
		e.printStackTrace();
	}
	session.close();
return null;
}*/
