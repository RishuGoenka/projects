package com.sayali.service;

import com.sayali.dao.CustomerDAO;
import com.sayali.model.Customer;

public class CustomerService {

	public CustomerService() {
		super();
	}
	
	public boolean validate(Customer customer) {
		
		// PrintWriter pw = new PrintWriter(System.out);
		String username = customer.getUsername();
		String password = customer.getPassword();
		

		if(username == null || username.trim().length()<1){
			System.out.println("Username cannot be blank");
			return false;
		}
		if(password == null || password.trim().length()<1){
			System.out.println("Password cannot be blank");
			return false;
		}
		if(username != null && username.equalsIgnoreCase(password)){
			System.out.println("Username and password cannot be same");
			return false;
		}
		
		
		CustomerDAO custdao = new CustomerDAO();
		Customer c =  new Customer();
		System.out.println("before find->"+username);
		c= custdao.findByUsername(username);
		
		if(username.equals( c.getUsername()) && password.equals( c.getPassword())){
			System.out.println("Welcome");			
			return true;
		}
		return false;		
	}
	
	public Customer getCustomer(String username, String password){
		
		Customer customer = new Customer();
		customer.setPassword(password);
		customer.setUsername(username);
		System.out.println(customer.getUsername());
		
		if (validate(customer) == true) {
			CustomerDAO custDao = new CustomerDAO();
			Customer loggedCustomer = (Customer) custDao.findByUsername(customer.getUsername());
			return loggedCustomer;
		}		
		return null;
	}
}
