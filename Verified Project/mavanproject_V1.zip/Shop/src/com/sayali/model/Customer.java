package com.sayali.model;
import java.io.*;



public class Customer implements Serializable {
		
		/**
		 * 
		 */
		private static final long serialVersionUID = -7634333752239905306L;
		private Integer cid,zip,mobno;
		private String cname,address,city,state,country,email,username,password;
		
		public Customer() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Customer(Integer cid, Integer zip, Integer mobno, String cname,
				String address, String city, String state, String country,
				String email, String username, String password) {
			super();
			this.cid = cid;
			this.zip = zip;
			this.mobno = mobno;
			this.cname = cname;
			this.address = address;
			this.city = city;
			this.state = state;
			this.country = country;
			this.email = email;
			this.username = username;
			this.password = password;
		}

		public Integer getCid() {
			return cid;
		}

		public void setCid(Integer cid) {
			this.cid = cid;
		}

		public Integer getZip() {
			return zip;
		}

		public void setZip(Integer zip) {
			this.zip = zip;
		}

		public Integer getMobno() {
			return mobno;
		}

		public void setMobno(Integer mobno) {
			this.mobno = mobno;
		}

		public String getCname() {
			return cname;
		}

		public void setCname(String cname) {
			this.cname = cname;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getCountry() {
			return country;
		}

		public void setCountry(String country) {
			this.country = country;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getUsername() {
			return username;
		}

		public void setUsername(String username) {
			this.username = username;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}
}


