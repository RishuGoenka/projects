package com.zycus.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.zycus.service.CompileExecuteService;
import com.zycus.utility.StatusEnum;

@Controller
@RequestMapping("/Code")
public class CompileExecuteController {

	CompileExecuteService service = new CompileExecuteService();

	@RequestMapping(value = "/onSubmit", method = RequestMethod.POST)
	private String onSubmit(ModelMap model, HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		//int userId = Integer.parseInt(request.getParameter("userId"));
		String problemId = request.getParameter("problemId");
		String code = (String) request.getAttribute("text");
		FileWriter writer = new FileWriter(
				"C://Users//harshvardhan.dudeja//Desktop//bin//" + problemId
						+ "//Main.java");
		writer.write(code);
		writer.close();
		service.compile(problemId);
		System.setProperty("dir",
				"C://Users//harshvardhan.dudeja//Desktop//bin//" + problemId
						+ "//");

		long startTime = System.nanoTime();
		List<String> inputList = getInputList();

		List<String> outputList = getOutputList();
		// code
		for (String str : inputList) {
			int i = 0;
			FileWriter writer2 = new FileWriter(
					"C://Users//harshvardhan.dudeja//Desktop//bin//INPUT.txt");
			writer2.write(str);
			writer2.close();
			/* System.out.println( */service.execute("Item",
					"C://Users//harshvardhan.dudeja//Desktop//bin//INPUT.txt",
					outputList, i)/* ) */;
			i++;
		}

		/*
		 * System.out.println(compile.execute("Item",
		 * "C://Users//harshvardhan.dudeja//Desktop//bin//INPUT.txt"));
		 */

		MemoryMXBean memBean = ManagementFactory.getMemoryMXBean();
		MemoryUsage heap = memBean.getHeapMemoryUsage();
		MemoryUsage nonHeap = memBean.getNonHeapMemoryUsage();

		System.out.println("Heap memory used: " + heap.getUsed());
		System.out.println("Non-heap memory: " + nonHeap.getUsed());
		long endTime = System.nanoTime();
		System.out.println("Took " + (endTime - startTime) + " ns");
		return "index";
	}

	private List<String> getOutputList() {
		List<String> outputList = new ArrayList<String>();
		outputList.add("6");
		outputList.add("8");
		outputList.add("10");
		outputList.add("12");
		return outputList;
	}

	private List<String> getInputList() {
		List<String> inputList = new ArrayList<String>();
		inputList.add("2 4");
		inputList.add("3 5");
		inputList.add("4 6");
		inputList.add("5 7");
		return inputList;
	}

}
