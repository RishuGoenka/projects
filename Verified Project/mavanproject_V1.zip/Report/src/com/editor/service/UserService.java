package com.editor.service;

import com.editor.dao.UserDAO;
import com.editor.model.User;

public class UserService {

	public UserService() {
		super();
	}
	
	public boolean validate(User user) {
		if(user.getFirstname() == null)
		return false;
		if(user.getLastname() == null)
			return false;
		if(user.getDepartment() == null)
			return false;
		if(user.getEmail() == null)
			return false;
		if(user.getPassword() == null)
			return false;
		return true;
	}
}
