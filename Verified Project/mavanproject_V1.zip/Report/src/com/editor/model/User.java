package com.editor.model;

import java.io.Serializable;

public class User implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3578732568707885364L;
	private long userId;
	private String firstname;
	private String lastname;
	private String department;
	private String email;
	private String password;

	public User() {
		super();
	}

	public User(String firstname, String lastname, String department,
			String email, String password) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.department = department;
		this.email = email;
		this.password = password;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", firstname=" + firstname
				+ ", lastname=" + lastname + ", department=" + department
				+ ", email=" + email + ", password=" + password + "]";
	}
}
