package com.editor.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.editor.dao.UserDAO;
import com.editor.model.User;
import com.editor.service.UserService;

/**
 * Servlet implementation class RegisterServlet
 */
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserController() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		String firstname = request.getParameter("first");
		String lastname = request.getParameter("last");
		String department = request.getParameter("department");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		User user = new User(firstname,lastname,department,email,password);
		UserDAO userdao = new UserDAO();
		UserService userservice = new UserService();
		if(userservice.validate(user)){
			userdao.save(user);
		}else
			System.out.println("Something Missing");
		System.out.println(user.toString());
	}


}
