package com.editor.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.editor.model.User;
import com.editor.web.HibernateUtil;

public class UserDAO {

	private SessionFactory factory = null;

	// Constructor to connect to DataBase
	public UserDAO() {
		super();
		factory = HibernateUtil.getFactory();
	}

	// Add new Code
	public void save(User user) {
		Session session = factory.openSession();
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			session.save(user);
			tn.commit();
			System.out.println(" Record created ");
		} catch (HibernateException e) {
			if (tn != null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}

	// modify Code details
	public void modify(User user) {
		Session session = factory.openSession();
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			session.update(user);
			tn.commit();
			System.out.println("Record updated ");
		} catch (HibernateException e) {
			if (tn != null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}

	// Find Code
	public User findByText(String codeText) {
		Session session = factory.openSession();
		User customer = null;
		customer = (User) session
				.createQuery("from Customer c where c.codeText = :nm")
				.setString("nm", codeText).uniqueResult();
		return customer;
	}

}
