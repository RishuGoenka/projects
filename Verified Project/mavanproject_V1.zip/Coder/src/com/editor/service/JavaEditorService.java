package com.editor.service;

import com.editor.dao.JavaEditorDAO;
import com.editor.model.JavaEditor;

public class JavaEditorService {

	public JavaEditorService() {
		super();
	}
	
	public boolean validate(JavaEditor javaeditor) {
		
		String codeText = javaeditor.getCodeText();

		if(codeText == null || codeText.trim().length()<1){
			System.out.println("text cannot be blank");
			return false;
		}
				
		JavaEditorDAO javaeditordao = new JavaEditorDAO();
		JavaEditor javaeditorobj =  new JavaEditor();
		System.out.println("before find->"+codeText);
		javaeditorobj = javaeditordao.findByText(codeText);
		
		if(codeText.equals(javaeditorobj.getCodeText())){
			System.out.println(" Already Exist ");			
			return true;
		}
		return false;		
	}
}
