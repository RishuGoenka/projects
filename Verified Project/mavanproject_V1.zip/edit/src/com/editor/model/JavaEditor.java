package com.editor.model;

import java.io.*;

public class JavaEditor implements Serializable {

	private static final long serialVersionUID = -7634333752239905306L;
	private int codeid;
	private String codeText;
	public JavaEditor() {
		super();
	}

	public JavaEditor(String codeText) {
		super();
		this.codeText = codeText;
	}

	public int getCodeid() {
		return codeid;
	}

	public void setCodeid(int codeid) {
		this.codeid = codeid;
	}

	public String getCodeText() {
		return codeText;
	}

	public void setCodeText(String codeText) {
		this.codeText = codeText;
	}

}