import java.util.Date;

public class StandardKeys {

	static final String READINESSLOG = "R:\\SMT_Release_For_RM_Review\\SMT_Release_Delivery_Log\\readinesslogs.log";
	static final String READINESSLOGPATH = "R:\\SMT_Release_For_RM_Review\\SMT_Release_Delivery_Log\\ReadinessLog";
	static final String REFRENCE = "Y:\\Release_Management\\release_artifacts\\ProductName_NN.NN.N.N_production_readiness.xlsx";

	static final String AchievedValue = "10.0|YES";
	static final String UnachievedValue = "[0-9]\\.\\d+|NO";
	static final String NAValue = "NA";
	static final String INVALID = "InValid";
	static final String INVALIDREMARK = "InValid|NA|Not applicable|Done|Cannot be achieved|\\d+|\\s\\s";
	static final String RESOLVED = "Resolved|Fixed|Closed";
	static final String NA = "Not Applicable";
	static final String TEAM = "To be fixed by support team";

	static final Date INVALIDDATE = new Date(1990 / 01 / 01);
	static final Coordinate ACHIEVEDSCORE = new Coordinate(110, 7);
	static final int READINESSPOINTAXIS = 1;
	static final int APPROVINGAUTHORITYAXIS = 8;

	static final String PDTRM = "SMTRM@zycus.com";
	static final String FROM = "no.reply@zycus.com";
}
