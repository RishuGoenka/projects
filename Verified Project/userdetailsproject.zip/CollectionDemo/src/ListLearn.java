import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class ListLearn {

	public static void main(String[] args) {
		List<String> listStrings = new ArrayList<String>();
		listStrings.add("One");
		listStrings.add("Two");
		listStrings.add("Three");
		listStrings.add("Four");

		System.out.println(listStrings.get(2));
		System.out.println(listStrings.get(1));

		System.out.println(listStrings);
		List<String> listStringss = new LinkedList<String>();
		listStringss.add("Five");
		listStringss.add("Six");
		listStringss.add("Seven");
		listStringss.add("Eight");
		System.out.println(listStringss.get(2));
		System.out.println(listStringss.get(1));
		System.out.println(listStringss);

	}

}
