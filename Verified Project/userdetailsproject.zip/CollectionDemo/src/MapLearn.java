import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;


public class MapLearn {

	public static void main(String[] args) {
		Map<String, String> mapLang = new HashMap<>();
		 
		mapLang.put(".c", "C");
		mapLang.put(".java", "Java");
		mapLang.put(".pl", "Perl");
		mapLang.put(".cs", "C#");
		mapLang.put(".php", "PHP");
		mapLang.put(".cpp", "C++");
		mapLang.put(".xml", "XML");
		 
		System.out.println(mapLang);
		
		Map<String, String> mapLangs = new LinkedHashMap<>();
		 
		mapLangs.put(".c", "C");
		mapLangs.put(".java", "Java");
		mapLangs.put(".pl", "Perl");
		mapLangs.put(".cs", "C#");
		mapLangs.put(".php", "PHP");
		mapLangs.put(".cpp", "C++");
		mapLangs.put(".xml", "XML");
		 
		System.out.println(mapLangs);
		
		Map<String, String> mapLangss = new TreeMap<>();
		 
		mapLangss.put(".c", "C");
		mapLangss.put(".java", "Java");
		mapLangss.put(".pl", "Perl");
		mapLangss.put(".cs", "C#");
		mapLangss.put(".php", "PHP");
		mapLangss.put(".cpp", "C++");
		mapLangss.put(".xml", "XML");
		 
		System.out.println(mapLangss);

	}

}
