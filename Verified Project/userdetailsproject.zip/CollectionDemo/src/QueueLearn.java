import java.util.Deque;
import java.util.LinkedList;


public class QueueLearn {

	public static void main(String[] args) {
		Deque<String> ques = new LinkedList<String>();
		ques.offer("1");
		ques.offerFirst("2");
		ques.offerLast("3");
		ques.offer("4");

		System.out.println(ques);
		System.out.println(ques.peekFirst());
		System.out.println(ques.pollLast());
		System.out.println(ques);
	}

}
