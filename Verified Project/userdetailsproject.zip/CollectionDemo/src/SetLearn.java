import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


public class SetLearn {

	public static void main(String[] args) {
		List<Integer> listNumbers = Arrays.asList(3, 9, 1, 4, 7, 2, 5, 3, 8, 9, 1, 3, 8, 6);
		System.out.println(listNumbers);
		Set<Integer> uniqueNumbers = new TreeSet<>(listNumbers);
		System.out.println(uniqueNumbers);

	}

}
