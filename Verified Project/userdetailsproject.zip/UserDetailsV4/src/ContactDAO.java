import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ContactDAO {
	private static SessionFactory factory;

	ContactDAO() {
		factory = new Configuration().configure().buildSessionFactory();
	}

	public void pers(Contact contact) {
		Session session = factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.persist(contact);
			tx.commit();
			System.out.println(" Record created ");
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}
		session.close();
	}

	public Serializable save(Contact contact2) {
		Session session = factory.openSession();
		Transaction tx = null;
		Integer id = null;
		try {
			tx = session.beginTransaction();
			id = (Integer) session.save(contact2);
			tx.commit();
			System.out.println(" Record created ");
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}
		session.close();
		return id;
	}
}
