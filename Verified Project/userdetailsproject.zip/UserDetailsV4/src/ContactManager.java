import java.io.Serializable;

public class ContactManager {
	static ContactDAO contactdao = new ContactDAO();

	public static void main(String[] args) {
		Contact contact1 = new Contact("Nam", "hainatu@gmail.com", "Vietnam", "0904277091");
		contactdao.pers(contact1);

		Contact contact2 = new Contact("Bill", "bill@gmail.com", "USA", "18001900");
		Serializable id = contactdao.save(contact2);
		System.out.println("created id: " + id);

	}

}
