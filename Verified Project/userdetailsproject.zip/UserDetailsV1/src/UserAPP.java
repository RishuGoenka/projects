import java.io.BufferedReader;
import java.io.InputStreamReader;

public class UserAPP {

	public static void main(String[] args) {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		UserDAO userdao = new UserDAO();
		try {
			do {
				System.out.println("Enter FFirst name");
				String firstname = read.readLine();
				System.out.println("Enter last name");
				String lastname = read.readLine();
				userdao.save(new User(firstname, lastname));
				System.out.println("Press Enter For More record");
			} while (read.readLine().equals(""));
		} catch (Exception e) {
			System.out.println("Error");
		}
		
		userdao.display();
	}

}
