import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UserDAO {
	private static SessionFactory factory;

	public UserDAO() {
		factory = new Configuration().configure().buildSessionFactory();
	}

	public void save(User user) {
		Session session = factory.openSession();
		Transaction tx = null;
		try {
			tx = session.beginTransaction();
			session.save(user);
			tx.commit();
			System.out.println(" Record created ");

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			e.printStackTrace();
		}
		session.close();
	}

	public void display() {Session session = factory.openSession();
	Transaction tx = null;
	try {
		tx = session.beginTransaction();
		Query query = session.createQuery("select lastname From User");
		List<?> users = query.list();
		System.out.println(users);
		tx.commit();

	} catch (HibernateException e) {
		if (tx != null)
			tx.rollback();
		e.printStackTrace();
	}
	session.close();
		
		
	}

}
