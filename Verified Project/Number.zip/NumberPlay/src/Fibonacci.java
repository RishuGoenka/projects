
public class Fibonacci {

	public static void main(String[] args) {
		int fibo = 0;
		int out1 = 1;
		int out2 = 0;
		for(int i = 1 ; i<=10;i++){
			fibo= out1+out2;
			System.out.println(fibo);
			out2 = out1;
			out1 = fibo;
		}

	}

}
