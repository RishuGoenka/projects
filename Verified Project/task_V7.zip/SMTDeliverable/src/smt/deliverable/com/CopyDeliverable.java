package smt.deliverable.com;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import org.apache.log4j.Logger;

/**
 * 
 * @author rishu.goenka
 *
 *         copy content from one location to another
 */
public class CopyDeliverable {

	static Logger log = Logger.getLogger(CopyDeliverable.class.getName());

	public CopyDeliverable() {
		super();
	}

	/**
	 * 
	 * @param sourcepath
	 *            folder path to copy
	 * @param destinationPath
	 *            folder location to location
	 * @param logFilePath
	 *            copy log file location
	 * @return count of source file and destination file
	 */
	public String sourceCopy(String sourcepath, String destinationPath, String logFilePath) {
		// store complete list of Source Path
		ArrayList<String> srcPath = new ArrayList<>();
		// store complete list of Destination Path
		ArrayList<String> destPath = new ArrayList<>();

		try (BufferedWriter bw = new BufferedWriter(new FileWriter(logFilePath, true))) {
			File srcSMT = new File(sourcepath);
			File destClient = new File(destinationPath);
			bw.write("Destinatin is : " + destinationPath);
			bw.newLine();
			// copy the file from source to destination
			copy(srcSMT, destClient, srcPath, destPath);
			bw.write("Source File's Count : " + srcPath.size());
			bw.newLine();
			bw.write("Destination File's Count : " + destPath.size());
			bw.newLine();
			bw.newLine();
			bw.write("---------------------!!--Copy Completed--!!---------------------");
			bw.newLine();
			bw.newLine();
			return srcPath.size() + "@" + destPath.size();
		} catch (Exception e) {
			log.info("error in sourceCopy method : ", e);
			return "0@0";
		}
	}

	/**
	 * 
	 * @param src
	 *            source folder/file path
	 * @param dest
	 *            destination folder/file path
	 * @param srcPath
	 * @param destPath
	 */
	public static void copy(File src, File dest, ArrayList<String> srcPath, ArrayList<String> destPath) {
		try {
			if (src.isDirectory()) {
				// if directory not exists, create it
				if (!dest.exists()) {
					dest.mkdirs();
				}
				// list all the directory contents
				String[] files = src.list();
				for (String file : files) {
					// construct the src and dest file structure
					File srcFile = new File(src, file);
					File destFile = new File(dest, file);
					// recursive copy
					copy(srcFile, destFile, srcPath, destPath);
				}
			} else if (src.isFile()) {
				// if file, then copy it
				InputStream in = new FileInputStream(src);
				OutputStream out = new FileOutputStream(dest);
				// store source file path
				srcPath.add(src.getAbsolutePath());
				// Use bytes stream to support all file types
				byte[] buffer = new byte[1024];
				int length;
				// copy the file content in bytes
				while ((length = in.read(buffer)) > 0)
					out.write(buffer, 0, length);

				in.close();
				out.close();
				// store destination file path
				destPath.add(dest.getAbsolutePath());
			}
		} catch (Exception e) {
			log.info("error while copying file : ", e);
			System.out.println("error while copying file : " + src);
			System.exit(0);
		}
	}
}
