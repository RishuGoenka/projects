package smt.deliverable.com;

import java.io.InputStream;
import java.util.Properties;
import org.apache.log4j.Logger;
import java.io.FileInputStream;

public class PropertiesUtil {

	static Logger log = Logger.getLogger(PropertiesUtil.class.getName());

	/**
	 * 
	 * @return complete property file data
	 */
	static Properties getvalue() {
		try {
			Properties prop = new Properties();
			InputStream input = null;
			input = new FileInputStream(StandardKeys.FILE_NAME);

			// load a properties file
			prop.load(input);

			// return the property value
			return prop;
		} catch (Exception e) {
			log.info("error while fetching data from property file", e);
			System.out.println("unable to fetch file data");
			return null;
		}
	}

	/**
	 * 
	 * @param Key
	 *            key for which value is required
	 * @return
	 */
	static String getvalue(String Key) {
		try {
			Properties prop = new Properties();
			InputStream input = null;
			input = new FileInputStream(StandardKeys.FILE_NAME);

			// load a properties file
			prop.load(input);

			// return the property value
			return prop.getProperty(Key);
		} catch (Exception e) {
			log.info("error while fetching data for key", e);
			System.out.println("unable to fetch value for key" + Key);
			return Key;
		}
	}

}
