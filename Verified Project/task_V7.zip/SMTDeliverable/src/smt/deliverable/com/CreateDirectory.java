package smt.deliverable.com;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import org.apache.log4j.Logger;

/**
 * 
 * @author rishu.goenka
 *
 *         create base directory for the provided path
 */
public class CreateDirectory {

	static Logger log = Logger.getLogger(CreateDirectory.class.getName());

	/**
	 * 
	 * @param path
	 *            directory path
	 * @return directory created successfully or not
	 */
	public static boolean createDir(String path) {
		File filePath = new File(path);
		if (!filePath.exists())
			filePath.mkdirs();
		else {
			cleanFolder(filePath);
			filePath.mkdirs();
		}
		return filePath.exists();
	}

	/**
	 * 
	 * @param logPath
	 * @return fileName
	 */
	public static String logFileCreation(String logPath) {
		BufferedWriter bufferedWriter = null;
		FileWriter fileWrite = null;
		String logFile = logPath + PropertiesUtil.getvalue(StandardKeys.LOG_FILE_NAME);
		try {
			File file = new File(logFile);
			// if file doesn't exists, then create it
			if (!file.exists())
				file.createNewFile();
			System.out.println("Log File : " + logFile);
			// true means append file content
			fileWrite = new FileWriter(file.getAbsoluteFile(), true);
			bufferedWriter = new BufferedWriter(fileWrite);

			bufferedWriter.write("--------------------------------!!---STARTED---!!--------------------------------");
			bufferedWriter.newLine();
			bufferedWriter.newLine();
			bufferedWriter.close();
			fileWrite.close();
			return logFile;
		} catch (Exception e) {
			log.info("error while creating log file : ", e);
			return "./copylist.txt";
		}
	}

	/**
	 * 
	 * @param file
	 *            clean folder before copying
	 */
	public static void cleanFolder(File file) {
		try {
			if (file.isDirectory()) {
				// directory is empty, then delete it
				if (file.list().length == 0)
					file.delete();
				else {
					// list all the directory contents
					String files[] = file.list();
					for (String temp : files) {
						// construct the file structure
						File fileDelete = new File(file, temp);
						// recursive delete
						cleanFolder(fileDelete);
					}
					// check the directory again, if empty then delete it
					if (file.list().length == 0)
						file.delete();
				}
			} else {
				file.delete();
			}
		} catch (Exception e) {
			log.info("error while cleaning folder/file : ", e);
			System.out.println("error while cleaning folder/file : " + file.getAbsolutePath());
			System.exit(0);
		}
	}
}
