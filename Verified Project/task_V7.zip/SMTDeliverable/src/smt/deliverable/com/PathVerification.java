package smt.deliverable.com;

import java.io.File;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * 
 * @author rishu.goenka
 *
 *         verify the path is standard or not
 */
public class PathVerification {

	static Logger log = Logger.getLogger(PathVerification.class.getName());

	/**
	 * 
	 * @param source
	 *            Folder path
	 * @return verification success or failure
	 */
	public static String validatePath(String source) {
		try {
			Properties prop = PropertiesUtil.getvalue();
			String[] sourcePath = source.split("\\\\");
			int sourcePathLength = sourcePath.length;
			if (sourcePath[0].contentEquals(prop.getProperty(StandardKeys.ROOT))
					&& sourcePath[1].contentEquals(prop.getProperty(StandardKeys.SMT))) {
				if (new File(source).isDirectory()) {
					switch (sourcePathLength) {
					case 4:
						if (sourcePath[sourcePathLength - 1].matches(prop.getProperty(StandardKeys.RELEASE)))
							return "valid";
						else
							return "incorrect folder name";
					case 6:
						if (sourcePath[sourcePathLength - 3].matches(prop.getProperty(StandardKeys.RELEASE))
								&& (sourcePath[sourcePathLength - 2]
										.contentEquals(prop.getProperty(StandardKeys.PATCHS))
										&& sourcePath[sourcePathLength - 1]
												.matches(prop.getProperty(StandardKeys.PATCH)))
								|| (sourcePath[sourcePathLength - 2]
										.contentEquals(prop.getProperty(StandardKeys.UTILITYS))
										&& sourcePath[sourcePathLength - 1].split("_")[0]
												.contentEquals(prop.getProperty(StandardKeys.UTILITY)))
								|| ((sourcePath[sourcePathLength - 2]
										.contentEquals(prop.getProperty(StandardKeys.CSCRS)))
										&& sourcePath[sourcePathLength - 1]
												.matches(prop.getProperty(StandardKeys.CSCR))))
							return "valid";
						else
							return "incorrect folder name";
					default:
						return "incorrect folder path";
					}
				} else {
					return "incorrect deliverable";
				}
			} else {
				return "incorrect root path";
			}
		} catch (Exception e) {
			log.info("error while validating path : ", e);
			return "failed to verify" + source;
		}
	}
}
