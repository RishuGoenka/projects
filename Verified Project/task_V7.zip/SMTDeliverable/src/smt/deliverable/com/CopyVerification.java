package smt.deliverable.com;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import org.apache.log4j.Logger;

/**
 * 
 * @author rishu.goenka
 *
 *         verified that the folder/files are properly copied or not
 */
public class CopyVerification {

	static Logger log = Logger.getLogger(CopyVerification.class.getName());

	public CopyVerification() {
		super();
	}

	/**
	 * 
	 * @param count
	 *            number of folder/file found wile copying
	 * @param path
	 *            the path for which verification has to be performed
	 * @param logFilePath
	 * @return
	 */
	public int countVerify(String count, String path, String logFilePath) {
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(logFilePath, true))) {
			File sourceDir = new File(path);
			int counts = Integer.parseInt(count);
			bw.write("count while Copying : " + counts);
			bw.newLine();
			int reCount = countFilesInDirectory(sourceDir, logFilePath);
			bw.write("Re-count after Copying : " + reCount);
			bw.newLine();
			bw.newLine();
			if (reCount == counts)
				return counts;
			else
				return reCount;
		} catch (Exception e) {
			log.info("error while performing file count : ", e);
			return 0;
		}
	}

	/**
	 * 
	 * @param directory
	 *            the path for which verification has to be performed
	 * @param logFilePath
	 * @return
	 */

	public static int countFilesInDirectory(File directory, String logFilePath) {
		try (BufferedWriter bw = new BufferedWriter(new FileWriter(logFilePath, true))) {
			int count = 0;
			for (File file : directory.listFiles()) {
				if (file.isFile()) {
					count++;
					bw.write(file.toString());
					bw.newLine();
				}
				if (file.isDirectory()) {
					count += countFilesInDirectory(file, logFilePath);
				}
			}
			return count;
		} catch (Exception e) {
			log.info("error while performing file count in directory : ", e);
			return 0;
		}
	}
}
