package smt.deliverable.com;

import java.lang.reflect.Field;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * 
 * @author rishu.goenka
 * 
 *         Copy Complete Folder form source to destination
 */

public class Deliverable {

	static Logger log = Logger.getLogger(Deliverable.class.getName());

	/**
	 * 
	 * @param args
	 *            folder path as input
	 */
	public static void main(String[] args) {

		try {
			CopyDeliverable copy = new CopyDeliverable();
			CopyVerification verify = new CopyVerification();
			Properties prop = PropertiesUtil.getvalue();
			String subject;
			String body;

			// Deliverable Path
			String sourcePath = args[0].trim();
			System.out.println("----------------------------!!---STARTED---!!----------------------------");

			// Destination Mail ID
			TeamIds teamIds = new TeamIds();
			String productName = sourcePath.split("\\\\")[2];
			String mailto = prop.getProperty(StandardKeys.PDTRM);

			// Mail Id Check using Reflection
			Field[] fields = TeamIds.class.getDeclaredFields();
			for (Field field : fields) {
				if (field.getName().equals(productName)) {
					Object object = field.get(teamIds);
					mailto = object.toString();
				}
			}

			System.out.println("team Mail id : " + mailto);
			
			String pathValidation = PathVerification.validatePath(sourcePath);
			// verify Source Path
			if (pathValidation.equals("valid") && sourcePath.contains(prop.getProperty(StandardKeys.SMT_PATH))) {

				// client Directory Creation
				String clientPath = sourcePath.replace(prop.getProperty(StandardKeys.SMT_PATH),
						prop.getProperty(StandardKeys.CLIENT_PATH));
				System.out.println(clientPath);
				System.out.println("Client Directory Created : " + CreateDirectory.createDir(clientPath));

				// turbatio Directory Creation
				String turbatioPath = sourcePath.replace(prop.getProperty(StandardKeys.SMT_PATH),
						prop.getProperty(StandardKeys.TURBATIO_PATH));
				System.out.println(turbatioPath);
				System.out.println("Turbatio Directory Created : " + CreateDirectory.createDir(turbatioPath));

				// log Directory Creation
				String logPath = sourcePath.replace(prop.getProperty(StandardKeys.SMT_PATH),
						prop.getProperty(StandardKeys.LOG_PATH));
				System.out.println(logPath);
				System.out.println("Log Directory Created : " + CreateDirectory.createDir(logPath));

				// create log File for the Deliverable Path
				String logFilePath = CreateDirectory.logFileCreation(logPath);

				// copy to Client
				String[] clientCopyCount = copy.sourceCopy(sourcePath, clientPath, logFilePath).split("@");

				// copy to Turbatio
				String[] turbatioCopyCount = copy.sourceCopy(sourcePath, turbatioPath, logFilePath).split("@");

				int sourceCount = verify.countVerify(clientCopyCount[0], sourcePath, logFilePath);
				int clientCount = verify.countVerify(clientCopyCount[1], clientPath, logFilePath);
				int turbatioCount = verify.countVerify(turbatioCopyCount[1], turbatioPath, logFilePath);
				String copydetails = "Total no of file in SMT : " + sourceCount + "<br>Total no of file in Client : "
						+ clientCount + "<br>Total no of file in Turbatio : " + turbatioCount;
				if (sourceCount == clientCount) {
					System.out.println("Total no of file in Client : " + clientCount);
					System.out.println("Total no of file in Turbatio : " + turbatioCount);
					System.out.println("copy successful");
					subject = "Deliverable Copied Successfully";
				} else {
					System.out.println("Total no of file in source : " + sourceCount);
					System.out.println("Total no of file in Client : " + clientCount);
					System.out.println("Total no of file in turbatio : " + turbatioCount);
					System.out.println("Some file must be missing verify log");
					subject = "Deliverable Copy Failed";
				}
				body = "<!DOCTYPE html><html><head><style>body {font-family: Segoe UI;font-size: 16px;font-weight: lighter;}h1 {color: red;font-family: consolas;font-size: 22px;}h3 {background: #ffffff none repeat scroll 0 0;border: 1px solid #776565;color: #444;font-size: 24px;font-style: normal;padding-left: 10px;font-weight: initial;width: 673px;}h4 {color: #0d1716;font-size: 16px;font-style: normal;font-weight: initial;}.zycusLogo {height: 33px;margin-bottom: -20px;margin-left: 0;margin-top: 0;width: 120px;}</style></head><body><div>Hello Team ,</div><div><h4>Provided Source Path : "
						+ sourcePath + "</h4></div><div><h4>Destination Path : " + clientPath
						+ "</h4></div><div><h4>Details : <br>" + copydetails
						+ "</h4></div><div>Deliverable copied.</div><br><div>For any concern verify the attached log.</div><div><h2>NOTE :</h2></div><h3>Kindly refer confluence for <a href='https://pdtzycus.atlassian.net/wiki/spaces/RM'>Release Management Process</a>.</h3><h5>Thanks and Regards,<br>PDT|Release Management<br>Zycus Infotech Pvt. Ltd.</h5></div></body></html>";

				SendMail.mailReport(mailto, logFilePath, sourcePath, subject, body);

			} else if (sourcePath.contains(prop.getProperty(StandardKeys.CLIENT_PATH))) {

				// turbatio Directory Creation
				String turbatioPath = sourcePath.replace(prop.getProperty(StandardKeys.CLIENT_PATH),
						prop.getProperty(StandardKeys.TURBATIO_PATH));
				System.out.println(turbatioPath);
				System.out.println("Turbatio Directory Created : " + CreateDirectory.createDir(turbatioPath));

				// log Directory Creation
				String logPath = sourcePath.replace(prop.getProperty(StandardKeys.CLIENT_PATH),
						prop.getProperty(StandardKeys.LOG_PATH));
				System.out.println(logPath);
				System.out.println("Log Directory Created : " + CreateDirectory.createDir(logPath));

				// create log File for the Deliverable Path
				String logFilePath = CreateDirectory.logFileCreation(logPath);

				// copy to Turbatio
				String[] turbatioCopyCount = copy.sourceCopy(sourcePath, turbatioPath, logFilePath).split("@");

				int sourceCount = verify.countVerify(turbatioCopyCount[0], sourcePath, logFilePath);
				int turbatioCount = verify.countVerify(turbatioCopyCount[1], turbatioPath, logFilePath);
				String copydetails = "Total no of file in Client : " + sourceCount
						+ "<br>Total no of file in Turbatio : " + turbatioCount;
				if (sourceCount == turbatioCount && turbatioCount != -1) {
					System.out.println("Total no of file in Client : " + sourceCount);
					System.out.println("Total no of file in Turbatio : " + turbatioCount);
					System.out.println("copy successful");
					subject = "Deliverable Copied Successfully";
				} else {
					System.out.println("Total no of file in source : " + sourceCount);
					System.out.println("Total no of file in turbatio : " + turbatioCount);
					System.out.println("Some file must be missing verify log");
					subject = "Deliverable Copy Failed";
				}
				body = "<!DOCTYPE html><html><head><style>body {font-family: Segoe UI;font-size: 16px;font-weight: lighter;}h1 {color: red;font-family: consolas;font-size: 22px;}h3 {background: #ffffff none repeat scroll 0 0;border: 1px solid #776565;color: #444;font-size: 24px;font-style: normal;padding-left: 10px;font-weight: initial;width: 673px;}h4 {color: #0d1716;font-size: 16px;font-style: normal;font-weight: initial;}.zycusLogo {height: 33px;margin-bottom: -20px;margin-left: 0;margin-top: 0;width: 120px;}</style></head><body><div>Hello Team ,</div><div><h4>Provided Source Path : "
						+ sourcePath + "</h4></div><div><h4>Destination Path : " + turbatioPath
						+ "</h4></div><div><h4>Details : <br>" + copydetails
						+ "</h4></div><div>Deliverable copied.</div><br><div>For any concern verify the attached log.</div><div><h2>NOTE :</h2></div><h3>Kindly refer confluence for <a href='https://pdtzycus.atlassian.net/wiki/spaces/RM'>Release Management Process</a>.</h3><h5>Thanks and Regards,<br>PDT|Release Management<br>Zycus Infotech Pvt. Ltd.</h5></div></body></html>";

				SendMail.mailReport(mailto, logFilePath, sourcePath, subject, body);
			} else {
				System.out.println(pathValidation);
				subject = "Invaild Deliverable : Failed to Copy";
				body = "<!DOCTYPE html><html><head><style>body {font-family: Segoe UI;font-size: 16px;font-weight: lighter;}h1 {color: red;font-family: consolas;font-size: 22px;}table {width: 100%;border: 1px solid #e6e6e6;border-collapse: collapse;background: #ffffff none repeat scroll 0 0;}td {border: 1px solid #e6e6e6;text-align: left;padding-bottom: 10px;padding-top: 10px;padding-left: 10px;}h3 {background: #ffffff none repeat scroll 0 0;border: 1px solid #776565;color: #444;font-size: 24px;font-style: normal;padding-left: 10px;font-weight: initial;}h4 {color: #0d1716;font-size: 16px;font-style: normal;font-weight: initial;}.zycusLogo {height: 33px;margin-bottom: -20px;margin-left: 0;margin-top: 0;width: 120px;}</style></head><body><div>Hi Team ,</div><div><h4>The provided Deliverable Path is : "
						+ sourcePath
						+ "</h4></div><div style='color: red;'>The provided path does not follow the standard. Hence, failed to copy the Deliverable.</div><div>Kindly follow and provide the standard path for successful copy of the Deliverable.</div><div><h2>NOTE :</h2></div><div>The Standard source path format is as mentioned below.</div><table><tr><td>Release Path :</td><td>R:\\SMT_Release_For_RM_Review\\productName\\release_YY.MM.X.x</td></tr><tr><td>Patch Path :</td><td>R:\\SMT_Release_For_RM_Review\\productName\\release_YY.MM.X.x\\patches\\patch_NN</td></tr><tr><td>CSCR Path :</td><td>R:\\SMT_Release_For_RM_Review\\productName\\release_YY.MM.X.x\\customer_specific_change_requests\\CSCR_NN</td></tr><tr><td>Utility Path :</td><td>R:\\SMT_Release_For_RM_Review\\productName\\release_YY.MM.X.x\\utilities\\utility_title</td></tr></table><h3>Kindly refer confluence for <a href='https://pdtzycus.atlassian.net/wiki/spaces/RM'>Release Management Process</a>.</h3><div><h5>Thanks and Regards,<br>PDT|Release Management<br>Zycus Infotech Pvt. Ltd.</h5></div></body></html>";
				SendMail.mailReport(mailto, null, sourcePath, subject, body);
			}
			System.out.println("----------------------------!!---COMPLETED---!!----------------------------");
		} catch (Exception e) {
			log.info("Deliverbale Main Error : ", e);
			System.out.println("----------------------!!---FAILED TO COMPLETE---!!-------------------------");
		}
	}
}
