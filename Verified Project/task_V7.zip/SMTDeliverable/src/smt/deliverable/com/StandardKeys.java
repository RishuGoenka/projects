package smt.deliverable.com;

public class StandardKeys {

	static final String FILE_NAME = "./StandardKeys.properties";

	static String SMT_PATH = "SMT_PATH";
	static String CLIENT_PATH = "CLIENT_PATH";
	static String TURBATIO_PATH = "TURBATIO_PATH";
	static String LOG_PATH = "LOG_PATH";
	static String LOG_FILE_NAME = "LOG_FILE_NAME";

	static String RELEASE = "RELEASE";
	static String PATCHS = "PATCHS";
	static String PATCH = "PATCH";
	static String UTILITYS = "UTILITYS";
	static String UTILITY = "UTILITY";
	static String CSCRS = "CSCRS";
	static String CSCR = "CSCR";
	static String SMT = "SMT";
	static String ROOT = "ROOT";

	static String FROM = "FROM";
	static String PDTRM = "PDTRM";
	static String HOST = "HOST";
}
