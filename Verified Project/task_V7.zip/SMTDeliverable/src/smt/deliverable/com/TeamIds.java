package smt.deliverable.com;

public class TeamIds {

	static final String ActiveMQ_Cluster = "SMTRM@zycus.com";
	static final String ActiveMQ_Monitor = "SMTRM@zycus.com";
	static final String Auto_Restart_Monitor = "SMTRM@zycus.com";
	static final String CMD = "Team_CMD@zycus.com";
	static final String CNS = "GD-IT@zycus.com";
	static final String CRMS = "Team_Galaxy@zycus.com";
	static final String Customer_Branding = "GD-IT@zycus.com";
	static final String Dashboard = "GD-IT@zycus.com";
	static final String eCatalog = "team_eproc@zycus.com";
	static final String eInvoice = "Team_eInvoice@zycus.com";
	static final String eProc = "team_eproc@zycus.com";
	static final String FieldLibrary = "Team_FL@zycus.com";
	static final String Flexiform = "Team_FL@zycus.com";
	static final String Forum = "GD-IT@zycus.com";
	static final String Framework = "Team_Framework@zycus.com";
	static final String FTE = "pdt-integration@zycus.com";
	static final String iAnalyze = "team_nova@zycus.com";
	static final String iConsole = "pdt-integration@zycus.com ";
	static final String iContract = "team_cobra@zycus.com";
	static final String iCost = "Team_Pgm_Management@zycus.com";
	static final String iManage = "Team_Pgm_Management@zycus.com";
	static final String iMine = "Team_iRequest@zycus.com";
	static final String iMobile = "Team_OneView@zycus.com";
	static final String iMonitor = "Team_iRequest@zycus.com";
	static final String iNotify = "Team_iRequest@zycus.com";
	static final String Integration = "pdt-integration@zycus.com ";
	static final String IntegrationPlatform = "pdt-integration@zycus.com";
	static final String iRequest = "Team_iRequest@zycus.com";
	static final String iSave = "Team_Pgm_Management@zycus.com";
	static final String iSource = "team_sting@zycus.com";
	static final String Memcached = "SMTRM@zycus.com";
	static final String MongoDB = "SMTRM@zycus.com";
	static final String Notifier_Engine = "SMTRM@zycus.com";
	static final String OneView = "Team_OneView@zycus.com";
	static final String QuickSearch = "team_nova@zycus.com";
	static final String Rainbow = "Team_Rainbow@zycus.com";
	static final String Redis = "SMTRM@zycus.com";
	static final String Redis_Cluster = "SMTRM@zycus.com";
	static final String Reporting = "SMTRM@zycus.com";
	static final String rsync = "SMTRM@zycus.com";
	static final String SIM = "team_sim@zycus.com";
	static final String SMT_Common = "SMTRM@zycus.com";
	static final String SolrZookeeper_Cluster = "SMTRM@zycus.com";
	static final String SpendDashboard = "team_nova@zycus.com";
	static final String SPM = "team_spm@zycus.com";
	static final String SSO_Bridge = "SSO-DEV@zycus.com";
	static final String Supplier_Portal = "Team_ZSN@zycus.com";
	static final String TMS = "team_sso@zycus.com";
	static final String Transformation_Engine = "pdt-integration@zycus.com";
	static final String Workflow = "Team_workflow@zycus.com";
	static final String ZCS = "Team_workflow@zycus.com";
	static final String ZDocManager = "pdt-integration@zycus.com";
	static final String ZSN = "Team_ZSN@zycus.com";
	static final String ZygrateSecurity = "pdt-integration@zycus.com";
	static final String Zytrack = "team_sso@zycus.com";

	public TeamIds() {
		super();
	}

}
