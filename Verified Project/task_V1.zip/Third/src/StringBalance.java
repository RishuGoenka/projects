import java.io.IOException;
import java.util.ArrayList;

public class StringBalance {
	private static int count = 0;
	private static int eqal = 0;
	private static ArrayList<Integer> countArray = new ArrayList<Integer>();

	public static void stringInput(String input) throws IOException {

		for (int i = 0; i < input.length(); i++) {
			for (int j = i + 1; j <= input.length(); j++) {
				String check = input.substring(i, j);
				if (getCount(check)) {
					count++;
					countArray = divideCount();
					while (!countArray.contains(1)) {
						count = count + countArray.size();
						countArray = divideCount();
					}
				}
				deleteArray();
			}
		}
		System.out.println(count+eqal);
		count = 0;
	}

	private static ArrayList<Integer> divideCount() {
		if (countArray.size() > 0) {
			for (int k = 0; k < countArray.size(); k++)
				countArray.set(k, (countArray.get(k) / 2));
		}
		return countArray;
	}

	private static boolean getCount(String substring) {
		int c = 0;
		for (int i = 97; i < 122; i++) {
			c = 0;
			for (int j = 0; j < substring.length(); j++) {

				if (substring.charAt(j) == i) {
					c++;
				}
			}
			if ((c % 2) == 0 && c != 0) {
				countArray.add(c);
			} else if (c % 2 != 0) {
				deleteArray();
				return false;
			}
		}
		return true;
	}

	public static void deleteArray() {
		for (int k = 0; k < countArray.size(); k++)
			countArray.remove(k);
	}
}
