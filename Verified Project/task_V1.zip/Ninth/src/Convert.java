import java.io.IOException;

public class Convert {
	
	public static int binary(String string1,String string2) throws IOException {
		return Integer.parseInt(string1, 2)*Integer.parseInt(string2, 2);  //Converting and Multiplying
	}

}
