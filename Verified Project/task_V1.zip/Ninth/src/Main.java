import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		String string1,string2;
		System.out.println("Input first Binary String");
		string1 = read.readLine();
		System.out.println("Input second Binary String");
		string2 = read.readLine();
		if(Pattern.matches("[0-1]+", string1) && Pattern.matches("[0-1]+", string2) ){
			if(string1.length()<=32 && string2.length()<=32 )
		System.out.println(Convert.binary(string1,string2));
			else
				System.out.println("No. not in INTEGER RANGE");
		}
		else
			System.out.println("Invalid Input");
	}

}
