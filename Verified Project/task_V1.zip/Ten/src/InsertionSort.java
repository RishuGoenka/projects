

public class InsertionSort {
	static ClosestElements close = new ClosestElements();
	static void sort(int[] arrayA,int[] arrayB,int[] arrayC, int stringArrayALength, int stringArrayBLength, int stringArrayCLength){
		for(int i = 1;i< stringArrayALength;i++){
			int valueToSort = arrayA[i];
			int j = i;
			while(j>0 && arrayA[j-1] > valueToSort){
				arrayA[j] = arrayA[j-1];
				j--;
			}
			arrayA[j] = valueToSort;
		}
		for(int i = 1;i< stringArrayBLength;i++){
			int valueToSort = arrayB[i];
			int j = i;
			while(j>0 && arrayB[j-1] > valueToSort){
				arrayB[j] = arrayB[j-1];
				j--;
			}
			arrayB[j] = valueToSort;
		}
		for(int i = 1;i< stringArrayCLength;i++){
			int valueToSort = arrayC[i];
			int j = i;
			while(j>0 && arrayC[j-1] > valueToSort){
				arrayC[j] = arrayC[j-1];
				j--;
			}
			arrayC[j] = valueToSort;
		}
		close.find(arrayA, arrayB, arrayC);
	}
}
