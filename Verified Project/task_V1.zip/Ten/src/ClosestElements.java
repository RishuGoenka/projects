public class ClosestElements {

	static int a, b, c, k, l, m, calculatedMin;
	public void find(int[] x, int[] y, int[] z) {

		int defaultmax = 99999999;

		while (true) {
			if (k >= x.length)
				break;
			if (l >= y.length)
				break;
			if (m >= z.length)
				break;

			calculatedMin = Math.abs(x[k] - y[l]) + Math.abs(x[k] - z[m])
					+ Math.abs(y[l] - z[m]);

			if (calculatedMin < defaultmax) {

				defaultmax = calculatedMin;
				a = k;
				b = l;
				c = m;
			}

			if (x[k] <= y[l] && x[k] <= z[m]) {
				k++;
			} else if (y[l] <= x[k]) {
				l++;
			} else {
				m++;
			}
		}

		System.out.println(x[a] + " " + y[b] + " " + z[c]);

	}
}
