import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter two space separated integers, n and k.");
		System.out.println("n is the No. and k is its Repitations");
		String intString = read.readLine();
		String[] separate = intString.trim().split(" ");
		int n = 0,k = 0;
		try{
		n = Integer.parseInt(separate[0]);
		k = Integer.parseInt(separate[1]);
		}catch(InputMismatchException| IllegalArgumentException | ArrayIndexOutOfBoundsException ex)
		{
			System.out.println("Invalid Input Enter Integer String");
		}
		if(n>=1 && n< 100000 && k>=1 && k<100000)
		System.out.println(Digit.superDigit(n,k));

	}

}
