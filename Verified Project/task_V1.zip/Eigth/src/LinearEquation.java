import java.io.IOException;
import java.util.Stack;

public class LinearEquation {
	public static Stack<Float> variables = new Stack<>();
	public static Stack<Float> numbers = new Stack<>();

	public static void operate(String equation) throws IOException {
		boolean inverse = false;
		boolean variable = false;

		String[] separate = equation.trim().split("=");
		String eq1 = separate[0];
		String eq2 = separate[1];

		if (eq1.charAt(0) != '-' && eq1.charAt(0) != '+')
			eq1 = "+" + eq1;
		System.out.println(eq1);

		// Write Divide Code here
		while(eq1.contains("/")){
			float LHS=0;
			float RHS = 1;
			int index = eq1.indexOf("/");
			int start = index-1;
			int end = index+1;
			if(eq1.charAt(index-1)=='x'){
				variable = true;
				int check = index;
				String x = null;
				while (eq1.charAt(check) != '+' && eq1.charAt(check) != '-') {
					check--;
				}
				if (eq1.charAt(check) == '+')
					x = eq1.substring(check + 1, index-1);
				else
					x = eq1.substring(check, index-1);
				LHS=Integer.parseInt(x);
			}
			else{
				start = index-1;
				while(eq1.charAt(start)!='+' && eq1.charAt(start)!='-' && start>0){
					start--;
				}
				 LHS = Integer.parseInt(eq1.substring(start+1, index));
			}
			
			
				while(end!=eq1.length() && eq1.charAt(end)!='+' && eq1.charAt(end)!='-' )
					end++;
				
				if(eq1.charAt(end-1)=='x'){
					variable=true;
					inverse = true;
					end--;
				}
				RHS = Integer.parseInt(eq1.substring(index+1, end));	
					System.out.println(LHS);
					System.out.println(RHS);
					
					String result = Float.toString(LHS/RHS);
					
				String temp1 = eq1.substring(0, start+1);
				String temp2 = result;
				String temp3 = eq1.substring(end, eq1.length());
				
				eq1 = temp1+temp2+temp3;
				System.out.println(eq1);
				
				}
		

		while (eq1.contains("x")) {
			int index = eq1.indexOf("x");
			eq1 = getVariableValue(index, eq1);
		}

		while (!eq1.equals("")) {
			if (eq1.lastIndexOf("-") > eq1.lastIndexOf("+")) {
				int index = eq1.indexOf("-");
				eq1 = getConstantValue(index, eq1);
			} else {
				int index = eq1.indexOf("+");
				eq1 = getConstantValue(index, eq1);
			}

		}
		
		float a = computeStack(variables);
		float b = computeStack(numbers);
		
		variables.removeAllElements();
		numbers.removeAllElements();
		
		while (eq2.contains("x")) {
			int index = eq2.indexOf("x");
			eq2 = getVariableValue(index, eq2);
		}

		while (!eq2.equals("")) {
			if (eq2.lastIndexOf("-") > eq2.lastIndexOf("+")) {
				int index = eq2.indexOf("-");
				eq2 = getConstantValue(index, eq2);
			} else {
				int index = eq2.indexOf("+");
				eq2 = getConstantValue(index, eq2);
			}

		}
		
		float c = computeStack(variables);
		float d = computeStack(numbers);
		
		double numerator = d-b;
		double denominator = c-a;
		double answer = (d-b)/(a-c);
		if(inverse){
			if(answer!=0)
				answer = 1/answer;
			else
				answer=0;
		}
		System.out.println(numerator);
		System.out.println(denominator);
		System.out.println("Answer is : " + answer);

}

	private static String getConstantValue(int index, String eq1) {
		int check = getConstant(index, eq1);
		eq1 = eq1.substring(0, index);
		return eq1;
	}

	private static int getConstant(int index, String eq1) {
		int check = index;
		String x;
		while (check != eq1.length()) {
			check++;
		}
		if (eq1.charAt(index) == '+')
			x = eq1.substring(index + 1, check);
		else
			x = eq1.substring(index, check);

		numbers.add(Float.parseFloat(x));
		return check;
	}

	public static String getVariableValue(int index, String eq1) {

		int check = getVariable(index, eq1);
		String temp1 = eq1.substring(0, check);
		String temp2 = eq1.substring(index + 1, eq1.length());
		eq1 = temp1 + temp2;
		System.out.println(eq1);
		return eq1;

	}

	private static int getVariable(int index, String eq1) {
		int check = index;
		String x = null;
		while (eq1.charAt(check) != '+' && eq1.charAt(check) != '-' && check>0) {
			check--;
		}
		if (eq1.charAt(check) == '+')
			x = eq1.substring(check + 1, index);
		else
			x = eq1.substring(check, index);

		variables.add(Float.parseFloat(x));
		return check;
	}
	
	private static float computeStack(Stack<Float> variables){
		float c = 0;
		while(variables.size()>0){
		if(variables.size()==1)
			return variables.pop();
		else{
		float a = variables.pop();
		float b = variables.pop();
			c = a+b;
			variables.push(c);
		}
		}
		return 0;
	}
	
}
