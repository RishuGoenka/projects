import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
		String equation = null;
		try{
		System.out.println("Enter Liner Equation");
		equation = read.readLine();
		}catch(IOException e){
			System.out.println("Invalid input");
		}
	//	if(Pattern.matches("[\\dx+-=\\/]+", equation)){
		Test.sort(equation);
	//	LinearEquation.operate(equation);
//		}
	//	else
	//		System.out.println("Invalid Input");

	}

}
