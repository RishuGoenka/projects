public class Test {

	public static void sort(String equation) {
		String[] separate = equation.trim().split("=");
		String[] separatePlus1 = separate[0].trim().split("+");
		int separatePlus1Length = separatePlus1.length;
		String separateaddX = "";
		String separateadd = "";
		for (int i = 0; i < separatePlus1Length; i++) {
			if (separatePlus1[i].contains("x")) 
				separateaddX = separateaddX +"+"+separatePlus1[i];
			else
				separateadd = separateadd +"+"+separatePlus1[i];
		}
		separateaddX = separateadd+separateaddX;
		String[] separateMinus1 = separateaddX.trim().split("-");
		int separateMinus1Length = separateMinus1.length;
		for (int i = 0; i < separateMinus1Length; i++) {
			if (separateMinus1[i].contains("x")) 
				separateaddX = separateaddX +"-"+separateMinus1[i];
			else
				separateadd = separateadd +"-"+separateMinus1[i];
		}
		System.out.println(separateaddX+separateadd);
	/*	String[] separatePlus2 = separate[1].trim().split("+");
		int separatePlus2Length = separatePlus2.length;
		for (int i = 0; i < separatePlus2Length; i++) {
			if (separatePlus2[i].contains("-")) {
				String[] separateMinus2 = separatePlus2[i].trim().split("-");
			}
		}*/
	}

}
