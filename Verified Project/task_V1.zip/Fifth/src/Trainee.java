import java.util.Comparator;

public class Trainee {

	private String name;
	private int age;
	private int marks;

	public Trainee(String name, int age, int marks) {
		super();
		this.name = name;
		this.age = age;
		this.marks = marks;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getMarks() {
		return marks;
	}

	public void setMarks(int marks) {
		this.marks = marks;
	}

	public static Comparator<Trainee> COMPARE_NAME = new Comparator<Trainee>() {
		
		@Override
		public int compare(Trainee obj1, Trainee obj2) {

			return obj1.getName().compareTo(obj2.getName());
		}
	};
	
public static Comparator<Trainee> COMPARE_AGE = new Comparator<Trainee>() {
		
		@Override
		public int compare(Trainee obj1, Trainee obj2) {

			return obj1.getAge() - (obj2.getAge());
		}
	};
	
public static Comparator<Trainee> COMPARE_MARKS = new Comparator<Trainee>() {
		
		@Override
		public int compare(Trainee obj1, Trainee obj2) {

			return (obj1.getMarks() - obj2.getMarks());		}
	};
	
	@Override
	public String toString() {
		return "Trainee [name=" + name + ", age=" + age + ", marks=" + marks
				+ "]";
	}

}
