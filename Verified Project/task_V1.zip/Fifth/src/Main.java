import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
	static BufferedReader read = new BufferedReader(new InputStreamReader(
			System.in));

	public static void main(String[] args) throws IOException {

		List<Trainee> traineeList = new ArrayList<>();

		String name = null;
		int age = 0;
		int marks = 0;
		do {
			System.out.println("Enter Name:");
			name = read.readLine();
			System.out.println("Enter Age:");
			age = Integer.parseInt(read.readLine());
			System.out.println("Enter Marks:");
			marks = Integer.parseInt(read.readLine());
			Trainee trainee = new Trainee(name, age, marks);
			traineeList.add(trainee);
			System.out.println("Enter  to continue Entering Trainee");
		} while ("".equalsIgnoreCase(read.readLine()));

		do{
			switch (choice()) {
		case 1:
			Collections.sort(traineeList, Trainee.COMPARE_NAME);
			System.out.println(traineeList);
			break;
		case 2:
			Collections.sort(traineeList, Trainee.COMPARE_AGE);
			System.out.println(traineeList);
			break;
		case 3:
			Collections.sort(traineeList, Trainee.COMPARE_MARKS);
			System.out.println(traineeList);
			break;
		}
			System.out.println("Enter y to continue Shorting");
		} while ("y".equalsIgnoreCase(read.readLine()));
	}
	private static int choice() throws NumberFormatException, IOException {
		System.out.println("Enter Your Shorting Choice");
		System.out.println("Enter 1 to short with Name");
		System.out.println("Enter 2 to short with Age");
		System.out.println("Enter 3 to short with Marks");
		return Integer.parseInt(read.readLine());
	}

}
