class MainDefault {
	public static void main(String args[]) {
		new NewThread("First Thread");
		new NewThread("Second Thread");
		new NewThread("Three Thread");
		try {
				Thread.sleep(10000);
		} catch (InterruptedException e) {
			System.out.println("Main thread Interrupted");
		}
		System.out.println("Main thread exiting.");
	}
}