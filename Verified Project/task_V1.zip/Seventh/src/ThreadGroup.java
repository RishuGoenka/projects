public class ThreadGroup implements Comparable<ThreadGroup> {

	private Thread thread;

	public ThreadGroup(Thread t) {

		this.thread = t;
	}

	public Thread getThread() {
		return thread;
	}

	public void setThread(Thread thread) {
		this.thread = thread;
	}

	/**
	 * Compares threads by priority
	 */
	public int compareTo(ThreadGroup obj) {
		
		return this.thread.getPriority() - obj.getThread().getPriority();
		
	}

}
