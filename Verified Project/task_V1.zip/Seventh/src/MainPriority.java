import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainPriority {

	public static void main(String[] arg) throws InterruptedException,
			NumberFormatException, IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		Thread childThread;
		ArrayList<ThreadGroup> threads = new ArrayList<>();
		int priorityA = 0, priorityB = 0, priorityC = 0;
		try {
			System.out.println("Enter priorities of First childThread: ");
			priorityA = Integer.parseInt(read.readLine());
			System.out.println("Enter priorities of Second childThread: ");
			priorityB = Integer.parseInt(read.readLine());
			System.out.println("Enter priorities of Third childThread: ");
			priorityC = Integer.parseInt(read.readLine());
		} catch (IllegalArgumentException e) {
			System.out.println("invalid input");
		}
		ThreadOrder threadA = new ThreadOrder("childThread " + priorityA);
		ThreadOrder threadB = new ThreadOrder("childThread " + priorityB);
		ThreadOrder threadC = new ThreadOrder("childThread " + priorityC);

		childThread = new Thread(threadA);
		childThread.setPriority(priorityA);
		threads.add(new ThreadGroup(childThread));

		childThread = new Thread(threadB);
		childThread.setPriority(priorityB);
		threads.add(new ThreadGroup(childThread));

		childThread = new Thread(threadC);
		childThread.setPriority(priorityC);
		threads.add(new ThreadGroup(childThread));

		for (ThreadGroup currThreadGroup : threads) {
			currThreadGroup.getThread().start();
			currThreadGroup.getThread().join();
		}
	}
}
