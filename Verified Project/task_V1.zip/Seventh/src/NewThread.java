class NewThread implements Runnable {
	private String name;
	Thread childThread;

	public NewThread(String threadname) {
		this.name = threadname;
		childThread = new Thread(this, name);
		System.out.println("New thread: " + childThread);
		childThread.start();
	}

	@Override
	public void run() {
		System.out.println("Hello from " + this.name);
		try {
			for (int i = 2; i > 0; i--) {
				System.out.println(name + ": " + i);
				Thread.sleep(1000);
			}
		} catch (InterruptedException e) {
			System.out.println(name + " interrupted.");
		}
		System.out.println(name + " exiting.");
	}
}