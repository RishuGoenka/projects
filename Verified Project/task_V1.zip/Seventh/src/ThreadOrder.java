public class ThreadOrder implements Runnable {

	private String threadName;

	public ThreadOrder(String name) {
		this.threadName = name;
	}

	@Override
	public void run() {
		System.out.println("Hello from " + this.threadName);
	}


}
