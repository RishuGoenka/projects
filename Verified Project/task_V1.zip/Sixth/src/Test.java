import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter The Pattern");
		String patternString = scn.next();
		System.out.println("Enter text");
		String textString = scn.next();
		if (patternString.length() > textString.length())
			System.out.println("Invalid match");
		int txtLength = textString.length();
		int patLength = patternString.length();
		for (int i = 0; i <= txtLength-patLength; i++) {
			System.out.println(textString.substring(i,patLength+i ));
			if (textString.substring(i,patLength+i ).contains(patternString)) {
			//System.out.println(textString.substring(i,txtLength ).indexOf(patternString));
				System.out.println(i);
			}
		}
		scn.close();
	}

}