public class StringTxt {

	private int repitition1;
	private boolean match;

	public void search(char pattern[], char text[], int patternLength,int textLength) {

		int subPattern = findSubPatterns(pattern,patternLength);

		for (int i = 0; i < textLength; i++) {
			repitition1 = 0;
			match = true;
			for (int j = 0; j < patternLength; j++) {
				if (i + repitition1 < textLength && pattern[j] == text[i + repitition1])
					repitition1++;
				else {
					match = false;
					break;
				}
			}
			if (match) {
				System.out.println("Pattern matchs at " + (i));
				i = i + patternLength - subPattern;
			}
		}
	}

	
	public int findSubPatterns(char pattern[], int patternLength) {

		int repitition2 = 1;
		int skip = 0;

		for (int i = 0; i < patternLength; i++) {
			repitition2 = i + 1;
			repitition1 = repitition2;
			match = true;
			for (int j = 0; j < repitition2; j++) {
				if (pattern[j] == pattern[patternLength - repitition1]) 
					repitition1--;
				else 
					match = false;
			}
			if (match) 
				skip = repitition2;
		}
		return skip;
	}
}
