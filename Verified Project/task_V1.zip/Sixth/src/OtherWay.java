import java.util.regex.*;

public class OtherWay {

	//Its an optimized way of search but skip the pattern once index Matched
		public void search(String pats, String txts) {
		Pattern pattern = Pattern.compile(pats);
		Matcher matches = pattern.matcher(txts);
		while(matches.find()){
			System.out.println(matches.start());
		}
		
	}

	
}
