import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		StringTxt stringText = new StringTxt();
		// OtherWay test = new OtherWay(); /* Optimized Way */
		Scanner scn = new Scanner(System.in);
		String patternString = null,textString = null;
			System.out.println("Enter The Pattern :");
		    patternString = scn.next();
	     	System.out.println("Enter the text");
	     	textString = scn.next();
		int patternLength = patternString.length();
		int textLength = textString.length();
		if(textLength<patternLength)
			System.out.println("Invalid input : text Length less than pattern");
		char pattern[] = new char[patternLength];
		char text[] = new char[textLength];
		for (int i = 0; i < patternLength; i++) {
			pattern[i] = patternString.charAt(i);
		}
		for (int i = 0; i <textLength; i++) {
			text[i] = textString.charAt(i);
		}
		stringText.search(pattern, text,patternLength,textLength);
		// Test.search(pattern, text,patternLength,textLength);
		// test.search(pats, txts); /* Optimized Way */
		scn.close();

	}

}
