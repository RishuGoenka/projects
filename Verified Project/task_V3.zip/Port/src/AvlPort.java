import java.util.List;
import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;

public class AvlPort {

	public static void main(String[] args) {
		ServerSocket s = null;
		 List<Integer> a = new ArrayList<Integer>();
		for (int i = 0; i < 99; i++) {
			try {
				s = new ServerSocket(i);
				s.getLocalPort();
				System.out.println("yes");
			} catch (IOException e) {
				a.add(i);
				continue;
			}
		}
		 System.out.print("\t" + a);
	}
}