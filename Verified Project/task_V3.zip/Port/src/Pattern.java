public class Pattern {

	public static void main(String[] args) {
		int i, j, c, m = 5;
		for (i = 0; i < 5; i++) {
			c = i * 2 + 1;
			for (int k = 0; k < m; k++)
				System.out.print(" ");
			for (j = 0; j < c; j++) {
				System.out.print("*");
				if (j == (c - 1)){
					System.out.println();
					m--;
				}
			}
		}

	}

}
