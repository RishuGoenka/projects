public class Series {

	/**
	 * To print the Star pattern in Triangle.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		invisibleTriangle();
		invisibleReverseTriangle();
	}

	/**
	 * This print the invisible part of the Triangle.
	 */
	public static void invisibleTriangle() {
		int i, j = 5;
		for (i = 0; i <= j; i++) {
			System.out.print("@");
			if (i == j) {
				j--;
				i = -1;
				System.out.println();
			}
		}
	}

	/**
	 * This print the invisible part of the Triangle reverse.
	 */
	public static void invisibleReverseTriangle() {
		int i, j = 0;
		for (i = 0; i <= j; i++) {
			System.out.print("#");
			if (i == j && j != 5) {
				j++;
				i = -1;
				System.out.println();
			}
		}
	}

}