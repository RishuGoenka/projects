
public class Test {

	public static void main(String[] args) {
		Age ageObj = new Age();
		ageObj.setAge(12);
		
		System.out.println(ageObj.getAge());

	}

}
