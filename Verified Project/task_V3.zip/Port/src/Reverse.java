public class Reverse {

	public static void main(String[] args) {
		int i, j, k, l = 5, c;
		for (k = 5; k >= 0; k--) {
			c = k * 2 + 1;
			for (j = 5; j >= l; j--) {
				System.out.print(" ");
			}
			for (i = c; i > 0; i--) {
				System.out.print("*");
			}
			l--;
			System.out.println();
		}

	}
}
