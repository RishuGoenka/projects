import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		int arrSize = 0;
		String arrString = null;
		String[] separateArrString = new String[arrSize];
		try {
			System.out.println("Enter Array Size");
			arrSize = Integer.parseInt(read.readLine());
			if (arrSize >= 1 && arrSize <= 5000) {
				System.out.println("Enter Array");
				arrString = read.readLine();
				if (arrSize == arrString.trim().split(" ").length) {
					separateArrString = arrString.trim().split(" ");
					arrValid(separateArrString, arrSize);
				} else
					System.out.println("Array Length less than Inputed Length");
			} else
				System.out.println("Out of range");
		} catch (IllegalArgumentException | IOException e) {
			System.out.println("Invalid Input");
		}
	}

	private static void arrValid(String[] separateArrString, int arrSize) {
		try {
			for (int i = 0; i < arrSize; i++) {
				if (Integer.parseInt(separateArrString[i]) != 0
						&& Integer.parseInt(separateArrString[i]) <= 109)
					System.out.println(Integer.parseInt(separateArrString[i]));
				// Call function for Calculation
				else {
					System.out.println("Array Element out of Range");
					break;
				}
			}
		} catch (IllegalArgumentException | ArrayIndexOutOfBoundsException e) {
			System.out.println("Invalid array Element");
		}

	}

}
