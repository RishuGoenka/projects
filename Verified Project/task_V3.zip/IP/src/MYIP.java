import java.net.InetAddress;
import java.net.UnknownHostException;


public class MYIP {

	public static void main(String[] args) {
		try {
			System.out.println(InetAddress.getLocalHost());
			System.out.println(InetAddress.getLoopbackAddress());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

	}

}
