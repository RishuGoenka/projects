
public class Main {

	public static void main(String[] args) {
		for(int i=0;i<10;i++)
			new Thread(new MyThread()).start();
		
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(Counter.getCounter());
	}

}
