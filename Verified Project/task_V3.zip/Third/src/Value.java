public class Value {
	int QUANTITY = 500;
	int TOTAL = 0;

	synchronized void calc(int i) {// synchronized method
		System.out.println("Total quantity: " + i);
		QUANTITY = QUANTITY - i;
		TOTAL = TOTAL + i;
		if (QUANTITY >= 0 && TOTAL <= 500) {
			System.out.println("Quantity Remaining: " + QUANTITY);
			System.out.println("Total quantity ordered: " + TOTAL);
			System.out.println();
		} else
			System.out.println("Out of Stock");
		try {
			Thread.sleep(100);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
