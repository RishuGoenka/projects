import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) throws IOException {
		final Value valueObj = new Value();
		BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the inputs");
		String[] separate = read.readLine().trim().split(" ");
		int[] price = new int[separate.length];
		Thread[] threads = new Thread[price.length];
		for(int i =0;i<price.length;i++){
			price[i] = Integer.parseInt(separate[i]);
			final int dump = price[i];
			threads[i] = new Thread(){
				public void run(){
					valueObj.calc(dump);  
				}
			};
		}
		for(int i =0;i<price.length;i++){
			threads[i].start();
		}
	}

}
