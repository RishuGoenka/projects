public class TicTacToe {
	private static int[][] playingBoard = new int[3][3];

	public boolean checkMove(int row, int column) {
		try{
		if (playingBoard[row][column] == 0)
			return true;
		}catch(ArrayIndexOutOfBoundsException e){
			return false;
		}
		return false;
	}

	public boolean play(int row, int column, char player) {
		int move = 1;
		if (player == 'Y')
			move = 5;
		playingBoard[row][column] = move;
		print();
		return checkIfWon();

	}

	public void print(){
		for(int i=0;i<3;i++){
			for(int j=0;j<3;j++){
				if(playingBoard[i][j]==0)
					System.out.print(" ");
				else if(playingBoard[i][j]==1)
					System.out.print("X");
				else if(playingBoard[i][j]==5)
					System.out.print("O");
				
				System.out.print(" |");
			}
			System.out.println("\n-----------");
		}
	}
	
	public boolean checkIfWon() {
		String[][] winPositions = { { "00", "01", "02" }, { "10", "11", "12" },
				{ "20", "21", "22" }, { "00", "10", "20" },
				{ "01", "11", "21" }, { "02", "12", "22" },
				{ "00", "11", "22" }, { "02", "11", "20" } };

		for (int i = 0; i < winPositions.length; i++) {
			int sum = getSum(winPositions, i);
			if((sum==3)||(sum==15))
				return true;
		}
		return false;
	}

	private int getSum(String[][] winPositions, int i) {
		int sum = 0;
		for (int j = 0; j < 3; j++) {
			sum += playingBoard[Character
					.getNumericValue(winPositions[i][j].charAt(0))][Character
					.getNumericValue(winPositions[i][j].charAt(1))];
		}
		return sum;
	}
}
