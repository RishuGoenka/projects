import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class T3App {
	static boolean won = false;
	static int moves = 9;

	public static void main(String[] args) {
		try{
		TicTacToe player = new TicTacToe();
		char currentPlayer = 'X';

		while (!won && moves > 0) {
			currentPlayer = playTicTacToe(player, currentPlayer);
		}
		}catch(Exception e){
			System.out.println("Invalid Input");
		}
	}

	private static char playTicTacToe(TicTacToe player, char currentPlayer) {
		System.out.println("Enter move: row[1-3] column [1-3]");
		String[] input = getInput();
		int row = Integer.parseInt(input[0]) - 1;
		int col = Integer.parseInt(input[1]) - 1;
		currentPlayer = checkMove(player, currentPlayer, row, col);

		moves--;
		return currentPlayer;
	}

	private static char checkMove(TicTacToe player, char currentPlayer,
			int row, int col) {
		if (player.checkMove(row, col)) {
			won = player.play(row, col, currentPlayer);
			if (won) {
				System.out.println("Player " + currentPlayer + "Looses");
			}
			if (currentPlayer == 'X')
				currentPlayer = 'Y';
			else
				currentPlayer = 'X';
		} else {
			System.out.println("Invalid Move!!!");
			player.print();
			moves++;
		}
		return currentPlayer;
	}

	private static String[] getInput() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		try {
			return br.readLine().trim().split(" ");
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

}
