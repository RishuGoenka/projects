public class Cacheing {

	public static void cacheList(StringBuilder sb) {
		String[] simulationSeparate = sb.toString().split(" q1w2e3r4t5y6 ");
		int simulationLength = simulationSeparate.length;
		String[][] separate = new String[simulationLength][2];
		for (int i = 0; i < simulationLength; i++) {
			int spaceIndex = simulationSeparate[i].indexOf(" ");
			separate[i][0] = simulationSeparate[i].substring(0, spaceIndex);
			separate[i][1] = simulationSeparate[i].substring(spaceIndex + 1);
		}
		int simun = 1;
		for (int i = 0; i < simulationLength; i++) {
			System.out.println("Simunlation " + simun);
			cacheStack(Integer.parseInt(separate[i][0]), separate[i][1]);
			simun++;
		}
	}

	private static void cacheStack(int cacheSize, String simulationString) {
		StringBuilder cache = new StringBuilder("");
		do {
			if (simulationString.charAt(0) == '!') {
				System.out.println(cache);
			} else {
				if (cache.toString().contains(
						Character.toString(simulationString.charAt(0)))) {
					cache.deleteCharAt(cache.indexOf(Character
							.toString(simulationString.charAt(0))));
					cache.append(simulationString.charAt(0));
				} else if (cache.length() == cacheSize) {
					cache.deleteCharAt(0);
					cache.append(simulationString.charAt(0));
				} else {
					cache.append(simulationString.charAt(0));
				}
			}
			simulationString = simulationString.substring(1);
		} while (!"".equals(simulationString));
	}
}
