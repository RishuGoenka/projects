package com.zycus.scriptExecutor.junit;

import junit.framework.TestCase;

public class MainAppTest extends TestCase {

	@Override
	protected void setUp() throws Exception {

	}

	@Override
	protected void tearDown() throws Exception {

	}

	public void testStartVersioning() {
		assertEquals("Successfully Committed", null);
	}

}
