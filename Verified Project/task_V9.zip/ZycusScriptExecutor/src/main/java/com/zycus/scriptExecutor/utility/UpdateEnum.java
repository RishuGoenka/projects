package com.zycus.scriptExecutor.utility;

public enum UpdateEnum {
	SUCCESSFUL
}
