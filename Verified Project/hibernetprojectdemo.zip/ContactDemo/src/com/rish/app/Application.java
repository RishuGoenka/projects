package com.rish.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import com.rish.dao.ContactDAO;
import com.rish.models.Contact;

public class Application {

	public static void main(String[] args) throws IOException {

		BufferedReader read = new BufferedReader(new InputStreamReader(System.in));

		ContactDAO dao = new ContactDAO();
		dao.save(new Contact((short) 101, "Abhishek", "Bachan", "2435465"));
		dao.save(new Contact((short) 102, "Ronit", "Roy", "441165"));
		dao.save(new Contact((short) 103, "Uday", "Chopra", "4544465"));

		int id;
		String f, l, m;

		do {
			System.out.println("Enter");
			id = Integer.parseInt(read.readLine());
			f = read.readLine();
			l = read.readLine();
			m = read.readLine();
			dao.save(new Contact((short) id, f, l, m));
		} while (read.readLine().equals(""));
		List<Contact> contacts = dao.findByName("Chopra");
		System.out.println("Found" + contacts.size() + "chopras");

		for (Contact c : contacts) {
			System.out.println(c.getFirstName() + " " + c.getLastname());
		}

	}

}
