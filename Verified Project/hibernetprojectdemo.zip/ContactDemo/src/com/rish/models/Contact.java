package com.rish.models;

import java.io.Serializable;

public class Contact implements Serializable {

	private static final long serialVersionUID = 1L;

	private Short contactId;
	private String firstName, lastname;
	private String phone;

	public Contact() {
		super();
	}

	public Contact(Short contactId, String firstName, String lastname, String phone) {
		super();
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastname = lastname;
		this.phone = phone;
	}

	public Short getContactId() {
		return contactId;
	}

	public void setContactId(Short contactId) {
		this.contactId = contactId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
