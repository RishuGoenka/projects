package com.rish.app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.rish.dao.UserDAO;
import com.rish.model.User;

public class UserAPP {

	public static void main(String[] args) throws IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
		UserDAO userdaoObj = new UserDAO();
		do{
			System.out.println("Enter User name");
			String userName = read.readLine();
			System.out.println("Enter Password");
			String password = read.readLine();
			userdaoObj.save(new User(userName,password));
		}while(read.readLine().equals(""));

	}

}
