package com.rish.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.rish.app.HibernateUtil;
import com.rish.model.User;

public class UserDAO {

	private SessionFactory factory = null;

	public UserDAO() {
		factory = HibernateUtil.getFactory();
	}

	public void save(User user) {
		Session session = factory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			session.save(user);
			transaction.commit();
			System.out.println("Record Saved!");
		} catch (HibernateException ex) {
			if (transaction != null)
				transaction.rollback();
			ex.printStackTrace();
		}
		session.close();

	}

}
