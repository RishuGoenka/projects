import java.text.DateFormat;
import java.util.Date;

public class SystemDate {

	public static void main(String[] args) {
		Date d = new Date(); // Gets current system date
		String formattedDate = null;

		// try 'getDateTimeInstance' OR 'getTimeInstance'
		DateFormat ft = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL);
		formattedDate = ft.format(d);
		System.out.println("Today is " + formattedDate);
	}
}
