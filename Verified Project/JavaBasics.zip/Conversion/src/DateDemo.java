import java.text.DateFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class DateDemo {

	public static void main(String[] args) {
		String birthDate = "1/13/1991"; // Assume date is mm/dd/yyyy [US Style]

		// Date Formatter to format/parse date in US Short Style ie. mm/dd/yy
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, Locale.US);
		df.setLenient(false);
		Date d = null;
		try {
			d = df.parse(birthDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println("The date of Birth you entered is :" + d);
	}
}
