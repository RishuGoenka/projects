import java.text.NumberFormat;

public class FormatNumber {

	public static void main(String[] args) {
		float amt = 1254856.15F; // normal [Unformatted] number
		NumberFormat fm = NumberFormat.getCurrencyInstance();
		String formattedAmount = fm.format(amt);
		System.out.println("Number formatted in Currency : " + formattedAmount);
	}
}
