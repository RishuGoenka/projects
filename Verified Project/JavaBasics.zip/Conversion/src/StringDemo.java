public class StringDemo {

	public static void main(String[] args) {
		String name = "Mahendra";
		StringBuilder sb = new StringBuilder(name);
		sb.append(" ").append("Shinde").insert(0, "Mr. ");
		System.out.println(sb.toString()); // Count: 5 Objects
		
		/* Without String buffer OR builder:
		name = name + " " + "Shinde"; //Count : 5 Objects
		name = "Mr. "+ name; //Count: 7 Objects
		*/
	}
}
