public class Date extends Object {
	// Member Variables : initialized with default values
	// Instance variables : [Non Static]
	private int day, month, year;
	// Class variable : [Static]
	static char seperator = '/';

	// Member method : Instance method [Non Static]
	public Date(int day, int month, int year) {
		// Both Local and Instance variables have SAME NAME!!!
		this.day = day;
		this.month = month;
		this.year = year;
	}

	void print() {
		System.out.println("Date : " + day + seperator + month + seperator + year);
	}

	// : Class method [Static]
	static void setSeperator(char sp) {
		// Local variables : variables declared as arguments and variables
		// declared inside method body are local variables
		// In Java, local variables [Other than arguments]
		// must be initialized explicitly
		seperator = sp;
	}
}
