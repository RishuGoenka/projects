/**
 * A Sample java class
 * 
 * @author Rishu
 *
 */
public class Greeting implements Flyable {

	/**
	 * Method to display greeting message
	 * 
	 * @param arg
	 *            Name of Person to greet
	 */
	public void greet(String arg) {
		System.out.println("Hello " + arg);
	}

	@Override
	public void fly() {
		System.out.println("Interface");
	}
}
