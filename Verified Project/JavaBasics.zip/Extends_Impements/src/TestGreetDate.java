public class TestGreetDate {

	public static void main(String[] args) {
		Greeting greeting = new Greeting();
		greeting.greet("Rishu");
		System.out.println(greeting);
		Date d = new Date(180, 23, 10000);
		// d.day =180;
		// d.month = 23;
		// d.year = 10000;
		d.print();
		greeting.fly();
	}
}
