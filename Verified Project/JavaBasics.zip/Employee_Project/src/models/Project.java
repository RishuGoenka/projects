package models;

import java.util.*;

public class Project {

	public static void main(String[] args) {
		ProjectMaster project1 = new ProjectMaster(101, "Xyz", "Citi bank");
		List<Employee> team = new ArrayList<>();
		ProjectDetails details = new ProjectDetails(project1, team);
		team.add(new Employee(123, "Raj", "singh", "PDT"));
		team.add(new Employee(124, "Shounab", "sharma", "PDT"));
		System.out.println(details.toString());
	}
}
