package models;

import java.io.Serializable;

public class ProjectMaster implements Serializable {
	private static final long serialVersionUID = -5222369040367361484L;
	private int projectId;
	private String title;
	private String clientName;

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public ProjectMaster(int projectId, String title, String clientName) {
		super();
		this.projectId = projectId;
		this.title = title;
		this.clientName = clientName;
	}

	public ProjectMaster() {
		super();
	}

}
