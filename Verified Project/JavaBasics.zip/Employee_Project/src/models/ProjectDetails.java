package models;

import java.io.Serializable;
import java.util.List;

public class ProjectDetails implements Serializable {

	private static final long serialVersionUID = 4529706160391676503L;
	private ProjectMaster project;
	private List<Employee> team;

	public ProjectDetails(ProjectMaster project, List<Employee> team) {
		super();
		this.project = project;
		this.team = team;
	}

	public ProjectMaster getProject() {
		return project;
	}

	public void setProject(ProjectMaster project) {
		this.project = project;
	}

	public List<Employee> getTeam() {
		return team;
	}

	public void setTeam(List<Employee> team) {
		this.team = team;
	}

	@Override
	public String toString() {
		return "ProjectDetails [project=" + project + ", team=" + team + "]";
	}

}
