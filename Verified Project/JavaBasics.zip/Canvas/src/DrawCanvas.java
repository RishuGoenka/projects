public class DrawCanvas {
	public static void main(String[] args) {
		CanvasV1 can = new CanvasV1();
		can.drawLine(5);
		can.drawLine(CanvasV1.DOUBLE_LINE);

		CanvasV2 can2 = new CanvasV2();
		can2.drawLine(LineStyle.SINGLE_LINE);
	}
}
