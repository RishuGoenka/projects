public class Memory {

	public static void main(String[] args) {
		long memory = Runtime.getRuntime().maxMemory();
		System.out.println("Memory available : " + memory / (1024 * 1024));

		long totalMemory = Runtime.getRuntime().totalMemory();
		System.out.println("Memory total : " + totalMemory / (1024 * 1024));

		double data[] = new double[100000000];
		for (int i = 0; i < data.length; i++)
			data[i] = i * 1.1;
	}
}
