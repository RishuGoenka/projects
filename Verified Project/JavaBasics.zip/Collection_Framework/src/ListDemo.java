import java.util.*;

public class ListDemo {

	public static void main(String[] args) {

		Collection data = new ArrayList();
		data.add("Dharmendra");
		data.add("Rajendra");
		data.add(10.0);
		data.add("Narendra");
		data.add("Rajendra");
		data.add("Jeetendra");
		data.add("Gajendra");
		data.add("Surendra");
		data.add("Shailendra");
		data.add("Jeetendra");

		Iterator it = data.iterator();
		while (it.hasNext())
			System.out.println(it.next());

		for (Object obj : data) // Internally uses iterator object
			System.out.println(obj + " is type of " + obj.getClass().getName());
	}

}
