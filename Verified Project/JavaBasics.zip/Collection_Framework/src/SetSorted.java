import java.util.*;

public class SetSorted {

	public static void main(String[] args) {

		SortedSet<String> friends = new TreeSet<>();
		friends.add("Dharmendra");
		friends.add("Jeetendra");
		friends.add("Rajendra");
		friends.add("Gajendra");
		friends.add("Surendra");
		friends.add("Shailendra");

		System.out.println("FRiends : ");
		for (String s : friends) {
			System.out.println(s);
		}
	}

}
