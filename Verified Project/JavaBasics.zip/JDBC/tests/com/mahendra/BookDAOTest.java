package com.mahendra;

import static org.junit.Assert.*;

import org.junit.Test;

public class BookDAOTest {

	@Test
	public void testSave() {
		
		BookDAO dao = new BookDAO();
		
		dao.save(112, "Athiesm - The case against god", "George H. Smith");
		
		assertEquals("Athiesm - The case against god", dao.findTitleById(112));
	}

}
