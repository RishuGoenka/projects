package com.mahendra;

import java.sql.*;

public class BookDAOV2 {

	private static final String FIND_BY_ID = "select * from books where book_id = ?";
	private static final String INSERT_QUERY = "insert into books values(?,?,?,?)";
	private static final String UPDATE_QUERY = "update books set title=?, author=?, status=? where book_id=?";
	private static final String DELETE_QUERY = "delete from books where book_id=?";

	public void save(Book book) {
		Connection con = DBUtil.openConnection();
		try {
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);
			ps.setInt(1, book.getBookId());
			ps.setString(2, book.getTitle());
			ps.setString(3, book.getAuthor());
			ps.setString(4, book.getStatus());
			int n = ps.executeUpdate();
			System.out.println(n + " Record created!");
		} catch (SQLException se) {
			System.out.println("Unable to save new book");
			se.printStackTrace();
		}
		DBUtil.closeConnection(con);
	}

	public Book findById(int id) {
		Book book = null;
		Connection con = DBUtil.openConnection();
		try {
			PreparedStatement ps = con.prepareStatement(FIND_BY_ID);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			book = new Book();
			if (rs.next()) {
				book.setBookId(rs.getInt(1));
				book.setTitle(rs.getString(2));
				book.setAuthor(rs.getString(3));
				book.setStatus(rs.getString(4));
			}
		} catch (SQLException se) {
			System.out.println("Unable to find book");
			se.printStackTrace();
		}
		DBUtil.closeConnection(con);

		return book;
	}

	public void modify(Book b) {
		Connection con = DBUtil.openConnection();
		try {
			PreparedStatement ps = con.prepareStatement(UPDATE_QUERY);
			ps.setString(1, b.getTitle());
			ps.setString(2, b.getAuthor());
			ps.setString(3, b.getStatus());
			ps.setInt(4, b.getBookId());
			ps.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		DBUtil.closeConnection(con);
	}

	public void delete(int bookId) {
		Connection con = DBUtil.openConnection();
		try {
			PreparedStatement ps = con.prepareStatement(DELETE_QUERY);
			ps.setInt(1, bookId);
			ps.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}
		DBUtil.closeConnection(con);
	}

	public void delete(Book book) {
		delete(book.getBookId());
	}
}
