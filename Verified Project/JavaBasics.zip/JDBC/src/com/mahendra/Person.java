package com.mahendra;

public class Person {
	static {
		System.out.println("Loading class person");
	}
}
