package pack;

import java.sql.*;
import com.mahendra.DBUtil;

public class StatementDemo {

	public static void main(String[] args) throws SQLException {
		Connection con = null;
		Statement st = null;

		// Step1 : Get connection
		con = DBUtil.openConnection();

		// Step2 : Get Statement
		st = con.createStatement();

		// Step3 : Execute a DQL Statement
		ResultSet rs = st.executeQuery("select * from members");

		// Step4 : Iterate over ResultSet
		while (rs.next()) {
			// Print value of 1st Attribute/Column in INT type
			// Print values of 2nd and 3rd in String type
			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3));
		}
		// Step5 : Close the connection
		DBUtil.closeConnection(con);
	}
}
