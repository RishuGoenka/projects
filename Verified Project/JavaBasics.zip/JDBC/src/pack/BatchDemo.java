package pack;

import java.sql.*;
import com.mahendra.DBUtil;

public class BatchDemo {
	private static final String INSERT_QUERY = "insert into books values(?,?,?,?)";

	public static void main(String arg[]) throws SQLException {
		Connection con = null;
		PreparedStatement ps = null;

		con = DBUtil.openConnection();
		ps = con.prepareStatement(BatchDemo.INSERT_QUERY);

		for (int i = 201; i <= 205; i++) {
			ps.setInt(1, i);
			ps.setString(2, "Harry Potter Vol " + i);
			ps.setString(3, "J.K. Rolling");
			ps.setString(4, "A");
			ps.addBatch();
			System.out.println("Added ONE statement to Batch");
		}

		// Send ALL statements/SQL queries to Server at ONCE
		int[] rs = ps.executeBatch();
		System.out.println(rs);
		System.out.println("Records added...");
		DBUtil.closeConnection(con);
	}
}
