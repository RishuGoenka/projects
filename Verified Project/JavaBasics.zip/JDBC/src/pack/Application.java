package pack;

public class Application {

	public static void main(String[] args) {
		// Implicit class loading
		// com.mahendra.Person p = new com.mahendra.Person();

		// Manual class loading
		try {
			Class.forName(args[0]);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
