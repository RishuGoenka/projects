package data;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import model.Product;

/**
 * Write/Read binary data from file
 * 
 * @author rishu
 *
 */
public class DataManagerBinary implements IProductDAO {

	private static final String DATAFILE = "./products.dat";

	@Override
	public void add(Product p) {
		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream(new FileOutputStream(DataManagerBinary.DATAFILE));
			out.writeObject(p);
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

	}

	@Override
	public Product[] getAll() {
		return null;
	}

	@Override
	public Product get() {
		ObjectInputStream oin = null;
		Product p = null;
		try {
			oin = new ObjectInputStream(new FileInputStream(DataManagerBinary.DATAFILE));
			Object obj = null;
			obj = oin.readObject();
			if (obj != null && obj instanceof Product) {
				p = (Product) obj;
			}
		} catch (IOException | ClassNotFoundException ex) {
			ex.printStackTrace();
		}
		return p;
	}
}
