package data;

import model.Product;

/**
 * Data Access Object [DAO] Interface Inform Developers working on next layer
 * what all methods are available
 * 
 * You must provided Minimum ONE implementation of this interface
 * 
 * @author rishu
 *
 */
public interface IProductDAO {
	/**
	 * Method to add product, target depends on which implementation you choose
	 * 
	 * @param p
	 *            Product to be saved/recorded
	 */
	void add(Product p);

	/**
	 * Get all the products saved
	 * 
	 * @return Array of products
	 */
	Product[] getAll();

	/**
	 * Get Single product
	 * 
	 * @return Product read from file/database
	 */
	Product get();
}
