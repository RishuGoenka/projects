import java.util.concurrent.Callable;

// A Callable Task, which may return a value!!
public class FactorialCalculator implements Callable<Long> {
	private long number;

	public FactorialCalculator(long number) {
		super();
		this.number = number;
	}

	@Override
	public Long call() throws Exception {
		if (number <= 0) // Factorial only for >0 numbers
			return 1L;
		System.out.println("Calculating factorial in Thread " + Thread.currentThread().getName());
		long fact = 1;
		for (long value = 1; value <= number; value++) {
			fact *= value;
		}
		return fact;
	}
}
