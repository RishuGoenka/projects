import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Application3 {

	public static void main(String[] args) {
		// Common Account object
		Account jointAccount = new Account(10112, "Rajiv Bhatia", 35000, new Date());
		ATMWithdrawal akshayAtmCard = new ATMWithdrawal(jointAccount, 20000);
		ATMWithdrawal twinkleAtmCard = new ATMWithdrawal(jointAccount, 21000);
		ExecutorService service = Executors.newCachedThreadPool();
		service.execute(akshayAtmCard);
		service.execute(twinkleAtmCard);
		try {
			// Wait for 10 seconds
			// So all jobs are done
			service.shutdown(); // If All Tasks are Over, time-out of 10 seconds
								// WIll be ignored!
			service.awaitTermination(10, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// Run this statement only after child thread t1 and t2 are
		// finished/dead
		System.out.println("The balance left is : " + jointAccount.getBalance());
	}
}
