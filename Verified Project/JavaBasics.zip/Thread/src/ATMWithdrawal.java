public class ATMWithdrawal implements Runnable {
	private Account account; // Account from which to withdraw
	private double amount; // Amount to withdraw

	public ATMWithdrawal(Account account, double amount) {
		super();
		this.account = account;
		this.amount = amount;
	}

	@Override
	public void run() {

		synchronized (account) { // Lock account object
			System.out.println("Thread name: " + Thread.currentThread().getName());
			System.out.println("Preparing to withdraw " + amount + " from " + account.getAccountNumber());

			AccountTransaction tn = new AccountTransaction();
			System.out.println("Checking for balance ");
			double temp = account.getBalance();
			if (temp < amount) {
				System.out.println("No sufficient funds!, Aborting...");
				return; // Quit from run method
			}
			if (tn.withdraw(account, amount)) {
				System.out.println("Withdrawal was successful");
			} else
				System.out.println("Withdrawal failed!!");
		} // Unlock account object
	}
}
