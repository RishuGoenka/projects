import java.util.Date;

public class Account {
	private int accountNumber;
	private String holderName;
	private double balance;

	private Date dateOfOpenining;

	public Account(int accountNumber, String holderName, double balance, Date dateOfOpenining) {
		super();
		this.accountNumber = accountNumber;
		this.holderName = holderName;
		this.balance = balance;
		this.dateOfOpenining = dateOfOpenining;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public String getHolderName() {
		return holderName;
	}

	public Date getDateOfOpenining() {
		return dateOfOpenining;
	}

}
