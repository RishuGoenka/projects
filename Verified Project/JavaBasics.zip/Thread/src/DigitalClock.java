import java.text.DateFormat;
import java.util.Date;

//Create / Define a Task to run
public class DigitalClock implements Runnable {

	@Override
	public void run() {
		// Initialize DateFormat instance to extract TIME value
		DateFormat df = DateFormat.getTimeInstance(DateFormat.LONG);
		int i = 0;
		while (i < 10) {
			Date now = new Date(); // Get current date and time
			String time = df.format(now);
			System.out.println(System.nanoTime());
			System.out.println(time);
			i++;
		}
	}
}
