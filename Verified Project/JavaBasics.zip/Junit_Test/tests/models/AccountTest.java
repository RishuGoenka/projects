package models;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.Test;

public class AccountTest {

	@Test
	public void testGetBalance() {
		Account a = new Account(101, "Abhishek Bacchan", 23500D, new Date());
		assertEquals("Incorrect balance", 23500D, a.getBalance(), 0.01);
	}

	@Test
	public void testGetAccountNumber() {
		Account a = new Account(101, "Abhishek Bacchan", 23500D, new Date());
		assertEquals(101, a.getAccountNumber());
	}
}
