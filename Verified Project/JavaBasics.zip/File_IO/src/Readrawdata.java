import java.io.IOException;

public class Readrawdata {

	public static void main(String[] args) {
		String name = null;
		System.out.println("Enter your name: ");
		byte[] rawdata = new byte[100];

		try {
			int x = System.in.read(rawdata);
			name = new String(rawdata, 0, x);
			System.out.println("Hello " + name.trim() + " How are you?");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
