public class InvalidRateOfInterestException extends Exception {

	private static final long serialVersionUID = -5043420309963762246L;

	public InvalidRateOfInterestException(String arg0) {
		super(arg0);
	}
}
