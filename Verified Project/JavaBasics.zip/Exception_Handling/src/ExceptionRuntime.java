public class ExceptionRuntime {

	public static void main(String[] args) {
		int sum = 0;
		for (String a : args) {
			try {
				sum += Integer.parseInt(a);
			} catch (RuntimeException xe) {
				System.out.println("Invalid number " + a + " and there for ignored");
			}
		}
		System.out.println("Sum is " + sum);
	}
}
