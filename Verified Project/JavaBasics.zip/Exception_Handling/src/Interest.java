
public class Interest {

	public static void main(String[] args) {
		InterestCalculator calc = new InterestCalculator();
		try {
			double amt = calc.calcInterest(150000, 42.05F, 60);
			System.out.println(amt);
		} catch (InvalidRateOfInterestException ex) {
			throw new RuntimeException("Invalid rate", ex);
		}
	}
}
