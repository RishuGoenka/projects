public abstract class Customer {
	protected int customerId;
	protected String firstName;
	protected String lastName;

	public Customer(int customerId, String firstName, String lastName) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public void print() {
		System.out.println("Name : " + firstName + " " + lastName);
	}

	public int hashCode() {
		return 0xc0e39;
	}

	public boolean equals(Object obj) {
		if (obj instanceof Customer) {
			Customer target = (Customer) obj;
			if (this.customerId == target.customerId)
				return true;
		}
		return false;
	}

	public String toString() {
		return firstName;
	}
}
