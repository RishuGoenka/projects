package service;

import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.List;
import java.util.concurrent.Callable;
import models.Person;

public class LoadPersonList implements Callable<List<Person>> {

	private String dataFile;

	public LoadPersonList(String dataFile) {
		super();
		this.dataFile = dataFile;
	}

	public List<Person> call() throws Exception {
		List<Person> personList = null;
		try (ObjectInputStream oin = new ObjectInputStream(new FileInputStream(dataFile))) {
			Object obj = oin.readObject();
			if (obj != null && obj instanceof List) {
				personList = (List<Person>) obj;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		return personList;
	}

}
