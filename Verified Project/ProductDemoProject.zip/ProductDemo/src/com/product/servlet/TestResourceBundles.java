package com.product.servlet;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.spi.LocaleServiceProvider;

public class TestResourceBundles {

	private static final String WELCOME_KEY = "welcome";

	public static void main(String[] args) {

		ResourceBundle bundle = ResourceBundle.getBundle("messages",Locale.getDefault());

		System.out.println("Default Welcome message : "
				+ bundle.getString(TestResourceBundles.WELCOME_KEY));
		
		bundle = ResourceBundle.getBundle("messages",Locale.FRANCE);
		System.out.println("France Welcome message : "
				+ bundle.getString(TestResourceBundles.WELCOME_KEY));
		
		bundle = ResourceBundle.getBundle("messages",Locale.GERMANY);
		System.out.println("GERMAN Welcome message : "
				+ bundle.getString(TestResourceBundles.WELCOME_KEY));

	}

}
