package com.product.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.product.models.Product;
import com.product.service.ProductService;

import java.util.logging.*;
/**
 * Servlet implementation class ShowProductServlet
 */
public class ShowProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShowProductServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	private ProductService service = null;
	private Logger logger;
	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		service = ProductService.getInstance();
		logger = Logger.getLogger(ShowProductServlet.class.getName());
	}

	/**
	 * @see Servlet#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		logger.info("loding list of product");
		List<Product> products = service.list();
		logger.info("Got" + products.size()+ "products");
		Object obj = request.getAttribute("message");
		List<String> messages = null;
		if (obj == null) {
			messages = new ArrayList<String>();
			logger.warning("no message found in the request scope");
		} else {
			messages = (List<String>) obj;
		}
		messages.add("Found " + products.size()+"records");
		
		request.setAttribute("productList", products);
		request.setAttribute("messages", messages);
		
		RequestDispatcher view = request.getRequestDispatcher("home.jsp");
		view.forward(request, response);
	}
}
