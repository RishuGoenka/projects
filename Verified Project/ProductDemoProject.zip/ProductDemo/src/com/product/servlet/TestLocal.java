package com.product.servlet;

import java.util.Locale;

public class TestLocal {

	public static void main(String[] args) {
		Locale locale = new Locale("en","US");//Locale.getDefault();

		System.out.println(locale.getCountry()+"  "+locale.getDisplayName() + "  " + locale.getDisplayLanguage());
		
		Locale[] locales = locale.getAvailableLocales();
		System.out.println("Support locales are:" + locales.length);
		for(Locale x : locales)
		{
			System.out.println(x.getDisplayName());
		}
	}

}
