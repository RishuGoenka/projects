package com.product.service;

import java.util.List;

import com.product.dao.ProductDAO;
import com.product.models.Product;

public class ProductService {
	private static ProductService service = null;
	private ProductDAO dao;

	public static ProductService getInstance() {
		if (service == null) // create if doesn't exists
			service = new ProductService();
	
		return service;
	}

	public ProductService() {
		dao = ProductDAO.getInstance();
	}

	public void add(Product p) {
		// Check if product exists
		Product temp = dao.findById(p.getProductId());
		if (temp == null)
			dao.save(p);
		else
			throw new RuntimeException("Product already exists");
	}

	public void edit(Product p) {
		dao.modify(p);
	}

	public void delete(int id) {
		dao.remove(id);
	}
	
	public List<Product> list(){
		return dao.getAll();
	}

}
