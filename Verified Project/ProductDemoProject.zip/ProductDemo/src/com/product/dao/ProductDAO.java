package com.product.dao;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;



import com.product.models.Product;

public class ProductDAO {
	private List<Product> products = null;

	// Simple implementation to make it singleton
	private static ProductDAO dao;

	/**
	 * Method to get Singleton instance of ProductDAO Syntax: ProductDAO dao =
	 * ProductDAO.getInstance();
	 * 
	 * @return Single instance of ProductDAO
	 */
	public static ProductDAO getInstance() {
		if (dao == null) // create if doesn't exists
			dao = new ProductDAO();
		return dao;
	}

	private ProductDAO() {
		products = new LinkedList<Product>();
		Product p1 = new Product(0, null, null);
		p1.setProductId(1);
		p1.setName("Bajaj");
		p1.setDescription("auto");
		p1.setPrice(2100);
		
		products.add(p1);
	}

	public synchronized void save(Product p) {
		products.add(p);
	}

	public synchronized Product findById(int id) {
		for (Product p : products) {
			if (p.getProductId() == id)
				return p;
		}
		return null;
	}

	public synchronized void modify(final Product p) {
		Product old = findById(p.getProductId());
		if (old != null) {
			old.setName(p.getName());
			old.setDescription(p.getDescription());
			old.setPrice(p.getPrice());
		} else
			throw new RuntimeException("Product doesn't exists");
	}

	public synchronized void remove(int id) {
		Product old = findById(id);
		if (old != null)
			throw new RuntimeException("Product doesn't exists");
		products.remove(old);
	}

	public synchronized  List<Product> getAll() {
		// TODO Auto-generated method stub
		return Collections.unmodifiableList(products);
	}
}
