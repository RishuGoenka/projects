package com.rish.app;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.rish.models.CustomerMaster;

public class CustomerApp {

	public static void main(String[] args) {
		SessionFactory factory = new Configuration().configure()
				.buildSessionFactory();

		Session session = factory.openSession();
		Transaction transaction = session.getTransaction();

		CustomerMaster customer = new CustomerMaster();
		customer.setCustomerID("123");
		customer.setFirstName("Rish");
		customer.setLastName("Goenka");
		customer.setEmail("rg@gmail.com");
		customer.setPassword("password");
		customer.setAddress("address");
		try {
			transaction.begin();
			session.save(customer);
			transaction.commit();
			System.out.println("record have been saved!");
		} catch (HibernateException ex) {
			ex.printStackTrace();
			if (transaction != null) {
				transaction.rollback();
			}

			session.close();
		}

	}

}
