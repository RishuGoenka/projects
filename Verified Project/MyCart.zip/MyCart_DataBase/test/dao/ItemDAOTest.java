package dao;

import static org.junit.Assert.assertEquals;
import models.Item;

import org.junit.Test;

public class ItemDAOTest {

	@Test
	public void testInsert() {
		ItemDAO itemdaoObj = new ItemDAO();
		Item item = null;
		item = new Item("Id", "catagory", "itemname", "description", 125, 5);
		itemdaoObj.insert(item);
		assertEquals("itemname", itemdaoObj.findById("Id").getItemName());
	}

}
