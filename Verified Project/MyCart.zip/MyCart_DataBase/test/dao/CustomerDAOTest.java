package dao;

import static org.junit.Assert.*;
import models.Customer;
import dao.CustomerDAO;

import org.junit.Test;

public class CustomerDAOTest {

	@Test
	public void testinsert() {
		CustomerDAO customerdaoObj = new CustomerDAO();
		Customer customer = null;
		customer = new Customer("Id", "first", "last", "email",
				"password", "password");
		customerdaoObj.insert(customer);
		assertEquals("email", customerdaoObj.findById("Id")
				.getEmail());
	}

}
