package models;

public class Item implements Comparable<Item> {
	private String itemID;
	private String catagory;
	private String itemName;
	private String description;
	private Integer price;
	private Integer quantity;

	public String getItemID() {
		return itemID;
	}

	public void setItemID(String itemID) {
		this.itemID = itemID;
	}

	public String getCatagory() {
		return catagory;
	}

	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	/**
	 * @param itemID
	 * @param catagory
	 * @param itemName
	 * @param description
	 * @param price
	 * @param quantity
	 */
	public Item(String itemID, String catagory, String itemName, String description, Integer price, Integer quantity) {
		super();
		this.itemID = itemID;
		this.catagory = catagory;
		this.itemName = itemName;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
	}

	public Item() {
		super();
	}

	@Override
	public int compareTo(Item item) {
		if (this.equals(item))
			return 0;
		else
			return -1;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((itemName == null) ? 0 : itemName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (itemName == null) {
			if (other.itemName != null)
				return false;
		} else if (!itemName.equals(other.itemName))
			return false;
		return true;
	}

}
