package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import models.Item;
import database.DataBaseUtil;

public class ItemDAO {
	public static final String INSERT_QUERY = "insert into item values(?,?,?,?,?,?)";
	public static final String FIND_BY_ID = "select * from item where ItemID=?";
	public static final String UPDATE_QUERY = "update item set catagory=? item_name=?, desciption=?,price=?, quantity=?  where ItemID=?";
	public static final String DELETE_QUERY = "delete from item where ItemID=?";

	public void insert(Item item) {
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(INSERT_QUERY);
			preparedstatmentObj.setString(1, item.getItemID());
			preparedstatmentObj.setString(2, item.getCatagory());
			preparedstatmentObj.setString(3, item.getItemName());
			preparedstatmentObj.setString(4, item.getDescription());
			preparedstatmentObj.setInt(5, item.getPrice());
			preparedstatmentObj.setInt(6, item.getQuantity());

			int update = preparedstatmentObj.executeUpdate();
			System.out.println(update + "record created!");
		} catch (SQLException e) {
			System.out.println("Unable to save new Item");
			e.printStackTrace();
		}

	}

	public Item findById(String itemID) {
		Item item = null;
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(FIND_BY_ID);
			preparedstatmentObj.setString(1, itemID);
			ResultSet resultsetObj = preparedstatmentObj.executeQuery();
			if (resultsetObj.next()) {
				item = new Item(resultsetObj.getString(1),
						resultsetObj.getString(2), resultsetObj.getString(3),
						resultsetObj.getString(4), resultsetObj.getInt(5),
						resultsetObj.getInt(6));
			}
			return item;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void modify(Item item) {
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(UPDATE_QUERY);
			preparedstatmentObj.setString(1, item.getCatagory());
			preparedstatmentObj.setString(2, item.getItemName());
			preparedstatmentObj.setString(3, item.getDescription());
			preparedstatmentObj.setInt(4, item.getPrice());
			preparedstatmentObj.setInt(5, item.getQuantity());
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseUtil.closeConnection(connectionObj);
	}

	public void delete(String itemID) {
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(DELETE_QUERY);
			preparedstatmentObj.setString(1, itemID);
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseUtil.closeConnection(connectionObj);
	}

	public void delete(Item item) {
		delete(item.getItemID());
	}

}
