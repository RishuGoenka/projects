package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import models.Order;
import database.DataBaseUtil;

public class OrderDAO {
	public static final String INSERT_QUERY = "insert into orders values(?,?,?,?)";
	public static final String FIND_BY_ID = "select * from orders where orderID=?";
	public static final String UPDATE_QUERY = "update orders set order_name=? item_name=?, quantity=?  where orderID=?";
	public static final String DELETE_QUERY = "delete from order where orderID=?";

	public void insert(Order order) {
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(INSERT_QUERY);
			preparedstatmentObj.setString(1, order.getOrderId());
			preparedstatmentObj.setString(2, order.getOrderName());
			preparedstatmentObj.setString(3, order.getItemName());
			preparedstatmentObj.setInt(4, order.getQuantity());

			int update = preparedstatmentObj.executeUpdate();
			System.out.println(update + "record created!");
		} catch (SQLException e) {
			System.out.println("Unable to save new Order");
			e.printStackTrace();
		}

	}

	public Order findById(String orderID) {
		Order order = null;
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(FIND_BY_ID);
			preparedstatmentObj.setString(1, orderID);
			ResultSet resultsetObj = preparedstatmentObj.executeQuery();
			if (resultsetObj.next()) {
				order = new Order(resultsetObj.getString(1),
						resultsetObj.getString(2), resultsetObj.getString(3),
						resultsetObj.getInt(4));
			}
			return order;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void modify(Order order) {
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(UPDATE_QUERY);
			preparedstatmentObj.setString(1, order.getOrderName());
			preparedstatmentObj.setString(2, order.getItemName());
			preparedstatmentObj.setInt(5, order.getQuantity());
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseUtil.closeConnection(connectionObj);
	}

	public void delete(String orderID) {
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(DELETE_QUERY);
			preparedstatmentObj.setString(1, orderID);
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseUtil.closeConnection(connectionObj);
	}

	public void delete(Order order) {
		delete(order.getOrderId());
	}

}
