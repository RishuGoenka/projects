package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import models.Customer;
import database.DataBaseUtil;

public class CustomerDAO {
	public static final String INSERT_QUERY = "insert into customer values(?,?,?,?,?,?)";
	public static final String FIND_BY_ID = "select * from customer where CustomerID=?";
	public static final String UPDATE_QUERY = "update customer set first_name= ?, last_name=?,email=?, password=?,address=?  where CustomerID=?";
	public static final String DELETE_QUERY = "delete from customer where CustomerID=?";

	public void insert(Customer customer) {
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(INSERT_QUERY);
			preparedstatmentObj.setString(1, customer.getCustomerID());
			preparedstatmentObj.setString(2, customer.getFirstName());
			preparedstatmentObj.setString(3, customer.getLastName());
			preparedstatmentObj.setString(4, customer.getEmail());
			preparedstatmentObj.setString(5, customer.getPassword());
			preparedstatmentObj.setString(6, customer.getAddress());

			int update = preparedstatmentObj.executeUpdate();
			System.out.println(update + "record created!");
		} catch (SQLException e) {
			System.out.println("Unable to save new Customer");
			e.printStackTrace();
		}

	}

	public Customer findById(String customerID) {
		Customer customer = null;
		Connection connectionObj = DataBaseUtil.openConnection();

		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(FIND_BY_ID);
			preparedstatmentObj.setString(1, customerID);
			ResultSet resultsetObj = preparedstatmentObj.executeQuery();
			if (resultsetObj.next()) {
				customer = new Customer(resultsetObj.getString(1),
						resultsetObj.getString(2), resultsetObj.getString(3),
						resultsetObj.getString(4), resultsetObj.getString(5),
						resultsetObj.getString(6));
			}
			return customer;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void modify(Customer customer) {
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(UPDATE_QUERY);
			preparedstatmentObj.setString(1, customer.getFirstName());
			preparedstatmentObj.setString(2, customer.getLastName());
			preparedstatmentObj.setString(3, customer.getEmail());
			preparedstatmentObj.setString(4, customer.getPassword());
			preparedstatmentObj.setString(5, customer.getAddress());
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseUtil.closeConnection(connectionObj);
	}

	public void delete(String customerID) {
		Connection connectionObj = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj
					.prepareStatement(DELETE_QUERY);
			preparedstatmentObj.setString(1, customerID);
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseUtil.closeConnection(connectionObj);
	}

	public void delete(Customer customer) {
		delete(customer.getCustomerID());
	}

}
