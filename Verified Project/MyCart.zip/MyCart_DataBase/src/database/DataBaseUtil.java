package database;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DataBaseUtil {

	private static Properties loadProperties(String progFile) {
		Properties propertiesObj = new Properties();
		try {
			propertiesObj.load(DataBaseUtil.class.getResourceAsStream(progFile));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return propertiesObj;
	}

	public static Connection openConnection() {
		Properties propertiesObj = loadProperties("/db.properties");
		Connection ObjConnection = null;
		try {
			Class.forName(propertiesObj.getProperty("driver"));
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Unable to connect", e);
		}
		try {
			ObjConnection = DriverManager.getConnection(propertiesObj.getProperty("url"),
					propertiesObj.getProperty("user"), propertiesObj.getProperty("password"));
			System.out.println("Connected to " + ObjConnection.getMetaData().getDatabaseProductName());

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ObjConnection;

	}

	public static void closeConnection(Connection ObjConnection) {
		try {
			ObjConnection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
