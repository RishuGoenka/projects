package com.rish.dao;

import org.junit.Test;

import com.rish.dao.ItemDAO;

public class ItemDAOTest {

	@Test
	public void testInsert() {
		ItemDAO.insert("test1","gjg","first","last",52,2);
	}

}
	