package com.rish.dao;

import org.junit.Test;

public class OrderDAOTest {

	@Test
	public void testInsert() {
		OrderDAO.insert("test1","11","326",52);
	}

}
