package com.rish.dao;

import org.junit.Test;

public class CustomerMasterDAOTest {

	@Test
	public void testInsert() {
		CustomerMasterDAO.insert("test1", "11", "first", "last", "email", "passs");
	}

}
