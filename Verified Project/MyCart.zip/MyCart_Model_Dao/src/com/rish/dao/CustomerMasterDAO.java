package com.rish.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.rish.models.CustomerMaster;

public class CustomerMasterDAO {

	static SessionFactory factory = new Configuration().configure()
			.buildSessionFactory();

	static Session session = factory.openSession();
	static Transaction transaction = session.getTransaction();

	public static void insert(String CustomerID, String FirstName,
			String LastName, String Email, String Password, String address) {

		CustomerMaster customer = new CustomerMaster(CustomerID, FirstName,
				LastName, Email, Password, address);
		try {
			transaction.begin();
			session.save(customer);
			transaction.commit();
			System.out.println("record have been saved!");
		} catch (HibernateException ex) {
			ex.printStackTrace();
			if (transaction != null) {
				transaction.rollback();
			}

			session.close();
		}
	}
}
