package com.rish.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.rish.models.ItemMaster;

public class ItemDAO {
	
	static SessionFactory factory = new Configuration().configure()
			.buildSessionFactory();

	static Session session = factory.openSession();
	static Transaction transaction = session.getTransaction();

	public static void insert(String itemID, String catagory, String itemName,
			String description, Integer price, Integer quantity) {

		ItemMaster item = new ItemMaster(itemID, catagory, itemName, description, price, quantity);
		try {
			transaction.begin();
			session.save(item);
			transaction.commit();
			System.out.println("record have been saved!");
		} catch (HibernateException ex) {
			ex.printStackTrace();
			if (transaction != null) {
				transaction.rollback();
			}

			session.close();
		}
	}

}
