package com.rish.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.rish.models.OrderMaster;

public class OrderDAO {
	
	static SessionFactory factory = new Configuration().configure()
			.buildSessionFactory();

	static Session session = factory.openSession();
	static Transaction transaction = session.getTransaction();

	public static void insert(String orderId, String orderName, String itemName,
			Integer quantity) {

		OrderMaster order = new OrderMaster(orderId, orderName, itemName, quantity);
		try {
			transaction.begin();
			session.save(order);
			transaction.commit();
			System.out.println("record have been saved!");
		} catch (HibernateException ex) {
			ex.printStackTrace();
			if (transaction != null) {
				transaction.rollback();
			}

			session.close();
		}
	}

}
