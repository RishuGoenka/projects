package model;

import java.io.Serializable;

public class AdminUser implements Serializable {
	private static final long serialVersionUID = 6439863214484494279L;
	private String adminID;
	private String fullName;
	private String email;
	private String password;

	public AdminUser() {
		super();
	}

	/**
	 * @param adminID
	 * @param fullName
	 * @param email
	 * @param password
	 */
	public AdminUser(String adminID, String fullName, String email, String password) {
		super();
		this.adminID = adminID;
		this.fullName = fullName;
		this.email = email;
		this.password = password;
	}

	public String getAdminID() {
		return adminID;
	}

	public void setAdminID(String adminID) {
		this.adminID = adminID;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
