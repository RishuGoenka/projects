package model;

import java.io.Serializable;

public class OrderMaster implements Serializable {

	private static final long serialVersionUID = -8522218405829214110L;
	private String orderID;
	private String orderName;
	private String itemName;
	private Integer quantity;

	public OrderMaster() {
		super();
	}

	/**
	 * @param orderID
	 * @param orderName
	 * @param itemName
	 * @param quantity
	 */
	public OrderMaster(String orderID, String orderName, String itemName, Integer quantity) {
		super();
		this.orderID = orderID;
		this.orderName = orderName;
		this.itemName = itemName;
		this.quantity = quantity;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setOrderID(String orderID) {
		this.orderID = orderID;
	}

	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}