package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import model.CustomerMaster;
import model.ItemMaster;
import model.OrderMaster;
import data.FileWrite;

public class DemoApp {
	static BufferedReader read = new BufferedReader(new InputStreamReader(System.in));

	public static void main(String[] args) throws IOException {
		String choice = null;
		Boolean match = true;
		DemoApp obj = new DemoApp();

		do {
			switch (select()) {
			case 1:
				obj.createUser();
				System.out.println("for performing more opertion Enter True else False");
				choice = read.readLine();
				break;
			case 2:
				obj.insertItem();
				System.out.println("for performing more opertion Enter True else False");
				choice = read.readLine();
				break;
			case 3:
				obj.createOrder();
				System.out.println("for performing more opertion Enter True else False");
				choice = read.readLine();
				break;
			default:
				System.out.println("invalid Choice");
			}

		} while (match.equals(choice.toLowerCase()));

	}

	public static int select() throws IOException {
		System.out.println("Enter Your Choice");
		System.out.println("Enter 1 for creating Customer:");
		System.out.println("Enter 2 for Item Update:");
		System.out.println("Enter 3 for Order Details:");
		int option = Integer.parseInt(read.readLine());
		return option;
	}

	public void insertItem() throws IOException {
		System.out.print("Enter Item ID:");
		String itemID = read.readLine();
		System.out.print("Enter Catagory:");
		String catagory = read.readLine();
		System.out.print("Enter Item Name: ");
		String itemName = read.readLine();
		System.out.print("Enter Item Description");
		String description = read.readLine();
		System.out.println("Enter Item Price");
		int price = Integer.parseInt(read.readLine());
		System.out.println("Enter Available Quantity");
		int quantity = Integer.parseInt(read.readLine());

		ItemMaster item = new ItemMaster(itemID, catagory, itemName, description, price, quantity);
		FileWrite.createItem(item);
	}

	public void createUser() throws IOException {
		System.out.println("Enter Customer ID:");
		String customerID = read.readLine();
		System.out.println("Enter First name");
		String firstName = read.readLine();
		System.out.println("Enter Last name");
		String lastName = read.readLine();
		System.out.println("Enter Email");
		String email = read.readLine();
		System.out.println("Enter password");
		String password = read.readLine();
		System.out.println("Enter Address");
		String address = read.readLine();

		CustomerMaster customer = new CustomerMaster(customerID, firstName, lastName, email, password, address);
		FileWrite.createCustomer(customer);
	}

	public void createOrder() throws IOException {
		System.out.println("Enter Order ID:");
		String orderID = read.readLine();
		System.out.println("Enter Order Name");
		String orderName = read.readLine();
		System.out.println("Enter Item Name");
		String itemName = read.readLine();
		System.out.println("Enter Available Quantity");
		int quantity = Integer.parseInt(read.readLine());

		OrderMaster order = new OrderMaster(orderID, orderName, itemName, quantity);
		FileWrite.createOrder(order);
	}
}
