package data;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import model.CustomerMaster;
import model.ItemMaster;
import model.OrderMaster;

public class FileWrite {

	static String CUSTOMER_PATH = "C:/Users/rishu.goenka/Desktop/Customer.dat";
	static String ITEM_PATH = "C:/Users/rishu.goenka/Desktop/Item.dat";
	static String ORDER_PATH = "C:/Users/rishu.goenka/Desktop/Order.dat";

	public static void createCustomer(CustomerMaster customer) {
		try {
			FileOutputStream fileOut = new FileOutputStream(CUSTOMER_PATH, true);
			ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(customer);
			objOut.close();
			System.out.println("Customer File Writing is Done..!!");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static void createItem(ItemMaster item) {
		try {
			FileOutputStream fileOut = new FileOutputStream(ITEM_PATH, true);
			ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(item);
			objOut.close();
			System.out.println("Item File Writing is Done..!!");
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public static void createOrder(OrderMaster order) {
		try {
			FileOutputStream fileOut = new FileOutputStream(ORDER_PATH, true);
			ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
			objOut.writeObject(order);
			objOut.close();
			System.out.println("Object File Writing is Done..!!");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
