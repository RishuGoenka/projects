package app;

import input.CustomerMasterIO;
import input.ItemMasterIO;
import input.OrderMasterIO;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class DemoApp {
	static BufferedReader read = new BufferedReader(new InputStreamReader(System.in));

	public static void main(String[] args) throws IOException {
		String choice = null;
		do {
			switch (select()) {
			case 1:
				new CustomerMasterIO().createUser();
				break;
			case 2:
				new ItemMasterIO().insertItem();
				break;
			case 3:
				new OrderMasterIO().createOrder();
				break;
			case 4:
				new CustomerMasterIO().removeUser();
				break;
			case 5:
				new ItemMasterIO().deleteItem();
				break;
			case 6:
				new OrderMasterIO().deleteOrder();
				break;
			case 7:
				new CustomerMasterIO().getUser();
				break;
			case 8:
				new ItemMasterIO().getItem();
				break;
			case 9:
				new OrderMasterIO().getOrder();
				break;
			default:
				System.out.println("invalid Choice");
			}
			System.out.println("for performing more opertion Enter Yes else No");
			choice = read.readLine();
		} while ("yes".equals(choice.toLowerCase()));

	}

	public static int select() throws IOException {
		System.out.println("Enter Your Choice");
		System.out.println("Enter 1 for creating Customer:");
		System.out.println("Enter 2 for Item Update:");
		System.out.println("Enter 3 for Order Details:");
		System.out.println("Enter 4 for Remove User:");
		System.out.println("Enter 5 for Delete Item:");
		System.out.println("Enter 6 for Delete Order:");
		System.out.println("Enter 7 for Get Customer List:");
		System.out.println("Enter 8 for get Item List:");
		System.out.println("Enter 9 for Get Order List:");
		int option = Integer.parseInt(read.readLine());
		return option;
	}

}
