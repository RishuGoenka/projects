package input;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import model.ItemMaster;

public class ItemMasterIO {
	public static BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
	private static List<ItemMaster> itemList = new ArrayList<ItemMaster>();

	public void insertItem() throws IOException {
		System.out.print("Enter Item ID:");
		String itemID = read.readLine();
		System.out.print("Enter Catagory:");
		String catagory = read.readLine();
		System.out.print("Enter Item Name: ");
		String itemName = read.readLine();
		System.out.print("Enter Item Description");
		String description = read.readLine();
		System.out.println("Enter Item Price");
		int price = Integer.parseInt(read.readLine());
		System.out.println("Enter Available Quantity");
		int quantity = Integer.parseInt(read.readLine());

		ItemMaster item = new ItemMaster(itemID, catagory, itemName, description, price, quantity);
		itemList.add(item);
	}

	public void deleteItem() throws IOException {
		System.out.println("Enter Item name");
		String itemName = read.readLine();
		for (int i = 0; i < itemList.size(); i++) {
			if (itemList.get(i).getItemName().equals(itemName.toLowerCase()))
				itemList.remove(i);
		}

	}

	public void getItem() throws IOException {
		for (int i = 0; i < itemList.size(); i++) {
			System.out.println(itemList.get(i));
		}
	}
}