package input;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import model.CustomerMaster;

public class CustomerMasterIO {

	public static BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
	private static List<CustomerMaster> customerList = new ArrayList<CustomerMaster>();

	public void createUser() throws IOException {
		System.out.println("Enter Customer ID:");
		String customerID = read.readLine();
		System.out.println("Enter First name");
		String firstName = read.readLine();
		System.out.println("Enter Last name");
		String lastName = read.readLine();
		System.out.println("Enter Email");
		String email = read.readLine();
		System.out.println("Enter password");
		String password = read.readLine();
		System.out.println("Enter Address");
		String address = read.readLine();

		CustomerMaster customer = new CustomerMaster(customerID, firstName, lastName, email, password, address);

		customerList.add(customer);
	}

	public void removeUser() throws IOException {
		System.out.println("Enter First name");
		String firstName = read.readLine();
		for (int i = 0; i < customerList.size(); i++) {
			if (customerList.get(i).getFirstName().equals(firstName.toLowerCase()))
				customerList.remove(i);
		}
	}

	public void getUser() throws IOException {
		for (int i = 0; i < customerList.size(); i++) {
			System.out.println(customerList.get(i));
		}
	}
}