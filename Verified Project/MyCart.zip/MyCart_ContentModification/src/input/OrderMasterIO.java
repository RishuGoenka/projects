package input;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import model.OrderMaster;

public class OrderMasterIO {
	public static BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
	private static List<OrderMaster> orderList = new ArrayList<OrderMaster>();

	public void createOrder() throws IOException {
		System.out.println("Enter Order ID:");
		String orderID = read.readLine();
		System.out.println("Enter Order Name");
		String orderName = read.readLine();
		System.out.println("Enter Item Name");
		String itemName = read.readLine();
		System.out.println("Enter Available Quantity");
		int quantity = Integer.parseInt(read.readLine());

		OrderMaster order = new OrderMaster(orderID, orderName, itemName, quantity);
		orderList.add(order);
	}

	public void deleteOrder() throws IOException {
		System.out.println("Enter First name");
		String orderName = read.readLine();
		for (int i = 0; i < orderList.size(); i++) {
			if (orderList.get(i).getOrderName().equals(orderName.toLowerCase()))
				orderList.remove(i);
		}
	}

	public void getOrder() throws IOException {
		for (int i = 0; i < orderList.size(); i++) {
			System.out.println(orderList.get(i));
		}
	}

}
