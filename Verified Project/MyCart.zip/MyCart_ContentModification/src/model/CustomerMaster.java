package model;

import java.io.Serializable;

public class CustomerMaster implements Serializable {
	private static final long serialVersionUID = 1060967976314031782L;
	private String customerID;
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	private String address;

	public CustomerMaster() {
		super();
	}

	/**
	 * @param customerID
	 * @param firstName
	 * @param lastName
	 * @param email
	 * @param password
	 * @param address
	 */
	public CustomerMaster(String customerID, String firstName, String lastName, String email, String password,
			String address) {
		super();
		this.customerID = customerID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.password = password;
		this.address = address;
	}

	public String getCustomerID() {
		return customerID;
	}

	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "CustomerMaster [customerID=" + customerID + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", email=" + email + ", password=" + password + ", address=" + address + "]";
	}

}