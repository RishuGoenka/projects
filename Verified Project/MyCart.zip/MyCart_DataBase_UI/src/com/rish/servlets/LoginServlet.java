package com.rish.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.rish.models.User;

/**
 * Servlet implementation class LoginServelet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");

		PrintWriter out = response.getWriter();

		request.getRequestDispatcher("login.html").include(request, response);

		String username = request.getParameter("uname");
		String password = request.getParameter("password");
		List<String> errors = new ArrayList<String>();

		// simple validation
		System.out.println(password);
		if (username == null || username.isEmpty())
			errors.add("Username cannot be blank!");
		if (password == null || password.trim().length() < 1)
			errors.add("Password cannot be blank!");
		if (username != null && username.equalsIgnoreCase(password))
			errors.add("username cannot be same as password!");
		HttpSession session = request.getSession();
		session.removeAttribute("errors");

		if (!errors.isEmpty()) {

			request.setAttribute("msg", "Login Failed");
			request.setAttribute("errors", errors);
		}

		else {
			request.setAttribute("msg", "Login Succedded");
			User user = new User();
			user.setUsername(username);
			user.setPassword(password);
			session.setAttribute("user", user);
		}

		RequestDispatcher view = request.getRequestDispatcher("result.jsp");
		view.forward(request, response);
	}
}
