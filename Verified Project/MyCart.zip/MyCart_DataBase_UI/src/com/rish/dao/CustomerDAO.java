package com.rish.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.rish.database.DataBaseUtil;
import com.rish.models.Customer;

public class CustomerDAO {

	private static final String INSERT_QUERY = "insert into customer values (?,?,?,?,?,?)";
	private static final String RETRIEVE_QUERY = "select * from customer";

	/**
	 * For creating customer
	 * 
	 * @param customer
	 */
	public void insert(Customer customer) {
		int update = 0;
		Connection connection = null;
		connection = DataBaseUtil.openConnection();
		try {
			PreparedStatement preparedstatmentObj = connection.prepareStatement(INSERT_QUERY);
			preparedstatmentObj.setString(1, customer.getCustomerID());
			preparedstatmentObj.setString(2, customer.getFirstName());
			preparedstatmentObj.setString(3, customer.getLastName());
			preparedstatmentObj.setString(4, customer.getEmail());
			preparedstatmentObj.setString(5, customer.getPassword());
			preparedstatmentObj.setString(6, customer.getAddress());
			update = preparedstatmentObj.executeUpdate();

			System.out.println(update + " Record Inserted . . .");
		} catch (SQLException e) {
			System.out.println("Unable to add new Customer ..");
			e.printStackTrace();
		}
		DataBaseUtil.closeConnection(connection);
	}

	/**
	 * getting customer details
	 * 
	 * @return
	 */
	public List<Customer> retrieve() {
		Customer customer = null;
		Connection connection = DataBaseUtil.openConnection();
		List<Customer> CustomerList = new ArrayList<Customer>();
		PreparedStatement preparedstatmentObj;

		try {
			preparedstatmentObj = connection.prepareStatement(RETRIEVE_QUERY);
			ResultSet ObjResultSet = preparedstatmentObj.executeQuery();

			while (ObjResultSet.next()) {
				customer = new Customer();
				customer.setCustomerID(ObjResultSet.getString(1));
				customer.setFirstName(ObjResultSet.getString(2));
				customer.setLastName(ObjResultSet.getString(3));
				customer.setEmail(ObjResultSet.getString(4));
				customer.setPassword(ObjResultSet.getString(5));
				customer.setAddress(ObjResultSet.getString(6));
				CustomerList.add(customer);

			}

		} catch (SQLException e) {
			System.out.println("Unable to find Customer . . .");
			e.printStackTrace();
		}
		DataBaseUtil.closeConnection(connection);
		return CustomerList;
	}

}
