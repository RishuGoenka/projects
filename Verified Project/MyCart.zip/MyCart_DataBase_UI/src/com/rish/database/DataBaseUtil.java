package com.rish.database;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DataBaseUtil {

	// Step 0 : Load Properties
	private static Properties loadProperties(String ProgFlie) {
		Properties propertiesObj = new Properties();
		try {
			propertiesObj.load(DataBaseUtil.class.getResourceAsStream(ProgFlie));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return propertiesObj;
	}

	// Step 1 : Load JDBC Driver
	public static Connection openConnection() {
		Properties propertiesObj = loadProperties("/db.properties");
		Connection connectionObj = null;
		try {
			Class.forName(propertiesObj.getProperty("driver"));
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Unable to connect", e);
		}

		// Step 2 : Connect to DB Server
		try {
			connectionObj = DriverManager.getConnection(propertiesObj.getProperty("url"),
					propertiesObj.getProperty("user"), propertiesObj.getProperty("password"));
			System.out.println("Connected to " + connectionObj.getMetaData().getDatabaseProductName());

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connectionObj;

	}

	public static void closeConnection(Connection connectionObj) {
		try {
			connectionObj.close();
			System.out.println("END");
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
