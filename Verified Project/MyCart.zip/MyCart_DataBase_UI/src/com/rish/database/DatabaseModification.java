package com.rish.database;

import java.io.*;
import java.sql.*;

public class DatabaseModification {
	static BufferedReader read;

	public static void main(String[] args) throws IOException, SQLException {

		read = new BufferedReader(new InputStreamReader(System.in));
		String choice = null;
		Boolean match = true;
		int option;
		do {
			showMenu();
			option = Integer.parseInt(read.readLine());
			switch (option) {
			case 1:
				createDatabase();
				break;
			case 2:
				System.out.println("Enter table name");
				String tableName = read.readLine();
				createTable(tableName);
				break;
			}
			System.out.println("to continue enter true else false");
			choice = read.readLine();
		} while (match.equals(choice.toLowerCase()));

	}

	public static void showMenu() {
		System.out.println("For Creating Database enter: 1");
		System.out.println("For Creating Table enter: 2");
	}

	public static void createDatabase() throws SQLException, IOException {
		Connection connection = DataBaseUtil.openConnection();
		Statement statmentObj = connection.createStatement();
		System.out.println("Enter name of database to be created");
		String StringVar = read.readLine();
		statmentObj.executeUpdate(" Create database " + StringVar);
		statmentObj.execute("use " + StringVar);
		System.out.println("Database Created");
		DataBaseUtil.closeConnection(connection);
	}

	public static void createTable(String tableName) throws SQLException, NumberFormatException, IOException {
		Connection connectionObj = DataBaseUtil.openConnection();
		Statement statmentObj = connectionObj.createStatement();
		System.out.println("Enter Number of Fields");
		int StringVar = Integer.parseInt(read.readLine());
		String query = "";
		int field_check = 0;
		for (int i = 1; i <= StringVar; i++) {
			System.out.println("Enter first field");
			String fieldName = read.readLine();
			System.out.println("Enter Field type:");
			String fieldType = read.readLine();
			if (field_check == 0)
				field_check++;
			else
				query = query + ",";
			query = query + " " + fieldName + " " + fieldType;
		}
		query = "create table " + tableName + "( " + query + ")";

		System.out.println(query);
		System.out.println("Table Created");
		statmentObj.executeUpdate(query);
		DataBaseUtil.closeConnection(connectionObj);
	}

}
