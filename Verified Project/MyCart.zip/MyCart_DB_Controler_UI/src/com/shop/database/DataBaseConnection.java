package com.shop.database;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DataBaseConnection {
	private static Properties loadProperties(String propertiesFile) {
		Properties propertiesObj = new Properties();
		try {
			propertiesObj.load(DataBaseConnection.class.getResourceAsStream(propertiesFile));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return propertiesObj;
	}

	public static Connection startConnection() {
		Properties propertiesObj = loadProperties("/database.properties");
		Connection connectionObj = null;
		try {
			Class.forName(propertiesObj.getProperty("driver"));
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Unable to connect", e);
		}
		try {
			connectionObj = DriverManager.getConnection(propertiesObj.getProperty("url"),
					propertiesObj.getProperty("user"), propertiesObj.getProperty("password"));
			System.out.println("Connected to " + connectionObj.getMetaData().getDatabaseProductName());

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connectionObj;

	}

	public static void stopConnection(Connection connectionObj) {
		try {
			connectionObj.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
