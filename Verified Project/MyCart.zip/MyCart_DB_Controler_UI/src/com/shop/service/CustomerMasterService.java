package com.shop.service;

import com.shop.dao.CustomerMasterDAO;
import com.shop.models.CustomerMaster;

public class CustomerMasterService {
	public boolean validate(String customerUID, String firstname, String lastname, String email, String password) {
		if (customerUID == null || customerUID.isEmpty()) {
			System.out.println("Unique cannot be blank");
			return false;
		}
		if (firstname == null || firstname.isEmpty()) {
			System.out.println("FirstName cannot be blank");
			return false;
		}
		if (lastname == null || lastname.isEmpty()) {
			System.out.println("lastName cannot be blank");
			return false;
		}
		if (email == null || email.isEmpty()) {
			System.out.println("email cannot be blank");
			return false;
		}
		if (password == null || password.isEmpty()) {
			System.out.println("password cannot be blank");
			return false;
		}
		if (email != null && email.equalsIgnoreCase(password)) {
			System.out.println("email and password cannot be same");
			return false;
		}

		CustomerMasterDAO customermasterdaoObj = new CustomerMasterDAO();
		CustomerMaster customermasterObj = new CustomerMaster();
		customermasterObj = customermasterdaoObj.findById(customerUID);

		if (email.equals(customermasterObj.getEmail()) && password.equals(customermasterObj.getPassword())) {
			System.out.println("Welcome logined successfull");
			return true;
		}
		return false;
	}

}