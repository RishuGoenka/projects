package com.shop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.shop.database.DataBaseConnection;
import com.shop.models.CustomerMaster;

public class CustomerMasterDAO {
	public static final String INSERT_QUERY = "insert into customermaster values(?,?,?,?,?)";
	public static final String FIND_BY_ID = "select * from customermaster where customerUID=?";
	public static final String UPDATE_QUERY = "update customermaster set first_name= ?, last_name=?,email=?, password=? where customerUID=?";
	public static final String DELETE_QUERY = "delete from customermaster where customerUID=?";
	private static CustomerMasterDAO customermasterdaoObj;

	/**
	 * Method to get Singleton instance of CustomerMasterDAO Syntax:
	 * CustomerMasterDAO customermasterdaoObj = CustomerMasterDAO.getInstance();
	 * 
	 * @return Single instance of CustomerMasterDAO
	 */
	public static CustomerMasterDAO getInstance() {
		if (customermasterdaoObj == null) // create if doesn't exists
			customermasterdaoObj = new CustomerMasterDAO();
		return customermasterdaoObj;
	}

	public static void insert(CustomerMaster customermasterObj) {
		Connection connectionObj = DataBaseConnection.startConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(INSERT_QUERY);
			preparedstatmentObj.setString(1, customermasterObj.getCustomerUID());
			preparedstatmentObj.setString(2, customermasterObj.getFirstname());
			preparedstatmentObj.setString(3, customermasterObj.getLastname());
			preparedstatmentObj.setString(4, customermasterObj.getEmail());
			preparedstatmentObj.setString(5, customermasterObj.getPassword());

			int newCustomer = preparedstatmentObj.executeUpdate();
			System.out.println(newCustomer + "record created!");
		} catch (SQLException e) {
			System.out.println("Unable to save new Customer");
			e.printStackTrace();
		}

	}

	public CustomerMaster findById(String customerUID) {
		CustomerMaster customermasterObj = null;
		Connection connectionObj = DataBaseConnection.startConnection();

		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(FIND_BY_ID);
			preparedstatmentObj.setString(1, customerUID);
			ResultSet resultsetObj = preparedstatmentObj.executeQuery();
			if (resultsetObj.next()) {
				customermasterObj = new CustomerMaster(resultsetObj.getString(1), resultsetObj.getString(2),
						resultsetObj.getString(3), resultsetObj.getString(4), resultsetObj.getString(5));
			}
			return customermasterObj;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void update(CustomerMaster customermasterObj) {
		Connection connectionObj = DataBaseConnection.startConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(UPDATE_QUERY);
			preparedstatmentObj.setString(1, customermasterObj.getCustomerUID());
			preparedstatmentObj.setString(2, customermasterObj.getFirstname());
			preparedstatmentObj.setString(3, customermasterObj.getLastname());
			preparedstatmentObj.setString(4, customermasterObj.getEmail());
			preparedstatmentObj.setString(5, customermasterObj.getPassword());
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseConnection.stopConnection(connectionObj);
	}

	public void delete(String customerUID) {
		Connection connectionObj = DataBaseConnection.startConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(DELETE_QUERY);
			preparedstatmentObj.setString(1, customerUID);
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseConnection.stopConnection(connectionObj);
	}

}
