package com.shop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.shop.database.DataBaseConnection;
import com.shop.models.ItemMaster;

public class ItemMasterDAO {
	public static final String INSERT_QUERY = "insert into itemmaster values(?,?,?,?,?,?)";
	public static final String FIND_BY_ID = "select * from itemmaster where itemUID=?";
	public static final String UPDATE_QUERY = "update itemmaster set category= ?, itemName=?,description=?, price=?,quantity=? where itemUID=?";
	public static final String DELETE_QUERY = "delete from itemmaster where itemUID=?";
	private static ItemMasterDAO itemmasterdaoObj;

	/**
	 * Method to get Singleton instance of ItemMasterDAO Syntax: ItemMasterDAO
	 * itemmasterdaoObj = ItemMasterDAO.getInstance();
	 * 
	 * @return Single instance of ItemMasterDAO
	 */
	public static ItemMasterDAO getInstance() {
		if (itemmasterdaoObj == null) // create if doesn't exists
			itemmasterdaoObj = new ItemMasterDAO();
		return itemmasterdaoObj;
	}

	public static void insert(ItemMaster itemmasterObj) {
		Connection connectionObj = DataBaseConnection.startConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(INSERT_QUERY);
			preparedstatmentObj.setString(1, itemmasterObj.getItemUID());
			preparedstatmentObj.setString(2, itemmasterObj.getCatagory());
			preparedstatmentObj.setString(3, itemmasterObj.getItemName());
			preparedstatmentObj.setString(4, itemmasterObj.getDescription());
			preparedstatmentObj.setInt(5, itemmasterObj.getPrice());
			preparedstatmentObj.setInt(6, itemmasterObj.getQuantity());

			int newItem = preparedstatmentObj.executeUpdate();
			System.out.println(newItem + "record created!");
		} catch (SQLException e) {
			System.out.println("Unable to save Item");
			e.printStackTrace();
		}

	}

	public ItemMaster findById(String itemUID) {
		ItemMaster itemmasterObj = null;
		Connection connectionObj = DataBaseConnection.startConnection();

		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(FIND_BY_ID);
			preparedstatmentObj.setString(1, itemUID);
			ResultSet resultsetObj = preparedstatmentObj.executeQuery();
			if (resultsetObj.next()) {
				itemmasterObj = new ItemMaster(resultsetObj.getString(1), resultsetObj.getString(2),
						resultsetObj.getString(3), resultsetObj.getString(4), resultsetObj.getInt(5),
						resultsetObj.getInt(6));
			}
			return itemmasterObj;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void update(ItemMaster itemmasterObj) {
		Connection connectionObj = DataBaseConnection.startConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(UPDATE_QUERY);
			preparedstatmentObj.setString(1, itemmasterObj.getItemUID());
			preparedstatmentObj.setString(2, itemmasterObj.getCatagory());
			preparedstatmentObj.setString(3, itemmasterObj.getItemName());
			preparedstatmentObj.setString(4, itemmasterObj.getDescription());
			preparedstatmentObj.setInt(5, itemmasterObj.getPrice());
			preparedstatmentObj.setInt(6, itemmasterObj.getQuantity());
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseConnection.stopConnection(connectionObj);
	}

	public void delete(String itemUID) {
		Connection connectionObj = DataBaseConnection.startConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(DELETE_QUERY);
			preparedstatmentObj.setString(1, itemUID);
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseConnection.stopConnection(connectionObj);
	}

}
