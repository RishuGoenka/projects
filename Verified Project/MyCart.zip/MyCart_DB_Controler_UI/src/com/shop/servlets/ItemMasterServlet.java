package com.shop.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.shop.dao.ItemMasterDAO;
import com.shop.models.ItemMaster;
import com.shop.service.ItemMasterService;

/**
 * Servlet implementation class ItemMasterServlet
 */
@WebServlet("/admin.item")
public class ItemMasterServlet extends HttpServlet {
	ItemMasterDAO itemmasterdaoObj = new ItemMasterDAO();
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ItemMasterServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String itemUID = request.getParameter("itemUID");
		String catagory = request.getParameter("catagory");
		String itemName = request.getParameter("itemName");
		String description = request.getParameter("description");
		int price = Integer.parseInt(request.getParameter("price"));
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		ItemMaster itemmasterObj = new ItemMaster(itemUID, catagory, itemName, description, price, quantity);

		ItemMasterDAO.insert(itemmasterObj);

		ItemMasterService itemmasterserviceObj = new ItemMasterService();
		if (itemmasterserviceObj.validate(itemUID, catagory, itemName, description, price, quantity)) {
			response.sendRedirect("item.html");
		} else {
			response.sendRedirect("home.html");
		}
	}
}
