package com.shop.models;

import java.io.Serializable;

public class ItemMaster implements Serializable {
	private static final long serialVersionUID = 1L;
	private String itemUID;
	private String catagory;
	private String itemName;
	private String description;
	private int price;
	private int quantity;

	public ItemMaster() {
		super();
	}

	/**
	 * @param itemUID
	 * @param catagory
	 * @param itemName
	 * @param description
	 * @param l
	 * @param m
	 */
	public ItemMaster(String itemUID, String catagory, String itemName, String description, int l, int m) {
		super();
		this.itemUID = itemUID;
		this.catagory = catagory;
		this.itemName = itemName;
		this.description = description;
		this.price = l;
		this.quantity = m;
	}

	public String getItemUID() {
		return itemUID;
	}

	public void setItemUID(String itemUID) {
		this.itemUID = itemUID;
	}

	public String getCatagory() {
		return catagory;
	}

	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
