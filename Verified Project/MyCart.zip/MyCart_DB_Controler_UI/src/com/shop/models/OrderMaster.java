package com.shop.models;

import java.io.Serializable;

public class OrderMaster implements Serializable {
	private static final long serialVersionUID = 1L;
	private String orderUID;
	private String orderName;
	private long quantity;
	private long bill;

	public OrderMaster() {
		super();
	}

	/**
	 * @param orderUID
	 * @param orderName
	 * @param quantity
	 * @param bill
	 */
	public OrderMaster(String orderUID, String orderName, long quantity, long bill) {
		super();
		this.orderUID = orderUID;
		this.orderName = orderName;
		this.quantity = quantity;
		this.bill = bill;
	}

	public String getOrderUID() {
		return orderUID;
	}

	public void setOrderUID(String orderUID) {
		this.orderUID = orderUID;
	}

	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public long getBill() {
		return bill;
	}

	public void setBill(long bill) {
		this.bill = bill;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
