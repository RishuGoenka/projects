package com.shop.models;

import java.io.Serializable;

public class CustomerMaster implements Serializable {

	private static final long serialVersionUID = 1L;
	private String customerUID;
	private String firstname;
	private String lastname;
	private String email;
	private String password;

	public CustomerMaster() {
		super();
	}

	/**
	 * @param customerUID
	 * @param firstname
	 * @param lastname
	 * @param email
	 * @param password
	 */
	public CustomerMaster(String customerUID, String firstname, String lastname, String email, String password) {
		super();
		this.customerUID = customerUID;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.password = password;
	}

	public String getCustomerUID() {
		return customerUID;
	}

	public void setCustomerUID(String customerUID) {
		this.customerUID = customerUID;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
