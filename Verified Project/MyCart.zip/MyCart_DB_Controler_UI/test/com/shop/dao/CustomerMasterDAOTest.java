package com.shop.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.Test;

import com.shop.models.CustomerMaster;

public class CustomerMasterDAOTest {

	@Test
	public void testInsert() {
		CustomerMasterDAO customermasterdaoObj = new CustomerMasterDAO();
		CustomerMaster customermasterObj = new CustomerMaster("11", "first", "last", "email", "pass");
		CustomerMasterDAO.insert(customermasterObj);
		assertEquals("email", customermasterdaoObj.findById("11").getEmail());
	}

	@Test
	public void testFindById() {
		fail("Not yet implemented");
	}

	@Test
	public void testModify() {
		fail("Not yet implemented");
	}

	@Test
	public void testDelete() {
		fail("Not yet implemented");
	}

}
