package com.shop.models;

import java.io.Serializable;

public class ItemMaster implements Serializable {
	private static final long serialVersionUID = 6191710157359705117L;
	private String itemID;
	private String catagory;
	private String itemName;
	private String description;
	private Integer price;
	private Integer quantity;

	public ItemMaster() {
		super();
	}

	/**
	 * @param itemID
	 * @param catagory
	 * @param itemName
	 * @param description
	 * @param price
	 * @param quantity
	 */
	public ItemMaster(String itemID, String catagory, String itemName, String description, Integer price,
			Integer quantity) {
		super();
		this.itemID = itemID;
		this.catagory = catagory;
		this.itemName = itemName;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
	}

	public String getItemID() {
		return itemID;
	}

	public void setItemID(String itemID) {
		this.itemID = itemID;
	}

	public String getCatagory() {
		return catagory;
	}

	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}