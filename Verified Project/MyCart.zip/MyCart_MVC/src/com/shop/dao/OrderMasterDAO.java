package com.shop.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.shop.database.DataBaseConnection;
import com.shop.models.OrderMaster;

public class OrderMasterDAO {
	public static final String INSERT_QUERY = "insert into ordermaster values(?,?,?,?)";
	public static final String FIND_BY_ID = "select * from ordermaster where orderUID=?";
	public static final String UPDATE_QUERY = "update ordermaster set orderName=?,ItemName=?,quantity=? where orderUID=?";
	public static final String DELETE_QUERY = "delete from ordermaster where orderUID=?";
	private static OrderMasterDAO ordermasterdaoObj;

	/**
	 * Method to get Singleton instance of OrderMasterDAO Syntax: OrderMasterDAO
	 * ordermasterdaoObj = OrderMasterDAO.getInstance();
	 * 
	 * @return Single instance of OrderMasterDAO
	 */
	public static OrderMasterDAO getInstance() {
		if (ordermasterdaoObj == null) // create if doesn't exists
			ordermasterdaoObj = new OrderMasterDAO();
		return ordermasterdaoObj;
	}

	public static void insert(OrderMaster ordermasterObj) {
		Connection connectionObj = DataBaseConnection.startConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(INSERT_QUERY);
			preparedstatmentObj.setString(1, ordermasterObj.getOrderId());
			preparedstatmentObj.setString(2, ordermasterObj.getOrderName());
			preparedstatmentObj.setString(3, ordermasterObj.getItemName());
			preparedstatmentObj.setInt(4, ordermasterObj.getQuantity());

			int newItem = preparedstatmentObj.executeUpdate();
			System.out.println(newItem + "record created!");
		} catch (SQLException e) {
			System.out.println("Unable to save Item");
			e.printStackTrace();
		}

	}

	public OrderMaster findById(String orderUID) {
		OrderMaster ordermasterObj = null;
		Connection connectionObj = DataBaseConnection.startConnection();

		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(FIND_BY_ID);
			preparedstatmentObj.setString(1, orderUID);
			ResultSet resultsetObj = preparedstatmentObj.executeQuery();
			if (resultsetObj.next()) {
				ordermasterObj = new OrderMaster(resultsetObj.getString(1), resultsetObj.getString(2),
						resultsetObj.getString(3), resultsetObj.getInt(4));
			}
			return ordermasterObj;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void update(OrderMaster ordermasterObj) {
		Connection connectionObj = DataBaseConnection.startConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(UPDATE_QUERY);
			preparedstatmentObj.setString(1, ordermasterObj.getOrderId());
			preparedstatmentObj.setString(2, ordermasterObj.getOrderName());
			preparedstatmentObj.setString(3, ordermasterObj.getItemName());
			preparedstatmentObj.setInt(4, ordermasterObj.getQuantity());
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseConnection.stopConnection(connectionObj);
	}

	public void delete(String orderUID) {
		Connection connectionObj = DataBaseConnection.startConnection();
		try {
			PreparedStatement preparedstatmentObj = connectionObj.prepareStatement(DELETE_QUERY);
			preparedstatmentObj.setString(1, orderUID);
			preparedstatmentObj.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		DataBaseConnection.stopConnection(connectionObj);
	}

}
