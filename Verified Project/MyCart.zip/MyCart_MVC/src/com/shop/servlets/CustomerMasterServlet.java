package com.shop.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.shop.dao.CustomerMasterDAO;
import com.shop.models.CustomerMaster;
import com.shop.service.CustomerMasterService;

/**
 * Servlet implementation class CustomerMasterServlet
 */
public class CustomerMasterServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CustomerMasterServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String customerUID = request.getParameter("customerUID");
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String address = request.getParameter("address");

		CustomerMaster customermasterObj = new CustomerMaster(customerUID, firstname, lastname, email, password,
				address);

		CustomerMasterDAO.insert(customermasterObj);

		CustomerMasterService customermasterserviceObj = new CustomerMasterService();
		if (customermasterserviceObj.validate(customerUID, firstname, lastname, email, password, address)) {
			response.sendRedirect("index.html");
		} else {
			response.sendRedirect("register.html");
		}
	}

}