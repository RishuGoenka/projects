package com.shop.service;

import com.shop.dao.ItemMasterDAO;
import com.shop.models.ItemMaster;

public class ItemMasterService {
	public boolean validate(String itemUID, String catagory, String itemName, String description, long price,
			long quantity) {
		if (itemUID == null || itemUID.isEmpty()) {
			System.out.println("Unique cannot be blank");
			return false;
		}
		if (catagory == null || catagory.isEmpty()) {
			System.out.println("catagory cannot be blank");
			return false;
		}
		if (itemName == null || itemName.isEmpty()) {
			System.out.println("itemName cannot be blank");
			return false;
		}
		if (description == null || description.isEmpty()) {
			System.out.println("description cannot be blank");
			return false;
		}
		if (price < 0) {
			System.out.println("price cannot be negative");
			return false;
		}
		if (quantity < 0) {
			System.out.println("quantity cannot be negative");
			return false;
		}

		ItemMasterDAO itemmasterdaoObj = new ItemMasterDAO();
		ItemMaster itemmasterObj = new ItemMaster();
		itemmasterObj = itemmasterdaoObj.findById(itemUID);

		if (itemName.equals(itemmasterObj.getItemName()) && price == itemmasterObj.getPrice()) {
			System.out.println("Input SuccessFul");
			return true;
		}
		return false;
	}
}