import java.sql.Connection;
import java.sql.DriverManager;

public class DataBaseConnection {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "root");
			if (con != null)
				System.out.println("Connected Successfully ..!!");
			else
				System.out.println("Failed to Connect");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
