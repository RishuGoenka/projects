package data;

import java.io.*;
import pack.Product;

public class DataManagerBinary implements IProductDAO {
	public static final String DATAFILE = "./product.dat";

	public void add(Product p) {
		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream(new FileOutputStream(DataManagerBinary.DATAFILE));
			out.writeObject(p);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public Product[] getAll() {
		return null;
	}

	@Override
	public Product get() {
		ObjectInputStream oin = null;
		Product p = null;
		try {
			oin = new ObjectInputStream(new FileInputStream(DataManagerBinary.DATAFILE));
			Object obj = null;
			obj = oin.readObject();
			if (obj != null && obj instanceof Product)
				p = (Product) obj;
			oin.close();
		} catch (IOException ev) {
			ev.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return p;
	}
}
