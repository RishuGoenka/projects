package data;

import pack.Product;

/**
 * you must provide at least one implementation of this interface
 * 
 * @author rishu.goenka
 *
 */
public interface IProductDAO {
	/**
	 * Method to add product, target on which implementation you choose
	 * 
	 * @param p
	 *            product p to be saved or recorded
	 */
	public void add(Product p);

	/**
	 * Get all the products saved
	 * 
	 * @return array of product
	 */
	public Product[] getAll();

	/**
	 * get all single product
	 * 
	 * @return Product read from file/databse
	 */
	Product get();
}
