package data;

import java.io.*;
import pack.Product;

public class DataManager {
	private static final String DATAFILE = "./datafile.txt";

	public void add(Product p) {
		try (FileWriter file = new FileWriter(DATAFILE, true)) {
			file.write(p.getName() + ",  " + p.getDescription() + ",  " + p.getPrice() + "\r\n");
		} catch (IOException e) {
			throw new RuntimeException("failed...", e);
		}
	}

	public Product[] getAll() {
		return null;
	}
}
