package pack;

import java.io.Serializable;

public class Product implements Serializable, Comparable<Product> {

	private static final long serialVersionUID = 2161961443965068607L;
	private String name;
	private String description;
	private double price;

	public Product(String name, String description, double price) {
		super();
		this.name = name;
		this.description = description;
		this.price = price;
	}

	public Product() {
		super();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	// @override
	public int compareTo(Product p) {
		if (this.price > p.price)
			return 1;
		else if (this.price < p.price)
			return -1;
		else
			return 0;
	}
}
