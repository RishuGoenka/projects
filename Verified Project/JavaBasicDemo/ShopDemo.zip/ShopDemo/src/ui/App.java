package ui;

import java.io.*;
import data.DataManagerBinary;
import data.IProductDAO;
import pack.Product;

public class App {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("�nter name of the product");
		String name = br.readLine();
		System.out.println("enter description");
		String desc = br.readLine();
		System.out.println("enter price");
		String t = br.readLine();
		double pr = Double.parseDouble(t);
		Product p = new Product(name, desc, pr);
		IProductDAO dm = new DataManagerBinary();
		dm.add(p);
		System.out.println("data written!");
		Product xm = dm.get();
		System.out.println("product name: " + xm.getName());
	}

}
