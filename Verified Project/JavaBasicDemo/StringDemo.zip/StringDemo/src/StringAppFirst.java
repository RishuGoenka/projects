public class StringAppFirst {
	public static void main(String[] args) {
		String name = "rish";
		StringBuffer sb = new StringBuffer(name);
		sb.append(" ").append("Goenka").insert(0, "Mr. ");
		System.out.println(sb);

		// without string builder or buffer name = name+ " " +"Goenka";//5
		// objects name = "Ms. "+ name;//7 objects

	}

}
