public class AppDemoFirst {
	public static void main(String[] args) {
		String s1 = "abc";
		String s2 = new String("abc");
		String s3 = "Abc".toLowerCase();
		System.out.println("Both strings s1 & s2 are same " + (s1 == s3));
		System.out.println("Both strings s1 & s3 are same " + (s1 == s3));
		System.out.println((s3 == s2));
		System.out.println(s3);
	}

}
