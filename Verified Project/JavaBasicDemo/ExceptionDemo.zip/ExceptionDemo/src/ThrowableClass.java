public class ThrowableClass {

	public static void main(String[] args) {
		int sum = 0;
		for (String a : args) {
			try {
				sum += Integer.parseInt(a);
			} catch (RuntimeException e) {
				System.out.println("Incorrect value entered therefore ignored");
			}
		}
		System.out.println("Sum is " + sum);
	}

}
