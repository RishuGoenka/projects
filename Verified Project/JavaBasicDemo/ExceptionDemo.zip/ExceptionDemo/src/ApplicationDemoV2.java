public class ApplicationDemoV2 {
	public static void main(String[] args) {
		InterestCalculator cal = new InterestCalculator();
		try {
			double amt = cal.calcInterest(50000, 42.05F, 60);
			System.out.println(amt);
		} catch (InvalidRateOfInterest e) {
			e.printStackTrace();
		}
	}

}
