public class InterestCalculator {
	public double calcInterest(double amt, float rate, int duration) throws RuntimeException {
		if (rate <= 4.0F || rate >= 20) {
			try {
				throw new InvalidRateOfInterest("rate " + rate + " must be in range");
			} catch (InvalidRateOfInterest e) {
				throw new RuntimeException("Hie");
			}
		}
		System.out.println("hello");
		return amt * rate / 100 / 12 * duration;
	}

	public static void main(String args[]) {
		new InterestCalculator().calcInterest(1200, 100, 12);
	}
}
