public class InvalidRateOfInterest extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidRateOfInterest(String a) {
		super(a);
	}
}
