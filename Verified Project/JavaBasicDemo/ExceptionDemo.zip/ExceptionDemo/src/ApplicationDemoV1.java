public class ApplicationDemoV1 {
	{
		System.out.println("hello world");
		System.out.println("hello world");
	}

	public static void main(String[] args) {
		// int sum=0;
		// for (String a:args)
		// {
		try {
			// sum+=Integer.parseInt(a);
			throw new MyException();
		} catch (Exception er) {
			er.printStackTrace();
		}
		// }
		// System.out.println(sum);
		// Demo ob=new Demo();
	}

}