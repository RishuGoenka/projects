public class ATMWithdrawl implements Runnable {
	private Account account;
	private double amount;

	@Override
	public void run() {
		synchronized (account) {

			System.out.println("preparing to withdraw " + amount + " from " + account.getAccountNumber());
			System.out.println("thread name is:" + Thread.currentThread().getName());
			AccountTransaction tn = new AccountTransaction();
			System.out.println("checking for the balance");
			double temp = account.getBalanace();
			if (temp < amount) {
				System.out.println("No sufficient funds! abborting.....");
				return;// quit running from this method
			}
			if (tn.withdraw(account, amount)) {
				System.out.println("withdrawal was successful");
			} else {
				System.out.println("withdraww failed!");
			}
		}

	}

	public ATMWithdrawl(Account account, double amount) {
		super();
		this.account = account;
		this.amount = amount;
	}

}
