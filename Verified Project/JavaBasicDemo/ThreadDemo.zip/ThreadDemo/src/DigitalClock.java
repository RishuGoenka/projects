import java.text.DateFormat;
import java.util.Date;

public class DigitalClock implements Runnable {

	@Override
	public void run() {
		DateFormat df = DateFormat.getTimeInstance(DateFormat.LONG);
		int n = 10;
		while (n-- != 0) {
			Date now = new Date();// get current date and time
			String time = df.format(now);
			System.out.println(System.nanoTime());
			System.out.println(time);
		}
	}

}
