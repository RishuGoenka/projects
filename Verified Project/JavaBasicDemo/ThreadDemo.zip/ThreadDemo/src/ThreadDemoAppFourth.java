import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ThreadDemoAppFourth {
	public static void main(String[] args) {
		ExecutorService service = Executors.newCachedThreadPool();
		// Run a task get factorial of a number
		Future<Long> future = service.submit(new FactorialCalculator(10));
		future.cancel(true);
		System.out.println("waiting for the answer....");
		try {
			// if(future.isDone()){
			System.out.println("Factorial is " + future.get());
			// }
		} catch (InterruptedException | ExecutionException ee) {
			ee.printStackTrace();
		}
		service.shutdown();
	}

}
