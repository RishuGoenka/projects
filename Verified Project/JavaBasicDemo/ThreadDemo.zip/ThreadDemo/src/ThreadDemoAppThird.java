import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ThreadDemoAppThird {
	public static void main(String[] args) {
		Account jointaccoun = new Account(868, "rajiv", 20000, new Date());
		ATMWithdrawl aka = new ATMWithdrawl(jointaccoun, 20000);
		ATMWithdrawl kk = new ATMWithdrawl(jointaccoun, 21000);
		// ExecutorService service=Executors.newFixedThreadPool(1); //for fixed
		// number of threads to be declared at the compile thread
		ExecutorService service = Executors.newCachedThreadPool();
		// for JVM to decide the size of the pool during runtime
		service.execute(aka);
		service.execute(kk);

		try {
			// wait for 10 seconds
			// so all jobs are done
			service.awaitTermination(10, TimeUnit.SECONDS);
		} catch (InterruptedException ee) {
			ee.printStackTrace();
		}

		// run the statement only after the child threads t1 and t2 are finished
		// or dead...
		System.out.println("the balance left is:" + jointaccoun.getBalanace());
		service.shutdown();
	}

}
