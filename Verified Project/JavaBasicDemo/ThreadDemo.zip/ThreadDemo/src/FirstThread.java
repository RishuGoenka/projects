public class FirstThread extends Thread {
	public void run() {
		System.out.println("some task...");
		System.out.println("task started");
		System.out.println(".........");
		System.out.println("task finished!");
	}
}
