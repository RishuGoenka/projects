import java.util.Date;

public class ThreadDemoAppSecond {
	public static void main(String[] args) {
		// common account object
		Account jointaccoun = new Account(868, "rajiv", 20000, new Date());
		ATMWithdrawl aka = new ATMWithdrawl(jointaccoun, 20000);
		ATMWithdrawl kk = new ATMWithdrawl(jointaccoun, 21000);
		Thread t1 = new Thread(aka);
		Thread t2 = new Thread(kk);
		t1.start();
		t2.start();
		try {
			t1.join();// request jvm to run t1 instead[if not dead]
			t2.join();// request jvm to run t2 instead[if not dead]
		} catch (InterruptedException ee) {
			ee.printStackTrace();
		}
		// run this statement only after the child class thread ha s
		// finished/dead
		System.out.println("the balance left is :" + jointaccoun.getBalanace());
	}

}
