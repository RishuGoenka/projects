import java.util.Date;

public class Account {
	private int accountNumber;
	private String holderName;
	private double balanace;

	private Date dateOfOpenning;

	public Account(int accountNumber, String holderName, double balanace, Date dateOfOpenning) {
		super();
		this.accountNumber = accountNumber;
		this.holderName = holderName;
		this.balanace = balanace;
		this.dateOfOpenning = dateOfOpenning;
	}

	public double getBalanace() {
		return balanace;
	}

	public void setBalanace(double balanace) {
		this.balanace = balanace;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public String getHolderName() {
		return holderName;
	}

	public Date getDateOfOpenning() {
		return dateOfOpenning;
	}

}
