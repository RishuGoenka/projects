public class ThreadDemoAppFirst {
	public static void main(String[] args) {
		Thread t1 = new FirstThread();
		t1.start();
		// A task is defined by Runnable still need a worker
		Thread t2 = new Thread(new DigitalClock());
		t2.run();
		int count = Thread.activeCount();
		String name = Thread.currentThread().getName();
		System.out.println("there are " + count + " threads running");
		System.out.println("the name of the thread:" + name);
	}

}
