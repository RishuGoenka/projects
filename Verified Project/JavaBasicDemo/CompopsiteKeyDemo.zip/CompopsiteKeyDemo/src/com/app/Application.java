package com.app;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import com.models.Planet;
import com.models.PlanetID;

public class Application {

	public static void main(String[] args) {

		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.getTransaction();

		Planet planet = new Planet();
		PlanetID id = new PlanetID();
		id.setPlanetId(4);
		id.setStarId(101245);
		planet.setId(id);
		planet.setPlanetClass("META");

		try {
			t.begin();
			session.save(planet);
			t.commit();
			System.out.println("record saved");
		} catch (HibernateException ex) {
			ex.printStackTrace();
			if (t != null)
				t.rollback();
		}
		session.close();
	}
}
