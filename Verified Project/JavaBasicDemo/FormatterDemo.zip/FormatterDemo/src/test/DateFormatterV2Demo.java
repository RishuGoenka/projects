package test;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class DateFormatterV2Demo {

	public static void main(String[] args) {
		Date date = new Date();
		String formattedDate = null;
		DateFormat ft = DateFormat.getTimeInstance(DateFormat.FULL, Locale.UK);
		formattedDate = ft.format(date);
		System.out.println("Value is " + formattedDate);
	}

}
