package test;

public class StringBuilderDemo {

	public static void main(String[] args) {
		String name = "Mahendra";
		StringBuffer sb = new StringBuffer(name);
		sb.append(" ").append(" hello").insert(0, "Mr.");
		System.out.println(sb);
	}

}
