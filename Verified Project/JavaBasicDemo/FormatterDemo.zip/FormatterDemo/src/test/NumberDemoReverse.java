package test;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

public class NumberDemoReverse {

	public static void main(String[] args) {

		String amt = "$200,000.00";
		NumberFormat nf = NumberFormat.getCurrencyInstance(Locale.US);
		Number a = null;
		try {
			a = nf.parse(amt);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println(" value is " + a.floatValue());
	}

}
