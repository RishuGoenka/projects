package test;

import java.text.NumberFormat;
import java.util.Locale;

public class NumberFormatterDemo {

	public static void main(String[] args) {
		float amount = 1254856.15F;
		NumberFormat fm = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
		System.out.println(fm.format(amount));
	}
}