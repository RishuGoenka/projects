package test;

import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Locale;

/**
 * provides Demo Date Format
 * 
 * @author samriddha.banik
 *
 */
public class DateFormatterV1Demo {

	/**
	 * main method
	 * 
	 * @param args
	 * @throws ParseException
	 */
	public static void main(String[] args) throws ParseException {
		/**
		 * With String Date Of Birth
		 */
		String birthDate = "12/20/1994";
		/**
		 * Date Format Specification
		 */
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, Locale.US);
		df.setLenient(false);
		/**
		 * Formatted String as Date
		 */
		Date date = df.parse(birthDate);

		System.out.println("D.O.B : " + date);
	}
}
