package employee_test;

public class Application {

	public static void main(String[] args) {
		Employee emp = new Employee();
		emp.setName("Rish Goenka");
		emp.setDateOfBirth(EmployeeDetailsParser.toDate("12/05/1994"));
		emp.setDateOfJoinning(EmployeeDetailsParser.toDate("04/06/2016"));
		emp.setSalary(EmployeeDetailsParser.toFloat("999999.00"));
		emp.print();
	}

}
