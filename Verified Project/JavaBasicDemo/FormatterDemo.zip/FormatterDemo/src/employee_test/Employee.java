package employee_test;

import java.util.Date;

public class Employee {

	private String name;
	private Date dateOfBirth;
	private Date dateOfJoinning;
	private Float salary;

	public Employee(String name, Date dateOfBirth, Date dateOfJoinning, Float salary) {
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.dateOfJoinning = dateOfJoinning;
		this.salary = salary;
	}

	public Employee() {

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Date getDateOfJoinning() {
		return dateOfJoinning;
	}

	public void setDateOfJoinning(Date dateOfJoinning) {
		this.dateOfJoinning = dateOfJoinning;
	}

	public Float getSalary() {
		return salary;
	}

	public void setSalary(Float salary) {
		this.salary = salary;
	}

	public void print() {
		System.out.println("Name : " + getName() + " Date Of Birth : " + EmployeeDetailsParser.fromDate(dateOfBirth)
				+ " Date Of Joinning : " + EmployeeDetailsParser.fromDate(dateOfJoinning) + " Salary : "
				+ EmployeeDetailsParser.fromNumber(getSalary()));
	}

}
