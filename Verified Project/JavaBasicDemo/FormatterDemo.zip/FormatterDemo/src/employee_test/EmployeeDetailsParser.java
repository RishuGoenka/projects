package employee_test;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class EmployeeDetailsParser {

	public static String fromNumber(Float number) {
		NumberFormat salaryFormatter = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
		return salaryFormatter.format(number);
	}

	public static String fromDate(Date date) {
		DateFormat dateFormat = DateFormat.getDateInstance();
		return dateFormat.format(date);
	}

	public static Date toDate(String date) {
		try {
			return DateFormat.getDateInstance(DateFormat.SHORT, Locale.UK).parse(date);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static Float toFloat(String number) {
		return Float.parseFloat(number);
	}

}
