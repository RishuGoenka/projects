abstract public class Customer {
	String custFN, custLN;
	int custId;

	public Customer(String custFN, String custLN, int custId) {
		this.custFN = custFN;
		this.custLN = custLN;
		this.custId = custId;
	}

	public void print() {
		System.out.println("Customer " + custFN + " " + custLN);
	}

}
