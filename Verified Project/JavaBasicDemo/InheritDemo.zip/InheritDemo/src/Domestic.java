public class Domestic extends Customer {
	String city;

	public Domestic(String custFN, String custLN, int custId, String city) {
		super(custFN, custLN, custId);
		this.city = city;
	}

	public void print() {
		super.print();
		System.out.print("City :" + city);
	}

	public static void main(String args[]) {
		Domestic d = new Domestic("rish", "goenka", 1, "bbsr");
		d.print();
	}
}
