public class ForEach {
	public static void main(String[] args) {
		String[] str = { "first", "second" };
		for (String s : str) {
			System.out.println(s);
		}
	}
}
