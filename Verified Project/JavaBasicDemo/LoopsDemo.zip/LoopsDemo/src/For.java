public class For {
	public static void main(String[] args) {
		for (int i = 0; i < 11; i++)
			System.out.println(i * i);
	}
}
