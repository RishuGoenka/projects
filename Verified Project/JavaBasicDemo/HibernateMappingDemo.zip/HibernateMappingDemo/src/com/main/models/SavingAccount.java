package com.main.models;

public class SavingAccount extends Account {

	private static final long serialVersionUID = 1L;
	private Double minBalance;

	public Double getMinBalance() {
		return minBalance;
	}

	public void setMinBalance(Double minBalance) {
		this.minBalance = minBalance;
	}

}
