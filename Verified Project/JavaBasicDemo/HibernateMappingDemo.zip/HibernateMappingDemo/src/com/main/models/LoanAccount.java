package com.main.models;

public class LoanAccount extends Account {

	private static final long serialVersionUID = 1L;
	private Double installment;

	public Double getInstallment() {
		return installment;
	}

	public void setInstallment(Double installment) {
		this.installment = installment;
	}

}
