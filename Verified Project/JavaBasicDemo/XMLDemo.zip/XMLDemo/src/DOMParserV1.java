import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DOMParserV1 {

	public static void main(String[] args) {
		Document d = null;
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();

		try {
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			d = builder.parse(new File("src/emp.xml"));
			System.out.println("Document validation is done..!!");

			System.out.println("found employees: " + d.getElementsByTagName("employee").getLength());
			List<String> names = getAllNames(d);

			for (String s : names) {
				System.out.println(s);
			}
		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}

	}

	private static List<String> getAllNames(Document d) {
		List<String> enames = new ArrayList<String>();
		NodeList list = d.getElementsByTagName("employee");
		for (int i = 0; i < list.getLength(); i++) {
			Node n = list.item(i);
			String name = n.getAttributes().item(0).getNodeValue();
			enames.add(name);
		}
		return enames;
	}

}
