import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser; //The Parser to parse/validate/read XML files
import javax.xml.parsers.SAXParserFactory; //The Factory from where we get Parser
import org.xml.sax.SAXException;

public class SAXDemoV2 {

	public static void main(String[] args) {

		SAXParserFactory factory = SAXParserFactory.newInstance();
		factory.setNamespaceAware(true);
		SAXParser parser = null;

		try {
			// get instance of parser from SAXParserFactory
			parser = factory.newSAXParser();
			SAXListenerV2 s2 = new SAXListenerV2();
			parser.parse(new File("src/emp12.xml"), s2);
			System.out.println("Validation is over");

			System.out.println("Name of employees are : ");
			for (String n : s2.getNames()) {
				System.out.println(n);
			}

		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}

	}

}
