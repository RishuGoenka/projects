import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class SAXListenerV2 extends SAXListenerV1 {

	List<String> empNames = new ArrayList<>();

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		super.startElement(uri, localName, qName, attributes);

		// If selected element is "employee" element
		if (localName.equals("employee")) {
			String name = attributes.getValue("name");// Read value of "name"
														// attribute
			empNames.add(name);
		}
	}

	public List<String> getNames() {
		return empNames;
	}

}
