import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser; //The Parser to parse/validate/read XML files
import javax.xml.parsers.SAXParserFactory; //The Factory from where we get Parser
import org.xml.sax.SAXException;

public class SAXDemoV1 {

	public static void main(String[] args) {

		SAXParserFactory factory = SAXParserFactory.newInstance();
		SAXParser parser = null;

		try {
			// get instance of parser from SAXParserFactory
			parser = factory.newSAXParser();
			// Validate file "emp.xml" and use Listener "SAXListener"
			parser.parse(new File("src/emp.xml"), new SAXListenerV1());
			System.out.println("Validation is over");

		} catch (ParserConfigurationException | SAXException | IOException e) {
			e.printStackTrace();
		}

	}

}
