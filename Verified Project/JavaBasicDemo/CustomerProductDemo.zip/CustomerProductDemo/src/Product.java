public class Product {
	protected int prodId, prodPrice;
	protected String prodName, prodDes;

	public Product(int prodId, String prodName, String prodDes, int prodPrice) {
		this.prodId = prodId;
		this.prodPrice = prodPrice;
		this.prodName = prodName;
		this.prodDes = prodDes;
	}

	void print() {
		System.out.println("The Product id is " + prodId);
		System.out.println("The Product Name is " + prodName);
		System.out.println("The Product Price is " + prodPrice);
		System.out.println("The Product Description " + prodDes);
	}
}
