public class CustomerProduct {
	public static void main(String args[]) {

		Customer c = new Customer(1, "Rish", "BBSR");
		c.print();

		Product p = new Product(1, "Cake", "Chocolate", 10);
		p.print();
	}
}
