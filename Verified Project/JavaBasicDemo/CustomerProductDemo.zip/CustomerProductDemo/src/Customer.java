public class Customer {
	protected int custId;
	protected String custName, custAddr;

	public Customer(int custId, String custName, String custAddr) {
		this.custId = custId;
		this.custName = custName;
		this.custAddr = custAddr;
	}

	void print() {
		System.out.println("The Customer id is " + custId);
		System.out.println("The Customer Name is " + custName);
		System.out.println("The Customer Address is " + custAddr);
	}

}
