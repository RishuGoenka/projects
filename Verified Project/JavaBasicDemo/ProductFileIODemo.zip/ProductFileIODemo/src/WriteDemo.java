import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;

public class WriteDemo {

	private static final String DATAFILE = "./prod.dat";

	public static void main(String[] args) {

		Collection<Product> data = new LinkedList<Product>();

		data.add(new Product("hamam", "Soap", 24));
		data.add(new Product("Colgate", "Toothpaste", 30));
		data.add(new Product("Colgate", "Toothbrush", 20));

		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream(new FileOutputStream(WriteDemo.DATAFILE));
			out.writeObject(data);
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
