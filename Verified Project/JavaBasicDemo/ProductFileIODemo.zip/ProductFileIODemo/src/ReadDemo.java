import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.*;

public class ReadDemo {

	private static final String DATAFILE = "./prod.dat";

	public static void main(String[] args) {

		Collection<Product> data = new LinkedList<Product>();

		ObjectInputStream oin = null;
		try {
			oin = new ObjectInputStream(new FileInputStream(ReadDemo.DATAFILE));
			Object obj = null;
			obj = oin.readObject();
			if (obj != null && obj instanceof LinkedList) {
				data = (LinkedList) obj;
			}
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}

		Iterator<Product> it = data.iterator();

		while (it.hasNext()) {
			Product p = (Product) it.next();
			System.out.println(
					"Product name " + p.getName() + "\tDescription " + p.getDescription() + "\tPrice " + p.getPrice());
		}

	}

}
