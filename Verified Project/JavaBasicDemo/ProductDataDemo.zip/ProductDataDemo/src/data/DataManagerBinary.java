package data;

import java.io.*;
import model.Product;

public class DataManagerBinary implements IProductDAO {
	private static final String DATAFILE = "./products.dat";

	@Override
	public void add(Product p) {
		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream(new FileOutputStream(DataManagerBinary.DATAFILE));
			out.writeObject(p);
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				out.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	public Product[] getAll() {
		return null;
	}

	public Product get() {
		ObjectInputStream oln = null;
		Product p = null;
		try {
			oln = new ObjectInputStream(new FileInputStream(DataManagerBinary.DATAFILE));
			Object obj = null;
			obj = oln.readObject();
			if (obj != null && obj instanceof Product) {
				p = (Product) obj;
				oln.close();
			}
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return p;
	}

}
