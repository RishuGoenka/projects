package data;

import java.io.*;
import model.Product;

public class DataManager {
	private static final String DATAFILE = "./products.txt";

	public void add(Product p) {
		try (FileWriter file = new FileWriter(DATAFILE, true)) {

			file.write(p.getName() + ", " + p.getDescription() + ", " + p.getPrice() + "\n");
		} catch (IOException e) {
			throw new RuntimeException("Could not save this record", e);
		}

	}

	public Product[] getAll() {

		return null;
	}
}
