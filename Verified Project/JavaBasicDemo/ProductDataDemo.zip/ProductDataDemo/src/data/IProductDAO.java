package data;

import model.Product;

/**
 * Data access object [DAO] interface inform developer working on next layer
 * what all methods Are available
 *
 * you must provided minimum ONE implementation of this interface
 */
public interface IProductDAO {
	/**
	 * Method to add product. target depends on which implementation you choose
	 * 
	 * @param p
	 *            Product to be saved/recorded
	 */
	void add(Product p);

	/**
	 * Get all the products saved
	 * 
	 * @return Array of products
	 */
	Product[] getAll();

	/**
	 * Get single product
	 * 
	 * @return Product read form file /DB
	 */
	Product get();
}
