package ui;

import model.Product;
import data.DataManagerBinary;
import data.IProductDAO;

import java.io.*;

public class App {
	public static void main(String args[]) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter name of the product: ");
		String name = br.readLine();

		System.out.println("Enter Description of the product: ");
		String desc = br.readLine();

		System.out.println("Enter Price of the product: ");
		String t = br.readLine();
		double price = Double.parseDouble(t);

		Product p = new Product(name, desc, price);

		IProductDAO dmb = new DataManagerBinary();
		dmb.add(p);

		System.out.println("Data Written.");

		Product x = dmb.get();
		System.out.println("Product name: " + x.getName());
	}
}
