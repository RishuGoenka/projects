package com.mahendra.demo.web.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.mahendra.demo.app.models.Contact;
import com.mahendra.demo.app.services.ContactService;

@Controller

public class AddContactController {

	@Autowired
	private ContactService service;

	@RequestMapping(value = "/home.do", method = RequestMethod.GET)
	public String process() {
		Contact contact = new Contact();
		contact.setFirstName("Test");
		contact.setLastName("Root");
		contact.setEmail("TR20@zycus.com");

		service.createContact(contact);
		System.out.println("Saved");
		return "success";
	}

}
