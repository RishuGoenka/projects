package com.mahendra.app;

import com.mahendra.services.LibraryService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain {

	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("./Spring.xml");
		LibraryService service = context.getBean("libraryService", LibraryService.class);
		LibraryService service2 = (LibraryService) context.getBean("libraryService");

		System.out.println("First instance : " + service);
		System.out.println("Second instance : " + service2);

		service.doSomething();
		// context.close(); //manually close/shutdown IoC Container
		context.registerShutdownHook();

	}

}
