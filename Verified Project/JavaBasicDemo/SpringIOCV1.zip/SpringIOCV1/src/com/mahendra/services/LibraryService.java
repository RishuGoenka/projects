package com.mahendra.services;

import java.util.logging.Logger;
import com.mahendra.dao.BookDAO;
import com.mahendra.dao.MemberDAO;

public class LibraryService {
	private static Logger log = Logger.getLogger(LibraryService.class.getCanonicalName());

	private BookDAO bookDao;
	private MemberDAO memberDao;

	// An example of dependency injection by constructor
	// Also called as Constructor Injection
	public LibraryService(BookDAO bookDao, MemberDAO memberDao) {
		this.bookDao = bookDao;
		this.memberDao = memberDao;
	}

	public LibraryService() {

	}

	// An example of dependency injection by setter
	// Also called by setter injection
	public void setBookDao(BookDAO dao1) {
		this.bookDao = dao1;
	}

	public void setMemberDao(MemberDAO dao2) {
		this.memberDao = dao2;
	}

	public void doSomething() {
		// this service class need to call methods on DAO classes
		// And those methods are 'instance' method [ non-static]
		// So need to created instances first

		// log.info("Creating instances of dependencies");
		// BookDAO dao1 = new BookDAO();
		// MemberDAO dao2 = new MemberDAO();

		log.info("Calling required methods ");
		bookDao.someMethod();
		memberDao.someMethod();
	}
}
