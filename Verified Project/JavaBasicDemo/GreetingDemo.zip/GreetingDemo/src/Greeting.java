public class Greeting {
	public void greet(String args) {
		System.out.println("Hello : " + args);
	}
}
