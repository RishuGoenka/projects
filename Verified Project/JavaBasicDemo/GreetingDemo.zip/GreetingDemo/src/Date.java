public class Date extends Object {

	// Member variables
	// instance variables: [non static]
	private int day, month, year;
	// class variables: [static]
	static char seperator = '/';

	// Member Method : instance methods [non static] OR
	void print() {
		System.out.println("Date : " + day + seperator + month + seperator + year);
	}

	// Member method: Class Method[static method]
	static void setSeperator(char sp) {
		// Local variables": variables declared as arguments and variables
		// declared
		// inside method body are local variables
		// in java, local variables [other than arguments]
		// must be initialized explicitly
		seperator = sp;
	}

	public Date(int day, int month, int year) {
		// Both local and global variables are same....

		int quotent;
		if (day > 31) {
			quotent = day / 31;
			month += quotent;
			day = day % 31;
		}
		if (month > 12) {
			quotent = month / 12;
			year += quotent;
			month = month % 12;
		}
		if (year <= 0)
			year = 1000;
		this.day = day;
		this.month = month;
		this.year = year;
	}
}
