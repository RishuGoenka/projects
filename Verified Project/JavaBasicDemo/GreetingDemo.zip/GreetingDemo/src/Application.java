public class Application {

	public static void main(String[] args) {

		Greeting obj = new Greeting();
		obj.greet("Ram");
		Date d = new Date(41, 1, 2016);
		d.print();

	}
}
