import java.text.NumberFormat;
import java.util.Locale;

public class NumberDemo {

	public static void main(String[] args) {

		float amt = 123456.78f; // un-formated or not formated number
		NumberFormat fm = NumberFormat.getCurrencyInstance(Locale.KOREAN);
		String formatedamount = fm.format(amt);
		System.out.println("number formatted in curency:" + formatedamount);
	}

}
