import java.util.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Locale;

public class DateDemoTypeOne {
	public static void main(String[] args) {

		String birthdate = "1/13/1998"; // Asume date is mm/dd/yyyy
		// DateFormatter to format date in US short Style i.e.mm/dd/yy
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, Locale.US);
		Date d = null;
		try {
			d = df.parse(birthdate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println("The date of birth you entered is :" + d);
	}

}
