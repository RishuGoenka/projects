import java.text.DateFormat;
import java.util.Date;

public class DateDemoTypeTwo {
	public static void main(String[] args) {

		Date d = new Date(); // Gets current system date
		String formattedate = null;
		DateFormat ft = DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.FULL);
		formattedate = ft.format(d);
		System.out.println("today is:" + formattedate);
	}

}
