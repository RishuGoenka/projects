import java.util.Date;

public class SIRDateClassTwo {

	public static void main(String[] args) {

		SIRDateClass emp = new SIRDateClass("Yash Chopra", toDate("4/7/2004"), toDate("8/2/1978"), toFloat("3,50,000"));
		System.out.println("hello " + emp.getName() + " your joining was on:" + emp.getDateOfJoining()
				+ " date of birth:" + emp.getDateOfBirth());
	}

	private static float toFloat(String string) {

		return 0;
	}

	public static Date toDate(String strDate) {

		return null;
	}

}
