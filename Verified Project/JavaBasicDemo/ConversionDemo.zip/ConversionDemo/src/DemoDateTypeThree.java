import java.text.DateFormat;
import java.util.*;

public class DemoDateTypeThree {

	public static void main(String[] args) {
		Date d = new Date();
		Date t = new Date();// get the current date
		String formattedDate = null;
		DateFormat ft = DateFormat.getDateInstance(DateFormat.SHORT, Locale.UK);
		DateFormat dt = DateFormat.getTimeInstance(DateFormat.SHORT);
		formattedDate = ft.format(d);
		String formattedTime = dt.format(t);
		System.out.println("Today's date is " + formattedDate);
		System.out.println("Time is " + formattedTime);
	}

}
