import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;

public class DataEmployee {
	static String name;
	static Date dob, doj;
	static float salary;
	static String dobirth, dojoining;

	public static void main(String[] args) {
		name = "Rish Goenka";
		salary = 999999.09f;
		dobirth = "12/05/1994";
		dojoining = "04/06/2016";
		print();
	}

	public static void print() {
		NumberFormat fm = NumberFormat.getCurrencyInstance(Locale.UK);
		String formatedamount = fm.format(salary);
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, Locale.US);
		// DateFormat
		// ft=DateFormat.getDateTimeInstance(DateFormat.FULL,DateFormat.FULL);
		Date d = null;
		try {
			d = df.parse(dobirth);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println("number formatted in date:" + d);
		df = DateFormat.getDateInstance(DateFormat.SHORT, Locale.US);
		// ft=DateFormat.getDateTimeInstance(DateFormat.FULL,DateFormat.FULL);
		d = null;
		try {
			d = df.parse(dojoining);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println("number formatted in date:" + d);
		System.out.println("number formatted in curency:" + formatedamount);
	}
}
