package com.mahendra.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
//import javax.servlet.http.Cookie;

import com.mahendra.models.*;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("uname");
		String password = request.getParameter("password");
		List<String> errors = new ArrayList<>();

		// Simple validation
		if (username == null || username.trim().length() < 1) {
			errors.add("Username cannot be blank");
		}
		if (password == null || password.trim().length() < 1) {
			errors.add("Password cannot be blank");
		}
		if (username != null && username.equalsIgnoreCase(password)) {
			errors.add("Username and password cannot be same");
		}

		HttpSession session = request.getSession();
		session.removeAttribute("errors");

		if (!errors.isEmpty()) {
			request.setAttribute("msg", "Login Failed");
			request.setAttribute("errors", errors);
			// Cookie cookie = new Cookie("msg","Login Failed");
			// cookie.setMaxAge(5);

			// session.setAttribute("msg", "Login Failed");
			// session.setAttribute("errors", errors);
		} else {
			request.setAttribute("msg", "Login Succeeded");

			// Cookie cookie = new Cookie("msg","Login Succeeded");
			// cookie.setMaxAge(5);

			// session.setAttribute("msg","Login Succeeded");
			User user = new User();
			user.setUsername(username);
			user.setPassword(password);
			session.setAttribute("user", user);
		}

		// response.sendRedirect("result.jsp");
		RequestDispatcher view = request.getRequestDispatcher("result.jsp");
		view.forward(request, response);
	}

}
