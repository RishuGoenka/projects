package com.mahendra.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mahendra.models.Comment;
import com.mahendra.models.CommentDAO;

/**
 * Servlet implementation class ShowCommentServlet
 */
public class ShowCommentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShowCommentServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		CommentDAO dao = (CommentDAO) getServletContext().getAttribute("commentDao");

		String par = request.getParameter("article");
		int articleId = Integer.parseInt(par);

		List<Comment> comments = dao.getCommentForArticleId(articleId);

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		for (Comment c : comments) {
			out.println("<div>");
			out.print("Comment by " + c.getUser() + " " + c.getDateOfPost() + "<br/>");
			out.println("<p>" + c.getText() + "</p>");
			out.println("</div>");
		}
		out.close();
	}

}
