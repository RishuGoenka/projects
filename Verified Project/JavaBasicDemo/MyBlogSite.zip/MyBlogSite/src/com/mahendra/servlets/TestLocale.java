package com.mahendra.servlets;

import java.util.Locale;

public class TestLocale {

	public static void main(String[] args) {
		Locale locale = new Locale("en", "IN");
		System.out.println(locale.getCountry() + " " + locale.getDisplayName() + " " + locale.getDisplayLanguage());
		Locale[] locales = locale.getAvailableLocales();
		System.out.println("supported locales are: " + locales.length);
		for (Locale x : locales) {
			System.out.println(x.getDisplayName());
		}
	}

}
