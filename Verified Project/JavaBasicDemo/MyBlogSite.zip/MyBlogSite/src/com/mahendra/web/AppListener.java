package com.mahendra.web;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import com.mahendra.dao.ArticleDAOImpl;
import com.mahendra.dao.CommentDAOImpl;
import com.mahendra.models.Article;
import com.mahendra.models.ArticleDAO;
import com.mahendra.models.Comment;
import com.mahendra.models.CommentDAO;

/**
 * Application Lifecycle Listener implementation class AppListener
 *
 */
public class AppListener implements ServletContextListener {

	/**
	 * Default constructor.
	 */
	public AppListener() {
	}

	/**
	 * @see ServletContextListener#contextDestroyed(ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent arg0) {
		arg0.getServletContext().removeAttribute("commentDao");
		arg0.getServletContext().removeAttribute("articleDao");

	}

	/**
	 * @see ServletContextListener#contextInitialized(ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent arg0) {
		List<Article> articles = new LinkedList<Article>();
		// Create a dummy article
		Article a = new Article();
		a.setArticleId(1);
		a.setAuthor("Mahendra");
		a.setText(
				"The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. The quick brown fox jumps over the lazy dog. ");
		a.setDateOfPost(new Date());

		articles.add(a);

		List<Comment> comments = new LinkedList<Comment>();
		// Create a dummy comment
		Comment c = new Comment();
		c.setCommentId(1);
		c.setUser("Salman");
		c.setText("Badhiya....hain, mujhe bhi sikha do");
		c.setDateOfPost(new Date());
		c.setArticleId(1);

		comments.add(c);

		// Create DAO Objects
		ArticleDAO articleDAO = new ArticleDAOImpl(articles);
		CommentDAO commentDAO = new CommentDAOImpl(comments);

		arg0.getServletContext().setAttribute("articleDao", articleDAO);
		arg0.getServletContext().setAttribute("commentDao", commentDAO);
		System.out.println("DAO's are now stored in Application scope");
	}

}
