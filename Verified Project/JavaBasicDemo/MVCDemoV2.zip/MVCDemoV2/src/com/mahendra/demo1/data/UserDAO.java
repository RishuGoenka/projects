package com.mahendra.demo1.data;

import java.util.List;
import com.mahendra.demo1.model.User;

public class UserDAO {
	private List<User> users;

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}

	public void add(User user) {
		users.add(user);
		System.out.println("New user added");
	}

	public User findByName(String name) {
		User user = null;
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i).getUserName().equalsIgnoreCase(name)) {
				user = users.get(i);
				break; // stop next search
			}
		}
		return user;
	}

	public void update(User user) {
		User target = findByName(user.getUserName());
		if (target == null) {
			throw new RuntimeException("No record found!");
		}
		target.setPassword(user.getPassword());
		target.setEmail(user.getEmail());
		target.setGender(user.getGender());
	}

}
