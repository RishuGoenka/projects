package com.mahendra.demo1.controllers;

import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;
import com.mahendra.demo1.data.UserDAO;
import com.mahendra.demo1.model.User;

@SuppressWarnings("deprecation")
public class RegisterUserController extends SimpleFormController {
	private UserDAO dao;

	/*
	 * With SimpleFormController, code to validate your model element And
	 * redirect to form page is done by Controller internally You just provide
	 * SUBMIT behaviour
	 */
	@Override
	protected ModelAndView onSubmit(Object command, BindException errors) throws Exception {
		User user = (User) command;
		dao.add(user);
		ModelAndView mv = new ModelAndView(getSuccessView());
		mv.addObject("msg", "User " + user.getUserName() + " successfuly registered!");
		return mv;
	}

	public void setDao(UserDAO dao) {
		this.dao = dao;
	}

}
