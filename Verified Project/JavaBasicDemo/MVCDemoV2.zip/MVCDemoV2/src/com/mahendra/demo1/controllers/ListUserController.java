package com.mahendra.demo1.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.mahendra.demo1.data.UserDAO;

public class ListUserController extends AbstractController {

	private UserDAO dao;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {
		ModelAndView mv = new ModelAndView("list");
		// Store list of users with key "users"
		mv.addObject("users", dao.getUsers());
		// And send it to view page "list"
		return mv;
	}

	public void setDao(UserDAO dao) {
		this.dao = dao;
	}

}
