public class Application {
	public static void main(String[] args) {
		long totalmemory = Runtime.getRuntime().totalMemory();
		System.out.println("total memory=" + totalmemory / (1024 * 1024));
		long maxmemory = Runtime.getRuntime().maxMemory();
		System.out.println("max memory=" + maxmemory / (1024 * 1024));
		long freememory = Runtime.getRuntime().freeMemory();
		System.out.println("free memory=" + freememory / (1024 * 1024));
		double data[] = new double[100000000];
		for (int i = 0; i < data.length; i++)
			data[i] = i * 1.1;
		totalmemory = Runtime.getRuntime().totalMemory();
		System.out.println("total memory=" + totalmemory / (1024 * 1024));
		maxmemory = Runtime.getRuntime().maxMemory();
		System.out.println("max memory=" + maxmemory / (1024 * 1024));
		freememory = Runtime.getRuntime().freeMemory();
		System.out.println("free memory=" + freememory / (1024 * 1024));
	}
}
