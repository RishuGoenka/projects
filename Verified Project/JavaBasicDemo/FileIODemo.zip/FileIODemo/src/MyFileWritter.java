import java.io.FileWriter;
import java.io.IOException;

public class MyFileWritter {

	public static void main(String[] args) {
		try {
			String line = "The quick cat jumps over the lazy dog.";
			FileWriter out = new FileWriter("./setup.log");
			out.write(line + "\n");
			out.close();
		} catch (IOException x) {
			x.printStackTrace();
		}
	}
}
