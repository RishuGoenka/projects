import java.io.IOException;

public class ReadMeApp {

	public static void main(String[] args) {
		String name = null;
		System.out.println("Enter ur name");
		byte[] rw = new byte[100];
		try {
			int x = System.in.read(rw);
			name = new String(rw);// or name=new string(rw,0,x);---> for
									// converting particular length for
									// conversion
			System.out.println("hello " + name.trim() + " how are you?");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
