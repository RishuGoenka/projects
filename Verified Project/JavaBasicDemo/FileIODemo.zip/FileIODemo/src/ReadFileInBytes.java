import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadFileInBytes {
	public static void main(String[] args) {
		try {
			FileReader fx = new FileReader("./setup.log");
			BufferedReader file = new BufferedReader(fx);
			// FileInputStream file=new FileInputStream("C:\\setup.log");
			// long sizeOfFile=file.available();
			// System.out.println("file size in bytes:"+sizeOfFile);
			// char[] buffer=new char[100]; int len=file.read(buffer);
			// while(len>0) { String line=new String(buffer,0,len);
			// System.out.println(line); len=file.read(buffer); }

			String line = file.readLine();
			while (line != null) {
				System.out.println(line);
				line = file.readLine();
			}
			file.close();
			System.out.println("==========done reading============");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
