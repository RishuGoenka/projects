public class AccountTransaction {
	public boolean deposit(Account account, double amount) {
		account.setBalanace(account.getBalanace() + amount);
		return true;
	}

	public boolean withdraw(Account account, double amount) {
		if (account.getBalanace() < amount)
			return false;
		account.setBalanace(account.getBalanace() - amount);
		return true;
	}

	public boolean transfer(Account from, Account to, double amount) {
		// serious problems...
		boolean b1 = deposit(to, amount);
		boolean b2 = withdraw(from, amount);
		if (b1 && b2)
			return true;
		return false;
	}
}
