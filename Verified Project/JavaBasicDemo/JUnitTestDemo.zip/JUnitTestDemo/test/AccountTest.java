import static org.junit.Assert.*;
import java.util.Date;
import org.junit.Test;

public class AccountTest {

	@Test
	public void testGetAccountNumber() {
		Account a = new Account(101, "Abhishek", 2135455, new Date());
		assertEquals(101, a.getAccountNumber());
	}

	@Test
	public void testGetBalance() {
		Account a = new Account(101, "Abhishek", 2135455, new Date());
		assertEquals("Incorrect balance", 2135455, a.getBalanace(), 0.01);
	}

}