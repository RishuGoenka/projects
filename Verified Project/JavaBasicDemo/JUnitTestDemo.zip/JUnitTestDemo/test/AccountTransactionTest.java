import static org.junit.Assert.*;
import java.util.Date;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AccountTransactionTest {
	Account a1 = null;
	Account a2 = null;
	AccountTransaction tn = null;

	@Before
	public void setUp() throws Exception {
		// Prepare test case conditions
		a1 = new Account(101, "salman", 1200, new Date());
		a2 = new Account(102, "katrina", 1250, new Date());
		tn = new AccountTransaction();
	}

	@After
	public void tearDown() throws Exception {
		// destroy the pre-test conditions
		a1 = null;
		a2 = null;
		tn = new AccountTransaction();

	}

	@Test
	public void testDeposit() {
		// try to deposit rs 500 in a1...!
		tn.deposit(a1, 500);
		assertEquals("problem with deposit!", 1700, a1.getBalanace(), 0.01);
	}

	@Test
	public void testWithdraw() {
		// try to withdraw rs 2000...!
		assertFalse(tn.withdraw(a1, 2000));
	}

	@Test
	public void testTransfer() {
		// try to transfer from a2 to a1
		tn.transfer(a2, a1, 1000);
		// balance of a1 show now be 3000
		// System.out.println(a1.getBalanace());
		assertEquals(2200, a1.getBalanace(), 0.01);
	}

}
