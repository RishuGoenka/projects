package com.mahendra.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.mahendra.models.Employee;

public class ApplicationV1 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getFactory();
		Session session = factory.openSession();
		Employee e = (Employee) session.load(Employee.class, 9013);
		session.close();
		System.out.println(e.getName() + " working in " + e.getDepartment().getName());
		System.out.println(e.getHiredate());

	}
}
