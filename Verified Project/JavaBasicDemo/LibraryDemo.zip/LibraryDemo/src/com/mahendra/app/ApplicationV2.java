package com.mahendra.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.mahendra.models.Department;
//import com.mahendra.models.Employee;

public class ApplicationV2 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getFactory();
		Session session = factory.openSession();
		Department d = (Department) session.get(Department.class, 20);
		System.out.println("Name of department:" + d.getName());

		session.close();
	}

}
