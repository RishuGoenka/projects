package com.mahendra.app;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.mahendra.models.Author;
import com.mahendra.models.Book;

public class ApplicationMain {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getFactory();
		Session session = factory.openSession();
		Transaction tn = null;
		Author a1 = new Author(1, "Abc", "Def");
		Book b1 = new Book(11, "My book", a1);
		Author a2 = new Author(2, "Ghi", "Jkl");
		Book b2 = new Book(21, "Romeo", a2);
		Book b3 = new Book(22, "Juliet", a2);

		try {
			tn = session.beginTransaction();
			session.save(a1);
			session.save(a2);
			session.save(b1);
			session.save(b2);
			session.save(b3);
			tn.commit();
			System.out.println("Saved all!!!!");
		} catch (HibernateException ex) {
			if (tn != null)
				tn.rollback();
			ex.printStackTrace();
		}

		session.close();
	}

}
