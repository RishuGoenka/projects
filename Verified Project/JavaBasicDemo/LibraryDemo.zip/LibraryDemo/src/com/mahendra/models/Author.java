package com.mahendra.models;

import java.io.Serializable;

public class Author implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer authorId;
	private String firstName, lastName;

	public Author() {
		super();
	}

	public Author(Integer authorId, String firstName, String lastName) {
		super();
		this.authorId = authorId;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public Integer getAuthorId() {
		return authorId;
	}

	public void setAuthorId(Integer authorId) {
		this.authorId = authorId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}
