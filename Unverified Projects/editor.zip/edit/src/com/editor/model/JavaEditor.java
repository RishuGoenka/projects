package com.editor.model;

import java.io.*;

public class JavaEditor implements Serializable {

	private static final long serialVersionUID = -7634333752239905306L;
	private String codeText;

	public JavaEditor() {
		super();
	}

	public JavaEditor(String codeText) {
		super();
		this.codeText = codeText;
	}

	public String getCodeText() {
		return codeText;
	}

	public void setCodeText(String codeText) {
		this.codeText = codeText;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
