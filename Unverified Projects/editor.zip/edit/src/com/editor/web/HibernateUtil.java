package com.editor.web;

import org.hibernate.cfg.Configuration;
import org.hibernate.*;

public class HibernateUtil {
	private static SessionFactory factory = build();

	private static SessionFactory build() {
		Configuration config = new Configuration().configure();
		SessionFactory factory = config.buildSessionFactory();
		return factory;
	}

	public static SessionFactory getFactory() {
		return factory;
	}
}
