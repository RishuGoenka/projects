
package com.editor.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.editor.model.JavaEditor;
import com.editor.web.HibernateUtil;


public class JavaEditorDAO {
	private SessionFactory factory = null;
	//Constructor to connect to DataBase
	public JavaEditorDAO() {
		super();
		factory = HibernateUtil.getFactory();
	}

	//Add new Code
	public void save(JavaEditor javaeditor){
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			session.save(javaeditor);
			tn.commit();
			System.out.println(" Record created ");
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}
	
	//modify Code details
	public void modify(JavaEditor javaeditor){
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			session.update(javaeditor);
			tn.commit();
			System.out.println("Record updated ");
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}

	//Find Code
	public JavaEditor findByText(String codeText) {
		Session session =factory.openSession();
		JavaEditor customer = null;
		customer = (JavaEditor) session.createQuery("from Customer c where c.codeText = :nm").setString("nm", codeText).uniqueResult();				
		return customer;	
	}
	
}
