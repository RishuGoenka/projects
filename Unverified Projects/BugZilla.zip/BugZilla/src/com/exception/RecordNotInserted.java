package com.exception;

public class RecordNotInserted extends Exception
{

	public RecordNotInserted()
	{
		// TODO Auto-generated constructor stub
	}

	public RecordNotInserted(String arg0)
	{
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public RecordNotInserted(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public RecordNotInserted(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RecordNotInserted(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
