package com.exception;

public class BugNotFoundException extends Exception
{

	public BugNotFoundException()
	{
		// TODO Auto-generated constructor stub
	}

	public BugNotFoundException(String message)
	{
		super(message);
		// TODO Auto-generated constructor stub
	}

	public BugNotFoundException(Throwable cause)
	{
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public BugNotFoundException(String message, Throwable cause)
	{
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public BugNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace)
	{
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
