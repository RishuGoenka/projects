package com.BussObj;

public class BugType
{
	private int		bugTypeId;
	private String	bugTypeName;

	public BugType(int bugTypeId, String bugTypeName)
	{
		super();
		this.bugTypeId = bugTypeId;
		this.bugTypeName = bugTypeName;
	}

	public int getBugTypeId()
	{
		return bugTypeId;
	}

	public void setBugTypeId(int bugTypeId)
	{
		this.bugTypeId = bugTypeId;
	}

	public String getBugTypeName()
	{
		return bugTypeName;
	}

	public void setBugTypeName(String bugTypeName)
	{
		this.bugTypeName = bugTypeName;
	}

	@Override
	public String toString()
	{
		return "BugType [bugTypeId=" + bugTypeId + ", bugTypeName=" + bugTypeName + "]";
	}

}
