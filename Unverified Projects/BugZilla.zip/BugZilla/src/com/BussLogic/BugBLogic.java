package com.BussLogic;

import java.util.ArrayList;

import com.BussObj.BugStatus;
import com.BussObj.BugType;
import com.BussObj.Bugs;
import com.daos.IBugDao;
import com.exception.BugNotFoundException;
import com.exception.InvalidStatusName;
import com.exception.InvalidTypeName;
import com.exception.RecordNotInserted;

public class BugBLogic
{

	private IBugDao	bugDao;

	//for setting dependency
	public void setBugDao(IBugDao bugDao)
	{
		this.bugDao = bugDao;
	}

	public ArrayList<Bugs> getAllBug()
	{
		return bugDao.getAllBug();
	}

	public Bugs getBugById(int bugId) throws BugNotFoundException
	{
		return bugDao.getBugById(bugId);
	}

	public ArrayList<Bugs> getBugByAssignee(String assignee) throws BugNotFoundException
	{
		return bugDao.getBugByAssignee(assignee);
	}

	public ArrayList<Bugs> getBugByType(String bugTypeName) throws InvalidTypeName, BugNotFoundException
	{
		return bugDao.getBugByType(bugTypeName);
	}

	public ArrayList<Bugs> getBugByStatus(String bugStatusName) throws InvalidStatusName, BugNotFoundException
	{
		return bugDao.getBugByStatus(bugStatusName);
	}

	public void fileBug(String bugDesc, String bugType, String bugStatus, String assignee, String reportee)
			throws RecordNotInserted
	{
		bugDao.fileBug(bugDesc, bugType, bugStatus, assignee, reportee);
	}

	public ArrayList<BugType> getAllBugType()
	{
		return bugDao.getAllBugType();
	}

	public ArrayList<BugStatus> getAllBugStatus()
	{
		return bugDao.getAllBugStatus();
	}
}
