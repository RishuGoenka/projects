package com.service;

import com.BussObj.UserCredentials;
import com.daos.UserMasterDao;
import com.exception.DuplicateUserException;

public class UserServices
{
	private UserMasterDao	userDao;

	public void setUserDao(UserMasterDao userDao)
	{
		this.userDao = userDao;
	}

	public UserCredentials getAuthenticationStatus(String userName, String password)
	{
		UserCredentials cred = userDao.getUserCredentials(userName);
		if (cred == null)
		{
			cred = new UserCredentials();
			cred.setStatus("login.UserMissing");
			return cred;
		}
		if (cred.getPassword().equals(password))
		{
			cred.setStatus("login.authenticate");
			return cred;
		}
		else
		{
			cred.setStatus("login.wrongPassword");
			return cred;
		}

	}

	public void addNewUser(String userName, String fullName, String password) throws DuplicateUserException
	{
		userDao.addNewUser(userName, fullName, password);
	}

}
