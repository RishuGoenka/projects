package com.factory;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class JNDIFactoryServiceImpl implements ConnectionFactoryService
{
	private DataSource	dataSource	= null;

	public JNDIFactoryServiceImpl()
	{
		try
		{
			Context jndiContext = new InitialContext();

			//get datsource from jndi
			Context envContext = (Context) jndiContext.lookup("java:/comp/env");

			dataSource = (DataSource) envContext.lookup("jdbc/myoracle");
		}
		catch (NamingException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Connection getConnection() throws SQLException
	{
		return dataSource.getConnection();
	}

}
