package com.factory;

import java.sql.Connection;
import java.sql.SQLException;

public interface ConnectionFactoryService
{
	public Connection getConnection() throws SQLException;
}
