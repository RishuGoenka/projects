package com.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBCFactoryService implements ConnectionFactoryService
{
	private Connection	connection;

	public JDBCFactoryService() throws ClassNotFoundException, SQLException
	{
		Class.forName("oracle.jdbc.OracleDriver");
		connection = DriverManager.getConnection("jdbc:oracle:thin:@192.168.1.187:1521:ORCL187", "PDT_TRAINING",
				"PDT_TRAINING#123");
	}

	@Override
	public Connection getConnection()
	{
		return connection;
	}

}
