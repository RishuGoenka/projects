package com.daos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.BussObj.BugStatus;
import com.BussObj.BugType;
import com.BussObj.Bugs;
import com.exception.BugNotFoundException;
import com.exception.InvalidStatusName;
import com.exception.InvalidTypeName;
import com.exception.RecordNotInserted;

public class BugDao implements IBugDao, AutoCloseable
{
	private Connection	connection;

	public BugDao()
	{
		String driver = "oracle.jdbc.OracleDriver";
		String url = "jdbc:oracle:thin:@192.168.1.187:1521:ORCL187";
		String username = "PDT_TRAINING";
		String password = "PDT_TRAINING#123";
		try
		{
			//1.Load driver
			Class.forName(driver);

			//2.request database connection
			connection = DriverManager.getConnection(url, username, password);

		}
		catch (ClassNotFoundException | SQLException e)
		{
			e.printStackTrace();
		}
	}

	//Get All bug in database

	public ArrayList<Bugs> getAllBug()
	{
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<Bugs> bugList = new ArrayList<Bugs>();
		try
		{
			stmt = connection.createStatement();

			rs = stmt.executeQuery("SELECT rahul_bugs.bugid,rahul_bugs.bugdes,rahul_bugs.bugtypeid,"
					+ "rahul_bugs.bugstatusid,rahul_bugs.assigneename,rahul_bugs.repoteename,"
					+ "rahul_bugs_type.bugtypename,rahul_bugs_status.bugstatusname FROM rahul_bugs,"
					+ "rahul_bugs_type,rahul_bugs_status where rahul_bugs.bugtypeid=rahul_bugs_type.BUGTYPEID "
					+ "and rahul_bugs.bugstatusid=rahul_bugs_status.bugstatusid");

			while (rs.next())
			{
				int bugId = rs.getInt("bugid");
				String bugDesc = rs.getString("bugdes");
				int bugTypeId = rs.getInt("bugtypeid");
				int bugStatusId = rs.getInt("bugstatusid");
				String assignee = rs.getString("assigneename");
				String reporte = rs.getString("repoteename");
				String bugTypeName = rs.getString("bugtypename");
				String bugStatusName = rs.getString("bugstatusname");

				BugType bugType = new BugType(bugTypeId, bugTypeName);
				BugStatus bugStatus = new BugStatus(bugStatusId, bugStatusName);
				Bugs bugs = new Bugs(bugId, bugDesc, bugType, bugStatus, assignee, reporte);
				bugList.add(bugs);

			}

		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}

			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bugList;
	}

	//bug by bugid
	public Bugs getBugById(int bugId) throws BugNotFoundException
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Bugs bug = null;
		int status = 0;
		try
		{
			stmt = connection.prepareStatement("SELECT rahul_bugs.bugdes,"
					+ "rahul_bugs.bugtypeid,rahul_bugs.bugstatusid,"
					+ "rahul_bugs.assigneename,rahul_bugs.repoteename,rahul_bugs_type.bugtypename,"
					+ "rahul_bugs_status.bugstatusname FROM rahul_bugs,rahul_bugs_type,rahul_bugs_status"
					+ " where rahul_bugs.bugtypeid=rahul_bugs_type.BUGTYPEID and "
					+ "rahul_bugs.bugstatusid=rahul_bugs_status.bugstatusid and rahul_bugs.bugid=?");
			stmt.setInt(1, bugId);

			rs = stmt.executeQuery();
			while (rs.next())
			{
				status++;
				//int bugId = rs.getInt("bugid");
				String bugDesc = rs.getString("bugdes");
				int bugTypeId = rs.getInt("bugtypeid");
				int bugStatusId = rs.getInt("bugstatusid");
				String assignee = rs.getString("assigneename");
				String reporte = rs.getString("repoteename");
				String bugTypeName = rs.getString("bugtypename");
				String bugStatusName = rs.getString("bugstatusname");

				BugType bugType = new BugType(bugTypeId, bugTypeName);
				BugStatus bugStatus = new BugStatus(bugStatusId, bugStatusName);
				bug = new Bugs(bugId, bugDesc, bugType, bugStatus, assignee, reporte);
			}
			if (status == 0)
			{
				throw new BugNotFoundException("Bug not found with the particular bugId");
			}

		}
		catch (Exception e)
		{
			throw new BugNotFoundException("Bug not found with the particular bugId");
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}

			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bug;
	}

	//List of Bug to particular Assignee
	public ArrayList<Bugs> getBugByAssignee(String assignee) throws BugNotFoundException
	{
		ArrayList<Bugs> bugListToAssignee = new ArrayList<Bugs>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Bugs bug = null;
		int status = 0;
		try
		{
			stmt = connection.prepareStatement("SELECT rahul_bugs.bugid,rahul_bugs.bugdes,"
					+ "rahul_bugs.bugtypeid,rahul_bugs.bugstatusid,"
					+ "rahul_bugs.repoteename,rahul_bugs_type.bugtypename,"
					+ "rahul_bugs_status.bugstatusname FROM rahul_bugs,rahul_bugs_type,rahul_bugs_status"
					+ " where rahul_bugs.bugtypeid=rahul_bugs_type.BUGTYPEID and "
					+ "rahul_bugs.bugstatusid=rahul_bugs_status.bugstatusid and rahul_bugs.assigneename=?");
			stmt.setString(1, assignee);

			rs = stmt.executeQuery();
			while (rs.next())
			{
				status++;
				int bugId = rs.getInt("bugid");
				String bugDesc = rs.getString("bugdes");
				int bugTypeId = rs.getInt("bugtypeid");
				int bugStatusId = rs.getInt("bugstatusid");
				//String assignee = rs.getString("assigneename");
				String reporte = rs.getString("repoteename");
				String bugTypeName = rs.getString("bugtypename");
				String bugStatusName = rs.getString("bugstatusname");

				BugType bugType = new BugType(bugTypeId, bugTypeName);
				BugStatus bugStatus = new BugStatus(bugStatusId, bugStatusName);
				bug = new Bugs(bugId, bugDesc, bugType, bugStatus, assignee, reporte);
				bugListToAssignee.add(bug);
			}
			if (status == 0)
			{
				throw new BugNotFoundException("No Bug found with this reportee");
			}

		}
		catch (Exception e)
		{
			throw new BugNotFoundException("No Bug found with this reporteed");
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}

			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bugListToAssignee;
	}

	//get the bugs by the Bug Type Name
	public ArrayList<Bugs> getBugByType(String bugTypeName) throws InvalidTypeName, BugNotFoundException
	{
		ArrayList<Bugs> bugListByType = new ArrayList<Bugs>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Bugs bug = null;
		int bugTypeId = 0;
		int status = 0;
		try
		{
			bugTypeId = getBugTypeId(bugTypeName);
		}
		catch (InvalidTypeName e)
		{
			throw new InvalidTypeName("No Type Id is Associated with this name");
		}

		try
		{
			stmt = connection.prepareStatement("SELECT rahul_bugs.bugid,rahul_bugs.bugdes," + "rahul_bugs.bugstatusid,"
					+ "rahul_bugs.assigneename,rahul_bugs.repoteename,"
					+ "rahul_bugs_status.bugstatusname FROM rahul_bugs,rahul_bugs_type,rahul_bugs_status"
					+ " where rahul_bugs.bugtypeid=rahul_bugs_type.BUGTYPEID and "
					+ "rahul_bugs.bugstatusid=rahul_bugs_status.bugstatusid and rahul_bugs.bugtypeid=?");
			stmt.setInt(1, bugTypeId);

			rs = stmt.executeQuery();
			while (rs.next())
			{
				status++;
				int bugId = rs.getInt("bugid");
				String bugDesc = rs.getString("bugdes");
				//int bugTypeId = rs.getInt("bugtypeid");
				int bugStatusId = rs.getInt("bugstatusid");
				String assignee = rs.getString("assigneename");
				String reporte = rs.getString("repoteename");
				//String bugTypeName = rs.getString("bugtypename");
				String bugStatusName = rs.getString("bugstatusname");

				BugType bugType = new BugType(bugTypeId, bugTypeName);
				BugStatus bugStatus = new BugStatus(bugStatusId, bugStatusName);
				bug = new Bugs(bugId, bugDesc, bugType, bugStatus, assignee, reporte);
				bugListByType.add(bug);
			}
			if (status == 0)
			{
				throw new BugNotFoundException("Bug not  with the particular bug Type");
			}

		}
		catch (Exception e)
		{
			throw new BugNotFoundException("Bug not  with the particular bug Type");
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}

			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bugListByType;

	}

	//get list of bug by the status
	public ArrayList<Bugs> getBugByStatus(String bugStatusName) throws InvalidStatusName, BugNotFoundException
	{

		ArrayList<Bugs> bugListByStatus = new ArrayList<Bugs>();
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Bugs bug = null;
		int bugStatusId = 0;
		int status = 0;

		try
		{
			bugStatusId = getBugStatusId(bugStatusName);
		}
		catch (InvalidStatusName e)
		{
			throw new InvalidStatusName("No Status Id is Associated with this status");
		}

		try
		{
			stmt = connection.prepareStatement("SELECT rahul_bugs.bugid,rahul_bugs.bugdes,rahul_bugs.bugtypeid,"
					+ "rahul_bugs.assigneename,rahul_bugs.repoteename,"
					+ "rahul_bugs_type.bugtypename FROM rahul_bugs,rahul_bugs_type,"
					+ "rahul_bugs_status where rahul_bugs.bugtypeid=rahul_bugs_type.BUGTYPEID "
					+ "and rahul_bugs.bugstatusid=rahul_bugs_status.bugstatusid and rahul_bugs.bugstatusid=?");
			stmt.setInt(1, bugStatusId);

			rs = stmt.executeQuery();
			while (rs.next())
			{
				status++;
				int bugId = rs.getInt("bugid");
				String bugDesc = rs.getString("bugdes");
				int bugTypeId = rs.getInt("bugtypeid");
				//int bugStatusId = rs.getInt("bugstatusid");
				String assignee = rs.getString("assigneename");
				String reporte = rs.getString("repoteename");
				String bugTypeName = rs.getString("bugtypename");
				//String bugStatusName = rs.getString("bugstatusname");

				BugType bugType = new BugType(bugTypeId, bugTypeName);
				BugStatus bugStatus = new BugStatus(bugStatusId, bugStatusName);
				bug = new Bugs(bugId, bugDesc, bugType, bugStatus, assignee, reporte);
				bugListByStatus.add(bug);
			}
			if (status == 0)
			{
				throw new BugNotFoundException("Bug not found with the particular bugId");
			}

		}
		catch (Exception e)
		{
			e.printStackTrace();
			/*throw new BugNotFoundException("Bug not found with the particular Status");*/
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}

			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bugListByStatus;

	}

	//insert the bug into the database
	public void fileBug(String bugDesc, String bugType, String bugStatus, String assignee, String reportee)
			throws RecordNotInserted
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int bugStatusId = 0;
		int bugTypeId = 0;
		try
		{
			bugStatusId = getBugStatusId(bugStatus);
			bugTypeId = getBugTypeId(bugType);
		}
		catch (InvalidStatusName | InvalidTypeName e)
		{
			e.printStackTrace();
		}

		try
		{

			stmt = connection.prepareStatement("insert into RAHUL_BUGS values(?,?,?,?,?,?)");
			stmt.setInt(1, getMaxBugId());
			stmt.setString(2, bugDesc);
			stmt.setInt(3, bugTypeId);
			stmt.setInt(4, bugStatusId);
			stmt.setString(5, assignee);
			stmt.setString(6, reportee);
			rs = stmt.executeQuery();

		}
		catch (SQLException e)
		{
			throw new RecordNotInserted("Bug not entered into the database");
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}

			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	//get the bug id from the bug name 
	public int getBugTypeId(String bugtypename) throws InvalidTypeName
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int bugTypeId = 0;
		int status = 0;
		try
		{
			stmt = connection.prepareStatement("select bugtypeid from rahul_bugs_type where bugtypename=?");
			stmt.setString(1, bugtypename);

			rs = stmt.executeQuery();
			while (rs.next())
			{
				status++;
				bugTypeId = rs.getInt("bugtypeid");
			}
			if (status == 0)
			{
				throw new InvalidTypeName("No Type Id is Associated with this name");
			}

		}
		catch (Exception e)
		{
			throw new InvalidTypeName("No Type Id is Associated with this name");
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}

			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bugTypeId;

	}

	//get Status id by the status name
	public int getBugStatusId(String bugStatusName) throws InvalidStatusName
	{
		PreparedStatement stmt = null;
		ResultSet rs = null;
		int bugStatusId = 0;
		int status = 0;
		try
		{
			stmt = connection.prepareStatement("select bugstatusid from rahul_bugs_status where bugstatusname=?");
			stmt.setString(1, bugStatusName);

			rs = stmt.executeQuery();
			while (rs.next())
			{
				status++;
				bugStatusId = rs.getInt("bugstatusid");
			}
			if (status == 0)
			{
				throw new InvalidStatusName("No Status Id is Associated with this status");
			}

		}
		catch (Exception e)
		{
			throw new InvalidStatusName("No Status Id is Associated with this status");
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}

			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return bugStatusId;

	}

	public int getMaxBugId()
	{

		Statement stmt = null;
		ResultSet rs = null;
		String qry = "select max(bugid) as NEXT_BUGID from RAHUL_BUGS";
		try
		{
			stmt = connection.createStatement();
			rs = stmt.executeQuery(qry);
			if (rs.next())
			{
				int nextEmpNo = rs.getInt("NEXT_BUGID");
				return (nextEmpNo + 1);
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}
			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 1;

	}

	public ArrayList<BugStatus> getAllBugStatus()
	{
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<BugStatus> allBugStatus = new ArrayList<BugStatus>();

		try
		{
			stmt = connection.createStatement();

			rs = stmt.executeQuery("SELECT * from RAHUL_BUGS_STATUS");

			while (rs.next())
			{

				int bugStatusId = rs.getInt("bugstatusid");
				String bugStatusName = rs.getString("bugstatusname");

				BugStatus bugStatus = new BugStatus(bugStatusId, bugStatusName);
				allBugStatus.add(bugStatus);

			}

		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}

			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return allBugStatus;
	}

	//for geting all bug type
	public ArrayList<BugType> getAllBugType()
	{
		Statement stmt = null;
		ResultSet rs = null;
		ArrayList<BugType> allBugType = new ArrayList<BugType>();

		try
		{
			stmt = connection.createStatement();

			rs = stmt.executeQuery("SELECT * from RAHUL_BUGS_TYPE");

			while (rs.next())
			{

				int bugTypeId = rs.getInt("bugtypeid");
				String bugTypeName = rs.getString("bugtypename");

				BugType bugType = new BugType(bugTypeId, bugTypeName);
				allBugType.add(bugType);

			}

		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				if (rs != null)
				{
					rs.close();
					rs = null;
				}
				if (stmt != null)
				{
					stmt.close();
					stmt = null;
				}

			}
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return allBugType;
	}

	@Override
	public void close() throws SQLException
	{
		if (connection != null)
		{
			System.out.println("connection closed");
			connection.close();
			connection = null;

		}
	}

	@Override
	protected void finalize() throws Throwable
	{
		close();
		super.finalize();
	}

	public static void main(String[] args)
	{
		BugDao dao = new BugDao();
		/*ArrayList<Bugs> bugList = dao.getAllBug();
		for (Bugs bug : bugList)
		{
			System.out.println(bug);
		}*/
		/*ArrayList<Bugs> bugList;
		try
		{
			bugList = dao.getBugByAssignee("aaa");
			for (Bugs bug : bugList)
			{
				System.out.println(bug);
			}
		}
		catch (BugNotFoundException e)
		{
			System.out.println("No bugs for this user");
		}*/

		/*int id;
		try
		{
			id = dao.getBugStatusId("New");
			System.out.println(id);
		}
		catch (InvalidStatusName e)
		{
			System.out.println("no ");
		}*/

		/*ArrayList<Bugs> bugList;
		try
		{
			bugList = dao.getBugByStatus("New");
			for (Bugs bug : bugList)
			{
				System.out.println(bug);
			}
		}
		catch (InvalidStatusName e)
		{
			System.out.println("Invalid Status");
		}
		catch (BugNotFoundException e)
		{
			System.out.println("bug not found");
		}*/
		/*int a = dao.getMaxBugId();
		System.out.println(a);*/
		/*try
		{
			dao.fileBug("Installization problem", "Major", "New", "rahul", "aaa");
		}
		catch (RecordNotInserted e)
		{
			e.printStackTrace();
		}*/
		ArrayList<BugType> bugList = dao.getAllBugType();
		for (BugType bug : bugList)
		{
			System.out.println(bug);
		}
	}
}
