package com.mahendra.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mahendra.dao.BookDAO;
import com.mahendra.dao.MemberDAO;
import com.mahendra.services.LibraryService;

public class AppMain {

	public static void main(String[] args) {	
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		LibraryService service = context.getBean("libraryService",LibraryService.class);
		
		service.doSomething();
	}

}
