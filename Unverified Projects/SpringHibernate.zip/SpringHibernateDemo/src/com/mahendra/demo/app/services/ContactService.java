package com.mahendra.demo.app.services;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mahendra.demo.app.daos.ContactDAO;
import com.mahendra.demo.app.models.Contact;

@Service
public class ContactService {

	@Autowired private ContactDAO dao;
	
	@Transactional(propagation=Propagation.REQUIRED)
	public void createContact(Contact contact)
	{
		Serializable id= dao.save(contact);		
	}
	
	//DO NOT USE TRANSACTIONS, throws exceptions when called from transaction
	@Transactional(propagation=Propagation.NEVER)
	public List<Contact> getAllContacts(){
		return dao.getAll();
	}
	
}
