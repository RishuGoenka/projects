package com.mahendra.demo.app.daos;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.mahendra.demo.app.models.Contact;

@Repository
public class ContactDAO {

	/*
	 * I. Inject SessionFactory directly
	 * 
	 * @Autowired private SessionFactory factory;
	 */

	// II. Inject HibernateTemplate
	@Autowired
	private HibernateTemplate template;

	public Serializable save(Contact contact) {
		return template.save(contact);
	}

	public List<Contact> getAll() {
		return template.find("from Contact c");
	}

	public List<Contact> getByName(String name) {
		return template.find(
				"from Contact c where c.firstName=? or c.lastName=?", name,
				name);
	}

	public Contact findById(Integer id) {
		return template.get(Contact.class, id);
	}

}
