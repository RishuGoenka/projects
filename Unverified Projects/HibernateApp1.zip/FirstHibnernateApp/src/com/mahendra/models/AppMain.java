package com.mahendra.models;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import com.mahendra.util.HibernateUtil;

public class AppMain {

	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getFactory();
		
		//Obtain one session 
		Session session = factory.openSession();
		//Transient object
		Contact c = new Contact(110,"Barak","Obama","23465156");
		Transaction tn =null;
		try{
			tn = session.beginTransaction();
			session.save(c); //Persisted
			System.out.println("Changing name");
			c.setFirstName("Michelle");			
			System.out.println("After name change");
			tn.commit();
			System.out.println("Record saved");
			c.setLastName("Shinde"); //detached
		}catch(HibernateException ex){
			if(tn!=null){
				tn.rollback();
			}
			System.out.println("Unable to save record "+ex.getMessage());
		}
		//end of session All resources [sql-connection & primary cache]
		//closed
		session.close();
		//detached object
		
	}

}
