package com.mahendra.util;

import org.hibernate.*;

import com.mahendra.models.Contact;

public class AppMain2 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getFactory();
		
		Session session = factory.openSession();
		//READ operation doesn't need transaction
		Contact c = (Contact) session.get(Contact.class,101);
		System.out.println("Contact details "+c.getFirstName()
					+" "+c.getLastName());
		
		System.out.println(c.getClass().getName());
		session.close();

	}

}
