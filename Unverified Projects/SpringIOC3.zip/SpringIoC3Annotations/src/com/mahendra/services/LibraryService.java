package com.mahendra.services;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.mahendra.dao.BookDAO;
import com.mahendra.dao.MemberDAO;

@Service
@Qualifier("libraryService")
public class LibraryService {
	private static Logger log = Logger.getLogger(LibraryService.class
			.getCanonicalName());

	@Autowired
	private BookDAO bookDao;
	
	@Autowired
	private MemberDAO memberDao;

	public LibraryService() {
	}

	// An example of Dependency injection by setter
	// Also called by SETTER INJECTION
	public void setBookDao(BookDAO dao) {
		this.bookDao = dao;
	}

	public void setMemberDao(MemberDAO memberDao) {
		this.memberDao = memberDao;
	}

	public void doSomething() {
		log.info("Calling required methods ");
		bookDao.someMethod();
		memberDao.someMethod();
	}
}
