package com.rish.app;

//import org.hibernate.HibernateException;
//import org.hibernate.Session;
import org.hibernate.SessionFactory;
//import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

//import com.rish.models.Contact;

public class HibernateUtil {
	private static SessionFactory factory = build();

	private static SessionFactory build() {
		// public static void main(String[] args) {
		// create instance of configuration
		Configuration config = new Configuration().configure();
		// Call "config" method to read default "hibernate.properties"
		// or hibernate.cfg.xml file
		// Incase using non-standard name like "rish.properties"
		// You should call it " config.configure("rish.properties");
		// config.configure();

		// load "hibernate mappings" file
		// config.addResource("mappings.xml");

		// obtain session factory
		SessionFactory factory = config.buildSessionFactory();
		//
		// //Session session = factory.openSession();
		// Transaction t = session.getTransaction();
		// try {
		// t.begin();
		// session.save(new Contact((short) 102, "varun", "Dhav", "987654321"));
		// t.commit();
		// System.out.println("Record Saved");
		// } catch (HibernateException ex) {
		// if (t != null)
		// t.rollback();
		// ex.printStackTrace();
		// }

		return factory;
	}

	// session.close();
	public static SessionFactory getFactory() {
		return factory;
	}
}
