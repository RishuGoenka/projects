package com.mahendra.services;

import java.util.logging.Logger;

import com.mahendra.dao.BookDAO;
import com.mahendra.dao.MemberDAO;

public class LibraryService {
private static Logger log = Logger.getLogger(LibraryService.class.getCanonicalName());
	
	public void doSomething(){
		// this service class need to call methods on DAO classes
		// And those methods are 'instance' method [ non-static]
		// So need to created instances first
		log.info("Creating instances of dependencies");
		BookDAO dao1 = new BookDAO();
		MemberDAO dao2 = new MemberDAO();
		log.info("Calling required methods ");
		dao1.someMethod();
		dao2.someMethod();
	}
}
