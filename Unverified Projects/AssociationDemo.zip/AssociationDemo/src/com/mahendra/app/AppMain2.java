package com.mahendra.app;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mahendra.models.Department;
import com.mahendra.models.Employee;

public class AppMain2 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getFactory();
		Session session = factory.openSession();
		Department d = (Department) session.get(Department.class, 20);
		System.out.println("Name of department:" +d.getName());
		/*System.out.println("Contains "+d.getEmployees().size()+" employees");
		for(Employee e: d.getEmployees()){
			
			System.out.println(e.getName()+" "+e.getJob());
		}*/
		session.close();
	}

}
