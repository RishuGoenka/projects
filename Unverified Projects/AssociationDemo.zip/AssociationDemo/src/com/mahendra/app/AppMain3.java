package com.mahendra.app;

import java.util.HashSet;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mahendra.models.Department;
import com.mahendra.models.Employee;

public class AppMain3 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getFactory();
		Session session = factory.openSession();
		Transaction tn = null;
		Department d = new Department(43, "Development", "MUMBAI");
		Employee e1  = new Employee(9013,"Pancham","Developer",8054,null,null,null,d);
		Employee e2  = new Employee(9014,"Ashish","Developer",8054,null,null,null,d);
		
		HashSet<Employee> emps = new HashSet<Employee>();
		emps.add(e1);
		emps.add(e2);
		d.setEmployees(emps);
			
		try{
			tn = session.beginTransaction();
			session.save(d);
			tn.commit();
			System.out.println("Saved all!!!!");
		}catch(HibernateException ex){
			if(tn!=null)
				tn.rollback();
			ex.printStackTrace();
		}
		
		session.close();
	}

}
