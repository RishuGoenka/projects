package com.mahendra.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.mahendra.dao.ProductDAO;
import com.mahendra.models.Product;

public class ListProductController extends AbstractController {

	private ProductDAO dao;
	
	public void setDao(ProductDAO dao) {
		this.dao = dao;
	}

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0,
			HttpServletResponse arg1) throws Exception {
		List<Product> products = dao.getAllProducts();
		ModelAndView mv = new ModelAndView("/WEB-INF/views/page.jsp");
		mv.addObject("productList", products);
		return mv;
	}

}
