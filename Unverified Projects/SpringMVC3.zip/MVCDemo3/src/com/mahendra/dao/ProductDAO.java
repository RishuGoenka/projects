package com.mahendra.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.mahendra.models.Product;

public class ProductDAO {

		private JdbcTemplate template;
		
		public void init(){
			template.execute("create table products (productid int primary key, pname varchar(20), pdesc varchar(50), price double)");
			template.execute("insert into products values(101,'Product X','Mysterious product with unknown substances',2500)");
			template.execute("insert into products values(102,'Product Y','Mysterious product with unknown qualities',1500)");
			
		}
		
		public List<Product> getAllProducts(){
			List<Product> products = null;
			products = template.query("select * from products",new MyRowMapper());	
			return products;
		}

		public JdbcTemplate getTemplate() {
			return template;
		}


		public void setTemplate(JdbcTemplate template) {
			this.template = template;
		}
		
		static class MyRowMapper implements RowMapper<Product>{

			@Override
			public Product mapRow(ResultSet arg0, int arg1) throws SQLException {
				Product p = new Product();
				p.setProductId(arg0.getInt("productid"));
				p.setName(arg0.getString("pname"));
				p.setDescription(arg0.getString("pdesc"));
				p.setPrice(arg0.getDouble("price"));
				return p;
			}
			
		}
}
