
public class Digit {

	public static int superDigit(int n,int k) {
		int digit=n,check=0;
		while(digit!=0){
			check=digit%10+check;
			digit=digit/10;
		}
		check = check*k;
		String length = Integer.toString(check);
		while(length.length()!=1){
		for(int i = 0; i < length.length(); i++){
			digit=check%10+digit;
			check=check/10;}
		check=digit;
		digit=0;
		length =Integer.toString(check);
		}
		return check;

	}

}
