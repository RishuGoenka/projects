package com.zycus.dao;

import java.util.List;

import com.zycus.model.ResultEntity;

public interface ResultDAO {

	public abstract List<ResultEntity> getById(int submissionId);

	public abstract void saveResult(ResultEntity result);

	public abstract void deleteResult(ResultEntity result);

}