public class CalculatorMain {
	public static void main(String args[]) {
		Calculator calculate = new Calculator();
		int resultValue = calculate.divide(15, 0);
		System.out.println(resultValue);
	}
}
