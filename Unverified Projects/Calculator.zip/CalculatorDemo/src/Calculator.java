public class Calculator {
	public int divide(int numerator, int denominator) {
		System.out.println("Number is Divide and answered : ");
		try {
			return numerator / denominator;
		} catch (ArithmeticException ex) {
			System.out.println("Error");
			return 0;
		}
	}
}
