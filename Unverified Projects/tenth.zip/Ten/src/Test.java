import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Test {
	public static void main(String[] args) {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		String stringA = null, stringB = null, stringC = null;
		try {
			System.out.println("Enter First Array");
			stringA = read.readLine();
			System.out.println("Enter Second Array");
			stringB = read.readLine();
			System.out.println("Enter Third Array");
			stringC = read.readLine();
		} catch (IOException e) {
			System.out.println("Invalid Input");
		}
		String dummy = stringA + stringB + stringC;
		if (Pattern.matches("[\\d\\s]+", dummy)) {
			separate(stringA , stringB , stringC);
		}else
			System.out.println("Invalid input");
	}

	private static void separate(String stringA, String stringB, String stringC) {
		String[] stringArrayA = stringA.trim().split(" ");
		String[] stringArrayB = stringB.trim().split(" ");
		String[] stringArrayC = stringC.trim().split(" ");
		int stringArrayALength = stringArrayA.length;
		int stringArrayBLength = stringArrayB.length;
		int stringArrayCLength = stringArrayC.length;
		int[] arrayA = new int[stringArrayALength];
		int[] arrayB = new int[stringArrayBLength];
		int[] arrayC = new int[stringArrayCLength];
		try{
			for(int i = 0; i<stringArrayALength;i++)
			arrayA[i] = Integer.parseInt(stringArrayA[i]);
		for(int i = 0; i<stringArrayBLength;i++)
			arrayB[i] = Integer.parseInt(stringArrayB[i]);
		for(int i = 0; i<stringArrayCLength;i++)
			arrayC[i] = Integer.parseInt(stringArrayC[i]);
		}catch( ArrayIndexOutOfBoundsException | IllegalArgumentException e){
			System.out.println("Enter Valid Input");
		}
		InsertionSort.sort(arrayA,arrayB,arrayC,stringArrayALength,stringArrayBLength,stringArrayCLength);
	}
}