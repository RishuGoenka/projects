import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		ClosestElements close = new ClosestElements();
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter first Array length");
		int n = scn.nextInt();
		System.out.println("Enter second Array length");
		int m = scn.nextInt();
		System.out.println("Enter third Array length");
		int l = scn.nextInt();
		int x[] = new int[n];
		int y[] = new int[m];
		int z[] = new int[l];
		System.out.println("Enter first Array");
		for (int i = 0; i < n; i++)
			x[i] = scn.nextInt();
		System.out.println("Enter second Array");
		for (int i = 0; i < m; i++)
			y[i] = scn.nextInt();
		System.out.println("Enter third Array");
		for (int i = 0; i < l; i++)
			z[i] = scn.nextInt();
		scn.close();
		close.find(x, y, z);

	}

}
