package com.tushar.Service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.tushar.controller.LoginController;
import com.tushar.daos.MultiplexDAO;
import com.tushar.daos.SeatsDAO;
import com.tushar.daos.TheatreDAO;
import com.tushar.models.Multiplex;
import com.tushar.models.Seats;
import com.tushar.models.Theatre;

public class SeatService {

	final static Logger logger = Logger.getLogger(LoginController.class);
	private SeatsDAO seatsDAO;
	private TheatreDAO theatreDAO;
	private MultiplexDAO multiplexDAO;
	private PlatformTransactionManager txManager;

	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public void setMultiplexDAO(MultiplexDAO multiplexDAO) {
		this.multiplexDAO = multiplexDAO;
	}

	public void setTheatreDAO(TheatreDAO theatreDAO) {
		this.theatreDAO = theatreDAO;
	}

	public void setSeatsDAO(SeatsDAO seatsDAO) {
		this.seatsDAO = seatsDAO;
	}

	public Seats saveWhenEmpty() {
		Theatre theatre = new Theatre();
		Seats seats = new Seats(null, theatre);
		return seats;
	}

	public List<Theatre> forDropDown() {
		return theatreDAO.getAll();
	}

	public Integer add(Seats seat) {

		if (seatsDAO.findByTheatre(seat.getTheatre()).size() == 0) {
			Integer id = null;
			TransactionDefinition def = new DefaultTransactionDefinition();
			TransactionStatus status = txManager.getTransaction(def);
			try {
				id = (Integer) seatsDAO.save(seat);
				txManager.commit(status);
			} catch (DataAccessException e) {
				txManager.rollback(status);
			}
			return id;
		}
		return 0;
	}

	public Theatre findTheatreByName(String name, String multiplexName) {
		Multiplex multiplex = multiplexDAO.findByName(multiplexName).get(0);
		return theatreDAO.getByMultiplexAndTheatreName(multiplex, name).get(0);
	}

	public List<Multiplex> getAllMultiplex() {
		return multiplexDAO.getAll();
	}

	public List<Theatre> getTheatreByMultiplex(String multiplexName) {

		System.out.println(multiplexName);

		Multiplex multiplex = multiplexDAO.findByName(multiplexName).get(0);
		List<Theatre> theatres = theatreDAO.getByMultiplex(multiplex);
		return theatres;
	}

}
