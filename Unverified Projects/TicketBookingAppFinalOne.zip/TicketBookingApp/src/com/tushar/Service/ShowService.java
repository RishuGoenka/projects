package com.tushar.Service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.tushar.controller.LoginController;
import com.tushar.daos.ColumnDAO;
import com.tushar.daos.MovieDAO;
import com.tushar.daos.MultiplexDAO;
import com.tushar.daos.SeatsDAO;
import com.tushar.daos.ShowDAO;
import com.tushar.daos.TheatreDAO;
import com.tushar.models.Column;
import com.tushar.models.Movie;
import com.tushar.models.Multiplex;
import com.tushar.models.Seats;
import com.tushar.models.Shows;
import com.tushar.models.Theatre;

public class ShowService {

	final static Logger logger = Logger.getLogger(LoginController.class);
	private ShowDAO showDAO;
	private MovieDAO movieDAO;
	private TheatreDAO theatreDAO;
	private SeatsDAO seatDAO;
	private ColumnDAO columnDAO;
	private MultiplexDAO multiplexDAO;
	private PlatformTransactionManager txManager;

	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public void setMultiplexDAO(MultiplexDAO multiplexDAO) {
		this.multiplexDAO = multiplexDAO;
	}

	public void setColumnDAO(ColumnDAO columnDAO) {
		this.columnDAO = columnDAO;
	}

	public void setSeatDAO(SeatsDAO seatDAO) {
		this.seatDAO = seatDAO;
	}

	public void setTheatreDAO(TheatreDAO theatreDAO) {
		this.theatreDAO = theatreDAO;
	}

	public void setMovieDAO(MovieDAO movieDAO) {
		this.movieDAO = movieDAO;
	}

	public void setShowDAO(ShowDAO showDAO) {
		this.showDAO = showDAO;
	}

	public Integer add(Shows show) {
		Integer showId = null;
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);
		try {
			showId = (Integer) showDAO.save(show);
			txManager.commit(status);
		} catch (DataAccessException e) {
			txManager.rollback(status);
		}

		return showId;
	}

	public List<Movie> getMovie() {
		List<Movie> movies = movieDAO.getAll();
		return movies;
	}

	public Shows saveWhenEmpty() {
		Theatre theatre = new Theatre();
		Movie movie = new Movie(null, theatre, null);
		Shows show = new Shows(null, null, movie, null, null, null, null);
		return show;
	}

	public Movie findMovieByTheater(String theatreName, String movieName,
			String multiplexName) {

		Theatre theatre = new Theatre();
		Multiplex multiplex = new Multiplex();
		List<Movie> movies = new ArrayList<Movie>();
		try {
			multiplex = multiplexDAO.findByName(multiplexName).get(0);
			theatre = theatreDAO.getByMultiplexAndTheatreName(multiplex,
					theatreName).get(0);
			movies = movieDAO.getByTheatreIdAndMovieName(theatre, movieName);
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
		Movie movie = movies.get(0);
		return movie;
	}

	public List<Theatre> getTheatre() {
		List<Theatre> theatres = theatreDAO.getAll();
		return theatres;
	}

	public List<Movie> getTheatreByName(String name, String multiplexName) {
		Multiplex multiplex = multiplexDAO.findByName(multiplexName).get(0);
		Theatre theatre = theatreDAO.getByMultiplexAndTheatreName(multiplex,
				name).get(0);
		System.out.println("In get TheatreName " + theatre.getTheatreID());
		List<Movie> movies = movieDAO.getByTheatreId(theatre);
		return movies;
	}

	public List<Shows> getAllShows(String movieName) {

		Movie movie = movieDAO.findByName(movieName).get(0);
		List<Shows> shows = showDAO.getAllByMovieId(movie);
		return shows;
	}

	public String deleteShow(String showId) {
		Integer id = Integer.parseInt(showId);
		Shows show = showDAO.findById(id);
		List<Column> columns = columnDAO.findByShow(show);
		for (Column column : columns) {
			columnDAO.delete(column);
		}
		showDAO.delete(id);
		return "Show has been successfully Deleted";
	}

	public Seats getSeat(String theatreName) {
		Theatre theatre = theatreDAO.findByName(theatreName).get(0);

		System.out.println("in getSeat of ShowService : " + theatre.toString());
		Seats seat = seatDAO.findByTheatre(theatre).get(0);
		return seat;
	}

	public List<Shows> getByTheatreNameAndMovieName(String theatreName,
			String movieNameString, String multiplexName) {
		Multiplex multiplex = multiplexDAO.findByName(multiplexName).get(0);
		Theatre theatre = theatreDAO.getByMultiplexAndTheatreName(multiplex,
				theatreName).get(0);

		logger.info("In getByTheatreNameAndMovieName of showService theatreName = "
				+ theatre.getTheatreName());
		logger.info("In getByTheatreNameAndMovieName of showService movieName = "
				+ movieNameString);

		Movie movie = movieDAO.getByTheatreIdAndMovieName(theatre,
				movieNameString).get(0);
		logger.info("and the movie name is " + movie.getMovieName()
				+ " and movie id is " + movie.getMovieId());

		List<Shows> shows = showDAO.getAllByMovieId(movie);
		return shows;
	}

	public String addEndTime(String startTime, String endTimeString,
			String movieDuration) throws ParseException {

		String[] startTimeInHoursAndMinutes = startTime.split(":");
		int startTimeHour = Integer.parseInt(startTimeInHoursAndMinutes[0]
				.trim());
		int startTimeMinutes = Integer.parseInt(startTimeInHoursAndMinutes[1]
				.trim());

		String[] durationInHoursAndMinutes = movieDuration.split(":");
		int durationHour = Integer
				.parseInt(durationInHoursAndMinutes[0].trim());
		int durationMinutes = Integer.parseInt(durationInHoursAndMinutes[1]
				.trim());

		int endTimeHours = startTimeHour + durationHour;
		int endTimeMinutes = startTimeMinutes + durationMinutes;

		if (endTimeMinutes >= 60) {
			endTimeHours++;
			endTimeMinutes = endTimeMinutes % 60;
		}

		String endTime = endTimeHours + ":" + endTimeMinutes;

		return endTime;

		/*
		 * String startTimeActual = startTime+":00";
		 * 
		 * 
		 * String movieDuartionActual = movieDuration+":00";
		 * 
		 * 
		 * SimpleDateFormat localDateFormat = new SimpleDateFormat("hh:mm:ss");
		 * 
		 * 
		 * SimpleDateFormat simpledf = new SimpleDateFormat("HH:mm:ss"); Date d1
		 * = simpledf.parse(startTimeActual);
		 * 
		 * System.out.println("Actual Start Time "+d1.toString());
		 * 
		 * Date d2 = simpledf.parse(movieDuartionActual);
		 * 
		 * System.out.println("Duration  "+d2.toString());
		 * 
		 * 
		 * 
		 * Long sumtime = d1.getTime()+3*60*60*1000; Date d3 = new
		 * Date(sumtime); String timeStringNew = localDateFormat.format(d3);
		 * System.out.println("In Show Service and the time is "+timeStringNew);
		 * return timeStringNew;
		 */

	}

	public String compareTimimgs(Movie movie, String startTime, String endTime)
			throws ParseException {
		SimpleDateFormat simpledf = new SimpleDateFormat("HH:mm");
		Date startTimeDate = simpledf.parse(startTime);
		Timestamp newStartTime = new Timestamp(startTimeDate.getTime());

		logger.info("Checking myTime : " + newStartTime.toString());

		List<Shows> shows = showDAO.getAllByMovieId(movie);
		for (Shows show : shows) {
			Date prevStartTimeDate = simpledf.parse(show.getStartTime());
			Date prevEndTimeDate = simpledf.parse(show.getEndTime());

			Timestamp timeStampStart = new Timestamp(
					prevStartTimeDate.getTime());
			Timestamp timeStampEnd = new Timestamp(prevEndTimeDate.getTime());

			logger.info("Checking startTime " + timeStampStart.toString());
			logger.info("Checking endtime : " + timeStampEnd.toString());

			logger.info("Comparing my time and then displaying it : "
					+ timeStampStart.after(newStartTime));
			logger.info("Comparing endtimes : "
					+ timeStampEnd.before(newStartTime));

			if (!(timeStampStart.after(newStartTime))
					&& !(timeStampEnd.before(newStartTime))) {
				logger.info("In show : ");
				return "Show already exist..";
			}
		}
		return null;
	}

	public List<Multiplex> getAllMultiplex() {
		List<Multiplex> multiplexes = new ArrayList<Multiplex>();
		multiplexes = multiplexDAO.getAll();
		List<Multiplex> uniqueMultiplexes = new ArrayList<Multiplex>();
		List<Theatre> theatres = theatreDAO.getAll();
		List<Movie> movies = movieDAO.getAll();
		boolean flag = false;
		for (Multiplex multiplex : multiplexes) {
			flag = false;
			for (Theatre theatre : theatres) {
				if (multiplex.getMultiplexId() == theatre.getMultiplex()
						.getMultiplexId()) {
					for (Movie movie : movies) {
						if (theatre.getTheatreID() == movie.getTheatre()
								.getTheatreID()) {
							flag = true;
						}
					}
				}
			}
			if (flag == true) {
				uniqueMultiplexes.add(multiplex);
			}
		}

		return uniqueMultiplexes;
	}

	public List<Theatre> getTheatreByMultiplex(String multiplexName) {
		Multiplex multiplex = multiplexDAO.findByName(multiplexName).get(0);
		List<Theatre> theatres = theatreDAO.getByMultiplex(multiplex);
		return theatres;
	}

}
