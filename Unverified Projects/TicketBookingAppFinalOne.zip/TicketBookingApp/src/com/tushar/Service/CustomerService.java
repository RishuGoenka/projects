package com.tushar.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.tushar.controller.LoginController;
import com.tushar.daos.ColumnDAO;
import com.tushar.daos.CustomerDAO;
import com.tushar.daos.MovieDAO;
import com.tushar.daos.MultiplexDAO;
import com.tushar.daos.RowDAO;
import com.tushar.daos.SeatsDAO;
import com.tushar.daos.ShowDAO;
import com.tushar.daos.TheatreDAO;
import com.tushar.daos.TicketDAO;
import com.tushar.models.Column;
import com.tushar.models.Customer;
import com.tushar.models.Movie;
import com.tushar.models.Multiplex;
import com.tushar.models.Row;
import com.tushar.models.Seats;
import com.tushar.models.Shows;
import com.tushar.models.Theatre;
import com.tushar.models.Ticket;

public class CustomerService {

	final static Logger logger = Logger.getLogger(LoginController.class);
	private CustomerDAO customerDAO;
	private MovieDAO movieDAO;
	private TheatreDAO theatreDAO;
	private ShowDAO showDAO;
	private SeatsDAO seatsDAO;
	private RowDAO rowDAO;
	private ColumnDAO columnDAO;
	private TicketDAO ticketDAO;
	private MultiplexDAO multiplexDAO;
	private PlatformTransactionManager txManager;

	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public void setMultiplexDAO(MultiplexDAO multiplexDAO) {
		this.multiplexDAO = multiplexDAO;
	}

	public void setTicketDAO(TicketDAO ticketDAO) {
		this.ticketDAO = ticketDAO;
	}

	public void setColumnDAO(ColumnDAO columnDAO) {
		this.columnDAO = columnDAO;
	}

	public void setRowDAO(RowDAO rowDAO) {
		this.rowDAO = rowDAO;
	}

	public void setSeatsDAO(SeatsDAO seatsDAO) {
		this.seatsDAO = seatsDAO;
	}

	public void setTheatreDAO(TheatreDAO theatreDAO) {
		this.theatreDAO = theatreDAO;
	}

	public void setShowDAO(ShowDAO showDAO) {
		this.showDAO = showDAO;
	}

	public void setMovieDAO(MovieDAO movieDAO) {
		this.movieDAO = movieDAO;
	}

	public void setCustomerDAO(CustomerDAO customerDAO) {
		this.customerDAO = customerDAO;
	}

	public Customer loginDisplayForm() {
		Customer customer = new Customer();
		return customer;
	}

	public Customer customerAuthorizationService(Customer customer) {

		Customer customerForAuthorization = new Customer();
		try {
			customerForAuthorization = customerDAO.findByEmailAndPassowrd(
					customer.getCustomerEmail(), customer.getPassword()).get(0);
		} catch (Exception e) {
			return null;
		}

		return customerForAuthorization;

	}

	public Boolean checkPassword(String confirmPassword, String password) {
		if (confirmPassword.equals(password)) {
			return true;
		}
		return false;
	}

	public Integer addCustomer(Customer customer) {
		List<Customer> customers = customerDAO.getAll();
		for (Customer customerCheck : customers) {
			if (customer.getCustomerEmail().equals(
					customerCheck.getCustomerEmail())) {
				return 0;
			}
		}

		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);
		Integer customerId = null;
		try {
			customerId = (Integer) customerDAO.save(customer);
			txManager.commit(status);
		} catch (DataAccessException e) {
			txManager.rollback(status);
		}
		return customerId;
	}

	public Customer getCustomerById(Integer id) {
		return customerDAO.findById(id);
	}

	public List<Movie> displayMovie() {
		List<Movie> movies = movieDAO.getAll();
		List<Movie> uniqueMovies = new ArrayList<Movie>();
		Boolean flag = true;
		for (int i = 0; i < movies.size(); i++) {
			for (Movie uniquemovie : uniqueMovies) {
				if (!(uniquemovie.getMovieName().equals(movies.get(i)
						.getMovieName()))) {
					flag = true;
				} else {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				uniqueMovies.add(movies.get(i));
			}

		}

		Collections.sort(uniqueMovies, Movie.COMPARE_BY_NAME);

		return uniqueMovies;
	}

	public List<Theatre> getAllTheatreByMovieName(String movieName) {
		List<Movie> movies = movieDAO.findByName(movieName);
		List<Theatre> theatres = new ArrayList<Theatre>();
		for (Movie movie : movies) {
			theatres.add(theatreDAO.findById(movie.getTheatre().getTheatreID()));
			System.out.println(movie.getTheatre().getTheatreID());
		}
		return theatres;
	}
	
	/**
	 * 
	 * @param theatres
	 * @param movieName
	 * @return
	 * 			This is for generating the hash map for displaying the hash map related to movies and their corresponding multiplexes..
	 */

	public HashMap<Multiplex, HashMap<Theatre, ArrayList<Shows>>> getAllShowsByTheatreAndMovie(
			List<Theatre> theatres, String movieName) {
		ArrayList<Shows> shows = new ArrayList<Shows>();
		List<Multiplex> multiplexes = getMultiplex(theatres);

		HashMap<Multiplex, HashMap<Theatre, ArrayList<Shows>>> multiplexHashMap = new HashMap<Multiplex, HashMap<Theatre, ArrayList<Shows>>>();

		for (Multiplex multiplex : multiplexes) {
			HashMap<Theatre, ArrayList<Shows>> theaterShowMap = new HashMap<Theatre, ArrayList<Shows>>();
			logger.info("In customerService checking for multiplex name "
					+ multiplex.getMultiplexName());

			for (Theatre theatre : theatres) {

				logger.info("In same "
						+ theatre.getMultiplex().getMultiplexName()
						+ " And Multiplex Name is  "
						+ multiplex.getMultiplexName());

				if (multiplex.getMultiplexName().equals(
						theatre.getMultiplex().getMultiplexName())) {
					Movie movie = movieDAO.getByTheatreIdAndMovieName(theatre,
							movieName).get(0);
					shows = showDAO.getAllByMovieId(movie);
					theaterShowMap.put(theatre, shows);
				}
			}
			multiplexHashMap.put(multiplex, theaterShowMap);
		}
		return multiplexHashMap;
	}

	public List<Column> getColumnFromShowAndTypeOfRow(String showIdString,
			String typeOfRow) {
		Integer seatId = Integer.parseInt(showIdString);
		Shows show = showDAO.findById(seatId);
		Seats seat = seatsDAO.findById(show.getSeats().getSeatsId());
		Row row = rowDAO.findBySeatAndTypeOfRow(seat, typeOfRow).get(0);

		logger.info("In customerService of getting columns "
				+ row.getTypeOfRow() + row.getRowId());
		logger.info("In customerService of getting columns " + show.getShowId());

		List<Column> columns = columnDAO.findByRowAndShow(row, show);
		return columns;
	}

	/**
	 * 
	 * @param showIdString
	 * @return 
	 * 	This for getting the type of row silver , gold or platinum so that cost can be calculated based on that.. 
	 */
	public List<Row> getRowTypeFromRow(String showIdString) {
		Integer showId = Integer.parseInt(showIdString);
		Shows show = showDAO.findById(showId);
		Seats seat = seatsDAO.findById(show.getSeats().getSeatsId());
		List<Row> rows = rowDAO.findBySeat(seat);
		return rows;
	}
	
	/**
	 * 
	 * @param showIdString
	 * @return
	 * 			Creating a map of row and column so that it will be easier to display as in which seat number is selected..
	 */
	public LinkedHashMap<Row, List<Column>> getColumnFromRowAndShow(
			String showIdString) {
		Integer showId = Integer.parseInt(showIdString);
		Shows show = showDAO.findById(showId);
		Seats seat = seatsDAO.findById(show.getSeats().getSeatsId());
		List<Row> rows = rowDAO.findBySeat(seat);
		List<Column> columns = new ArrayList<Column>();

		LinkedHashMap<Row, List<Column>> rowColumnMap = new LinkedHashMap<Row, List<Column>>();
		for (Row row : rows) {
			logger.info("In customer service looking for : row Name "
					+ row.getNameOfRow() + " and rowId is " + row.getRowId());
			logger.info("and show id is " + show.getShowId());

			columns = columnDAO.findByRowAndShow(row, show);

			logger.info("Checking the column size " + columns.size());
			rowColumnMap.put(row, columns);
		}

		return rowColumnMap;

	}
	
	/**
	 * 
	 * @param columnIdString
	 * @return
	 * 			this is for calculating the cost of ticket on the basis of type of seat selected by the user...
	 */			
	public Double calculatingCostOfTicket(String columnIdString) {
		Integer columnId = Integer.parseInt(columnIdString);
		Column column = columnDAO.findById(columnId);
		Row row = rowDAO.findById(column.getRow().getRowId());
		Shows show = showDAO.findById(column.getShows().getShowId());

		Double totalAmount = null;

		if (row.getTypeOfRow().equals("Platinum")) {
			totalAmount = show.getCostOfPlatinum();
		} else if (row.getTypeOfRow().equals("Gold")) {
			totalAmount = show.getCostOfGold();
		} else if (row.getTypeOfRow().equals("Silver")) {
			totalAmount = show.getCostOfSilver();
		}
		return totalAmount;
	}
	
	/**
	 * 
	 * @param columnIdString
	 * @return
	 * 			Getting the show id for the and converting it back to string..
	 */

	public String gettingStringShowId(String columnIdString) {

		Integer columnId = Integer.parseInt(columnIdString);
		Column column = columnDAO.findById(columnId);
		Shows show = showDAO.findById(column.getShows().getShowId());
		String showIdString = "" + show.getShowId();
		return showIdString;
	}

	/**
	 * 
	 * @param customerIdString
	 * @param columnIdString
	 * @param totalAmount
	 * @return Synchronization is being done here to handle when two concurrent
	 *         users select same seat..
	 */
	public Integer bookTicket(String customerIdString, String columnIdString,
			Double totalAmount) {
		Customer customer = getCustomerById(Integer.parseInt(customerIdString));
		Column column = columnDAO.findById(Integer.parseInt(columnIdString));

		synchronized (column) {

			if (ticketDAO.findByColumn(column).size() == 0) {
				column.setStatusOfColumn("Booked");
				columnDAO.update(column);
			} else {
				return 0;
			}
		}

		logger.info(customer.getCustomerName());
		logger.info(totalAmount);
		logger.info(column.getColumnNumber());

		Ticket ticket = new Ticket(customer, totalAmount, column);
		Integer ticketId = (Integer) ticketDAO.save(ticket);
		return ticketId;
	}

	public Row getRowById(String rowIdString) {
		Integer rowId = Integer.parseInt(rowIdString);
		return rowDAO.findById(rowId);
	}

	public Column getColumnById(String columnIdString) {
		Integer columnId = Integer.parseInt(columnIdString);
		return columnDAO.findById(columnId);
	}
	
	/**
	 * 
	 * @param theatres
	 * @return
	 * 			Getting the list of single multiplexes with the movie in it..this is done so that no redundant multiplex is added even though 
	 * 			movie can be in different theaters of multiplex..
	 */

	public List<Multiplex> getMultiplex(List<Theatre> theatres) {

		List<Multiplex> multiplexesDuplicate = new ArrayList<Multiplex>();
		List<Multiplex> multiplexes = new ArrayList<Multiplex>();
		Multiplex multiplex = new Multiplex();
		for (Theatre theatre : theatres) {

			logger.info(theatre.getTheatreName());
			logger.info("In customer service "
					+ theatre.getMultiplex().getMultiplexName());
			String multiplexName = theatre.getMultiplex().getMultiplexName();
			multiplex = multiplexDAO.findByName(multiplexName).get(0);
			multiplexesDuplicate.add(multiplex);
		}

		Boolean flag = true;

		for (int i = 0; i < multiplexesDuplicate.size(); i++) {

			for (Multiplex multiplexUnique : multiplexes) {
				if (!(multiplexUnique.getMultiplexName()
						.equals(multiplexesDuplicate.get(i).getMultiplexName()))) {
					flag = true;
				} else {
					flag = false;
					break;
				}
			}
			if (flag == true) {
				multiplexes.add(multiplexesDuplicate.get(i));
			}
		}
		return multiplexes;
	}

	public Movie getMovieByShow(String showIdString) {
		Integer showId = Integer.parseInt(showIdString);
		Shows show = showDAO.findById(showId);
		Movie movie = movieDAO.findById(show.getMovie().getMovieId());
		return movie;
	}

	public Theatre getByMovie(Movie movie) {
		return theatreDAO.findById(movie.getTheatre().getTheatreID());
	}

	public Multiplex getByTheatre(Theatre theatre) {
		return multiplexDAO.findById(theatre.getMultiplex().getMultiplexId());
	}
}
