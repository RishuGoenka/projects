package com.tushar.Service;

import com.tushar.models.Customer;

public class AdminLoginService {
	
	String userName = "zycusadmin";
	String password = "pass@123";
	public String validator(Customer customer){
		System.out.println(customer.getCustomerEmail());
		
		if(!(customer.getCustomerEmail().equals(userName))||(!customer.getPassword().equals(password))){
			
			return "Either username or password is incorrect";
		}
		return customer.getCustomerEmail();
	}
}
