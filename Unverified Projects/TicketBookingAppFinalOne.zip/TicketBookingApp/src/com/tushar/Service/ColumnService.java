package com.tushar.Service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.tushar.controller.LoginController;
import com.tushar.daos.ColumnDAO;
import com.tushar.daos.RowDAO;
import com.tushar.models.Column;
import com.tushar.models.Row;
import com.tushar.models.Seats;
import com.tushar.models.Shows;

public class ColumnService {

	final static Logger logger = Logger.getLogger(LoginController.class);
	private ColumnDAO columnDAO;
	private RowDAO rowDAO;
	private PlatformTransactionManager txManager;

	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public void setRowDAO(RowDAO rowDAO) {
		this.rowDAO = rowDAO;
	}

	public void setColumnDAO(ColumnDAO columnDAO) {
		this.columnDAO = columnDAO;
	}

	public void saveColumn(Seats seat, Shows show) {
		List<Row> rows = rowDAO.findBySeat(seat);
		for (int i = 0; i < rows.size(); i++) {
			Row row = rows.get(i);
			for (int j = 0; j < row.getNumberOfColumns(); j++) {
				Column column = new Column(j + 1, "Available", row, show);
				TransactionDefinition def = new DefaultTransactionDefinition();
				TransactionStatus status = txManager.getTransaction(def);
				try {
					columnDAO.save(column);
					txManager.commit(status);
				} catch (DataAccessException e) {
					txManager.rollback(status);
				}
				
			}
		}
	}

}
