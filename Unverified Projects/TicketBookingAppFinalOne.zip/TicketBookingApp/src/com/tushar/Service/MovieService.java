package com.tushar.Service;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.tushar.controller.LoginController;
import com.tushar.daos.ColumnDAO;
import com.tushar.daos.MovieDAO;
import com.tushar.daos.MultiplexDAO;
import com.tushar.daos.ShowDAO;
import com.tushar.daos.TheatreDAO;
import com.tushar.models.Column;
import com.tushar.models.Movie;
import com.tushar.models.Multiplex;
import com.tushar.models.Shows;
import com.tushar.models.Theatre;

public class MovieService {
	final static Logger logger = Logger.getLogger(LoginController.class);

	private MovieDAO movieDAO;
	private TheatreDAO theatreDAO;
	private ShowDAO showDAO;
	private MultiplexDAO multiplexDAO;
	private ColumnDAO columnDAO;
	private PlatformTransactionManager txManager;

	public void setTxManager(PlatformTransactionManager txManager) {
		this.txManager = txManager;
	}

	public void setColumnDAO(ColumnDAO columnDAO) {
		this.columnDAO = columnDAO;
	}

	public void setMultiplexDAO(MultiplexDAO multiplexDAO) {
		this.multiplexDAO = multiplexDAO;
	}

	public void setShowDAO(ShowDAO showDAO) {
		this.showDAO = showDAO;
	}

	public void setTheatreDAO(TheatreDAO theatreDAO) {
		this.theatreDAO = theatreDAO;
	}

	public void setMovieDAO(MovieDAO movieDAO) {
		this.movieDAO = movieDAO;
	}

	public Movie saveWhenEmpty() {
		Theatre theatre = new Theatre();
		Movie newMovie = new Movie(null, theatre, null);
		return newMovie;

	}

	public Integer addMovie(Movie movie, String multiplexName) {
		List<Theatre> theatres = new ArrayList<Theatre>();
		Multiplex multiplex = multiplexDAO.findByName(multiplexName).get(0);
		logger.info("In addMovie of movie service "
				+ multiplex.getMultiplexName());

		logger.info("checking for theatre name "
				+ movie.getTheatre().getTheatreName());

		theatres = theatreDAO.getByMultiplexAndTheatreName(multiplex, movie
				.getTheatre().getTheatreName());
		Theatre theatre = theatres.get(0);

		Movie newMovie = new Movie(movie.getMovieName(), theatre,
				movie.getDuration());

		Integer movieId = null;
		TransactionDefinition def = new DefaultTransactionDefinition();
		TransactionStatus status = txManager.getTransaction(def);
		try {
			movieId = (Integer) movieDAO.save(newMovie);
			txManager.commit(status);
		} catch (DataAccessException e) {
			txManager.rollback(status);
		}

		return movieId;
	}

	public List<Theatre> forDropDown() {
		return theatreDAO.getAll();
	}

	public List<Movie> getAllMovieInTheatre(String name) {
		Theatre theatre = theatreDAO.findByName(name).get(0);
		return movieDAO.getByTheatreId(theatre);
	}

	public void removeMovie(String movieIdString) {
		Integer movieId = Integer.parseInt(movieIdString);
		Movie movie = movieDAO.findById(movieId);
		List<Shows> shows = showDAO.getAllByMovieId(movie);
		for (Shows show : shows) {
			List<Column> columns = columnDAO.findByShow(show);
			for (Column column : columns) {
				columnDAO.delete(column);
			}
			showDAO.delete(show.getShowId());
		}

		movieDAO.remove(movieId);
	}

	public List<Multiplex> getMultiplex() {
		List<Multiplex> multiplexes = new ArrayList<Multiplex>();
		multiplexes = multiplexDAO.getAll();
		List<Multiplex> uniqueMultiplexes = new ArrayList<Multiplex>();
		List<Theatre> theatres = theatreDAO.getAll();
		boolean flag = false;
		for (Multiplex multiplex : multiplexes) {
			flag = false;
			for (Theatre theatre : theatres) {
				if (multiplex.getMultiplexId() == theatre.getMultiplex()
						.getMultiplexId()) {
					flag = true;
				}
			}
			if (flag == true) {
				uniqueMultiplexes.add(multiplex);
			}
		}

		return uniqueMultiplexes;
	}

	public List<Theatre> getTheatreByMultiplex(String multiplexName) {
		Multiplex multiplex = multiplexDAO.findByName(multiplexName).get(0);
		List<Theatre> theatres = theatreDAO.getByMultiplex(multiplex);
		return theatres;
	}

	public List<Movie> getMovieList(String theatreName, String multiplexName) {
		Multiplex multiplex = multiplexDAO.findByName(multiplexName).get(0);
		Theatre theatre = theatreDAO.getByMultiplexAndTheatreName(multiplex,
				theatreName).get(0);
		return movieDAO.getByTheatreId(theatre);
	}
}
