package com.tushar.models;

import java.io.Serializable;


public class Seats implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer seatsId;
	private Integer numberOfRows;
	private Theatre theatre;


	public Integer getSeatsId() {
		return seatsId;
	}

	public void setSeatsId(Integer seatsId) {
		this.seatsId = seatsId;
	}

	public Integer getNumberOfRows() {
		return numberOfRows;
	}

	public void setNumberOfRows(Integer numberOfRows) {
		this.numberOfRows = numberOfRows;
	}

	public Theatre getTheatre() {
		return theatre;
	}

	public void setTheatre(Theatre theatre) {
		this.theatre = theatre;
	}

	public Seats(Integer numberOfRows, Theatre theatre) {
		super();
		this.numberOfRows = numberOfRows;
		this.theatre = theatre;
	}

	public Seats() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	

}
