package com.tushar.models;

import java.io.Serializable;
import java.util.List;

public class Row implements Serializable {
	
	private Integer RowId;
	private String nameOfRow;
	private String typeOfRow;
	private Integer numberOfColumns;
	private Seats seats;
	private List<Column> columns;
	
	public List<Column> getColumns() {
		return columns;
	}
	public void setColumns(List<Column> columns) {
		this.columns = columns;
	}
	public String getNameOfRow() {
		return nameOfRow;
	}
	public void setNameOfRow(String nameOfRow) {
		this.nameOfRow = nameOfRow;
	}
	public String getTypeOfRow() {
		return typeOfRow;
	}
	public void setTypeOfRow(String typeOfRow) {
		this.typeOfRow = typeOfRow;
	}
	public Integer getNumberOfColumns() {
		return numberOfColumns;
	}
	public void setNumberOfColumns(Integer numberOfColumns) {
		this.numberOfColumns = numberOfColumns;
	}
	public Seats getSeats() {
		return seats;
	}
	public void setSeats(Seats seats) {
		this.seats = seats;
	}
	public Integer getRowId() {
		return RowId;
	}
	public Row( String nameOfRow, String typeOfRow,
			Integer numberOfColumns, Seats seats) {
		super();
		this.nameOfRow = nameOfRow;
		this.typeOfRow = typeOfRow;
		this.numberOfColumns = numberOfColumns;
		this.seats = seats;
	}
	public Row() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

	
	

}
