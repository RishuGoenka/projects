package com.tushar.models;

import java.io.Serializable;
import java.util.List;

public class Theatre implements Serializable{
	private Integer theatreID;
	private String theatreName;
	private Multiplex multiplex;

	public Multiplex getMultiplex() {
		return multiplex;
	}
	public void setMultiplex(Multiplex multiplex) {
		this.multiplex = multiplex;
	}
	public Integer getTheatreID() {
		return theatreID;
	}
	public void setTheatreID(Integer theatreID) {
		this.theatreID = theatreID;
	}
	public String getTheatreName() {
		return theatreName;
	}
	public void setTheatreName(String theatreName) {
		this.theatreName = theatreName;
	}
	public Theatre(String theatreName, Multiplex multiplex) {
		super();
		this.theatreName = theatreName;
		this.multiplex = multiplex;
	}
	public Theatre() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}