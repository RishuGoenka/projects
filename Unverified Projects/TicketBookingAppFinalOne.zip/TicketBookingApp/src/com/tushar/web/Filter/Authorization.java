package com.tushar.web.Filter;

import java.io.IOException;




import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.tushar.controller.LoginController;

/**
 * Servlet Filter implementation class Authorization
 */
public class Authorization implements Filter {

	final static Logger logger = Logger.getLogger(LoginController.class);
    /**
     * Default constructor. 
     */
    public Authorization() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		boolean needsRedirection = false;
		// pass the request along the filter chain
		
		
		String uri = req.getRequestURI();
		logger.info(uri);
		
		if(uri.contains("/customer")){
			if(!(uri.contains("/loginDisplayForm.htm"))){	
				if(!(uri.contains("/customerAuthorization.htm"))){
					if(!(uri.contains("/customerRegisterDisplayForm.htm"))){
						if(!(uri.contains("register"))){
							Integer customerId = (Integer) req.getSession().getAttribute("customerId");
							System.out.println(customerId);
							if(customerId==null){
								needsRedirection = true;
								res.sendRedirect("../login/loginDisplayForm.htm");
							}			
						}
					}
				}
			}
		}
		
		
		if(!(uri.contains("/customer") )&& !(uri.contains("/login"))){
			if(!uri.contains("adminlogin/displayForm.htm")){
				if(!(uri.contains("loginAuthorization.htm"))){
					String adminlogin = (String) req.getSession().getAttribute("adminlogin");
					System.out.println(adminlogin);
					if(adminlogin==null){
						needsRedirection = true;
						res.sendRedirect("../login/loginDisplayForm.htm");
					}
				}
			}
		}
		
		if(!needsRedirection){
			chain.doFilter(request, response);
		}
		

//	chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
