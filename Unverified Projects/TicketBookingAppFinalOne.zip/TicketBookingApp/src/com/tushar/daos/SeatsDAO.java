package com.tushar.daos;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.tushar.models.Seats;
import com.tushar.models.Theatre;

public class SeatsDAO {
	private HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public Serializable save(Seats seat){
		return template.save(seat);
	}
	
	public void update(Seats seat){
		template.save(seat);
	}
	
	public Seats findById(Integer id){
		return template.get(Seats.class, id);
	}
	
	public void delete(Integer id){
		Seats seat = findById(id);
		template.delete(seat);
	}
	
	public List<Seats> findByTheatre(Theatre theatre){
		return  template.find("from Seats s where s.theatre = ?",theatre);
	}

}
