package com.tushar.daos;


import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.tushar.models.Multiplex;
import com.tushar.models.Theatre;

public class TheatreDAO {
	
	private HibernateTemplate template;
	



	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}


	public Serializable save (Theatre theatre){
		return template.save(theatre);
	}
	
	public void update(Theatre theatre){
		template.update(theatre);
	}
	
	public Theatre findById(Integer id){
		return template.get(Theatre.class,id);
	}
	
	
	public void remove(Integer id){
		Theatre theatre = findById(id);
		template.delete(theatre);
	}
	
	public List<Theatre> findByName(String name){
		return template.find("from Theatre t where t.theatreName = ?",name); 
	}
	
	public List<Theatre> getAll(){
		return template.find("from Theatre t");
	}
	
	public List<Theatre> getByMultiplex(Multiplex multiplex){
		return template.find("from Theatre t where t.multiplex = ?",multiplex);
	}
	
	public List<Theatre> getByMultiplexAndTheatreName(Multiplex multiplex , String name){
		return template.find("from Theatre t where t.multiplex = ? and t.theatreName = ?",multiplex,name);
	}

}
