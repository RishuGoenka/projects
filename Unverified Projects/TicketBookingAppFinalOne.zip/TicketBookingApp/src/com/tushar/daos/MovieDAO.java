package com.tushar.daos;

import java.io.Serializable;
import java.util.List;

import org.h2.engine.SysProperties;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.tushar.models.Movie;
import com.tushar.models.Theatre;

public class MovieDAO {
	private HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public Serializable save(Movie movie){
		return template.save(movie);
	}
	
	public void update(Movie movie){
		template.update(movie);
	}
	
	public Movie findById(Integer id){
		return template.get(Movie.class, id);
	}
	
	public List<Movie> findByName(String name){
		return template.find("from Movie m where m.movieName = ?",name);
	}
	
	public void remove(Integer id){
		Movie movie = findById(id);
		template.delete(movie);
	}
	public List<Movie> getAll(){
		return template.find("from Movie");
	}
	
	public List<Movie> getByTheatreId(Theatre theatre){
		return template.find("from Movie m where m.theatre = ?",theatre);
	}
	

	
	
	public List<Movie> getByTheatreIdAndMovieName (Theatre theatre , String name){
		return template.find("from Movie m where m.theatre = ? and m.movieName = ?",theatre,name);
	}
	
}
