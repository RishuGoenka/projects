package com.tushar.daos;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.tushar.models.Column;
import com.tushar.models.Ticket;

public class TicketDAO {
	private HibernateTemplate template;

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public Serializable save(Ticket ticket){
		return template.save(ticket);
	}
	
	public List<Ticket>findByColumn(Column column){
		return template.find("from Ticket t where t.column = ?",column);
	}
}
