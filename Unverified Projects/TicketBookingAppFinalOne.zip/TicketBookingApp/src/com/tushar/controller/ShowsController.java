package com.tushar.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tushar.Service.ColumnService;
import com.tushar.Service.ShowService;
import com.tushar.models.Movie;
import com.tushar.models.Multiplex;
import com.tushar.models.Seats;
import com.tushar.models.Shows;
import com.tushar.models.Theatre;

public class ShowsController extends MultiActionController {

	final static Logger logger = Logger.getLogger(LoginController.class);
	private ShowService showService;
	private ColumnService columnService;

	public void setColumnService(ColumnService columnService) {
		this.columnService = columnService;
	}

	public void setShowService(ShowService showService) {
		this.showService = showService;
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @return This method is for displaying list of Theaters by storing it in
	 *         request and fetching it at jsp page...
	 */

	public ModelAndView displayForm(HttpServletRequest request,
			HttpServletResponse response) {
		ModelAndView mv = new ModelAndView("admin/addShowAjax");
		List<Theatre> theatres = showService.getTheatre();
		// HttpSession session = request.getSession();
		// session.setAttribute("theatres", theatres);

		mv.addObject("theatres", theatres);

		Shows show = showService.saveWhenEmpty();
		mv.addObject("shows", show);
		return mv;
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * 
	 *         Method for displaying a MOVIE page It is firstly generating a
	 *         page which do not contain anything for now
	 * 
	 */

	public ModelAndView displayRemoveForMovie(HttpServletRequest request,
			HttpServletResponse response) {
		Shows show = showService.saveWhenEmpty();
		ModelAndView mv = new ModelAndView("admin/removeShow");
		mv.addObject("shows", show);
		return mv;
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @param show
	 * @return Getting list of all shows of a movie in particular theater...
	 *         Adding that list to Request Object
	 */

	/**
	 * 
	 * @param request
	 * @param response
	 * @param show
	 * @return This method is for removing the show...and displaying the message
	 *         that the show has been deleted...
	 */

	public ModelAndView removeShow(HttpServletRequest request,
			HttpServletResponse response, Shows show) {
		String showId = request.getParameter("showId");
		String message = showService.deleteShow(showId);
		ModelAndView mv = new ModelAndView(
				"redirect:/shows/displayRemoveShowForm.htm");
		mv.addObject("message", message);
		return mv;
	}

	/*
	 * This part is for Adding Show in Admin..
	 */

	// String movieName;

	/**
	 * 
	 * @param request
	 * @param response
	 * @param show
	 * @return this is for getting list of Movies in a particular theater for
	 *         adding the show..getting all the shows through movie name
	 */

	/*
	 * public ModelAndView selectMovieToAddShow(HttpServletRequest request,
	 * HttpServletResponse response, Shows show) { //movieName =
	 * show.getMovie().getMovieName(); List<Shows> shows =
	 * showService.getAllShows(show.getMovie() .getMovieName());
	 * 
	 * ModelAndView mv = new ModelAndView("redirect:/shows/displayForm.htm");
	 * mv.addObject("showsList",shows); HttpSession session =
	 * request.getSession(); session.setAttribute("showsList", shows);
	 * 
	 * return mv;
	 * 
	 * }
	 */

	/**
	 * Saving the entered show to the table.. To save a particular show you need
	 * to have seat..and seat is directly related to theater so you need to find
	 * seat id as well. And just when you save show you need to update your
	 * columns table so that you can have list of all available seats..
	 */

	/**
	 * For Ajax Only...................
	 */

	public void selectMovieToAddShowAjax(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String movieName = request.getParameter("movieName");
		List<Shows> shows = showService.getAllShows(movieName);
		for (Shows show : shows) {
			logger.info(show.getStartTime());
		}

		GsonBuilder builder = new GsonBuilder();
		Gson gson = builder.create();
		String jsonObject = gson.toJson(shows);
		PrintWriter writer = null;

		try {
			writer = response.getWriter();
			writer.write(jsonObject);

		} finally {
			if (writer != null) {
				writer.flush();
				writer.close();
			}
		}
	}

	/**
	 * 
	 * @param request
	 * @param response
	 * @return This id for adding the show...after selecting multiplex and
	 *         theater through ajax and the checking for the end time
	 * 
	 */
	public ModelAndView addAjax(HttpServletRequest request,
			HttpServletResponse response) {

		String message = null;
		String movieName = request.getParameter("movieName");
		String multiplexName = request.getParameter("multiplexName");
		String theatreName = request.getParameter("theatreName");

		logger.info("In Add ajax for adding movie and theatreName is : "
				+ theatreName);

		Movie movie = showService.findMovieByTheater(theatreName, movieName,
				multiplexName);

		if (movie == null) {
			message = "Please Select theatre and Movie";
			ModelAndView mv = new ModelAndView(
					"redirect:/shows/displayShowForm.htm");
			mv.addObject("Message", message);
			return mv;
		}

		Seats seat = showService.getSeat(theatreName);

		Shows show = new Shows();
		String endTime = null;

		try {
			endTime = showService.addEndTime(request.getParameter("startTime"),
					request.getParameter("endTime"), movie.getDuration());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		show.setStartTime(request.getParameter("startTime"));
		show.setEndTime(endTime);

		try {
			show.setCostOfPlatinum(Double.parseDouble(request
					.getParameter("costOfPlatinum")));
			show.setCostOfGold(Double.parseDouble(request
					.getParameter("costOfGold")));
			show.setCostOfSilver(Double.parseDouble(request
					.getParameter("costOfSilver")));
		} catch (NumberFormatException e) {
			e.printStackTrace();
			ModelAndView mv = new ModelAndView(
					"redirect:/shows/displayShowForm.htm");
			message = "Please Enter Numeric only in cost ";
			mv.addObject("Message", message);
			return mv;
		}

		Shows showWithMovie = new Shows(show.getStartTime(), show.getEndTime(),
				movie, seat, show.getCostOfGold(), show.getCostOfPlatinum(),
				show.getCostOfSilver());

		try {
			message = showService.compareTimimgs(movie, show.getStartTime(),
					show.getEndTime());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (message == null) {
			showService.add(showWithMovie);
			columnService.saveColumn(seat, showWithMovie);
			message = "Show of " + movie.getMovieName() + " at "
					+ showWithMovie.getStartTime() + " is created";
		}

		ModelAndView mv = new ModelAndView(
				"redirect:/shows/displayShowForm.htm");
		mv.addObject("Message", message);

		return mv;

	}

	public ModelAndView selectMovieAjaxToRemoveShow(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		List<Shows> shows = new ArrayList<Shows>();

		System.out.println("In selectMovieAjaxToRemoveShow");

		PrintWriter writer = null;
		String movieNameString = request.getParameter("movieId");
		String theatreName = (String) request.getSession().getAttribute(
				"theatreName");
		String multiplexName = (String) request.getSession().getAttribute(
				"multiplexName");
		shows = showService.getByTheatreNameAndMovieName(theatreName,
				movieNameString, multiplexName);

		for (Shows show : shows) {
			System.out.println(show.getStartTime());
		}

		GsonBuilder builder = new GsonBuilder();
		builder.registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY);
		Gson gson = builder.create();
		String jsonObject = gson.toJson(shows);

		System.out.println(jsonObject);
		request.getSession().removeAttribute(multiplexName);
		request.getSession().removeAttribute(theatreName);

		try {
			writer = response.getWriter();
			writer.write(jsonObject);

		} finally {
			if (writer != null) {
				writer.flush();
				writer.close();
			}
		}
		return null;
	}

	public void selectTheatreToAddShowAjax(HttpServletRequest request,
			HttpServletResponse response) throws JsonGenerationException,
			JsonMappingException, IOException {
		PrintWriter writer = null;
		String theatreName = request.getParameter("theatreName");
		String multiplexName = (String) request.getSession().getAttribute(
				"multiplexName");

		logger.info("In selectTheatreToAddShowAjax and multiplexname is "
				+ multiplexName);

		request.getSession().setAttribute("theatreName", theatreName);

		logger.info(theatreName);
		List<Movie> movies = showService.getTheatreByName(theatreName,
				multiplexName);
		for (Movie movie : movies) {
			logger.info(movie.getMovieName());
		}

		GsonBuilder builder = new GsonBuilder();
		builder.registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY);
		Gson gson = builder.create();
		String jsonObject = gson.toJson(movies);
		System.out.println(jsonObject);

		try {
			writer = response.getWriter();
			writer.write(jsonObject);

		} finally {
			if (writer != null) {
				writer.flush();
				writer.close();
			}
		}

	}

	public ModelAndView displayShowForm(HttpServletRequest request,
			HttpServletResponse response) {
		List<Multiplex> multiplexes = showService.getAllMultiplex();
		ModelAndView mv = new ModelAndView("admin/addShowAjax");
		Shows show = showService.saveWhenEmpty();
		mv.addObject("shows", show);
		mv.addObject("multiplexes", multiplexes);
		return mv;
	}

	public ModelAndView selectTheatreToAddMovie(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String multiplexName = request.getParameter("multiplexName");
		request.getSession().setAttribute("multiplexName", multiplexName);
		List<Theatre> theatres = showService
				.getTheatreByMultiplex(multiplexName);

		for (Theatre theatre : theatres) {
			System.out.println(theatre.getTheatreName());
		}

		PrintWriter writer = null;
		GsonBuilder builder = new GsonBuilder();
		builder.registerTypeAdapterFactory(HibernateProxyTypeAdapter.FACTORY);
		Gson gson = builder.create();
		String jsonObject = gson.toJson(theatres);

		System.out.println(jsonObject);

		try {
			writer = response.getWriter();
			writer.write(jsonObject);

		} finally {
			if (writer != null) {
				writer.flush();
				writer.close();
			}
		}

		return null;
	}

	public ModelAndView displayRemoveShowForm(HttpServletRequest request,
			HttpServletResponse response) {
		List<Multiplex> multiplexes = showService.getAllMultiplex();
		ModelAndView mv = new ModelAndView("admin/removeShowAjax");
		Shows show = showService.saveWhenEmpty();
		mv.addObject("shows", show);
		mv.addObject("multiplexes", multiplexes);
		return mv;
	}

}
