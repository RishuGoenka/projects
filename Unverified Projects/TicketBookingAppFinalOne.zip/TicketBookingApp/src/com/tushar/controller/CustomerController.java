package com.tushar.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.tushar.Service.CustomerService;
import com.tushar.models.Column;
import com.tushar.models.Customer;
import com.tushar.models.Movie;
import com.tushar.models.Multiplex;
import com.tushar.models.Row;
import com.tushar.models.Shows;
import com.tushar.models.Theatre;

public class CustomerController extends MultiActionController {
	
	final static Logger logger = Logger.getLogger(LoginController.class);
	private CustomerService customerService;

	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	
	public ModelAndView customerRegisterDisplayForm(HttpServletRequest request ,HttpServletResponse response){
		Customer customer = customerService.loginDisplayForm();
		ModelAndView mv = new ModelAndView("customer/register");
		mv.addObject("customer",customer);
		return mv;
	}
	
	public ModelAndView register(HttpServletRequest request ,HttpServletResponse response , Customer customer){
		String confirmPassword = request.getParameter("confirmPassword");
		Boolean check = customerService.checkPassword(confirmPassword , customer.getPassword());
		if(check == true){
			customer.setCustomerType("Customer");
			Integer customerId = customerService.addCustomer(customer);
			if(customerId==0){
				ModelAndView mv = new ModelAndView("redirect:/customer/customerRegisterDisplayForm.htm");
				mv.addObject("passwordMessage","Email Already Exists");
				return mv;
			}
			
			ModelAndView mv = new ModelAndView("redirect:/customer/homePageDisplayForm.htm");
			HttpSession session = request.getSession();
			session.setAttribute("customerId", customer.getCustomerId());
			return mv;
		}
		
		ModelAndView mv = new ModelAndView("redirect:/customer/customerRegisterDisplayForm.htm");
		mv.addObject("passwordMessage","Your Passwords do not match");
		return mv;
	}
	
	
	public ModelAndView homePageDisplayForm(HttpServletRequest request ,HttpServletResponse response ){
		HttpSession session = request.getSession();
		Integer customerId = (Integer) session.getAttribute("customerId");
		Customer customer = customerService.getCustomerById(customerId);
		
		List<Movie> movies = customerService.displayMovie();

		
		ModelAndView mv = new ModelAndView("customer/movieDisplay");
		String welcomeMessage = "Welcome "+customer.getCustomerName();
		mv.addObject("welcomeMessage",welcomeMessage);
		mv.addObject("movies",movies);
		mv.addObject("movie",new Movie());
		return mv;
	}
	
	public ModelAndView selectedMovie(HttpServletRequest request ,HttpServletResponse response ,Movie movie){
		String movieName = movie.getMovieName();
		List<Theatre> theatres = customerService.getAllTheatreByMovieName(movieName);
		
		for(Theatre theatre : theatres){
			logger.info("In controller "+theatre.getTheatreName());
		}
		
		
		Map<Multiplex, HashMap<Theatre, ArrayList<Shows>>> theaterShowMap = customerService.getAllShowsByTheatreAndMovie(theatres , movieName);
		
		ModelAndView mv = new ModelAndView("customer/listOfShows");
		mv.addObject("theaterShowMap",theaterShowMap);
		
		return mv;
	}
	
	
	/**
	 * For Seat Selection Now...
	 */
	
	public ModelAndView selectRowFromShow(HttpServletRequest request ,HttpServletResponse response){
		String showIdString = request.getParameter("showId");
		HttpSession session = request.getSession();
		session.setAttribute("showId", showIdString);
		
		List<Row> rows = customerService.getRowTypeFromRow(showIdString);
		ModelAndView mv = new ModelAndView("customer/selectRowType");
		mv.addObject("rows",rows);
		return mv;
	}
	
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * 				To display the chart...
	 */
	
	public ModelAndView displaySeatingChart(HttpServletRequest request ,HttpServletResponse response ){
		
		LinkedHashMap<Row, List<Column>> rowColumnMap = new LinkedHashMap<Row, List<Column>>();
		String showIdString = request.getParameter("showId");
		HttpSession session = request.getSession();
		session.setAttribute("showId", showIdString);
		logger.info(showIdString);
		rowColumnMap = customerService.getColumnFromRowAndShow(showIdString);
		request.setAttribute("rowColumnMap", rowColumnMap);
		ModelAndView mv = new ModelAndView("customer/displayChart");
		mv.addObject("rowColumnMap",rowColumnMap);
		return mv;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * 
	 * This is for getting the rows and columns checked by the user for selecting seat...
	 * 	when a box is checked it shows "on" on request parameter so to get the checked box I iterated all the values 
	 * of the hash map and if any of the value is not null that means it is checked so i stored it in list as there can be multiple entries 
	 * 	related to it. 
	 */
	
	public ModelAndView check(HttpServletRequest request ,HttpServletResponse response){
		LinkedHashMap<Row, List<Column>> rowColumnMap = new LinkedHashMap<Row, List<Column>>();
		List<Row> rowsChecked = new ArrayList<Row>();
		List<Column> columnChecked = new ArrayList<Column>();
		String showIdString = (String) request.getSession().getAttribute("showId");
		rowColumnMap = customerService.getColumnFromRowAndShow(showIdString);
		//Name of the loop is outer loop
		//outerloop:		
		for(Row row : rowColumnMap.keySet()){
			String rowName = row.getNameOfRow();
			
			logger.info(row.getNameOfRow());
			
			for(List<Column> columns: rowColumnMap.values()){	
				for(Column column:columns){
					if(row.getRowId()==column.getRow().getRowId()){
						Integer columnNumber = column.getColumnNumber();
						String rowColumn = rowName+columnNumber;
						if(request.getParameter(rowColumn)!=null){
							rowsChecked.add(row);
							columnChecked.add(column);
							//break outerloop;
						}
					}
				}
			}
		}
		if(columnChecked.size()==0){
			ModelAndView mv = new ModelAndView("redirect:/customer/displaySeatingChart.htm");
			mv.addObject("Message","Please Select atleast one seat");
			mv.addObject("showId",showIdString);
			return mv;
		}
		request.getSession().setAttribute("columnIdString", columnChecked);
		request.getSession().setAttribute("rowIdString", rowsChecked);
		return new ModelAndView("redirect:/customer/bookTicket.htm");
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * 
	 * 	this method is for calculating the total Amount entered by the user and displaying it to a page..
	 */
	
	
	public ModelAndView bookTicket(HttpServletRequest request ,HttpServletResponse response){
		HttpSession session = request.getSession();
		@SuppressWarnings("unchecked")
		List<Column> columns = (List<Column>) request.getSession().getAttribute("columnIdString");		
		String showIdString  = customerService.gettingStringShowId(""+columns.get(0).getColumnId());
		
		Double totalAmount  = 0.0 ;
		for(Column column : columns){
			String columnIdString = ""+column.getColumnId();
			Double totalAmountPrev = customerService.calculatingCostOfTicket(columnIdString);
			totalAmount = totalAmount + totalAmountPrev ;
			
		}

		session.setAttribute("totalAmount", totalAmount);
		session.getAttribute("customerId");
		
		Integer customerId = (Integer) session.getAttribute("customerId");
		Customer customer = customerService.getCustomerById(customerId);
		
		ModelAndView mv = new ModelAndView("customer/displayTotalAmount");
		mv.addObject("customer" , customer);
		mv.addObject("showId",showIdString);
		return mv;
	}
	
	/**
	 * 
	 * @param request
	 * @param response
	 * @return
	 * 	This is for finally booking the ticket and displaying the message containing all...
	 * 	While booking the seat synchronization has been done in order to maintain concurrency when two users simultaneously are booking the 
	 * 	seats in bookticket function..
	 */
	public ModelAndView bookingTicket(HttpServletRequest request ,HttpServletResponse response){
		Integer customerId = (Integer) request.getSession().getAttribute("customerId");

		@SuppressWarnings("unchecked")
		List<Column> columns = (List<Column>) request.getSession().getAttribute("columnIdString");
		Double totalAmount = (Double) request.getSession().getAttribute("totalAmount");
		
		@SuppressWarnings("unchecked")
		List<Row> rows = (List<Row>) request.getSession().getAttribute("rowIdString");
		
		String showIdString = (String) request.getSession().getAttribute("showId");
		Movie movie = customerService.getMovieByShow(showIdString);
		Theatre theatre = customerService.getByMovie(movie);
		Multiplex multiplex = customerService.getByTheatre(theatre);
		Integer ticketId = null;
		String customerIdString = ""+customerId;
		
		for(Column column : columns){
			String columnIdString = ""+ column.getColumnId();
			ticketId = customerService.bookTicket(customerIdString , columnIdString , totalAmount);
			if(ticketId == 0){
				ModelAndView mv = new ModelAndView("redirect:/customer/displaySeatingChart.htm");
				mv.addObject("showId",showIdString);
				mv.addObject("Message","Seat booked by someone else..select any other seat");
				return mv;
			}
		}
	
		
		ModelAndView mv = new ModelAndView("customer/displayScene");
		String bookingMessage = null;
		List<String> seatNumbers = new ArrayList<String>();
		for(int i=0; i<rows.size();i++){
			String seatNumber = "and Your Seat Number is " + rows.get(i).getNameOfRow() + columns.get(i).getColumnNumber();
			seatNumbers.add(seatNumber);
		}
		
		bookingMessage = " Your booking of "+ movie.getMovieName() + " is confirmed at Screen " + theatre.getTheatreName() + " of " + multiplex.getMultiplexName();
		mv.addObject("ticketId",bookingMessage);
		mv.addObject("seatNumber" , seatNumbers);
	//	request.getSession().removeAttribute("totalAmount");
		request.getSession().removeAttribute("showId");
		request.getSession().removeAttribute("rowIdString");
		request.getSession().removeAttribute("columnIdString");
		
		return mv;
	}
	
	
	public ModelAndView logout(HttpServletRequest request ,HttpServletResponse response){
		Integer customerId = (Integer) request.getSession().getAttribute("customerId");
		logger.info(customerId);
		HttpSession session = request.getSession();
		session.removeAttribute("customerId");
		session.invalidate();
		return new ModelAndView("redirect:/login/loginDisplayForm.htm");
	}
}
