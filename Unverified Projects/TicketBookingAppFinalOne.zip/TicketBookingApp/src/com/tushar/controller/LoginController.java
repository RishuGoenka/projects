package com.tushar.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.tushar.Service.AdminLoginService;
import com.tushar.Service.CustomerService;
import com.tushar.models.Customer;

public class LoginController extends MultiActionController {
	
	private CustomerService customerService;
	private AdminLoginService adminLoginService;
	
	final static Logger logger = Logger.getLogger(LoginController.class);
	
	public void setCustomerService(CustomerService customerService) {
		this.customerService = customerService;
	}
	
	public void setAdminLoginService(AdminLoginService adminLoginService) {
		this.adminLoginService = adminLoginService;
	}
	
	
	
	public ModelAndView loginDisplayForm(HttpServletRequest request ,HttpServletResponse response){
		Customer customer = customerService.loginDisplayForm();
		ModelAndView mv = new ModelAndView("loginCustomer");
		mv.addObject("customer",customer);
		return mv;
	}
	
	public ModelAndView customerAuthorization(HttpServletRequest request ,HttpServletResponse response,Customer customer){
		

		
		HttpSession session = request.getSession();
		if(customer.getCustomerEmail().equals("zycusadmin")){
			ModelAndView mv ;
			String result = adminLoginService.validator(customer) ;
			
			if(result.equals(customer.getCustomerEmail())){
				session.setAttribute("adminlogin",result );
				mv = new ModelAndView("redirect:/adminlogin/adminHomePage.htm");
				return mv;
			}
			
			session.setAttribute("adminLoginValidation", result);
			mv = new ModelAndView("redirect:/adminlogin/displayForm.htm");
			return mv;
		}
		
		
		Customer customerAfterValidation = customerService.customerAuthorizationService(customer);
		
		if(customerAfterValidation==null){
			ModelAndView mv = new ModelAndView("loginCustomer");
			mv.addObject("Message" , "Either Email or Passowrd is wrong");
			mv.addObject("customer",new Customer());
			return mv;
		}
		
		
		else if(customerAfterValidation.getCustomerType().equals("Admin")){
			ModelAndView mv;
			session.setAttribute("adminlogin",customerAfterValidation.getCustomerName() );
			mv = new ModelAndView("redirect:/adminlogin/adminHomePage.htm");
			return mv;
		}
		
		ModelAndView mv = new ModelAndView("redirect:/customer/homePageDisplayForm.htm");
		System.out.println("In customerAfetrAuthorization "+customerAfterValidation.getCustomerId());
		session.setAttribute("customerId", customerAfterValidation.getCustomerId());
		return mv;
	}
}
