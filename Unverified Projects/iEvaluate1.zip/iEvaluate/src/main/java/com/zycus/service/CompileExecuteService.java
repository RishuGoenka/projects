package com.zycus.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import com.zycus.utility.StatusEnum;

public class CompileExecuteService {
	public StatusEnum compile(String programName) {
		ProcessBuilder p = new ProcessBuilder(
				"C://Program Files//Java//jdk1.7.0_51//bin//javac.exe",
				"C://Users//harshvardhan.dudeja//Desktop//bin//"+programName+"//Main.java");
		boolean compiled = true;
		p.redirectErrorStream(true);

		try {
			Process pp = p.start();
			InputStream is = pp.getInputStream();
			String temp;
			try (BufferedReader b = new BufferedReader(
					new InputStreamReader(is))) {
				while ((temp = b.readLine()) != null) {
					compiled = false;
					System.out.println(temp);
				}
				pp.waitFor();
			}

			if (!compiled) {
				is.close();
				return StatusEnum.COMPILE_ERROR;
			}
			is.close();
			return StatusEnum.COMPILE_SUCCESS;

		} catch (IOException | InterruptedException e) {
			System.out.println("in compile() " + e);
		}

		return StatusEnum.COMPILE_ERROR;
	}

	public StatusEnum execute(String programName, String input,
			List<String> outputList, int index) throws IOException {

		ProcessBuilder p = new ProcessBuilder(
				"C://Program Files//Java//jdk1.7.0_51//bin//java.exe",
				programName);

		File in = new File(input);
		p.directory(new File(System.getProperty("dir")));
		p.redirectInput(in);
		p.redirectErrorStream(true);

		File out = new File(System.getProperty("dir") + "/out.txt");
		p.redirectOutput(out);
		try {

			Process process = p.start();
			process.waitFor();
			int exitCode = process.exitValue();
			if (exitCode != 0)
				return StatusEnum.RUN_ERROR;
		} catch (IOException ioe) {
			System.err.println("in execute() " + ioe);
		} catch (InterruptedException ex) {
			System.err.println(ex);
		}
		BufferedReader br = new BufferedReader(new FileReader(out));
		int result = Integer.parseInt(br.readLine());
		br.close();
		if (result == Integer.parseInt(outputList.get(index)))
			System.out.println("Test Passed"); // reflect to DB
		else
			System.out.println("Test Failed"); // reflect to DB
		return StatusEnum.RUN_SUCCESS;
	}
}
