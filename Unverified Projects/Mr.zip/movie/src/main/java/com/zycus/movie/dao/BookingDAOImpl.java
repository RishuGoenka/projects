package com.zycus.movie.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.movie.model.Booking;
import com.zycus.movie.model.Genre;

@Repository
@Transactional
public class BookingDAOImpl implements BookingDAO {
	@PersistenceContext
	private EntityManager manager;

	static Logger log = Logger.getLogger(BookingDAOImpl.class.getName());

	@Override
	public boolean saveBooking(Booking bookingObj) {
		try {
			if (bookingObj != null) {
				manager.persist(bookingObj);
				return true;
			} else {
				log.error("bookingObj Object found Null");
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error while saving the Booking", e);
			return false;
		}
	}

	@Override
	public boolean updateBooking(Booking bookingObj) {
		try {
			if (bookingObj != null) {
				manager.merge(bookingObj);
				return true;
			} else {
				log.error("bookingObj Object found null");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while Updating the Booking", e);
			return false;
		}
	}

	@Override
	public boolean deleteBooking(int bookingId) {
		try {
			if (bookingId > 0) {
				Booking bookingObj = manager.find(Booking.class, bookingId);
				if (bookingObj != null) {
					manager.remove(bookingObj);
					return true;
				} else {
					log.error("Booking Object Found Null");
					return false;
				}
			} else {
				log.error("Booking with the Id Not Valid");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while Deleting the Booking", e);
			return false;
		}
	}

	@Override
	public Booking getBookingById(int bookingId) {
		try {
			if (bookingId > 0) {
				return manager.find(Booking.class, bookingId);
			} else {
				log.error("Booking with the Id Not Valid");
				return null;
			}
		} catch (Exception e) {
			log.error("Error while Finding the Booking with the Id", e);
			return null;
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Booking> getAllBookings() {
		try {
			List<Booking> bookingList = (List<Booking>) manager.createQuery("select b from Booking b").getResultList();
			if(bookingList==null){
				return null;
			}
			return bookingList;
		} catch (Exception e) {
			log.error("Error while retriving the Booking List", e);
			return null;
		}
	}

	@Override
	public List<Booking> getAllBookingsByUserId(int userId) {
		try {
			List<Booking> bookingList = manager.createQuery("select b from Booking b where b.user.userId =:userId").setParameter("userId", userId).getResultList();
			return bookingList;
		} catch (Exception e) {
			log.error("Error while retriving the Booking List By UserId", e);
			return null;
		}
	}

	@Override
	public List<Booking> getAllBookingsByMovieId(int movieId) {
		try {
			List<Booking> bookingList = manager.createQuery("select b from Booking b where b.movie.movieId =:movieId")
					.setParameter("movieId", movieId).getResultList();
			return bookingList;
		} catch (Exception e) {
			log.error("Error while retriving the Booking List By MovieId", e);
			return null;
		}
	}

	@Override
	public int getNoOfBookings() {
		try {
			int value = (int) manager.createQuery("select b from Booking b").getResultList().size();
			return value;
		} catch (Exception e) {
			log.error("Error while retriving the Booking Count By MovieId", e);
			return 0;
		}
	}

	@Override
	public int getNoOfBookingsByUserId(int userId) {
		try {
			return (int) manager.createQuery("select b from Booking b where b.user.userId =:userId")
					.setParameter("userId", userId).getResultList().size();
		} catch (Exception e) {
			log.error("Error while retriving the Booking Count By MovieId", e);
			return 0;
		}
	}

	@Override
	public int getNoOfBookingsByMovieId(int movieId) {
		try {
			return (int) manager.createQuery("select b from Booking b where b.movie.movieId =:movieId")
					.setParameter("movieId", movieId).getResultList().size();
		} catch (Exception e) {
			log.error("Error while retriving the Booking Count By MovieId", e);
			return 0;
		}
	}
}