package com.zycus.movie.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.zycus.movie.model.Genre;
import com.zycus.movie.model.Movie;
import com.zycus.movie.model.MovieGenre;

@Transactional
@Repository
public class MovieGenreDAOImpl implements MovieGenreDAO {

	@PersistenceContext
	EntityManager manager;
	static Logger log = Logger.getLogger(MovieGenreDAOImpl.class.getName());

	@Override
	public boolean saveMovieGenre(MovieGenre moviegenreObj) {
		try {
			if (moviegenreObj != null) {
				manager.persist(moviegenreObj);
				return true;
			} else {
				log.error("moviegenreObj Found Null");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while saving the MovieGenre", e);
			return false;
		}
	}

	@Override
	public boolean updateMovieGenre(MovieGenre moviegenreObj) {
		try {
			if (moviegenreObj != null) {
				manager.merge(moviegenreObj);
				return true;
			} else {
				log.error("moviegenreObj Found Null");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while Updating the MovieGenre", e);
			return false;
		}
	}

	@Override
	public boolean deleteMovieGenre(MovieGenre moviegenreObj) {
		try {
			if (moviegenreObj != null) {
				manager.remove(moviegenreObj);
				return true;
			} else {
				log.error("moviegenreObj Found Null");
				return false;
			}
		} catch (Exception e) {
			log.error("Error while Deleting the MovieGenre", e);
			return false;
		}
	}

	@Override
	public List<Movie> findMovieGenreByGenreId(int genreId) {
		try {
			List<Movie> movieIdList = manager
					.createQuery("Select mg.movie.movieId from MovieGenre mg where mg.genre.genreId =:genreId")
					.setParameter("genreId", genreId).getResultList();
			return movieIdList;
		} catch (Exception e) {
			log.error("Error at MovieGenreDAO", e);
			return null;
		}
	}

	@Override
	public List<Genre> findGenreMovieByMovieId(int movieId) {
		try {
			List<Genre> genreIdList = manager
					.createQuery("Select mg.genre.genreId from MovieGenre mg where mg.movie.movieId =:movieId")
					.setParameter("movieId", movieId).getResultList();
			return genreIdList;
		} catch (Exception e) {
			log.error("Error at MovieGenreDAO", e);
			return null;
		}
	}

	@Override
	public List<MovieGenre> getAllMovieGenre() {
		try {
			List<MovieGenre> byMovieIdList = manager.createQuery("Select mg from MovieGenre mg ").getResultList();
			return byMovieIdList;
		} catch (Exception e) {
			log.error("Error at MovieGenreDAO", e);
			return null;
		}
	}
	
	@Override
	public MovieGenre findByIDs(int genreId, int movieId) {
		try {
			return (MovieGenre) manager
					.createQuery(
							"select mg from MovieGenre mg where mg.movie.movieId =:movieId and mg.genre.genreId =:genreId")
					.setParameter("movieId", movieId).setParameter("genreId", genreId).getResultList().get(0);
		} catch (Exception e) {
			log.error("Error at MovieGenreDAO", e);
			return null;
		}
	}
}
