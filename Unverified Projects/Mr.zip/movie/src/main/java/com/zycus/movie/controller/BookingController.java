package com.zycus.movie.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.zycus.movie.model.Booking;
import com.zycus.movie.model.CartDTO;
import com.zycus.movie.model.Movie;
import com.zycus.movie.model.User;
import com.zycus.movie.service.BookingService;
import com.zycus.movie.service.MovieService;
import com.zycus.movie.service.UserService;

@Controller
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@Autowired
	private UserService userService;

	@Autowired
	private MovieService movieService;

	SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy");

	/**
	 * User Cart
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/cartlist", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody Set<Movie> saveToCart(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		Set<String> bookedMovie = (Set<String>) session.getAttribute("movieTitle");
		Set<Movie> bookedMovieDetail = new HashSet<Movie>();
		if (bookedMovie != null) {
			for (String i : bookedMovie) {
				Movie moive = movieService.getMovieByTitle(i);
				bookedMovieDetail.add(moive);
			}
		}
		return bookedMovieDetail;
	}

	/**
	 * Movie Booking
	 * 
	 * @param request
	 * @param response
	 * @return
	 */

	@RequestMapping(value = "/booking", method = RequestMethod.POST)
	public String saveBooking(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		Set<String> bookedMovie = (Set<String>) session.getAttribute("movieTitle");
		List<Movie> bookedMovieDetail = new LinkedList<Movie>();
		for (String i : bookedMovie) {
			Movie moive = movieService.getMovieByTitle(i);
			bookedMovieDetail.add(moive);
		}
		User user = (User) session.getAttribute("user");
		session.removeAttribute("movieTitle");
		List<Date> startdate = new LinkedList<>();
		List<Date> enddate = new LinkedList<>();
		List<Double> cost = new LinkedList<>();
		for (Movie i : bookedMovieDetail) {
			String startTimeName = "start" + i.getMovieTitle();
			String endTimeName = "end" + i.getMovieTitle();
			String starttimeStr = (String) request.getParameter(startTimeName);
			String endtimeStr = (String) request.getParameter(endTimeName);
			String[] startSplit = starttimeStr.split("-");
			String[] endSplit = endtimeStr.split("-");
			String startt = startSplit[1] + "/" + startSplit[2] + "/" + startSplit[0];
			String endt = endSplit[1] + "/" + endSplit[2] + "/" + endSplit[0];
			Date start = null;
			Date end = null;
			try {
				start = format.parse(startt);
				end = format.parse(endt);
			} catch (ParseException e) {
				e.printStackTrace();
			}
			startdate.add(start);
			enddate.add(end);
			long duration = (end.getTime() - start.getTime()) / 1000 / 60 / 60 / 24;
			if (duration < 0) {
				duration = 0;
				cost.add(i.getMovieCost() * duration);
			} else {
				cost.add(i.getMovieCost() * duration);
			}
		}
		int count = 0;
		for (Movie i : bookedMovieDetail) {
			Booking bookingObj = new Booking(user, i, startdate.get(count), enddate.get(count), cost.get(count));
			if (bookingService.saveBooking(bookingObj)) {
				count++;
			} else {
				return "booking";
			}
		}
		return "movielist";
	}

	/**
	 * User Profile
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/viewProfileBooking", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<CartDTO> viewProfileBooking(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		int userId = user.getUserId();

		List<Booking> bookingUserList = bookingService.getAllBookingsByUserID(userId);
		List<CartDTO> cart = new LinkedList<>();
		for (Booking i : bookingUserList) {
			CartDTO cartObj = new CartDTO();
			String T = i.getMovie().getMovieTitle();
			cartObj.setMovieTitle(T);
			Double c = i.getCost();
			String C = c.toString();
			cartObj.setTotalCost(C);
			Date SD = i.getStartTime();
			Date ED = i.getEndTime();
			String SDS = format.format(SD);
			String EDS = format.format(ED);
			cartObj.setStartTime(SDS);
			cartObj.setEndTime(EDS);
			cart.add(cartObj);
		}
		return cart;
	}

	/**
	 * Booking Page
	 * 
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/booking")
	public String booking(HttpServletRequest request) {
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("user");
		if (user == null)
			return "index";
		return "booking";
	}

}
