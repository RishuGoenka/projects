package com.zycus.movie.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.zycus.movie.model.Booking;

@Repository
public abstract interface BookingService {

	/**
	 * Save Booking
	 * 
	 * @param bookingObj
	 * @return
	 */
	public abstract boolean saveBooking(Booking bookingObj);

	/**
	 * Update Booking
	 * 
	 * @param bookingObj
	 * @return
	 */
	public abstract boolean updateBooking(Booking bookingObj);

	/**
	 * Delete Booking
	 * 
	 * @param bookingId
	 * @return
	 */
	public abstract boolean deleteBooking(int bookingId);

	/**
	 * Get Booking By Booking Id
	 * 
	 * @param bookingId
	 * @return
	 */
	public abstract Booking getBookingByID(int bookingId);

	/**
	 * Get List for all the Bookings
	 * 
	 * @return
	 */
	public abstract List<Booking> getAllBookings();

	/**
	 * Get list of Booking for the particular User
	 * 
	 * @param userId
	 * @return
	 */
	public abstract List<Booking> getAllBookingsByUserID(int userId);

	/**
	 * Get list of Booking for the particular Movie
	 * 
	 * @param movieId
	 * @return
	 */
	public abstract List<Booking> getAllBookingsByMovieID(int movieId);

	/**
	 * Get Total Number of Booking
	 * 
	 * @return
	 */
	public abstract int getNoOfBookings();

	/**
	 * Get Total Number of Booking for the Particular User
	 * 
	 * @param userId
	 * @return
	 */
	public abstract int getNoOfBookingsByUserID(int userId);

	/**
	 * Get Total Number of Booking for the Particular Movie
	 * 
	 * @param movieId
	 * @return
	 */
	public abstract int getNoOfBookingsByMovieID(int movieId);
	
}
