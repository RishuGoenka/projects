import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.InputMismatchException;

public class Main {

	public static void main(String[] args) throws NumberFormatException,
			IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		int testNumber = 0;
		boolean flag = true;
		try{
		System.out.println("Enter Number of Test case :");
		testNumber = Integer.parseInt(read.readLine());
		}catch(InputMismatchException| IllegalArgumentException | ArrayIndexOutOfBoundsException ex)
		{
			System.out.println("Invalid Input Enter Integer String");
		}
		//Case Check
		while (testNumber < 1 && testNumber > 100000) {
			System.out.println("Invalid Input Enter Test Case within Range");
			testNumber = Integer.parseInt(read.readLine());
		}
		//test
		for (int i = 1; i <= testNumber; i++) {
			System.out.println("Enter Test case:" + i);
			String input = read.readLine();
			flag = true;
			for (int j = 0; j < input.length(); j++) {
				if (!(((int) input.charAt(j)) > 96 && ((int) input.charAt(j)) < 123)) {
					flag = false;
				}				
			}
			if (flag == false) {
				System.out.println("Invalid Inputed String");
			} else {
				StringBalance.stringInput(input);
			}

		}

	}
}
