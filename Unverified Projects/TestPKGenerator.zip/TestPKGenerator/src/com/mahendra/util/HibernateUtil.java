package com.mahendra.util;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

//Singleton HibernateUtil
public class HibernateUtil {

	private static SessionFactory factory = build();

	private static SessionFactory build() {
		//Read / Parse all xmls & properties
				Configuration config = 
							new Configuration().configure();
				//configure() is same as configure("hibernate.cfg.xml")
				return config.buildSessionFactory();
	}
	
	public static SessionFactory getFactory(){
		return factory;
	}
}
