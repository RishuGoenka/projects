public class Check {
	
	public static void main(String[] args) {

		int length = 8;
		int[] arr = { 1, 2, -2, -3, 5, -7, -8, 10 };
		int[] count = new int[length];
		for (int i = 0; i < length; i++)
			count[i] = 1;
		
		for(int i =1;i<length;i++){
			for(int j = 0;j<i;j++){
				if(arr[j]<0 && arr[i]>0 || arr[j]>0 && arr[i]<0){
					if(count[i]<(count[j]+1)){
						if(arr[j] < Math.abs(arr[i])){
							count[i] = count[j]+1;
						}
					}
					
				}
			}
		}

		int largest = count[0];
		for(int i=0;i<length-1;i++){
			if(count[i] < count[i+1])
				largest = count[i+1];
		}
		System.out.println(largest);
	}
}