public class Check {

	public static void passes(int verticesN, int[][] edgeN, int[] elementWeight) {

		int matrix[][] = new int[verticesN + 1][verticesN + 1];
		int count = 0;

		for (int i = 0; i < verticesN - 1; i++)
			plot(matrix, edgeN[i][0], edgeN[i][1]);

		for (int i = 2; i < verticesN; i++) {
			for (int j = i + 1; j <= verticesN; j++) {
				if ((elementWeight[i] * elementWeight[j]) == elementWeight[LCA(verticesN, matrix, i, j)]) {
					System.out.println(i + " " + j + " -> " + LCA(verticesN, matrix, i, j));
					count++;
				}
			}
		}
		System.out.println(count);
	}

	public static int LCA(int verticesN, int matrix[][], int node1, int node2) {
		int lca = 0;
		int index = 1;
		while (matrix[node1][index] != 0 && matrix[node1][index] == matrix[node2][index]) {
			index++;
		}
		lca = matrix[node1][index - 1];

		return lca;
	}

	public static void plot(int matrix[][], int parent, int child) {
		if (parent == 1) matrix[child][1] = 1;
		else {
			int i;
			for (i = 1; i <= matrix[parent].length; i++) {
				if (matrix[parent][i] == 0) break;
				else matrix[child][i] = matrix[parent][i];

			}
			matrix[child][i] = parent;
		}
	}

}
