import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {

	static int	VERTICES_LIMIT	= 105;

	public static void main(String[] args) {
		try {
			BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
			int verticesN = 0;
			int match = 0;
			StringBuilder sb = new StringBuilder("1 COUNT ");
			System.out.println("Enter Total Number of Vertices");
			verticesN = Integer.parseInt(read.readLine());
			if (verticesN > 1 && verticesN <= VERTICES_LIMIT) {
				int[][] edgeN = new int[verticesN - 1][2];
				match = insertEdge(read, verticesN, match, sb, edgeN);
				String[] uniqueVertices = sb.toString().trim().split(" COUNT ");
				int uniqueVerticesLength = uniqueVertices.length;
				if (match == verticesN - 1 && uniqueVerticesLength == verticesN) {
					int[] elementWeight = new int[verticesN+1];
					System.out.println("Enter Weight");
					String[] weightString = read.readLine().trim().split(" ");
					elementWeight[0] = 0;
					for (int i = 1; i < verticesN+1; i++)
						elementWeight[i] = Integer.parseInt(weightString[i-1]);
					Check.passes(verticesN,edgeN,elementWeight);
				} else System.out.println("Invalid Edges");
			} else if (verticesN == 1) System.out.println("Only Root Node");
			else System.out.println("Invalid Length");
		} catch (Exception e) {
			System.out.println("Invalid Input Exception");
		}
	}

	private static int insertEdge(BufferedReader read, int verticesN, int match, StringBuilder sb, int[][] edgeN) {
		try {
			for (int i = 0; i < verticesN - 1; i++) {
				System.out.println("Enter edge " + (i + 1));
				String[] separate;
				separate = read.readLine().trim().split(" ");
				edgeN[i][0] = Integer.parseInt(separate[0]);
				edgeN[i][1] = Integer.parseInt(separate[1]);
				if (!sb.toString().contains(separate[1]) && sb.toString().contains(separate[0])) {
					sb.append(separate[1]);
					sb.append(" COUNT ");
				}
				if (edgeN[i][0] == edgeN[i][1] && edgeN[i][0] < edgeN[i][1]) {
					System.out.println("edge value can't be same");
					break;
				} else {
					match++;
				}
			}
		} catch (Exception e) {
			System.out.println("Invalid Edge");
		}
		return match;
	}
}