import java.util.ArrayList;

public class Knot {

	static int rows = 10;
	static int cols = 15;
	static int rep = 1;

	/*char[][] map = new char[][] {

			{'.','.','.','.','.','.','.','.','.','.','.','.','.','.','.'},
			{'.','.','.','+','-','-','-','-','-','-','+','.','.','.','.'},
			{'.','.','.','|','.','.','.','.','.','.','|','.','.','.','.'},
			{'.','.','.','|','.','.','.','+','-','-','I','-','-','-','-'},
			{'.','.','.','|','.','.','.','|','.','.','|','.','.','.','.'},
			{'-','-','-','I','-','-','-','H','-','-','+','.','.','.','.'},
			{'.','.','.','|','.','.','.','|','.','.','.','.','.','.','.'},
			{'.','.','.','+','-','-','-','+','.','.','.','.','.','.','.'},
			{'.','.','.','.','.','.','.','.','.','.','.','.','.','.','.'}

	};*/

	
	/*
	char[][] map = new char[][] {

			{'.','.','.','.','.','.','.','.','.','.','.','.','.','.','.'},
			{'.','.','.','+','-','+','.','.','+','-','+','.','.','.','.'},
			{'.','.','.','|','.','|','.','.','|','.','|','.','.','.','.'},
			{'.','.','.','|','.','|','.','.','|','-','|','.','.','.','.'},
			{'.','.','.','|','.','|','.','.','|','.','|','.','.','.','.'},
			{'-','-','-','I','-','+','.','.','+','-','H','-','-','-','-'},
			{'.','.','.','|','.','.','.','.','.','.','|','.','.','.','.'},
			{'.','.','.','+','-','-','-','-','-','-','+','.','.','.','.'},
			{'.','.','.','.','.','.','.','.','.','.','.','.','.','.','.'}

	};*/
	
	static char[][] map = new char[][] {

			{'.','.','+','-','-','-','-','-','-','-','-','-','-','-','-'},
			{'.','.','|','.','.','.','.','.','.','.','.','.','.','.','.'},
			{'.','.','|','+','-','-','-','+','.','.','.','.','.','.','.'},
			{'.','.','+','I','-','-','-','H','-','-','+','.','.','.','.'},
			{'.','.','.','|','.','.','.','|','.','.','|','.','.','.','.'},
			{'.','.','.','|','.','.','.','|','.','.','|','.','.','.','.'},
			{'-','-','-','H','-','-','-','+','.','.','|','.','.','.','.'},
			{'.','.','.','|','.','.','.','.','.','.','|','.','.','.','.'},
			{'.','.','.','+','-','-','-','-','-','-','+','.','.','.','.'},
			{'.','.','.','.','.','.','.','.','.','.','.','.','.','.','.'}

	};
	
/*	static char[][] map = new char[][]	{
		  {'.','.','.','.','.','.','.','.','.','.','.','.','.','.','.'},
		  {'.','.','+','-','-','-','-','-','-','-','-','-','-','+','.'},
		  {'.','.','|','.','.','.','.','.','.','.','.','.','.','|','.'},
		  {'.','.','|','.','.','.','.','.','.','.','.','.','.','|','.'},
		  {'.','.','|','.','.','+','-','-','+','.','.','.','.','|','.'},
		  {'.','.','|','.','.','|','.','.','|','.','.','.','.','|','.'},
		  {'.','.','|','.','.','|','.','.','|','.','.','.','.','|','.'},
		  {'.','.','|','.','.','+','-','-','H','-','-','-','-','I','-'},
		  {'.','.','|','.','.','.','.','.','|','.','.','.','.','|','.'},
		  {'-','-','I','-','-','-','-','-','H','-','-','-','-','+','.'},
		  {'.','.','|','.','.','.','.','.','|','.','.','.','.','.','.'},
		  {'.','.','+','-','-','-','-','-','+','.','.','.','.','.','.'},
		  {'.','.','.','.','.','.','.','.','.','.','.','.','.','.','.'},
		  {'.','.','.','.','.','.','.','.','.','.','.','.','.','.','.'}}; */

	
	public static void calculate() {

		ArrayList<String> crosses = new ArrayList<>();
		
		for (int i = 0; i < rows; i++) {

			for (int j = 0; j < cols; j++) {

				if (map[i][j] == 'H' || map[i][j] == 'I') {

					checkForSame(i, j);
					checkForDiff(i, j);
					crosses.add(i + " " + j);
				}

			}
		}

		boolean loop = hasLoop(crosses);
		
		System.out.println(loop);
		print();

	}
	
	private static boolean hasLoop(ArrayList<String> crosses) {
		
		
		for(String cross: crosses) {
			
			String[] parts = cross.split(" ");
			
			int rowStart = Integer.parseInt(parts[0]);
			int colStart = Integer.parseInt(parts[1]);
			
			char check = 'H';
			
			if(map[rowStart][colStart] == 'H') check = 'I';
			
			for(int i=colStart+1; i<cols; i++) {
				
				if(map[rowStart][i] == '.') break;
				
				if(map[rowStart][i] == check || (map[rowStart][i] == '#' && rep == 3)) {
					return true;
				}
			}
			
			for(int i=rowStart+1; i<rows; i++) {
				
				if(map[i][colStart] == '.') break;
				
				if(map[rowStart][i] == check) return true;
			}

		}
		return false;
	}

	private static void checkForSame(int rowStart, int colStart) {

		char check = map[rowStart][colStart];

		char breakingChar = 'H';
		
		if(check == 'H') breakingChar = 'I';
		
		for (int i = rowStart + 1; i < rows; i++) {

			if(map[i][colStart] == '.') break;
			
			if(map[i][colStart] == breakingChar) break;
			
			
			if (check == map[i][colStart]) {

				// found same, cancel them mam
				map[rowStart][colStart] = '#';
				map[i][colStart] = '#';
				rep++;
				break;
			}
		}

		for (int i = colStart + 1; i < cols; i++) {

			if(map[rowStart][i] == '.') break;			

			if(map[rowStart][i] == breakingChar) break;			
			
			if (check == map[rowStart][i]) {

				// found same, cancel them mam
				map[rowStart][colStart] = '#';
				map[rowStart][i] = '#';
				rep++;
				break;
			}
		}

	}

	private static void checkForDiff(int rowStart, int colStart) {

		char check = 'H';

		if (map[rowStart][colStart] == 'H')
			check = 'I';

		char breakingChar = 'H';
		
		if(check == 'H') breakingChar = 'I';
		
		for (int i = rowStart + 1; i < rows; i++) {

			for (int j = colStart - 1; j >= 0; j--) {

				if(map[i][j] == '.') break;
				
				if(map[i][j] == breakingChar) break;
				
				if (map[i][j] == check) {

					// found opposite, cancel them mam
					map[rowStart][colStart] = '#';
					map[i][j] = '#';
					rep++;
					break;

				}
			}

			for (int j = colStart + 1; j < cols; j++) {

				if(map[i][j] == '.') break;		

				if(map[i][j] == breakingChar) break;
				
				if (map[i][j] == check) {

					// found opposite, cancel them mam
					map[rowStart][colStart] = '#';
					map[i][j] = '#';
					rep++;
					break;

				}

			}

		}

	}

	private static void print() {

		for (int i = 0; i < rows; i++) {

			for (int j = 0; j < cols; j++) {

				System.out.print(map[i][j] + " ");
			}

			System.out.println();
		}
	}

}
