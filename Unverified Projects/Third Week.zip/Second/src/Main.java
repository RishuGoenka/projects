import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		try{
		System.out.println("No. of String");
		int n = Integer.parseInt(read.readLine());
		if(n<1 && n>10){
			System.out.println("Invalid String Number");
		}
		else{
		String stringPair;
		StringBuilder sb = new StringBuilder("");
		for(int i = 0 ;i < n; i++){
			System.out.println("Enter String");
			stringPair = read.readLine();
			String[] separate = stringPair.trim().split(" ");
			if(separate[0].length()>5 || separate[1].length()>5 || separate.length!=2 ){
				System.out.println("Invalid Input");
				break;
			}
			else{
				if(!sb.toString().contains(stringPair)){
					sb.append(stringPair);
					sb.append(" 12QW ");
				}
			}
		}
		System.out.println("No. of unique String " + sb.toString().trim().split(" 12QW ").length + " out of " + n + " String.");
	}
		}catch(Exception e){
			System.out.println("Invalid Input");
		}

}
}