import java.io.BufferedReader;
import java.io.InputStreamReader;


public class Main {

	public static void main(String[] args) {
		BufferedReader read = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Sequence");
		String sequenceString = null;
		try{
		sequenceString = read.readLine();
		}catch(Exception e){
			System.out.println("Invalid input");
		}
		reverse.seq(sequenceString);
	}

}
