
public class reverse {

	public static void seq(String sequenceString) {
		String[] separateSequence = sequenceString.trim().split(" ");
		int sequenceLength = separateSequence.length;
		int[] inputSequence = new int[sequenceLength];
		int[] indexs = new int[sequenceLength];
		for(int j=0;j<sequenceLength;j++){
			indexs[j] = j;
			inputSequence[j] = Integer.parseInt(separateSequence[j]);
		}
		
		for(int i=0;i<sequenceLength;i++){
			if(inputSequence[i]!=0){
				int len = inputSequence[i];
				for(int j=0;j<len;j++){
					int temp = indexs[i-j-1];
					indexs[i-j-1] = indexs[i-j];
					indexs[i-j] = temp;
				}
			}
		}
		
		for(int k=0;k<sequenceLength;k++){
			inputSequence[indexs[k]] = k+1;
		}
		
		for(int x: inputSequence)
			System.out.println(x);
	}

}
