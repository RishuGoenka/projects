import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		String dataSet = null;
		StringBuilder sb = new StringBuilder();
		while (true) {
			try {
				System.out.println("Enter the data Set");
				dataSet = read.readLine();
				int spaceIndex = dataSet.indexOf(" ");
				if (Integer.parseInt(dataSet.substring(0, spaceIndex)) >= 1	&& Integer.parseInt(dataSet.substring(0, spaceIndex)) <= 26) {
					if (Pattern.matches("[A-Z!]+",dataSet.substring(spaceIndex + 1)) && dataSet.substring(spaceIndex + 1).length() >= 2) {
						if (Pattern.matches("[A-Z]+", dataSet.substring(spaceIndex + 1, spaceIndex + 2))) {
							if (dataSet.substring(spaceIndex + 2).contains("!")) {
								sb.append(dataSet);
								sb.append(" q1w2e3r4t5y6 ");
							}
						} else
							System.out.println("Invalid Element of Data Set");
					} else
						System.out.println("Invalid Data Element");
				} else
					System.out.println("Invalid Data Catch Size");
			} catch (IOException | StringIndexOutOfBoundsException
					| NumberFormatException e) {
				if (dataSet.length() == 1 && dataSet.contains("0"))
					break;
				else
					System.out.println("Input Problem");
			}
		}
		Cacheing.cacheList(sb);
	}
}