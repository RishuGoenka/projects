package com.mahendra.dao;

import java.util.logging.Logger;

public class MemberDAO {
	
	private static Logger log = Logger.getLogger(MemberDAO.class.getName());
	
	public MemberDAO() {
		super();
		log.info("An instance of MemberDAO created!"); 
	}

	public void someMethod(){
		log.info("someMethod is being called!");
	}
}
