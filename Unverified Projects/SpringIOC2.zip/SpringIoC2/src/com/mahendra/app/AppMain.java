package com.mahendra.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mahendra.services.LibraryService;

public class AppMain {

	public static void main(String[] args) {
		
		//Initialize Spring IoC Container through 'ApplicationContext'
		AbstractApplicationContext context =  
					new ClassPathXmlApplicationContext("spring.xml");
		
		LibraryService service = 
					context.getBean("libraryService",LibraryService.class);
		LibraryService service2 = (LibraryService) context.getBean("libraryService");
		
		System.out.println("First instance : "+service);
		System.out.println("Second instance : "+service2);
		
		service.doSomething();
		
		 // context.close(); //Manually close/shutdown IoC Container
		context.registerShutdownHook();
	}

}
