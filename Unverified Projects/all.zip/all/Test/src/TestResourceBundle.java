

import java.util.Locale;
import java.util.ResourceBundle;

public class TestResourceBundle {

	private static final String WELCOME_KEY = "welcome";

	public static void main(String[] args) {
		
		ResourceBundle bundle = ResourceBundle.getBundle("messages");
		System.out.println("Default welcome messages : "+bundle.getString(TestResourceBundle.WELCOME_KEY));
		
		bundle = ResourceBundle.getBundle("messages",Locale.FRENCH);
		System.out.println("French welcome message : "+bundle.getString(TestResourceBundle.WELCOME_KEY));
		
		bundle = ResourceBundle.getBundle("messages",Locale.GERMAN);
		System.out.println("German welcome message : "+bundle.getString(TestResourceBundle.WELCOME_KEY));

	}

}
