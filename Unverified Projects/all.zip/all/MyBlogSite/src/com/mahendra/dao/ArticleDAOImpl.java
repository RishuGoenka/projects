package com.mahendra.dao;

import java.util.LinkedList;
import java.util.List;

import com.mahendra.models.Article;
import com.mahendra.models.ArticleDAO;

/**
 * IMplementation of ArticleDAO interface, Using collection API only!!
 * @author mahendra
 *
 */
public class ArticleDAOImpl implements ArticleDAO {
List<Article > articles = null;
	
	public ArticleDAOImpl(List<Article> articles) 
	{
		this.articles = articles;
	}

	@Override
	public int add(Article article) {
		int id = 1;
		if(articles==null)
			articles = new LinkedList<Article>();
		if(!articles.isEmpty())
			id = articles.size()+1;
		article.setArticleId(id);
		articles.add(article);
		return id;
	}

	@Override
	public List<Article> getAll() {
		return articles;
	}

	@Override
	public Article findById(int id) {
		Article article = null;
		for(Article a : articles)
			if(a.getArticleId() == id){
				article = a;
				break;
			}
		return article;
	}
}
