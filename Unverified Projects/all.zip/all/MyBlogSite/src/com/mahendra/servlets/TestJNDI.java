package com.mahendra.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class TestJNDI
 */
public class TestJNDI extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestJNDI() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/plain");
		PrintWriter out = response.getWriter();
		out.println("Performance JNDI Lookup...");
		try{
			InitialContext context = new InitialContext();
			Object obj = context.lookup("java:comp/env/jdbc/library");
			if(obj instanceof DataSource){
				out.println("Got resource object");
				DataSource ds = (DataSource)obj;
				Connection con=ds.getConnection();
				out.println("Connected to "+con.getMetaData().getDatabaseProductName());
			}
		}catch(NamingException | SQLException ex){
			ex.printStackTrace(out);
		}
		out.close();
		
		/*response.setContentType("text/plain");
		 PrintWriter out = response.getWriter();
		 Connection con;
		 try{
		 	con = ds.getConnection();
		 	out.println("Connected to "+con.getMetaData().getDatabaseProductName());
		 	}catch(NamingException | SQLException ex){
			ex.printStackTrace(out);
		}
		out.close();
		 */
	}

}
