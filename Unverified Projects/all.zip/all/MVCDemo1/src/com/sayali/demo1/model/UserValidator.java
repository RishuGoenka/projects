package com.sayali.demo1.model;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

public class UserValidator implements Validator {

	@Override
	public boolean supports(Class<?> arg0) {
		return arg0.isAssignableFrom(User.class);
		//return User.class.equals(args0);
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		User user = (User)arg0;
		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "userName","empty.username","Please enter username");
		ValidationUtils.rejectIfEmptyOrWhitespace(arg1, "password", "empty.username", "Please enter password");
		
		if(user.getPassword().trim().length()<8){
			arg1.rejectValue("password", "invalid.password", "Atleast 8 characters in password are required");
		}
	}

}
