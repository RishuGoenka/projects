package com.sayali.demo1.data;

import java.util.List;

import com.sayali.demo1.model.User;

public class UserDAO {
	private List<User> users;

	public List<User> getUsers() {
		return users;
	}

	public void setUsers(List<User> users) {
		this.users = users;
	}
	
	public void add(User user){
		users.add(user);
		System.out.println("New user added");
	}
}
