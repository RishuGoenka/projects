package com.sayali.demo1.controller;

import java.util.Date;
import javax.servlet.http.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class HelloController extends AbstractController{
	
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0,HttpServletResponse arg1)throws Exception{
		
		ModelAndView mv = new ModelAndView("/WEB-INF/views/result.jsp");
		Date today = new Date();
		String msg ="Welcome to Spring!";
		
		mv.addObject("msg",msg);
		mv.addObject("date",today);
		
		return mv;
	}
}
