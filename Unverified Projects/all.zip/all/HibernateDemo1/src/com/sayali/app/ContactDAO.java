package com.sayali.app;

import java.util.List;
import org.hibernate.*;
import com.sayali.models.Contact;

public class ContactDAO {
	private SessionFactory factory = null;
	
	
	
	public ContactDAO() {
		factory = HibernateUtil.getFactory();
	}

	public void save(Contact c){
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			session.save(c);
			tn.commit();
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}
	
	public void modify(Contact c){
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			session.update(c);
			tn.commit();
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}
	
	public void remove( short contactID){
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			Object c= session.get(Contact.class, contactID);
			if(c!=null){
				session.delete(c);
				System.out.println("Record deleted..!!");
			}else
				System.out.println("Record doesnt exists!!");
			tn.commit();
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}
	
	public List<Contact> findByName(String name){
		Session session =factory.openSession();
		List<Contact> contacts = null;
		//gets list of persistent object 
		contacts = session.createQuery("from Contact c where c.firstName = :nm or c.lastName = :nm").setString("nm", name).list();
		session.close();
		return contacts;// gets detached
		
	}
}
