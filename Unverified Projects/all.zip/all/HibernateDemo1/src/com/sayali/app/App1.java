package com.sayali.app;

import java.util.List;

import com.sayali.models.Contact;

public class App1 {

	public static void main(String[] args) {
		ContactDAO dao = new ContactDAO();
		dao.save(new Contact((short)101,"Sayali","Shedge","534354"));
		dao.save(new Contact((short)102,"Saya","Ddfgsdr","53754"));
		dao.save(new Contact((short)103,"Sana","Abc","531444"));
		dao.save(new Contact((short)104,"Sai","Xyz","534154"));
		
		List<Contact> contacts = dao.findByName("Abc");
		System.out.println("Found "+ contacts.size()+" Abc");
		
		for(Contact c:contacts)
			System.out.println(c.getFirstName()+" "+c.getLastName());

	}

}
