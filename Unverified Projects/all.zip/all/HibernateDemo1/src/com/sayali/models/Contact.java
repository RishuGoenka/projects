package com.sayali.models;

import java.io.Serializable;

public class Contact implements Serializable {
	
	private Short contactID;			//primary key must be serializable and can be done using Short 
	private String firstName,lastName;
	private String phone;
	
	public Contact() {
		super();
	}

	public Contact(Short contactID, String firstName, String lastName,
			String phone) {
		super();
		this.contactID = contactID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
	}

	public Short getcontactID() {
		return contactID;
	}

	public void setcontactID(Short contactID) {
		this.contactID = contactID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}	
}
