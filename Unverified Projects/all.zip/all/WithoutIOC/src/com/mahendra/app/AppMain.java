package com.mahendra.app;

import com.mahendra.dao.BookDAO;
import com.mahendra.dao.MemberDAO;
import com.mahendra.services.LibraryService;

public class AppMain {

	public static void main(String[] args) {
		
		BookDAO bookDao = new BookDAO();
		MemberDAO memberDao = new MemberDAO();
		
		LibraryService service = new LibraryService(bookDao,memberDao);
		service.doSomething();
		//Again after few seconds....
		service.doSomething();
		

	}

}
