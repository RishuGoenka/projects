package com.sayali.dao;


import org.hibernate.*;
import org.hibernate.criterion.Restrictions;

import com.sayali.app.HibernateUtil;
import com.sayali.models.Book;

public class BookDAO {
	
	private SessionFactory factory= HibernateUtil.getFactory();
	
	public Integer save(Book b){
		Session session = factory.openSession();
		Integer n=null;
		Transaction tn= session.getTransaction();
		System.out.println("Before try block "+tn.isActive());
		try{
			tn.begin();
			System.out.println("after begin "+tn.isActive());
			n= (Integer) session.save(b);			
			tn.commit();
		}catch(HibernateException e){
			if(tn!=null){
				tn.rollback();
				System.out.println("after rollback "+tn.isActive());
			}
		}
		return n;		
	}
	
	public void update(Book b){
		Session session = factory.openSession();
		Transaction tn= session.getTransaction();	
		try{
			tn.begin();
			session.update(b);			
			tn.commit();
		}catch(HibernateException e){
			if(tn!=null){
				tn.rollback();
				System.out.println("after rollback "+tn.isActive());
			}
		}
	}
	public Book getById(Integer id){
		Session session = factory.openSession();
		Book b= null;
		b=(Book)session.createCriteria(Book.class).add(Restrictions.eq("bookId", id)).list().get(0);
		return b;
	}
}
