package com.sayali.models;

import java.io.Serializable;

import javax.persistence.*;

@Entity @Table(name="books_2")
public class Book implements Serializable{
	@Id @Column(name="book_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer bookId;
	
	@Column(length=50)
	private String title;
	@Column(length=25)
	private String author;
	
	public Integer getVersion() {
		return version;
	}

	@Column(length=1)
	private String status;

	@Version
	private Integer version;
	
	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book(Integer bookId, String title, String author, String status) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.status = status;
	}

	

}
