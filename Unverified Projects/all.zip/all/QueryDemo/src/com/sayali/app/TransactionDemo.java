package com.sayali.app;

import com.sayali.dao.BookDAO;
import com.sayali.models.Book;

public class TransactionDemo {
	public static void main(String[] args) {
		BookDAO dao= new BookDAO();
		
		/* Book book = new Book();
		 book.setAuthor("Stephen Hawkings");
		 book.setStatus("A");
		 book.setTitle("The Universe in Nutshell");
		 
		 Integer id = dao.save(book);
		 System.out.println("Book saved with id : "+id);*/
		Book b=dao.getById(1);
		b.setTitle("Breif History of Time");
		dao.update(b);
		 
		 
	}
}
