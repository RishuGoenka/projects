package com.sayali.models;

import java.io.Serializable;
import java.util.Date;

public class Account implements Serializable {
	private Integer accountNo;
	private String accountHolder;
	private Date dateOfOpening;
	
	public Account(Integer accountNo, String accountHolder, Date dateOfOpening) {
		super();
		this.accountNo = accountNo;
		this.accountHolder = accountHolder;
		this.dateOfOpening = dateOfOpening;
	}
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Integer getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Integer accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountHolder() {
		return accountHolder;
	}
	public void setAccountHolder(String accountHolder) {
		this.accountHolder = accountHolder;
	}
	public Date getDateOfOpening() {
		return dateOfOpening;
	}
	public void setDateOfOpening(Date dateOfOpening) {
		this.dateOfOpening = dateOfOpening;
	}
}
