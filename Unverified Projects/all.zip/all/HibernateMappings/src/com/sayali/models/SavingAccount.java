package com.sayali.models;

public class SavingAccount extends Account{
	private Double minBalance;

	public Double getMinBalance() {
		return minBalance;
	}

	public void setMinBalance(Double minBalance) {
		this.minBalance = minBalance;
	}
	

}
