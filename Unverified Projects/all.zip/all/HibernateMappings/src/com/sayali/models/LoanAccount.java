package com.sayali.models;

public class LoanAccount extends Account{
	private Double installment;

	public Double getInstallment() {
		return installment;
	}

	public void setInstallment(Double installment) {
		this.installment = installment;
	}
	
	
}
