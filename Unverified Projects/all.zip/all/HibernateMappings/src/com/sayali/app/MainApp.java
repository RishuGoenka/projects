package com.sayali.app;

import java.util.Date;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import com.sayali.models.LoanAccount;
import com.sayali.models.SavingAccount;

public class MainApp {

	public static void main(String[] args) {
		
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session =factory.openSession();
		Transaction t = session.getTransaction();
		
		SavingAccount acc1 = new SavingAccount();
		acc1.setAccountNo(1001);
		acc1.setAccountHolder("Devdas");
		acc1.setDateOfOpening(new Date());
		acc1.setMinBalance(1000.00);
		
		LoanAccount acc2 = new LoanAccount();
		acc2.setAccountNo(1034);
		acc2.setAccountHolder("Paro");
		acc2.setDateOfOpening(new Date());
		acc2.setInstallment(14063D);
		
		try{
			t.begin();
			session.save(acc1);
			session.save(acc2);
			t.commit();
			System.out.println("Both records have been saved");
		}catch(HibernateException ex){
			ex.printStackTrace();
			if(t!=null)
				t.rollback();
		}
		session.close();
	}
}
