package com.sayali.app;



import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import com.sayali.models.Planet;
import com.sayali.models.PlanetID;



public class MainApp {

	public static void main(String[] args) {
		
		SessionFactory factory = new Configuration().configure().buildSessionFactory();
		Session session =factory.openSession();
		Transaction t = session.getTransaction();
		
		Planet planet= new Planet();
		PlanetID id= new PlanetID();
		id.setPlanetId(3);
		id.setStarId(101245);
		planet.setId(id);
		planet.setPlanetClass("Terra");
		
		
		try{
			t.begin();
			session.save(planet);
			t.commit();
			System.out.println("record saved");
		}catch(HibernateException ex){
			ex.printStackTrace();
			if(t!=null)
				t.rollback();
		}
		session.close();
	}
}
