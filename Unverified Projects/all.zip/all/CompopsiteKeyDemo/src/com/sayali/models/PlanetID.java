package com.sayali.models;

import java.io.Serializable;

public class PlanetID implements Serializable {
	private Integer planetId;
	private Integer starId;
	public Integer getPlanetId() {
		return planetId;
	}
	public void setPlanetId(Integer planetId) {
		this.planetId = planetId;
	}
	public Integer getStarId() {
		return starId;
	}
	public void setStarId(Integer starId) {
		this.starId = starId;
	}
	
	
}
