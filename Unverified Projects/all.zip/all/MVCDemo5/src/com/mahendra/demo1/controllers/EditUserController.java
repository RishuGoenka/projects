package com.mahendra.demo1.controllers;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.mahendra.demo1.data.UserDAO;
import com.mahendra.demo1.model.User;

public class EditUserController extends SimpleFormController {
	private UserDAO dao;
	
	@Override
	protected ModelAndView onSubmit(Object command, BindException errors)
			throws Exception {
		//call method to edit
		User user = (User)command;
		dao.update(user);
		return new ModelAndView(getSuccessView()).addObject("msg","Info changed");
	}

	@Override
	protected ModelAndView showForm(HttpServletRequest request,
			HttpServletResponse response, BindException errors)
			throws Exception {
		String name = request.getParameter("name");
		User user = dao.findByName(name);
		ModelAndView mv = new ModelAndView(getFormView());
		mv.addObject("user", user);
		return mv;
	}

	public void setDao(UserDAO dao) {
		this.dao = dao;
	}
	
}
