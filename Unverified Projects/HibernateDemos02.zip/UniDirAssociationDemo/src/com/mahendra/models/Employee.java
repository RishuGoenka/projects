package com.mahendra.models;

import java.io.Serializable;
import java.util.Date;

public class Employee implements Serializable {
	/** 
EMPNO    NOT NULL NUMBER(38)   
NAME              VARCHAR2(10) 
JOB               VARCHAR2(9)  
BOSS              NUMBER(38)   
HIREDATE          VARCHAR2(12) 
SALARY            NUMBER(7,2)  
COMM              NUMBER(7,2)  
DEPTNO            NUMBER(38)  
	 */
	private Integer empNo;
	private String name;
	private String job;
	private Integer boss;
	private Date hiredate;
	private Float salary;
	private Float comm;
	//Add reference to OWNED class 
	//instead of foreign key field
	private Department department;
	
	
	public Integer getEmpNo() {
		return empNo;
	}
	public void setEmpNo(Integer empNo) {
		this.empNo = empNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public Integer getBoss() {
		return boss;
	}
	public void setBoss(Integer boss) {
		this.boss = boss;
	}
	public Date getHiredate() {
		return hiredate;
	}
	public void setHiredate(Date hiredate) {
		this.hiredate = hiredate;
	}
	public Float getSalary() {
		return salary;
	}
	public void setSalary(Float salary) {
		this.salary = salary;
	}
	public Float getComm() {
		return comm;
	}
	public void setComm(Float comm) {
		this.comm = comm;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(Integer empNo, String name, String job, Integer boss,
			Date hiredate, Float salary, Float comm, Department department) {
		super();
		this.empNo = empNo;
		this.name = name;
		this.job = job;
		this.boss = boss;
		this.hiredate = hiredate;
		this.salary = salary;
		this.comm = comm;
		this.department = department;
	}
	
	
}
