package com.mahendra.models;

import java.util.List;

public interface ArticleDAO {

	int add(Article article);
	List<Article> getAll();
	Article findById(int id);
	
}
