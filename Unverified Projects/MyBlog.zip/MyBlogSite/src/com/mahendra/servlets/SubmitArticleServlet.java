package com.mahendra.servlets;

import java.io.IOException;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mahendra.models.Article;
import com.mahendra.models.ArticleDAO;

/**
 * Servlet implementation class SubmitArticleServlet
 */
public class SubmitArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SubmitArticleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname=request.getParameter("uname");
		String text = request.getParameter("text");
		Date now = new Date();
		
		Article article = new Article();
		article.setAuthor(uname);
		article.setText(text);
		article.setDateOfPost(now);
		
		ArticleDAO dao = (ArticleDAO)getServletContext().getAttribute("articleDao");
		dao.add(article);
		//Redirect client to home page!!!
		response.sendRedirect("index.htm");
	}

}
