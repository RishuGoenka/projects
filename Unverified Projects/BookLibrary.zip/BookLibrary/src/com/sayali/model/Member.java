package com.sayali.model;

import java.io.Serializable;

public class Member implements Serializable{
	private Integer member_id;
	private String member_name;
	private Integer mobileNo;
	private Integer noOfBooks;
	
	public Member() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Member(Integer member_id, String member_name, Integer mobileNo,
			Integer noOfBooks) {
		super();
		this.member_id = member_id;
		this.member_name = member_name;
		this.mobileNo = mobileNo;
		this.noOfBooks = noOfBooks;
	}

	public Integer getMember_id() {
		return member_id;
	}

	public void setMember_id(Integer member_id) {
		this.member_id = member_id;
	}

	public String getMember_name() {
		return member_name;
	}

	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}

	public Integer getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Integer mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Integer getNoOfBooks() {
		return noOfBooks;
	}

	public void setNoOfBooks(Integer noOfBooks) {
		this.noOfBooks = noOfBooks;
	}	
}
