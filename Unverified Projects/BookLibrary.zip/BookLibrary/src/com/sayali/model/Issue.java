package com.sayali.model;

import java.io.Serializable;
import java.util.Date;

public class Issue implements Serializable {
	private Integer issue_id;
	private Member member_id;
	private Book book_id;
	private Date dateOfIssue;
	private Date dateOfReturn;
		
	public Issue() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Issue(Integer issue_id, Member member_id, Book book_id,
			Date dateOfIssue, Date dateOfReturn) {
		super();
		this.issue_id = issue_id;
		this.member_id = member_id;
		this.book_id = book_id;
		this.dateOfIssue = dateOfIssue;
		this.dateOfReturn = dateOfReturn;
	}

	public Integer getIssue_id() {
		return issue_id;
	}

	public void setIssue_id(Integer issue_id) {
		this.issue_id = issue_id;
	}

	public Member getMember_id() {
		return member_id;
	}

	public void setMember_id(Member member_id) {
		this.member_id = member_id;
	}

	public Book getBook_id() {
		return book_id;
	}

	public void setBook_id(Book book_id) {
		this.book_id = book_id;
	}

	public Date getDateOfIssue() {
		return dateOfIssue;
	}

	public void setDateOfIssue(Date dateOfIssue) {
		this.dateOfIssue = dateOfIssue;
	}

	public Date getDateOfReturn() {
		return dateOfReturn;
	}

	public void setDateOfReturn(Date dateOfReturn) {
		this.dateOfReturn = dateOfReturn;
	}
	
}
