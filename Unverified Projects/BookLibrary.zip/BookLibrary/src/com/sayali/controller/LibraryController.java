package com.sayali.controller;

import java.text.ParseException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.sayali.model.Book;
import com.sayali.model.Issue;
import com.sayali.model.Member;
import com.sayali.service.BookService;
import com.sayali.service.IssueService;
import com.sayali.service.MemberService;


public class LibraryController extends MultiActionController {
	private MemberService memberservice;
	private BookService bookservice;
	private IssueService issueservice;
	

	public void setIssueservice(IssueService issueservice) {
		this.issueservice = issueservice;
	}

	public void setBookservice(BookService bookservice) {
		this.bookservice = bookservice;
	}

	public void setMemberservice(MemberService memberservice) {
		this.memberservice = memberservice;
	}

	public ModelAndView addnewmember(HttpServletRequest request,HttpServletResponse response){
		System.out.println("adding new member");
		ModelAndView mv = new ModelAndView("Member");
		return mv;
	}
	/*Checking whether member already exists or not 
		if yes then return its id
		else add member
	 */
	public ModelAndView addmember(HttpServletRequest request,HttpServletResponse response){
		System.out.println("adding "+request.getParameter("name"));
		if(memberservice.find(request.getParameter("name"),Integer.parseInt(request.getParameter("mobno")))){
			int id=(memberservice.findId(request.getParameter("name"),Integer.parseInt(request.getParameter("mobno"))));
			request.setAttribute("msg", "You are already registered with member id"+id);
			ModelAndView mv = new ModelAndView("index");
			return mv;
		}
		else{
			Member member = new Member();
			String name=request.getParameter("name");
			int mobno=Integer.parseInt(request.getParameter("mobno"));
			member.setMember_name(name);
			member.setMobileNo(mobno);
			memberservice.addmember(member);
			int id=memberservice.findId(name, mobno);
			request.setAttribute("msg", "Your id is "+id);
			System.out.println("member added");
			ModelAndView mv = new ModelAndView("index");
			return mv;
		}
	}
	
	// calling add book page
	public ModelAndView addbooks(HttpServletRequest request,HttpServletResponse response){
		ModelAndView mv = new ModelAndView("AddBook");
		return mv;
	}
	
	/*Checking whether book already exists or not 
		if yes then go back to index page id
		else add book
	 */
	public ModelAndView addbook(HttpServletRequest request,HttpServletResponse response){
		System.out.println(request.getParameter("bookname")+" "+request.getParameter("authorname"));
		String bookname=request.getParameter("bookname");
		String authorname=request.getParameter("authorname");
		if(bookservice.findbook(bookname,authorname)){
			request.setAttribute("notnew", "BookAlreadyExists");
			ModelAndView mv = new ModelAndView("index");
			return mv;
		}else{
			Book book = new Book();
			book.setBook_name(request.getParameter("bookname"));
			book.setBook_author(request.getParameter("authorname"));
			bookservice.addbook(book);
			request.setAttribute("new", "Book Added");
			ModelAndView mv =new ModelAndView("index");
			return mv;
		}
	}
	
	//find whether member id is valid
	public ModelAndView member(HttpServletRequest request,HttpServletResponse response){		
		if(memberservice.find(Integer.parseInt(request.getParameter("memberid")))){
			
			request.setAttribute("memberid", request.getParameter("memberid"));
			ModelAndView mv= new ModelAndView("issuereturn");
			return mv;
		}
		return null;
	}
	
	//calling issue page
	public ModelAndView issue(HttpServletRequest request,HttpServletResponse response){
		request.setAttribute("memberid",Integer.parseInt(request.getParameter("memberid")));
		ModelAndView mv = new ModelAndView("issue");
		return mv;
	}
	
	//calling return page
	public ModelAndView returnbook(HttpServletRequest request,HttpServletResponse response){
		request.setAttribute("memberid",Integer.parseInt(request.getParameter("memberid")));
		ModelAndView mv = new ModelAndView("return");
		return mv;
	}
	
	/*
	 * finding book
	 * if exist check for its availablity
	 * 	if available issue
	 * 	else dont
	 */
	public ModelAndView findBook(HttpServletRequest request,HttpServletResponse response) throws ParseException{
		String name =request.getParameter("name");
		int memberId= Integer.parseInt(request.getParameter("memberid"));
		if(bookservice.findByName(name)){
			if(bookservice.bookstatus(name)){
				Member member= new Member();
				member.setMember_id(memberId);
				Book book = new Book();
				book.setBook_id(bookservice.bookId(name));
				Issue issue = new Issue();
				issue.setMember_id(member);
				issue.setBook_id(book);
				issue.setDateOfIssue(new Date());
				Date returndate = bookservice.getreturndate();
				issue.setDateOfReturn(returndate);
				issueservice.issuebook(issue);		
				bookservice.changestatus(bookservice.findbook(name));
				ModelAndView mv = new ModelAndView("issued");
				return mv;			
			}else{
				request.setAttribute("notavailable","The book is already issued");
				ModelAndView mv = new ModelAndView("issue");
				return mv;
			}
		}else{
			request.setAttribute("notfound", "Book Not Found with name " + request.getParameter("name"));
			ModelAndView mv = new ModelAndView("issue");
			return mv;
		}
	}
	
	public ModelAndView returnid(HttpServletRequest request,HttpServletResponse response){
		int book_id=Integer.parseInt(request.getParameter("bookid"));
		if(bookservice.find(book_id)){
			System.out.println(book_id);
			int fine=issueservice.fine(book_id);
			request.setAttribute("fine", fine);
			ModelAndView mv = new ModelAndView("returned");
			return mv;
		}else{
			request.setAttribute("notfound", "Book with id " + request.getParameter("id")+" does not belong to MyLibrary ");
			ModelAndView mv = new ModelAndView("issue");
			return mv;
		}
	}
	
}
