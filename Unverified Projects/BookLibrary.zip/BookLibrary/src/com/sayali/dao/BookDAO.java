package com.sayali.dao;

import java.io.Serializable;

import com.sayali.model.Book;

public interface BookDAO {

	public boolean findbook(String name, String authorname);
	public Serializable addbook(Book book);
	public boolean findBookId(Integer bookid);
	public boolean findByName(String name);
	public boolean bookstatus(String name);
	public Integer bookId(String name);
	public void changestatus(Book book);
	public Book findbook(String name);
}
