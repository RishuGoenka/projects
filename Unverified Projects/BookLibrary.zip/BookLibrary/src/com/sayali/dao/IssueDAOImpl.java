package com.sayali.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.sayali.model.Book;
import com.sayali.model.Issue;

public class IssueDAOImpl implements IssueDAO {
	private HibernateTemplate template;
	

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	//Issue a book
	public Serializable issuebook(Issue issue) {
		Serializable id = template.save(issue);
		return id;
		
	}
	
	public Issue findBookById(int book_id) {
		List issue = template.find("from Issue i where i.book_id.book_id=?", book_id);
		return (Issue)issue.get(0);
	}
	
	
	

}
