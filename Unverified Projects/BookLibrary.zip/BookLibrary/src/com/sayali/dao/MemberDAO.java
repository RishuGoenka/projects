package com.sayali.dao;

import java.io.Serializable;

import com.sayali.model.Member;

public interface MemberDAO {

	boolean findmember(Integer memberid);
	public Serializable addmember(Member member);
	public boolean findmember(String name, int mobno);
	int findId(String name, int mobno);

}
