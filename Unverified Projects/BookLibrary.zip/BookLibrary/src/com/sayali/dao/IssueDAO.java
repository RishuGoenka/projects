package com.sayali.dao;

import java.io.Serializable;

import com.sayali.model.Issue;

public interface IssueDAO {

	public Serializable issuebook(Issue issue);

	public Issue findBookById(int book_id);

}
