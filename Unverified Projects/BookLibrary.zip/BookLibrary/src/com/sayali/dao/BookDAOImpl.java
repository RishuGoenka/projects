package com.sayali.dao;

import java.io.Serializable;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.sayali.model.Book;

public class BookDAOImpl implements BookDAO {

	private HibernateTemplate template;
	

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	//find whether book with bookname and authorname exist or not
	public boolean findbook(String bookname,String authorname) {
		List book = template.find("from Book b where b.book_name=? and b.book_author=?", bookname,authorname);
		if(book.size()!=0)
			return true;
		return false;
	}

	//Add book to library
	public Serializable addbook(Book book) {
		Serializable id = template.save(book);
		System.out.println(id);
		return id;
	}

	//find whether book with bookid exist or not
	public boolean findBookId(Integer bookid) {
		List book = template.find("from Book b where b.book_id=?", bookid);
		if(book.size()!=0)
			return true;
		return false;
	}

	//find whether book with bookname or authorname exist or not
	public boolean findByName(String name) {
		List book = template.find("from Book b where b.book_name=? or b.book_author=?", name,name);
		if(book.size()!=0)
			return true;
		return false;
	}

	//check whether book is available or not 
	@Override
	public boolean bookstatus(String name) {
		List book = template.find("from Book b where (b.book_name=? or b.book_author=?) and b.status='A'", name,name);
		if(book.size()!=0)
			return true;
		return false;
	}
	
	//return bookid for bookname or authorname 
	@Override
	public Integer bookId(String name) {
		List book = template.find("select b.book_id from Book b where b.book_name=? or b.book_author=?", name,name);
		return (Integer) book.get(0);
	}

	//Change status of issued book to not available
	public void changestatus(Book book) {
		book.setStatus('N');
		template.saveOrUpdate(book);
		
	}
	
	//Find book with bookname or authorname
	public Book findbook(String name) {
		List book = template.find("from Book b where b.book_name=? or b.book_author=?", name,name);
		return  (Book) book.get(0);
	}
}
