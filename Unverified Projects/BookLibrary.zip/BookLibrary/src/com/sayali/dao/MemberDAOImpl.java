package com.sayali.dao;


import java.io.Serializable;
import java.util.List;
import org.springframework.orm.hibernate3.HibernateTemplate;
import com.sayali.model.Member;

public class MemberDAOImpl implements MemberDAO {

	private HibernateTemplate template;
	

	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}

	//Find whether member with memberid exists or not
	public boolean findmember(Integer memberid) {
	List member= template.find("from Member m where m.member_id=?", memberid);
	if(member.size()!=0)
		return true;
	return false;
	}
	
	//Add member to library
	public Serializable addmember(Member member){
		Serializable id = template.save(member);
		System.out.println(id);
		return id;
	}

	//find whether member with membername and mobileno exists or not 
	public boolean findmember(String name, int mobno) {
		List member= template.find("from Member m where m.member_name=? and m.mobileNo=?", name,mobno);
		if(member.size()!=0)
			return true;
		return false;
	}

	//find id of member with name and mobileno 
	public int findId(String name, int mobno) {
		System.out.println("in find");
		List member = template.find("select m.member_id from Member m  where m.member_name=? and m.mobileNo=?",name,mobno);
		System.out.println(member.get(0));
		return  (int) member.get(0);
	}
}
