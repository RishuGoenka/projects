package com.sayali.service;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sayali.dao.BookDAO;
import com.sayali.model.Book;

public class BookService {

	private BookDAO bookdao;
	public void setBookdao(BookDAO bookdao) {
		this.bookdao = bookdao;
	}
	
	@Transactional(propagation=Propagation.REQUIRED)
	public boolean findbook(String bookname, String authorname) {
		if(bookdao.findbook(bookname,authorname))
			return true;
		return false;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public void addbook(Book book) {
		Serializable id=  bookdao.addbook(book);		
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public boolean find(Integer bookid) {
		if(bookdao.findBookId(bookid))
			return true;
		return false;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public boolean findByName(String name) {
		if(bookdao.findByName(name))
			return true;
		return false;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public boolean bookstatus(String name) {
		if(bookdao.bookstatus(name))
			return true;
		return false;
	}

	public Integer bookId(String name) {	
		return bookdao.bookId(name);
	}

	public Date getreturndate() throws ParseException {
		GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, 7);		                 
        return cal.getTime();
	}

	public void changestatus(Book book) {
		bookdao.changestatus(book);
		
	}
	public Book findbook(String name){
		return bookdao.findbook(name);
	}


}
