package com.sayali.service;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sayali.dao.BookDAO;
import com.sayali.dao.IssueDAO;
import com.sayali.model.Book;
import com.sayali.model.Issue;

public class IssueService {
	private IssueDAO issuedao;
	
	public void setIssuedao(IssueDAO issuedao) {
		this.issuedao = issuedao;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public void issuebook(Issue issue) {
		 	Serializable id = issuedao.issuebook(issue);
	}

	public int fine(int book_id) {
		Issue issue = issuedao.findBookById(book_id);
		Date date1= issue.getDateOfIssue();
		Date date2= issue.getDateOfReturn();
		System.out.println(date1+" "+date2);
		
	
		long miliSecondForDate1 = date1.getTime();
		long miliSecondForDate2 = date2.getTime();
		
		long diffInMilis = miliSecondForDate1 - miliSecondForDate2;
		
		long days = diffInMilis / (24 * 60 * 60 * 1000);
		if(days>7){
			int fine = (int) (5*days);
			return fine;
		}
		return 0;
		
	}

}
