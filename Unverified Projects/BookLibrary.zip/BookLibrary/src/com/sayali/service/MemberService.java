package com.sayali.service;

import java.io.Serializable;

import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sayali.dao.MemberDAO;
import com.sayali.model.Member;

public class MemberService {
	private MemberDAO memberdao;
	
	
	public void setMemberdao(MemberDAO memberdao) {
		this.memberdao = memberdao;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public boolean find(Integer memberid) {
		if(memberdao.findmember(memberid))
			return true;
		return false;
	}
	
	@Transactional(propagation=Propagation.REQUIRED)
	public void addmember(Member member) {
		Serializable id=  memberdao.addmember(member);
		
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public boolean find(String name, int mobno) {
		if(memberdao.findmember(name,mobno))
			return true;
		return false;
	}

	@Transactional(propagation=Propagation.REQUIRED)
	public int findId(String name, int mobno) {
		
		return memberdao.findId(name,mobno);
	}
	
}
