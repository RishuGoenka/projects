package com.sayali.service;


import com.sayali.dao.ItemsDAO;
import com.sayali.dao.OrderedItemDAO;
import com.sayali.model.ItemDetails;
import com.sayali.model.OrderedItems;


public class OrderedItemsService {
	
	OrderedItemDAO dao = null;

	ItemsService service= new ItemsService();
public boolean addtocart(OrderedItems oritem) {
		System.out.println(oritem.getCid());
		dao = new OrderedItemDAO();
		int iid=oritem.getIid();
		System.out.println("iid in somethin=="+iid);
		ItemDetails item = service.finditems(iid);
		System.out.println("items "+item.getName());
		if(item.getQuantityavail()< oritem.getQuantity()){
			
			System.out.println("serviceout of stock"+item.getQuantityavail()+" "+oritem.getQuantity());
			return false;
		}
		
		oritem.setPrice(oritem.getPrice()*oritem.getQuantity());
		dao.save(oritem);
		System.out.println("item added to cart price updated");
		return true;
		
	}
}
