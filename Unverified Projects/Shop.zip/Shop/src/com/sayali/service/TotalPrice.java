package com.sayali.service;

import com.sayali.dao.OrderedItemDAO;

public class TotalPrice {
	OrderedItemDAO dao = new OrderedItemDAO();
	
	public double totalprice(int cid) {	
		double totalprice = dao.total(cid);
		System.out.println(totalprice);
		return totalprice;
	}
	
}
