package com.sayali.service;

import java.util.List;

import com.sayali.dao.ItemsDAO;
import com.sayali.model.ItemDetails;



public class ItemsService {
	
	ItemsDAO itemdao = null;
	public ItemsService() {
		
	}
	
	//calling dao to add item in shop
	public void additems(ItemDetails item) {	
		itemdao = new ItemsDAO();
		itemdao.save(item);
		System.out.println("item added to shop");
		
	}
	
	//calling dao to modify item in shop
	public void modifyitems(ItemDetails item) {
		itemdao = new ItemsDAO();
		itemdao.modify(item);
	}

	//Calling dao to delete item
	public void deleteitems(int id ){
		itemdao = new ItemsDAO();
		itemdao.delete(id);
	}
	
	//Calling dao to fing items
	public ItemDetails finditems(int id) {
		System.out.println("id=="+id);
		itemdao = new ItemsDAO();
		System.out.println("finditems");
		return  itemdao.findbyid(id);
		
	}
}
