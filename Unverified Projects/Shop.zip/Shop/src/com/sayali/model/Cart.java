package com.sayali.model;

import java.io.Serializable;

public class Cart implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2151246531637103880L;
	private Integer iid,quantity;
	private Double price;
	private String iname;
	
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cart(Integer iid, Integer quantity, Double price, String iname) {
		super();
		this.iid = iid;
		this.quantity = quantity;
		this.price = price;
		this.iname = iname;
	}

	public Integer getIid() {
		return iid;
	}

	public void setIid(Integer iid) {
		this.iid = iid;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getIname() {
		return iname;
	}

	public void setIname(String iname) {
		this.iname = iname;
	}
}
