package com.sayali.model;

import java.io.Serializable;

public class ItemDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3565524199665458543L;
	private int iid;
	private int quantityavail;
	private double price;
	private String  name,category,brand,size,colour,desc;
	
	
	public ItemDetails(int iid, int quantityavail, double price,
			String name,String category, String brand, String size, String colour,
			String desc) {
		super();
		this.iid = iid;
		this.quantityavail=quantityavail;
		this.price = price;
		this.name= name;
		this.category = category;
		this.brand = brand;
		this.size = size;
		this.colour = colour;
		this.desc = desc;
	}
	
	

	public ItemDetails() {
		super();
		// TODO Auto-generated constructor stub
	}



	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getIid() {
		return iid;
	}


	public void setIid(int iid) {
		this.iid = iid;
	}

	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getSize() {
		return size;
	}


	public void setSize(String size) {
		this.size = size;
	}


	public String getColour() {
		return colour;
	}


	public void setColour(String colour) {
		this.colour = colour;
	}


	public String getDesc() {
		return desc;
	}


	public void setDesc(String desc) {
		this.desc = desc;
	}



	public int getQuantityavail() {
		return quantityavail;
	}



	public void setQuantityavail(int quantityavail) {
		this.quantityavail = quantityavail;
	}
}
