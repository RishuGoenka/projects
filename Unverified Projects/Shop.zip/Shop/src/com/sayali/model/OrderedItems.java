package com.sayali.model;

public class OrderedItems {
	private int cid, iid,quantity;
	private double price;
	
	public OrderedItems(int cid, int iid, int quantity, double price) {
		super();
		this.cid = cid;
		this.iid = iid;
		this.quantity = quantity;
		this.price = price;
	}

	public OrderedItems() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public int getIid() {
		return iid;
	}

	public void setIid(int iid) {
		this.iid = iid;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
}
