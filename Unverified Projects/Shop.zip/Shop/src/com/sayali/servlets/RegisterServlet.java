package com.sayali.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sayali.dao.CustomerDAO;
import com.sayali.model.Customer;



/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("in servlet");
		
		 
		 Customer customer = new Customer();
		 String cid=request.getParameter("cid");
		 customer.setCid(Integer.parseInt(cid));
		 customer.setCname(request.getParameter("cname"));
		 customer.setAddress(request.getParameter("address"));
		 customer.setCity(request.getParameter("city"));
		 customer.setState(request.getParameter("state"));
		 customer.setCountry(request.getParameter("country"));
		 String zip =request.getParameter("zip");
		 customer.setZip(Integer.parseInt(zip));
		 String mobno =request.getParameter("mobno");
		 customer.setMobno(Integer.parseInt(mobno));
		 customer.setEmail(request.getParameter("email"));
		 customer.setUsername(request.getParameter("username"));
		 customer.setPassword(request.getParameter("password"));
		 CustomerDAO custDAO= new CustomerDAO();
		 if(custDAO.findById(customer.getCid())){
			 custDAO.save(customer);
			 response.sendRedirect("mycart.jsp");
			 System.out.println("Welcome");
		 }else{
		 System.out.println("Customer id already exists..!!");
		 }		 
	}

}
