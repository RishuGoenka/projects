package com.sayali.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sayali.dao.OrderedItemDAO;
import com.sayali.model.Customer;
import com.sayali.model.ItemDetails;
import com.sayali.model.OrderedItems;
import com.sayali.service.ItemsService;
import com.sayali.service.OrderedItemsService;

/**
 * Servlet implementation class OrderedItemsServlet
 */
public class OrderedItemsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderedItemsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		OrderedItemsService item = new OrderedItemsService();
		OrderedItems oritem = new OrderedItems();
		String[] items= request.getParameterValues("items");
		ItemDetails myitem=  new ItemDetails();
	
		response.setContentType("text/html");	
		ItemsService serv = new ItemsService();
		for(String s: items){
			myitem =serv.finditems(Integer.parseInt(s));
			System.out.println( myitem.getName());
			String quantity= request.getParameter(myitem.getName());
			oritem.setQuantity(Integer.parseInt(quantity));
			oritem.setCid(Integer.parseInt(request.getParameter("cid")));	
			oritem.setPrice( myitem.getPrice());
			oritem.setIid(Integer.parseInt(s));
			System.out.println("order servllet"+oritem);
			boolean check=item.addtocart(oritem);
			System.out.println(check);
			if(check==false){
				System.out.println("out of stock");
				request.setAttribute("msg","Out of Stock");
				RequestDispatcher view=request.getRequestDispatcher("result.jsp");
				view.forward(request, response);
			}else{
				System.out.println("item added to cart");		
			}
			response.sendRedirect("mycart.jsp");
		}		
	}

}
