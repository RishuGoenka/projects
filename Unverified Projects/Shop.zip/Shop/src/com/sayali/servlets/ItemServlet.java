package com.sayali.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sayali.model.ItemDetails;
import com.sayali.service.ItemsService;

/**
 * Servlet implementation class ItemServlet
 */
public class ItemServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	ItemDetails item = null;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ItemServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	
		ItemsService service = new ItemsService();
		
		if(request.getParameter("add") != null){
			item = new ItemDetails();
			String id = request.getParameter("iid");
			item.setIid(Integer.parseInt(id));
			item.setName(request.getParameter("iname"));
			item.setCategory(request.getParameter("category"));
			item.setBrand(request.getParameter("brand"));
			String price = request.getParameter("price");
			item.setPrice(Double.parseDouble(price));
			item.setSize(request.getParameter("size"));
			item.setColour(request.getParameter("colour"));
			item.setDesc(request.getParameter("description"));
			item.setQuantityavail(Integer.parseInt(request.getParameter("quantityavail")));
			//System.out.println(id);
			service.additems(item);
			response.sendRedirect("item.jsp");
		}
		
		if(request.getParameter("modify")!=null){
			ItemDetails item = new ItemDetails();
			String id = request.getParameter("iid");
			item.setIid(Integer.parseInt(id));
			item.setName(request.getParameter("iname"));
			item.setCategory(request.getParameter("category"));
			item.setBrand(request.getParameter("brand"));
			String price = request.getParameter("price");
			item.setPrice(Double.parseDouble(price));
			item.setSize(request.getParameter("size"));
			item.setColour(request.getParameter("colour"));
			item.setDesc(request.getParameter("description"));
			item.setQuantityavail(Integer.parseInt(request.getParameter("quantityavail")));
			service.modifyitems(item);
			response.sendRedirect("item.jsp");
		}
		if(request.getParameter("delete")!=null){
			int id = Integer.parseInt(request.getParameter("iid1"));
			System.out.println(id);
			service.deleteitems(id);
			
			//response.sendRedirect("item.jsp");
		}
		if(request.getParameter("find")!=null){
			int id = Integer.parseInt(request.getParameter("iid2"));
			 item = service.finditems(id);
			if(item==null)
				System.out.println("Item not found");
			else
				System.out.println("Item Found");
		}
	}

}
