package com.sayali.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import javax.servlet.http.HttpSession;

import com.sayali.dao.OrderedItemDAO;
import com.sayali.model.Cart;
import com.sayali.model.Customer;
import com.sayali.service.TotalPrice;

/**
 * Servlet implementation class CartServlet
 */
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
		System.out.println(request.getParameter("iid"));
		HttpSession session=request.getSession();
		Customer customer=(Customer) session.getAttribute("user");
		TotalPrice tprice=new TotalPrice();
		//getting list of products in cart
		if(request.getParameter("showcart") != null){
			OrderedItemDAO cartdao = new OrderedItemDAO();
			List<Cart> cart = new ArrayList<Cart>();
			cart = (ArrayList<Cart>) cartdao.getAllById(Integer.parseInt(request.getParameter("cid")));
			request.setAttribute("list", cart);
			request.getSession().setAttribute("list", cart);
			if(cart.size()==0){
				request.setAttribute("msg", "No items incart");
				RequestDispatcher mycart = request.getRequestDispatcher("listcart.jsp");
				mycart.forward(request, response);	
			}else{
			
			double totalprice=tprice.totalprice(customer.getCid());
			request.setAttribute("totalprice", totalprice);
			RequestDispatcher mycart = request.getRequestDispatcher("listcart.jsp");
			mycart.forward(request, response);	
			}
		}
		
		//Deleting products from cart
		if(request.getParameter("iid") != null){
			System.out.println("in delete servlet");
			OrderedItemDAO cartdao = new OrderedItemDAO();
			cartdao.delete(Integer.parseInt(request.getParameter("iid")),customer.getCid());
		}
	}

}
