
package com.sayali.dao;

import java.util.List;
import org.hibernate.*;
import com.sayali.web.HibernateUtil;
import com.sayali.model.Customer;


public class CustomerDAO {
	private SessionFactory factory = null;
	//Constructor to connect to db
	public CustomerDAO() {
		super();
		factory = HibernateUtil.getFactory();
	}

	//Add new Customer
	public void save(Customer customer){
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			session.save(customer);
			tn.commit();
			System.out.println(" Record created");
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}
	
	//modify customer details
	public void modify(Customer customer){
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			session.update(customer);
			tn.commit();
			System.out.println("Record updated");
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}

	//Find customer
	public Customer findByUsername(String username) {
		Session session =factory.openSession();
		Customer customer = null;
		customer = (Customer) session.createQuery("from Customer c where c.username = :nm").setString("nm", username).uniqueResult();				
		return customer;	
	}
	
	public boolean findById(Integer cid){
		Session session =factory.openSession();
		List<Customer> customer = null;
		customer = session.createQuery("from Customer c where c.cid = :nm").setInteger("nm", cid).list();	
		System.out.println(customer);
		if(customer.size()==0)
			return true;
		return false;
	}
}
