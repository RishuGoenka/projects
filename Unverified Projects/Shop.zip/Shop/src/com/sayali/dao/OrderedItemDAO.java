package com.sayali.dao;

import java.util.ArrayList;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.sayali.model.Cart;
import com.sayali.model.OrderedItems;
import com.sayali.web.HibernateUtil;

public class OrderedItemDAO {
	private SessionFactory factory = null;
	
	public OrderedItemDAO() {
		super();
		factory = HibernateUtil.getFactory();
	}
	
	//Adding products to cart
	public void save(OrderedItems or_item){
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			session.save(or_item);
			tn.commit();
			System.out.println(" Record created");
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}
	
	//Getting list of products in cart by cid 
	public  List<Cart> getAllById(int cid){
		Session session =factory.openSession();
		List<Cart> cart =new ArrayList<Cart>();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
		//	cart =  session.createQuery("select o.iid,i.name,o.quantity,o.price from ItemDetails i, OrderedItems o where o.iid=i.iid AND o.cid=?" ).setInteger(0,cid).list();			
			Query q = session.createQuery("select new com.sayali.model.Cart (o.iid,o.quantity,o.price,i.name) from ItemDetails i, OrderedItems o where o.iid=i.iid AND o.cid=?").setInteger(0,cid);
			cart =q.list();
			for(Cart c:cart){
				System.out.println("items");
				System.out.println(c.getIname());
			}
			tn.commit();
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
		return cart;
	}
	 
	//Deleting items from cart
	public void delete (int iid,int cid){
		System.out.println("in delete");
		Session session =factory.openSession();
		Transaction tn= null;
		try{
			tn=session.beginTransaction();
			System.out.println(iid+" and "+cid);
			if(iid!=0){
				Query query=session.createQuery("delete from OrderedItems o where o.iid=? and o.cid=?").setString(0, ""+iid).setString(1, ""+cid);
				query.executeUpdate();
				System.out.println("Record deleted..!!");
			}else
				System.out.println("Record doesnt exists!!");
			tn.commit();
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
	}

	public double total(int cid) {
		System.out.println("in delete");
		Session session =factory.openSession();
		Transaction tn= null;
		double totalprice=0;
		try{
			tn=session.beginTransaction();
			Query q = session.createQuery("select SUM(price) FROM  OrderedItems o where o.cid=?").setString(0, ""+cid);
			totalprice =(double) q.uniqueResult();
		}catch(HibernateException e){
			if(tn!=null)
				tn.rollback();
			e.printStackTrace();
		}
		session.close();
		return totalprice;
	}
	 
	
	
}
