package com.mahendra.models;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;

import com.mahendra.util.HibernateUtil;

public class AppMain {

	public static void main(String[] args) {
		
		SessionFactory factory = HibernateUtil.getFactory();
		
		//Obtain one session 
		Session session = factory.openSession();
		
		Contact c = new Contact();
		c.setName("Pancham");
		
		Transaction tn = null;
		try{
			tn = session.beginTransaction();
		Integer id = (Integer) session.save(c);
		tn.commit();
		System.out.println("New contact #"+id+" was added");
		
		}catch(HibernateException ex){
			if(tn!=null)
				tn.rollback();
			ex.printStackTrace();
		}
		
		session.close();
	}

}
