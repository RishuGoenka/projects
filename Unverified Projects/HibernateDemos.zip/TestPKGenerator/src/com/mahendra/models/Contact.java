package com.mahendra.models;

import java.io.Serializable;

public class Contact implements Serializable {

		private Integer contactId;
		private String name;
		
		public Contact() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Integer getContactId() {
			return contactId;
		}
		public void setContactId(Integer contactId) {
			this.contactId = contactId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
}
