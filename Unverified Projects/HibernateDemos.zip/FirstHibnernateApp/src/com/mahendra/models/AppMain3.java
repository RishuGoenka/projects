package com.mahendra.models;

import java.util.List;

import org.hibernate.*;

import com.mahendra.util.HibernateUtil;

public class AppMain3 {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getFactory();
		Session session = factory.openSession();
		String param = "Mi%";
		List data = session.createQuery
			("select c.firstName, c.lastName from Contact c where c.firstName like ?")
			.setString(0, param).list();
		
		System.out.println(data.size()+" records found");
		for(Object obj: data){
			Object []fields = (Object[])obj;
			System.out.println(fields[0]+" "+fields[1]);
		}
		
		session.close();

	}

}
