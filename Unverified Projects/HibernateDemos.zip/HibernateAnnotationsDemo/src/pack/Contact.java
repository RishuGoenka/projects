package pack;

import java.io.Serializable;

import javax.persistence.*;


@Entity
@Table(name = "contact123")
public class Contact implements Serializable {
	
		//Field Access: Annotations on Declaration
		@Id  @Column(name="contactId")	
		private Integer contactId;
		
		@Column(name="fname",length=25)
		private String firstName;
		
		@Column(name="lname",length=25)
		private String lastName;
		
		@Column(length=12)
		private String phone;
		
		public Contact(Integer contactId, String firstName, String lastName,
				String phone) {
			super();
			this.contactId = contactId;
			this.firstName = firstName;
			this.lastName = lastName;
			this.phone = phone;
		}
		public Contact() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Integer getContactId() {
			return contactId;
		}
		public void setContactId(Integer contactId) {
			this.contactId = contactId;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
}
