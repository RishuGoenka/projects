package pack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class AppMain {

	public static void main(String[] args) {
		SessionFactory factory = HibernateUtil.getFactory();
		
		Session session = factory.openSession();
		
		Contact c = (Contact) session.get(Contact.class, 101);
		System.out.println(c.getLastName());
		session.close();
	}

}
