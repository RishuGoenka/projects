import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		int x = 0,y = 0;
		Scanner scn = new Scanner(System.in);
		try{
		System.out.println("Enter Number X :");
		x = scn.nextInt();  //First No. Input is taken
		System.out.println("Enter Number Y :");
		y = scn.nextInt();	//Second No. Input is taken
		}catch(InputMismatchException| IllegalArgumentException ex)
		{
			System.out.println("Invalid Input Enter Integer");
		}
		scn.close();
		System.out.println("Bits Change : " + Change.bitsChange(x,y)); //Method Call
	}

}
