import java.util.regex.Pattern;

public class Change {

	//Method Returning Number of Bits Need to Change
	//It takes two Argument
	public static int bitsChange(int x, int y) {
		if(Pattern.matches("\\d+", Integer.toString(x)) && Pattern.matches("\\d+", Integer.toString(y)))
		return Integer.bitCount(x ^ y); //The XOR Operation
		else
			return 0;
	}

}
