
public class Blocks {
	
	/**
	 * Group Sum is Calculated and Stored
	 * 
	 * @param arrayN  array Length
	 * @param blockK  group Length
	 * @param separateAR  Array
	 */

	public static void ioOperation(int arrayN, int blockK, String[] separateAR) {
		int array[] = new int[arrayN];
		int totalSum = 0;
		//total Sum is Calculated and array is stored
		for (int i = 0; i < arrayN; i++) {
			array[i] = Integer.parseInt(separateAR[i]);
			totalSum += array[i];
		}
		double blockSum = totalSum / blockK;
		int grpsum[] = new int[blockK];
		int grpCount = 0;
		
		for (int i = 0; i < arrayN; i++) {
			if ((i + 1) < arrayN && grpCount < blockK) {
				if (Math.abs(blockSum - grpsum[grpCount]) > Math.abs(blockSum - grpsum[grpCount]- array[i + 1])) {
					grpsum[grpCount] += array[i];
				} else {
					i--;
					grpCount++;
				}
			} else if (grpCount == blockK - 1 || grpCount == blockK - 2) {
				if (grpCount != blockK - 1)
					grpCount++;
				if (i != arrayN) {
					grpsum[grpCount] += array[i];
				} 
			}
		}
		print(blockK,grpsum);
	}

	/**
	 * Print the Minimized Value.
	 * 
	 * @param blockK Group Number
	 * @param grpsum Group Sum Array
	 */
	private static void print(int blockK, int[] grpsum) {
		int X = 0;
		for (int i = 0; i < blockK; i++)
			if (i != blockK - 1)
				X += Math.pow((grpsum[i] - grpsum[i + 1]), 2);
			else
				X += Math.pow((grpsum[i] - grpsum[0]), 2);
		System.out.println(X);		
	}

}
