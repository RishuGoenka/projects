
public class check {

	public static void implement(int[] caseN, int test) {
		for(int i = 0; i<test ;i++ ){
			int count = 0;
			for(int j = 1;j <= caseN[i] ; j++){
				for(int k = j+1;k <= caseN[i] ; k++){
					if(Integer.parseInt(Integer.toBinaryString(j^k), 2) <= caseN[i]){
						count++;
					}
				}
			}
			System.out.println(count);
		}
		
	}

}
