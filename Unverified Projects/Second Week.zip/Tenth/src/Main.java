import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws NumberFormatException,
			IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		int test = 0;
		try{
			do {
		System.out.println("Enter No of test case");
			test = Integer.parseInt(read.readLine());
		} while (test < 1 && test > 100);
		int[] caseN = new int[test];
		for (int i = 0; i < test;) {
			System.out.println("Enter " + i + " case");
			caseN[i] = Integer.parseInt(read.readLine());
			if (caseN[i] >= 2 && caseN[i] <= 2000)
				i++;
		}
		check.implement(caseN, test);
		}catch(NumberFormatException|NegativeArraySizeException e){
			System.out.println("Invalid Input");
		}
	}

}
