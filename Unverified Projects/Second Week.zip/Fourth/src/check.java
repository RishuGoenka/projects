public class check {

	static int lastind = 1;

	public static void inputOp(String nk, String ar) {
		String[] separate = nk.trim().split(" ");
		try{
			if (Integer.parseInt(separate[1]) >= 1		
				&& Integer.parseInt(separate[1]) <= 106) {
			if (Integer.parseInt(separate[0]) >= 1
					&& Integer.parseInt(separate[0]) <= Integer
							.parseInt(separate[1])) {
				System.out.println(checks.calcPower(ar,
						Integer.parseInt(separate[0])));
			} else
				System.out.printf("Invalid K");
		} else
			System.out.printf("Invalid N");
		}catch (ArrayIndexOutOfBoundsException e){
			System.out.println("Invalid Input");
		}
	}

}
