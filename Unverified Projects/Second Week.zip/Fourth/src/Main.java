import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader read = new BufferedReader(new InputStreamReader(
				System.in));
		System.out.println("Enter space-separated integers K and N.");
		String nk = read.readLine();
		System.out.println("Enter the String");
		String ar = read.readLine();
		if (Pattern.matches("[0-9\\s]+", nk) && Pattern.matches("[a-z]+", ar)) {
			try{
				check.inputOp(nk, ar);
			}catch(StringIndexOutOfBoundsException ex){
				System.out.println("Enter Correct String");
			}
		} else
			System.out.println("Invalid");
	}
}