package com.mahendra;

import java.sql.*;

public class BookDAO {
	private static final String INSERT_QUERY = "insert into books values(?,?,?,?)";

	public void save(int bookId, String title, String author) {
		Connection con = DBUtil.openConnection();
		try {
			PreparedStatement ps = con.prepareStatement(INSERT_QUERY);
			ps.setInt(1, bookId);
			ps.setString(2, title);
			ps.setString(3, author);
			ps.setString(4, "A");

			int n = ps.executeUpdate();

			System.out.println(n + " Record created!");
		} catch (SQLException se) {
			System.out.println("Unable to save new book");
			se.printStackTrace();
		}
		DBUtil.closeConnection(con);
	}
	
	private static final String FIND_BY_ID = "select title from books where book_id = ?";
	public String findTitleById(int id){
		Connection con = DBUtil.openConnection();
		String title = null;
		try {
			PreparedStatement ps = con.prepareStatement(FIND_BY_ID);
			ps.setInt(1, id);
			
			ResultSet rs=ps.executeQuery();
			
			if(rs.next()){
				title = rs.getString(1);
			}
			
			} catch (SQLException se) {
			System.out.println("Unable to find book");
			se.printStackTrace();
		}
		DBUtil.closeConnection(con);
		return title;	
	}
	
	// delete
}
