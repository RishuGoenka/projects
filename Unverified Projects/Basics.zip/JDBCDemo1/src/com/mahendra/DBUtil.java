package com.mahendra;

import java.io.IOException;
import java.sql.*;
import java.util.Properties;
import pack.DemoApp;

public class DBUtil {

	private static Properties loadProperties(String propFile){
		Properties ps = new Properties();
		try {
			ps.load(DemoApp.class.getResourceAsStream(propFile));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("Unable to load db.properties",e);
		}
		return ps;
	}
	/**
	 * Method to obtain new jdbc connection.
	 * @return Reference to Active Connection object 
	 */
	public static Connection openConnection(){
		Properties ps = loadProperties("/db.properties");
		Connection con = null;
		
		//Step1 : Load JDBC Driver
				try {
					Class.forName(ps.getProperty("driver"));
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					throw new RuntimeException("Unable to load JDBC Driver",e);
				}				
				//Step2 : Connect to DB Server
				try{
				con = DriverManager.getConnection
						(ps.getProperty("url"),
								ps.getProperty("user"),
								ps.getProperty("password"));
				
				System.out.println("Connected to "+ con.getMetaData().getDatabaseProductName());
				}catch(SQLException ex){
					throw new RuntimeException("Unable to connect",ex);
				}
		
		return con;
	}
	public static void closeConnection(Connection con){
			try {
				if(con!=null)
					con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new RuntimeException("Unable to close connection",e);
			}
	}
}
