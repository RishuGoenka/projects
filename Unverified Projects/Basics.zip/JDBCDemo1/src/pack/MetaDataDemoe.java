package pack;
import java.sql.*;
import java.util.Scanner;

import com.mahendra.DBUtil;
public class MetaDataDemoe {

	public static void main(String[] args)throws SQLException {
		
		Connection con = null;
		
		String tableName = null;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter name of table to fetch records: ");
		tableName = sc.nextLine();
		
		con = DBUtil.openConnection();
		
		Statement st = con.createStatement();
		
		ResultSet rs = st.executeQuery("select * from "+tableName);
		
		ResultSetMetaData metadata = rs.getMetaData();
		
		int count = metadata.getColumnCount();
		System.out.println("No of Columns: "+count);
		
		for(int i=1;i<=count;i++){
			System.out.println("Column #"+i+" Name: "+metadata.getColumnLabel(i)+ " Type:"+metadata.getColumnTypeName(i));
		}
		
		DBUtil.closeConnection(con);
		
		
	}

}
