package pack;

public class AppMain {

	public static void main(String[] args) {
		
		//Implicit class loading
		//com.mahendra.Person p = new com.mahendra.Person();

		//Manual class loading
		
		try {
			Class.forName(args[0]);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
