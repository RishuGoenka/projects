package pack;

import java.sql.*;

import com.mahendra.DBUtil;

public class DemoTransaction {

	public static void main(String[] args) throws SQLException{
		
		Connection con = DBUtil.openConnection();
		
		con.setAutoCommit(false); //Turn OFF auto-commit : Turn ON Explicit commit
		
		PreparedStatement ps = con.prepareStatement("INSERT into members values(?,?,?,?)");
		ps.setInt(1, 11);
		ps.setString(2, "Barak");
		ps.setString(3, "Obama");
		ps.setString(4, "464654654");
		System.out.println("Running DML Operation");
		ps.executeUpdate();
		con.commit();
		
		//Explicitely rollback??
		/*con.rollback();
		System.out.println("Rolled back!");*/
		DBUtil.closeConnection(con);

	}

}
