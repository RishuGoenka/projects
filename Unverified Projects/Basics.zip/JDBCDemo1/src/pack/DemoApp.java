package pack;

import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class DemoApp {

	public static void main(String[] args) {
		//Step 0 : Load properties
		
		Properties ps = new Properties();
		try {
			ps.load(DemoApp.class.getResourceAsStream("/db.properties"));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return;
		}
		
		//Step1 : Load JDBC Driver
		try {
			Class.forName(ps.getProperty("driver"));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//Step2 : Connect to DB Server
		Connection con = null;
		try{
		con = DriverManager.getConnection
				(ps.getProperty("url"),
						ps.getProperty("user"),
						ps.getProperty("password"));
		
		System.out.println("Connected to "+ con.getMetaData().getDatabaseProductName());
		}catch(SQLException ex){
			ex.printStackTrace();
		}finally{
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		System.out.println("End");
	}

}
