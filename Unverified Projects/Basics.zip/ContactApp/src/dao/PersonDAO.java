package dao;

import java.util.ArrayList;
import java.util.List;

import models.Person;

public class PersonDAO {
	List<Person> personList = null;
	
	public PersonDAO(){
		personList = new ArrayList<Person>();
	}
	
	public PersonDAO(List<Person> existsingList)
	{
		personList = existsingList;
	}
	
	public void add(Person p)
	{
		personList.add(p);
	}
	
	public Person getById(int id){
		for(Person p : personList){
			if(p.getPersonId()==id){
				return p;
			}
		}
		return null;
	}
	
	public List<Person> getAll(){
		return personList;
	}
	
	public void remove(int id){
		Person p = getById(id);
		if(p!=null){
			personList.remove(p);
		}
	}
}
