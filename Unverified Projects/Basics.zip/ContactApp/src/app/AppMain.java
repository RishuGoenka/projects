package app;

public class AppMain {

	public static void main(String[] args) {
		
		String input = "";
		
		AppUI ui = new AppUI();
		
		while(!input.equals("X")){
			
			ui.showMenu();
			
			input = ui.input("Enter your choice");
			
			switch(input.toUpperCase().trim()){
			case "A":
				ui.addPerson();
				break;
			case "L":
				ui.listPerson();
				break;
			case "R":
				ui.removePerson();
				break;
			case "X":
				ui.quit();
			}
			
			
		}
		
		System.out.println("End");
	}

}
