package app;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import dao.PersonDAO;
import models.Person;
import service.LoadPersonList;
import service.WritePersonList;

public class AppUI {
private BufferedReader br = null;
private ExecutorService service = null;
private static final String DATAFILE = "/home/mahendra/person.dat";
private PersonDAO dao = null;

	public AppUI(){
		
		br = new BufferedReader(new InputStreamReader(System.in));
		service = Executors.newFixedThreadPool(2);
		System.out.println("Loading data....");
		LoadPersonList loadList = new LoadPersonList(DATAFILE);
		Future<List<Person>> list = service.submit(loadList);
		System.out.println("Storing all data into list [Memory]");
		try {
			List<Person> temp  = list.get();
			if(temp == null)
				temp = new ArrayList<Person>();
			dao = new PersonDAO(temp);
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void showMenu(){
		System.out.println("Contact book application");
		System.out.println("A \t\t Add new person");
		System.out.println("L \t\t List all person");
		System.out.println("R \t\t Remove a person");
		System.out.println("X \t\t Quit application");
	}
	
	public void addPerson(){
		System.out.println("Adding new person");
		String s = input("Enter person id");
		int personId = Integer.parseInt(s);
		Person p = dao.getById(personId);
		if(p!=null){
			System.out.println("Person ID already exists!");
			return;
		}
		
		String firstName = input("Enter first name");
		String lastName = input("Enter last name");
		String email = input("Enter email");
		
		p = new Person(personId, firstName, lastName, email, null, null);
		dao.add(p);
		System.out.println("Added successfuly!");
	}
	
	public void removePerson(){
		System.out.println("Remove Person: Not yet implemented!");
	}
	
	public void listPerson(){
		System.out.println("List Person");
		
		List<Person> list = dao.getAll();
		
		for(Person p: list){
			System.out.printf("%4d %-20s %-20s %-40s%n",p.getPersonId(), p.getFirstName(), p.getLastName(), p.getEmail());
		}
	}
	
	public void quit(){
		
		System.out.println("Saving changes to data file");
		service.execute(new WritePersonList(dao.getAll(), DATAFILE));
		service.shutdown();
	}
	public String input(String msg){
		System.out.print("\n"+msg +" : ");
		try {
			return br.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}
