package service;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import models.Person;

public class WritePersonList implements Runnable {
private List<Person> personList;
private String dataFile;
	
	public WritePersonList(List<Person> personList, String dataFile) {
	super();
	this.personList = personList;
	this.dataFile = dataFile;
}

	@Override
	public void run() {
			
		try(ObjectOutputStream out 
				= new ObjectOutputStream(
						new FileOutputStream(dataFile)))
		{
			System.out.println("Writing data to file, please wait...");
			out.writeObject(personList);
			out.flush();
			System.out.println("Done writing..!");
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}
