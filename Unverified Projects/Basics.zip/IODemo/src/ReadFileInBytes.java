import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOError;
import java.io.IOException;


public class ReadFileInBytes {

	public static void main(String[] args) {
		
		try{
			
			FileReader fx = new FileReader("/home/mahendra/dummy.txt");
			BufferedReader file = new BufferedReader(fx);
		
			
		//	char[] buffer = new char[100];	//define a buffer of bytes
			
		/*	int len = file.read(buffer);	//Try to read FIRST 100 bytes
			while(len>0){	//Repeat unless there's nothing more to read
				String line = new String (buffer,0,len);
				System.out.println(line);
				
				//read next 100 bytes
				len = file.read(buffer);
			}*/
			
			String line = file.readLine();
			while(line!=null){
				System.out.println(line);
				
				line = file.readLine();
			}
			
			file.close();
			System.out.println("====== \n Done reading file");
			
		}catch(IOException ex){
			
			ex.printStackTrace();
		}
			
	}

}
