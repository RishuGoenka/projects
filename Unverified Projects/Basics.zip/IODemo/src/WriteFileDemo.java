import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;


public class WriteFileDemo {

	public static void main(String[] args) {
		try(PrintStream out = new PrintStream("/home/mahendra/file.txt"))
			
		{
			String line = "The quick brown lion jumps over the lazy cat. ";
			
			out.println(line);
			
			out.flush();
			
			
		}catch(IOException ex){
			ex.printStackTrace();
		}

	}

}
