
public class TestGreeting {

	public static void main(String[] args) {
		
		Greeting greeting = new Greeting();
		greeting.greet("Mahendra");
		
		System.out.println(greeting);
		
		Date d = new Date(180,23,10000);
		/*d.day =180;
		d.month = 23;
		d.year = 10000;
		*/
		
		d.print();
		
		int data[],x;
		int []data2,y;
		
		
		
		

	}

}
