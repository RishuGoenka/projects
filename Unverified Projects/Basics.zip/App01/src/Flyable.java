
public interface Flyable {
	void fly(){
		
		System.out.println("Fly");
	}
}
