

/** A Sample java class
 * 
 * @author Mahendra Shinde
 *
 */
public class Greeting {
	
	
	/**
	 * Method to display greeting message
	 * @param arg Name of Person to greet
	 */
	public void greet(String arg){
		
		System.out.println("Hello "+arg); 
		
	}
}
