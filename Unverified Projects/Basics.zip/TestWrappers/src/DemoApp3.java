
public class DemoApp3 {

	public static void main(String[] args) {
		Canvas can = new Canvas();
		can.drawLine(5);
		can.drawLine(Canvas.DOUBLE_LINE);
		
		CanvasV2 can2 = new CanvasV2();
		can2.drawLine(LineStyle.SINGLE_LINE);
	}

}
