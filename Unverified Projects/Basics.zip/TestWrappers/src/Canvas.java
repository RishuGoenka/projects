
public class Canvas {
	
	//Constants to define line style
	//No type safety, as they are actually INTs
	public static final int SINGLE_LINE = 0;
	public static final int DOUBLE_LINE = 1;
	public static final int STARRED_LINE = 2;
	
	
	public void drawLine(int style){
		
		switch(style){
		case 0:
			System.out.println("----------------------------");
			break;
		case 1:
			System.out.println("============================");
			break;
		case 2:
			System.out.println("****************************");
		break;
			default:
				System.out.println("Wrong style!!");
		}
		
	}
}
