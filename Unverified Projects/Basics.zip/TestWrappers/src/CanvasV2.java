public class CanvasV2 {
	
	public void drawLine(LineStyle style){
		switch(style){
		case SINGLE_LINE:
			System.out.println("----------------------------");
			break;
		case DOUBLE_LINE:
			System.out.println("============================");
			break;
		case STARRED_LINE:
			System.out.println("****************************");
		break;
		
		}
		
	}
}

enum LineStyle{
	SINGLE_LINE, DOUBLE_LINE, STARRED_LINE;
}
