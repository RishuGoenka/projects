
public class DemoApp1 {

	public static void main(String[] args) {
		
		Integer n = Integer.valueOf("100");
		
		int k = n.intValue();
		
		
		k = Integer.parseInt("100");
		//Following statements works for Java Version >= 1.5
		//But fails when compiled with Java version < 1.5
		k = Integer.valueOf("120");
		
		
	}
}
