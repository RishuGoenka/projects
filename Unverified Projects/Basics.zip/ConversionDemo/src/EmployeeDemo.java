import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Date;
import java.util.Locale;


public class EmployeeDemo {

	public static void main(String[] args) {
		
		Employee employee = null;
		
		employee = new Employee("Yash Chopra",
				toDate("4/7/2004") , toDate("8/2/1978") , toFloat("3,50,000"));
		
		System.out.println("Hello "+employee.getName()+" Your Joining was :"
					+ employee.getDateOfJoining() + "And package :"+ employee.getSalary());
	}
	
	
	static Date toDate(String strDate){
		
		try {
			return DateFormat.getDateInstance(DateFormat.SHORT,Locale.UK).parse(strDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	
	static float toFloat(String strSalary){
		
		try {
			return NumberFormat.getNumberInstance().parse(strSalary).floatValue();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		
	}

}
