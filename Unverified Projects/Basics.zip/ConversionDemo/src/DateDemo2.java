import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class DateDemo2 {

	public static void main(String[] args) {
		Date d = new Date();	//Gets current system date
		
		String formattedDate = null;
		
		//try 'getDateTimeInstance' OR 'getTimeInstance'
		DateFormat ft = DateFormat.getDateTimeInstance(DateFormat.FULL,DateFormat.FULL);
		
		formattedDate = ft.format(d);
		
		System.out.println("Today is "+formattedDate);
		
	}

}
