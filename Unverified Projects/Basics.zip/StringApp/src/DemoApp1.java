
public class DemoApp1 {

	public static void main(String[] args) {

			String s1 = "mahendra";
			String s2 = new String("mahendra");
			String s3 = "Mahendra".toLowerCase();
			
			System.out.println("Both s1 & s3 are same "+ (s1==s3));
			System.out.println("Both s1 & s2 are same "+ (s1==s2));
	}

}
