package models;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AccountTransactionTest {
	
	Account a1=null;
	Account a2=null;
	AccountTransaction tn = null;
	
	@Before
	public void setUp() throws Exception {
		
		//Prepare the Pre-Test conditions 
		a1 = new Account(1001,"Salman",1200,new Date());
		a2 = new Account(1002,"Katrina",3512400,new Date());
		tn = new AccountTransaction();	
	}

	@After
	public void tearDown() throws Exception {
		// destroy the Pre-Test conditions
		a1 = null;
		a2 = null;	//Now leave it to garbage collector
		tn =null;
	}

	@Test
	public void testDeposit() {
		
		//Try to deposit 500 Rs in a1
			tn.deposit(a1, 500);
			assertEquals("Problem with deposit!",1700, a1.getBalance(),0.01);
	}

	@Test
	public void testWithdraw() {

		//Try to withdraw 2000 from a1 : expected to return FALSE
			assertFalse(tn.withdraw(a1, 2000));
			
	}

	@Test
	public void testTransfer() {
		
		//Transfer 2000 from a2 to a1
		tn.transfer(a2, a1, 2000);
		
		//Balance of a1 should be now 3200
		assertEquals(3200, a1.getBalance(),0.01);
	
	}

}
