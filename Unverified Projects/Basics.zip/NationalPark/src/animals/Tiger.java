package animals;

public class Tiger {

	public void eat(){
		System.out.println
		("Lunch time for tiger...");
	}
}
