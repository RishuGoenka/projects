package animals;

class Goat {
	public void eat(){
		System.out.println
		("Lunch time for Goat...");
	}
}
