package staff;

import animals.Tiger;

public class CareTaker {
	public void feed(){
		
		Tiger tiger = new Tiger();
		//animals.Goat goat = new animals.Goat();
		
		
		
	}
}
