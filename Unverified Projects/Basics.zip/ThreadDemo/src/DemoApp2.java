import java.util.Date;


public class DemoApp2 {

	public static void main(String[] args) {
		//Common Account object
		Account jointAccount = new Account(10112, "Rajiv Bhatia", 35000, new Date());
		
		
		ATMWithdrawal akshayAtmCard = new ATMWithdrawal(jointAccount, 20000);
		
		ATMWithdrawal twinkleAtmCard = new ATMWithdrawal(jointAccount, 21000);
		
		Thread t1 = new Thread(akshayAtmCard);
		Thread t2 = new Thread(twinkleAtmCard);
		
		t1.start();
		t2.start();
		
		try{
		t1.join();	//Request JVM to run t1 instead [If not DEAD]
		t2.join();	//Request JVM to run t2 instead [If not DEAD]
		}catch(InterruptedException ex){
			ex.printStackTrace();
		}
		//Run this statement only after child thread t1 and t2 are finished/dead
		System.out.println("The balance left is : "+ jointAccount.getBalance());
		
		

	}

}
