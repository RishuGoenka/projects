import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class DemoApp4 {

	public static void main(String[] args) {
		ExecutorService service = Executors.newCachedThreadPool();
		
		//Run a Task get Factorial of a number
		Future<Long> future = service.submit(new FactorialCalculator(12));
	
		future.cancel(true); //You may decide to cancel the task
		
		System.out.println("Waiting for answer...");
		
		try {
				System.out.println("Factorial is "+ future.get());			
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		service.shutdown();
		
	}

}
