

public class AccountTransaction {
	
	public boolean deposit(Account account, double amount){
		account.setBalance( account.getBalance() + amount);
		return true;
	}
	
	public boolean withdraw(Account account, double amount){
		if(account.getBalance() < amount)
			return false;
		
		account.setBalance( account.getBalance() - amount);
		return true;
	}
	
	public boolean transfer(Account from, Account to, double amount){
		//SERIOUS PROBLEM !!!!!!!!
		boolean b1 = deposit(from,amount);
		boolean b2 = withdraw(to,amount);
		if(b1 && b2){
			return true;
		}
		return false;
	}
	
	
}
