
public class DemoApp1 {

	public static void main(String[] args) {
		Thread t1 = new FirstThread();
		t1.start();
		
		//A Task defined by "Runnable" still need a "Worker"
		Thread t2 = new Thread ( new DigitalClock());
		t2.start();
		
		int count = Thread.activeCount();
		
		String name = Thread.currentThread().getName();
		
		System.out.println("There are "+count+" Threads running");
		System.out.println("And, current one is "+ name);
		
	}

}
