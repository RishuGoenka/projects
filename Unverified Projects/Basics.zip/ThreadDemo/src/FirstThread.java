
//Worker responsible to complete/finish given task
public class FirstThread extends Thread {
	
	//Task to be completed
	public void run(){
		
		System.out.println("Some task ....");
		System.out.println("Task started....");
		System.out.println(".....");
		System.out.println("Task finished.!");
		
	}
}
