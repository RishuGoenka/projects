package model;

import java.io.Serializable;
import java.util.Set;

/**
 * Model class for Product, each instance of this class represents
 * Individual product in application. 
 * By Implementing "Serializable", we mark this class as eligible for serialization and de-serialization
 * @author mahendra
 *
 */
public class Product implements Serializable {

	
	/**
	 * Optional Unique ID to validate the Serialization / De-serialization process
	 */
	private static final long serialVersionUID = 876099052566719970L;
	/**
	 * Name of product
	 */
	private String name;
	/**
	 * Brief description about product
	 */
	private String description;
	/**
	 * Price of product in Rupees [Indian rupees]
	 */
	private double price;
	
	public Product(String name, String description, double price) {
		super();
		this.name = name;
		this.description = description;
		this.price = price;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	

}
