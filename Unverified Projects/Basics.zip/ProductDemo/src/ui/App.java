package ui;

import java.io.*;

import data.DataManager;
import data.DataManagerBinary;
import data.IProductDAO;
import model.Product;

public class App {
	public static void main(String arg[])throws IOException{
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter name of product:");
		String name = br.readLine();
		
		System.out.println("Enter description: ");
		String desc = br.readLine();
		
		System.out.println("Enter price: ");
		String t = br.readLine();
		double price = Double.parseDouble(t);
		
		Product p = new Product(name, desc, price);
		
		IProductDAO dm = new DataManagerBinary();
		dm.add(p);
		
		System.out.println("Data written.");
		
		
		Product x = dm.get();
		System.out.println("Product name: "+x.getName());
	}
}
