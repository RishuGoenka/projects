package data;

import java.io.*;
import model.Product;

/**
 * Read/Write product data to a Text File
 * @author mahendra
 *
 */
public class DataManager implements IProductDAO{

	private static final String DATAFILE = "/home/mahendra/products.txt";
	/**
	 * Add given product to datafile
	 * @param p Product tobe written in datafile
	 */
	public void add(Product p){
		try(FileWriter file = new FileWriter(DATAFILE,true)){
			file.write(p.getName()+", "+p.getDescription()+", "+p.getPrice()+"\r\n");
		}catch(IOException ex){
			throw new RuntimeException("Could not save this record",ex);
		}
		
	}
	
	public Product[] getAll(){
		//NOT yet implemented!!!
		return null;
	}

	@Override
	public Product get() {
		// TODO Auto-generated method stub
		return null;
	}
}
