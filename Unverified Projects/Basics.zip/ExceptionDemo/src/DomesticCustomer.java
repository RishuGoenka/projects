
public class DomesticCustomer extends Customer{
	protected String city;

	public DomesticCustomer(int customerId, String firstName, String lastName,
			String city) {
		super(customerId, firstName, lastName);
		this.city = city;
	}
	
	public void print(){
		super.print();
		System.out.println("City: "+city);
	}
}
