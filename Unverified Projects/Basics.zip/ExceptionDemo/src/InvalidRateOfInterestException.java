
public class InvalidRateOfInterestException extends Exception {

	public InvalidRateOfInterestException(String arg0) {
		super(arg0);	
	}
}
