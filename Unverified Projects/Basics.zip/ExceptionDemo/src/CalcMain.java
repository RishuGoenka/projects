
public class CalcMain {

	public static void main(String arg[]){
		
		Calculator calc = new Calculator();
		
		int z = calc.divide(15, 0);
		
		System.out.println("Answer : "+z);
		
	}
}
