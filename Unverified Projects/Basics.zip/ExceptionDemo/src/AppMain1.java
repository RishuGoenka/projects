
public class AppMain1 {

	public static void main(String[] args) {
		Customer c = new DomesticCustomer(101,"Thomas","Paine","Mumbai");
		
		System.out.println(c.hashCode());
		Customer c1 = new DomesticCustomer(102,"Cristopher","Columbus","Mumbai");
		
		System.out.println(c1.hashCode());

		System.out.println("Are they same? "+ (c==c1));
		
		System.out.println("Customer c:"+c);
	}

}
