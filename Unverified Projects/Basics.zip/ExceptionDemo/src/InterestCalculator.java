
public class InterestCalculator {
	
	public double calcInterest(double amt, float rate, int duration)
		throws InvalidRateOfInterestException
	{
		
		if (rate <= 4.0F || rate>=20 )
			throw new InvalidRateOfInterestException("Rate "+rate+ " must be in range 4.01 to 20");
				
		return amt*rate/100/12*duration;
	}
}
