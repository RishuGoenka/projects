
public class Calculator {
	
		public int divide(int n,int m){
			System.out.println("Divide and Answer: ");
			try{
				return n/m;
			}catch(ArithmeticException ex){
				System.out.println("Error");
				return 0;
			}
		}
}
