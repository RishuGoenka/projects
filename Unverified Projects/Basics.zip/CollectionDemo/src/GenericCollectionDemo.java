import java.util.*;

/*
 * Syntax for Generic collections
 * in JDK 1.5,1.6 
 * 	CollectionType < ElementType > varName = new CollectionType < ElementType >()	
 * in JDK 1.7 onwards:
 *  CollectionType < ElementType > varName = new CollectionType < >()
 *  
 * for Maps:
 *  Map < KeyType , ValueType> varName = new HashMap<>()
 */

public class GenericCollectionDemo {

	public static void main(String[] args) {
		
		// 'Collections' in JDK 1.5 onwards using refers to 'Generic Colloections'
		// Provides TYPE-SAFETY, by verifying contents at COMPILE TIME!!!
		List<String> names = new ArrayList<String>();
		
		names.add("Mahendra");
		//names.add(32.3);
		//names.add(false);
		
		Map<String,String> friends = new HashMap<>();
				
	}

}
