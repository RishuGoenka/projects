import java.util.*;


public class ProductCollectionDemo {

	public static void main(String[] args) {
		SortedSet<Product> productCatalog = new TreeSet<>();
		
		productCatalog.add(new Product("Galaxy J7","New J Series phone from Samsung",14000));
		productCatalog.add(new Product("iPhone A7","New J Series Smart phone from Samsung",14000));
		productCatalog.add(new Product("Galaxy A5","New A Series phone from Samsung",24000));
		productCatalog.add(new Product("iPhone 6S","New iPhone from Apple",78000));
		
		for(Product p : productCatalog){
			System.out.println(p.getName()+" "+p.getPrice()+" "+p.getDescription());
		}
		
	}

}
