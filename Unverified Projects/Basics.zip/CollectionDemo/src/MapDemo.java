import java.util.*;


public class MapDemo {

	public static void main(String[] args) {
		Map data = new HashMap();
		
		data.put("MH-04-AD-1234", "Red coloured ferrari");
		data.put("MH-43-A1-2356","A White Honda City");
		data.put("MH-43-A7-4546", "Yellow coloured Ashok Layland truck");
		data.put(new Integer(100), "A Spaceship from Mars");
		
		System.out.println(data.get("MH-04-AD-1234"));
		
		//Retrieve all KEYS from map [In Form of SET]
		Collection keys = data.keySet();
		for(Object k : keys){
			System.out.println(k);
		}
		
		//Retrieve Keys With Values as Set!!
		Set rows = data.entrySet();
		for(Object r : rows){
			System.out.println(r);
		}
		
		
	}

}
