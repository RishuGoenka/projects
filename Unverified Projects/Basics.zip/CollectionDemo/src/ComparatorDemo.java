import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class ComparatorDemo {

	public static void main(String[] args) {
		List<Product> myProducts = new ArrayList<Product>();
		
		myProducts.add(new Product("Micromax A102","Micromax Canvas doodle 3",6500));
		myProducts.add(new Product("HP Notebook","15.3\" notebook from HP",40000));
		myProducts.add(new Product("Samsung Core Prime","Galaxy core prime",9800));
		myProducts.add(new Product("HP Sleekbook b14","14\" notebook from HP",23000));
		
		
		System.out.println("Original list: ");
		print(myProducts);
		
		System.out.println("Sort using Name field");
		Collections.sort(myProducts,new NameComparator());
		print(myProducts);
		
		System.out.println("Sort using Price field");
		Collections.sort(myProducts,new PriceComapartor());
		print(myProducts);
			
	}
	
	static void print(List<Product> pd){
		for(Product p : pd){
			System.out.println(p.getName()+" "+p.getPrice());
		}
	}

}
