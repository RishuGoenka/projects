package com.mahendra.models;

import java.io.Serializable;

public class Contact implements Serializable {

	private Short contactId;
	private String firstName, lastName;
	private String phone;
	
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Contact(Short contactId, String firstName, String lastName,
			String phone) {
		super();
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
	}
	public Short getContactId() {
		return contactId;
	}
	public void setContactId(Short contactId) {
		this.contactId = contactId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
}
