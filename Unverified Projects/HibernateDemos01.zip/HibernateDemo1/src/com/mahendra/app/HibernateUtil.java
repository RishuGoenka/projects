package com.mahendra.app;

import org.hibernate.cfg.Configuration;
import org.hibernate.*;

public class HibernateUtil {

	private static SessionFactory factory = build();

	private static SessionFactory build() {
		// create instance and load "hibernate.cfg.xml
		Configuration config = new Configuration().configure();
		// Obtain session factory
		SessionFactory factory = config.buildSessionFactory();
		return factory;
	}

	public static SessionFactory getFactory() {
		return factory;
	}
}
