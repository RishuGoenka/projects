package com.mahendra.app;

import java.util.List;

import org.hibernate.*;
import com.mahendra.models.Contact;

public class ContactDAO {
	private SessionFactory factory = null;

	public ContactDAO() {
		factory = HibernateUtil.getFactory();
	}

	public void save(Contact c) {
		Session session = factory.openSession();
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			session.save(c);
			tn.commit();
			System.out.println("Record saved!");
		} catch (HibernateException ex) {

			if (tn != null)
				tn.rollback();

			ex.printStackTrace();
		}

		session.close();
	}

	public void modify(Contact c) {
		Session session = factory.openSession();
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			session.update(c);
			tn.commit();
			System.out.println("Record updated");
		} catch (HibernateException ex) {
			if (tn != null)
				tn.rollback();

			ex.printStackTrace();
		}
		session.close();
	}

	public void remove(short contactId) {
		Session session = factory.openSession();
		Transaction tn = null;
		try {
			tn = session.beginTransaction();
			Object c = session.get(Contact.class, contactId);
			if (c != null) {
				session.delete(c);
				System.out.println("Record deleted!");
			} else
				System.out.println("Record doesn't exists!!");
			tn.commit();
		} catch (HibernateException ex) {
			if (tn != null)
				tn.rollback();

			ex.printStackTrace();
		}
		session.close();
	}

	public List<Contact> findByName(String name) {
		Session session = factory.openSession();
		List<Contact> contacts = null;
		contacts = session
				.createQuery(
						"from Contact c where c.firstName = :nm or c.lastName = :nm")
				.setString("nm", name)

				.list();
		session.close();
		return contacts;
	}
}
