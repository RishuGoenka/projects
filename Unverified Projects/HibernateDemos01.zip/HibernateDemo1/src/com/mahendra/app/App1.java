package com.mahendra.app;

import java.util.List;

import com.mahendra.models.Contact;

public class App1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ContactDAO dao = new ContactDAO();
		dao.save(new Contact((short)101,"Abhishek","Bacchan","5464654"));
		dao.save(new Contact((short)102,"Ronit","Roy","654654654"));
		dao.save(new Contact((short)103,"Uday","Chopra","46546554"));
		
		List<Contact> contacts = dao.findByName("Chopra");
		System.out.println("Found "+ contacts.size() +" chopras");
		
		for(Contact c: contacts){
			System.out.println(c.getFirstName()+" "+c.getLastName());
		}
		
		
	}

}
